import { SonnToaster } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { cn } from "@/lib/utils";
import { ThemeProvider } from "next-themes";

const Providers = ({ children }) => {
    return(
        <ThemeProvider attribute="class" enableSystem={false} defaultTheme="light">
            <div className={cn("h-full")}>
                { children }
                <Toaster />
            </div>
            <SonnToaster />
        </ThemeProvider>
    );
};

export default Providers;