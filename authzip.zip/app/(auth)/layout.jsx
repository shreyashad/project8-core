"use client";
import Image from "next/image"
import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link";

export default function AuthLayout({ children, title }) {
    const [mounted, setMounted] = useState(false)
    return(
        <div className="w-full lg:grid lg:min-h-auto  xl:min-h-auto">
          <div className="supports-backdrp-blur:bg-background/60 fixed left-0 right-0 top-0 z-20 border-b bg-background/95 bg-blue-600 backdrop-blur text-white">
          <nav className="flex h-20 items-center justify-between px-4">
                <div className="flex items-center gap-4">
                    <Link href="#" className="hidden items-center justify-between gap-2 bg-white p-2 rounded md:flex">
                        <Image
                            src= "/mdi_logo1.png"
                            width={50} 
                            height={50}
                            alt="Mdindia logo" 
                            priority 
                        />
                    </Link>
                    <div className="flex flex-col">
                        <span className="font-bold text-indigo">MDIndia Health Insurance TPA Pvt. Ltd.</span>
                        <p><span className="text-indigo text-sm">IRDAI Licence No. 005</span></p>
                        <span className="text-indigo text-sm">Valid till 20/03/2026</span>
                    </div>
                </div>
              </nav>
            </div>
          {children}
          </div>
         
    )
}