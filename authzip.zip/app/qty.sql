

	-- Add the parameters for the stored procedure here
	
	declare @FromDate Date

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	-- Insert statements for procedure here
	DROP TABLE IF EXISTS #VCM;
DROP TABLE IF EXISTS #Inw;
DROP TABLE IF EXISTS #TblCM1;
DROP TABLE IF EXISTS #Pol_no;
DROP TABLE IF EXISTS #Enr1;
DROP TABLE IF EXISTS #CN;
DROP TABLE IF EXISTS #tbldeddmp;
DROP TABLE IF EXISTS #tblded;
DROP TABLE IF EXISTS #ADR;
DROP TABLE IF EXISTS #getCL;
DROP TABLE IF EXISTS #getCM;

DROP TABLE IF EXISTS AllIC_Settled_Cases_Of_QTY_Updated

Declare @FromDt datetime
Declare @FromDtt datetime
Declare @ToDt datetime

set @FromDt =@FromDate--'2019-04-01' ---conert(date,getdate()- (case when isnull(DATENAME(weekday,getdate()),'')='Monday' then 2 else 1 end),111) 
set @FromDtt=@FromDt

select * into #VCM from (
	Select Pol_no,mdid,CCNNumber,LodgeType,Effect_Date,CRSDate as UTR_CRS_dt,P_Status,PaidAmt from CCNMASTER WHERE ISNULL(P_STATUS,'') IN ('CRS','DAL') AND  CRSDATE>=@FromDtt union all 
	Select Pol_no,mdid,CCNNumber,LodgeType,Effect_Date,closure,P_Status,PaidAmt from CCNMASTER WHERE ISNULL(LODGETYPE,'') = 'CI RECEIVED' AND ISNULL(CLOSURE,'')>=@FromDtt union all
	Select Pol_no,mdid,CCNNumber,LodgeType,Effect_Date,prs_date,P_Status,PaidAmt from ccnmaster where 
	ISNULL(P_STATUS,'') IN ('SETTLED','PAID') AND ISNULL(PAIDAMT,0)=0  AND ISNULL(PRS_DATE,'')>=@FromDtt union all 
	select Pol_no,mdid,CCN,Lodgetype,LodgeDate,UTR_UpdateDate,'Claim Paid',ChequeAmt from PRS 
where ISNULL(UTR_UpdateDate,'')>=@FromDtt and isnull(dd_date,'')<>'' and isnull(DDNumber,'')<>''
) as A


Create Table AllIC_Settled_Cases_Of_QTY_Updated
(
[ICName]   varchar(150),
[Pol_Type]   varchar(30),
[PolicyStartDate]   smalldatetime,
[PolicyEndDate]   smalldatetime,
[InsuredName]   varchar(1000),
[POL_NO]   varchar(100),
[MDID]   varchar(100),
[CCN]   varchar(50),
[ipname]   varchar(1000),
[Hosp_Name]   varchar(3000),
[Hosp_City]   varchar(1000),
[DOA]   smalldatetime,
[DOD]   smalldatetime,
[Lodgeamt]   money,
[LodgeDate]   smalldatetime,
[LodgeType]   varchar(100),
[ActualLossType]   varchar(100),
[DedAmt]   money,
[Dis_Amt]   money,
[SettledAmt]   money,
[DD No.]   varchar(30),
[DD Date]   smalldatetime,
[Head]   varchar(250),
[Gen_Date]   datetime,
[Room_Paid_Amt]   money,
[Room_Bill_Amt]   money,
[Nursing_Paid_Amt]   money,
[Nursing_Bill_Amt]   money,
[ICU_Paid_Amt]   money,
[ICU_Bill_Amt]   money,
[Surgeon_Fees_Paid_Amt]   money,
[Surgeon_Fees_Bill_Amt]   money,
[Asst_Surgeon_Paid_Amt]   money,
[Asst_Surgeon_Bill_Amt]   money,
[Visit_Charges_Paid_Amt]   money,
[Visit_Charges_Bill_Amt]   money,
[Consultant_Paid_Amt]   money,
[Consultant_Bill_Amt]   money,
[Other_PROFESSIONAL_FEES_Paid_Amt]   money,
[Other_PROFESSIONAL_FEES_Bill_Amt]   money,
[Pharmacy_Paid_Amt]   money,
[Pharmacy_Bill_Amt]   money,
[Implants_Paid_Amt]   money,
[Implants_Bill_Amt]   money,
[Stent_Paid_Amt]   money,
[Stent_Bill_Amt]   money,
[MEDICAL_CONSUMABLES_Other_Than_Phaymacy_Paid_Amt]   money,
[MEDICAL_CONSUMABLES_Other_Than_Phaymacy_Bill_Amt]   money,
[INVESTIGATION_Paid_Amt]   money,
[INVESTIGATION_Bill_Amt]   money,
[Other_Paid_Amt]   money,
[Other_Bill_Amt]   money,
[Provider_Code]   varchar(200),
[Hospital_status]   varchar(100),
[Treatment_type]   varchar(5000),
[ICd_Code]   varchar(50),
[Secondary_treatment]   varchar(5000),
[Primary_diagnosis]   varchar(5000),
[UTR_CRS_UpdateDate]   datetime,
[Corp_Retail]   varchar(9),
[PSU_PVT]   varchar(3),
[Br_CD_DOR]   smalldatetime,
[HO_CD_DOR]   smalldatetime,
[Last_Document_Received]   smalldatetime,
[InwDt]   datetime,
[GMC_Category]   varchar(50),
[CPS_Date]   smalldatetime,
[PRS_Date]   smalldatetime,
[Repudiation / Closure Reason]   varchar(8000),
[Pre_policy]   varchar(50),
[Relation]   varchar(50),
[AGE]   numeric(5),
[SEX]   varchar(50),
[IPD_OPD]   varchar(50),
[Pdig]   varchar(550),
[InvDone]   varchar(10),
[Inv_Remark]   varchar(4000),
[Opinion]   varchar(250),
[Co_Payment_Percenrage]   nvarchar(12),
[Co_Payment_Amt]   money,
[BSI]   money,
[BSI_After]   money,
[PCSProcedure_1]   varchar(550),
[PCSProcedure_2]   varchar(550),
[First_Intimation_Date]   smalldatetime,
[CBAmt]   money,
[ADR_Send_Date]   smalldatetime,
[ADR_Recd_Date]   smalldatetime,
[File_Closure_Dates]   smalldatetime,
[Float_Generation_Date]   smalldatetime,
[Buffer_Amt]   money,
[IFD_Investigation_RaiseDate]   smalldatetime,
[IFD_Branch_VisitDate]   varchar(50),
[IFD_HO_RecivedDate]   smalldatetime,
[IP_SUMINSURED]   money,
[strRepudationReason]   varchar(500),
[Hospital_Pin]   varchar(50),
[Group_Name]   varchar(1000),
[Broker_Name]   varchar(1000),
[Broker_Code]   varchar(250),
[REVISED_SERVICING_BRANCH]   varchar(250),
[RAL LodgeDate]   smalldatetime,
[CI Lodge Date]   smalldatetime,
[AL Issued Date]   smalldatetime,
[RAL Lodge Amt]   money,
[AL Issued Amt]   money,
[First AL Issued Date]   smalldatetime,
[CI Lodge Amt]   money,
[TXT_ABHA_NO]   varchar(250)
)
INSERT INTO AllIC_Settled_Cases_Of_QTY_Updated ( Pol_no,mdid,CCN,LodgeType,LodgeDate,UTR_CRS_UpdateDate)
SELECT Pol_no,mdid,CCNNumber, LodgeType,Effect_Date,UTR_CRS_dt   FROM  #VCM 

Create nonclustered Index Ix_QTY on AllIC_Settled_Cases_Of_QTY_Updated (Pol_no asc,MDID asc,CCN asc,LodgeType asc,LodgeDate asc)


select distinct CCN into #CN from AllIC_Settled_Cases_Of_QTY_Updated
Create nonclustered Index Ix_CCNno on #CN (CCN asc)

SELECT * into  #tbldeddmp FROM (
Select CCN,lodgetype,lodgedate,Remarks,Amount FROM Deductions WHERE CCN in (select  CCN from #CN) and (Remarks Like '%Co-Pay%') UNION ALL
Select CCN,lodgetype,lodgedate,Remarks,Amount FROM Deductions WHERE CCN in (select  CCN from #CN) and (Remarks Like '%Co - Pay%') UNION ALL
Select CCN,lodgetype,lodgedate,Remarks,Amount FROM Deductions WHERE CCN in (select  CCN from #CN) and (Remarks Like '%Co Pay%') UNION ALL
Select CCN,lodgetype,lodgedate,Remarks,Amount FROM Deductions WHERE CCN in (select  CCN from #CN) and (Remarks Like '%Co -Pay%') UNION ALL
Select CCN,lodgetype,lodgedate,Remarks,Amount FROM Deductions WHERE CCN in (select  CCN from #CN) and (Remarks Like '%Co- Pay%') 
) AS A

Select CCN,lodgetype,lodgedate,Remarks, Isnull(Case When Substring(Remarks,charindex('%',Remarks,0)-1,1)='' then 
Substring(Remarks,charindex('%',Remarks,0)-3,3) else Substring(Remarks,charindex('%',Remarks,0)-2,2) end,0) As Co_Payment_Percentage, Amount 
INTO #tblded from deductions where CCN in (select  CCN from #CN)--drop table #tblded


select CCN,LODGETYPE,LODGEDATE,DATEOFRECEIPT,FILECLOSER,Reminder,SAVEDATE,
	
	case when isnull(case when isnull(FILECLOSER,'')<=Reminder then Reminder else FILECLOSER end,'')<=DATEOFRECEIPT then DATEOFRECEIPT
	else case when isnull(FILECLOSER,'')<=Reminder then Reminder else FILECLOSER end end as MxLDR
	into #ADR
	 from (
	
	SELECT  CCN,LODGETYPE,LODGEDATE,MIN(SAVEDATE) AS SAVEDATE,
		MAX(DATEOFRECEIPT) AS DATEOFRECEIPT,MAX(FILECLOSER) AS FILECLOSER,MAX(Reminder) AS Reminder
		FROM 
		(
	
	SELECT CCN,LODGETYPE,LODGEDATE,SAVEDATE,DATEOFRECEIPT,Reminder,FILECLOSER from  DBO.ADR_UO where CCN in (select  CCN from #CN)
		UNION ALL  SELECT CCN,LODGETYPE,LODGEDATE,SAVEDATE,DATEOFRECEIPT,Reminder,FILECLOSER from  DBO.ADR_HOSP where CCN in (select  CCN from #CN)
		UNION ALL  SELECT CCN,LODGETYPE,LODGEDATE,SAVEDATE,DATEOFRECEIPT,Reminder,FILECLOSER from  DBO.ADR_PAT where CCN in (select  CCN from #CN)
		) as A
		group by CCN,LODGETYPE,LODGEDATE
		) as B



select InwardNo,EntryDate into #Inw from OnlineClaimProcess.dbo.Branch_inw_tran where InwardNo in (select claimsinwardnumber 
from CCNMaster where CCNnumber in (select CCN from #CN)) 

select claimsinwardnumber,(select top 1 EntryDate from #Inw where InwardNo = CCNMAster.claimsinwardnumber) 
as InwDt, ccnnumber,Lodgetype,effect_date into #TblCM1 from ccnmaster where claimsinwardnumber in (select InwardNo from #Inw)


Update AllIC_Settled_Cases_Of_QTY_Updated with (rowlock) set 
	Co_Payment_Amt = isnull((select top 1 Amount from #tblded where CCN = A.ccn and LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),0),
	Co_Payment_Percenrage = isnull((select top 1 Co_Payment_Percentage from #tblded where CCN = A.ccn and LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),0)
From AllIC_Settled_Cases_Of_QTY_Updated as A


UPDATE AllIC_Settled_Cases_Of_QTY_Updated with (rowlock) SET 
	First_Intimation_Date  = dbo.Get_First_Intimation_Date(A.CCN) 
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A

Select CCNNUMBER,LODGEDATE,IC_NAME,Pol_Type,POL_ST_DATE,POL_END_DATE,INS_NAME,IP_NAME,HOSP_NAME,HOSP_CITY,CD_DOA,CD_DOD,PRE_POL_NO,Relation,IP_AGE,PROVIDER_CODE,IP_SUMINSURED,CORPORATE_POLICY,
	TYPE_TREAT,SEC_TREAT,PRI_DIGNO,Br_CD_DOR,CD_DOR,IP_CB_AMT,SEC_DIGNO,LodgeType,CD_LODGE_AMT,IP_SEX
	INTO #getCL
from claimlodge WHERE CCNnumber in (select CCN from #CN) --DROP TABLE #getCL

	Create nonclustered Index Ix_CL on #getCL (CCNnumber asc,LodgeType asc,LodgeDate asc)

Update AllIC_Settled_Cases_Of_QTY_Updated with (rowlock) set 
[ICName] =(select TOP 1 IC_NAME from #getCL WHERE CCNNUMBER = A.CCN),
[Pol_Type] =(select TOP 1 Pol_Type  from #getCL WHERE CCNNUMBER = A.CCN),
[PolicyStartDate] =(select TOP 1 POL_ST_DATE  from #getCL WHERE CCNNUMBER = A.CCN),
[PolicyEndDate] =(select TOP 1 POL_END_DATE  from #getCL WHERE CCNNUMBER = A.CCN),
[InsuredName] =(select TOP 1 INS_NAME  from #getCL WHERE CCNNUMBER = A.CCN),
[ipname] =(select TOP 1 IP_NAME  from #getCL WHERE CCNNUMBER = A.CCN),
[Hosp_Name] =(select TOP 1 HOSP_NAME  from #getCL WHERE CCNNUMBER = A.CCN),
[Hosp_City] =(select TOP 1 HOSP_CITY  from #getCL WHERE CCNNUMBER = A.CCN),
[DOA] =(select TOP 1 CD_DOA  from #getCL WHERE CCNNUMBER = A.CCN),
[DOD] =(select TOP 1 CD_DOD  from #getCL WHERE CCNNUMBER = A.CCN),
[PRE_POLICY] = (SELECT TOP 1 PRE_POL_NO FROM #getCL WHERE CCNNUMBER = A.CCN AND PRE_POL_NO>'0'),
[Relation] =(select TOP 1 Relation  from #getCL WHERE CCNNUMBER = A.CCN),
[AGE] =(select TOP 1 IP_AGE  from #getCL WHERE CCNNUMBER = A.CCN),
[SEX] =(select TOP 1 IP_SEX  from #getCL WHERE CCNNUMBER = A.CCN),
[Provider_Code] =(select TOP 1 PROVIDER_CODE  from #getCL WHERE CCNNUMBER = A.CCN),
[IP_SUMINSURED] = (select TOP 1 IP_SUMINSURED  from #getCL WHERE pol_no = A.pol_no and mdid = A.MDID and IP_SUMINSURED>0),
[Corp_Retail] = case when isnull((select TOP 1 CORPORATE_POLICY  from #getCL WHERE CCNNUMBER = A.CCN),'') in ('Group','CORPORATE') 
then 'Corporate' else 'Retail' end
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A

select CCNnumber,Lodgetype,effect_date,INVDONE,INV_REMARK,OPINION,CPS_Date,PRS_Date,Alamt,LodgeAmt into #getCM 
from ccnmaster Where CCNnumber in (select CCN from #CN)

CREATE NONclustered Index Ix_CM on #getCM (ccnnumber asc, Lodgetype asc,Effect_date asc)

---CCNMaster
Update AllIC_Settled_Cases_Of_QTY_Updated with (rowlock) set 
	INVDONE = B.INVDONE,	
	INV_REMARK = B.INV_REMARK,	
	OPINION = B.OPINION,	
	CPS_Date = B.CPS_Date,
	PRS_Date = B.PRS_Date
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A
LEFT JOIN 
#getCM AS B ON 
A.CCN = B.CCNNUMBER AND 
A.LODGETYPE = B.LODGETYPE AND 
A.LODGEDATE = B.EFFECT_DATE 

Update AllIC_Settled_Cases_Of_QTY_Updated set 
[ActualLossType] =DBO.fncActualGetLodgeTypeNew(A.CCN)
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A

---PRS
UPDATE AllIC_Settled_Cases_Of_QTY_Updated Set
[DedAmt] = ISNULL(Ded_Amt,0), 
[Dis_Amt] = ISNULL(B.Dis_Amt,0),
[SettledAmt] = ISNULL(ChequeAmt,0),
[DD No.] = DDNumber,
[DD Date] = DD_Date,
[Gen_Date] = GETDATE(),
Float_Generation_Date = Float_Gen_Date
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A
LEFT JOIN 
PRS AS B ON 
A.CCN = B.CCN AND 
A.LODGETYPE = B.LODGETYPE AND 
A.LODGEDATE = B.LODGEDATE 

Update AllIC_Settled_Cases_Of_QTY_Updated set
	 BSI = B.BSI
	,BSI_After = B.BSI_After 
From AllIC_Settled_Cases_Of_QTY_Updated as A
LEFT JOIN 
(
Select CCN,LodgeType,LodgeDate,BSI,BSI_After from CPPS 
	Where CCN in (select CCN from #CN)
) AS B ON 
A.CCN = B.CCN AND 
A.LODGETYPE = B.LODGETYPE AND 
A.LODGEDATE = B.LODGEDATE

Update AllIC_Settled_Cases_Of_QTY_Updated set
 	PCSProcedure_1 = B.PCSProcedure_1 
	,PCSProcedure_2 = B.PCSProcedure_2 
From AllIC_Settled_Cases_Of_QTY_Updated as A
LEFT JOIN 
(
select CCNnumber,LodgeType,Lodgedate,PCSProcedure_1,PCSProcedure_2 from DBO.PCSCode_Core where CCNnumber in (select  CCN from #CN)
) AS B ON 
A.CCN = B.CCNnumber AND 
A.LODGETYPE = B.LODGETYPE AND 
A.LODGEDATE = B.LODGEDATE

Update AllIC_Settled_Cases_Of_QTY_Updated set
[Room_Paid_Amt] =B.[Room_Paid_Amt],
[Room_Bill_Amt] =B.[Room_Bill_Amt],
[Nursing_Paid_Amt] = B.[Nursing_Paid_Amt],
[Nursing_Bill_Amt] = B.[Nursing_Bill_Amt],
[ICU_Paid_Amt] = B.[ICU_Paid_Amt],
[ICU_Bill_Amt] = B.[ICU_Bill_Amt],
[Surgeon_Fees_Paid_Amt] =B.[Surgeon_Fees_Paid_Amt],
[Surgeon_Fees_Bill_Amt]= B.[Surgeon_Fees_Bill_Amt],
[Asst_Surgeon_Paid_Amt]=B.[Asst_Surgeon_Paid_Amt],
[Asst_Surgeon_Bill_Amt]=B.[Asst_Surgeon_Bill_Amt],
[Visit_Charges_Paid_Amt] = B.[Visit_Charges_Paid_Amt],
[Visit_Charges_Bill_Amt] = B.[Visit_Charges_Bill_Amt],
[Consultant_Paid_Amt] =B.[Consultant_Paid_Amt],
[Consultant_Bill_Amt] =B.[Consultant_Bill_Amt],
[Other_PROFESSIONAL_FEES_Paid_Amt] =B.[Other_PROFESSIONAL_FEES_Paid_Amt],
[Other_PROFESSIONAL_FEES_Bill_Amt] = B.[Other_PROFESSIONAL_FEES_Bill_Amt],
[Pharmacy_Paid_Amt] =B.[Pharmacy_Paid_Amt],
[Pharmacy_Bill_Amt] =B.[Pharmacy_Bill_Amt],
[Implants_Paid_Amt] =B.[Implants_Paid_Amt],
[Implants_Bill_Amt] =B.[Implants_Bill_Amt],
[Stent_Paid_Amt] = B.[Stent_Paid_Amt],
[Stent_Bill_Amt] =B.[Stent_Bill_Amt],
[MEDICAL_CONSUMABLES_Other_Than_Phaymacy_Paid_Amt] =B.[MEDICAL_CONSUMABLES_Other_Than_Phaymacy_Paid_Amt],
[MEDICAL_CONSUMABLES_Other_Than_Phaymacy_Bill_Amt] = B.[MEDICAL_CONSUMABLES_Other_Than_Phaymacy_Bill_Amt],
[INVESTIGATION_Paid_Amt] =B.[INVESTIGATION_Paid_Amt],
[INVESTIGATION_Bill_Amt] =B.[INVESTIGATION_Bill_Amt],
[Other_Paid_Amt] =B.[Other_Paid_Amt],
[Other_Bill_Amt] =B.[Other_Bill_Amt]
--[MIS_Previous_Paid] =NULL,
--[BackDatedPaid] =NULL
	FROM AllIC_Settled_Cases_Of_QTY_Updated AS A
left join 
	claims_Master.dbo.ALL_IC_PAID_DUMP as B on
A.CCN = B.CCN AND 
A.LODGETYPE = B.LODGETYPE AND 
A.LODGEDATE = B.LODGEDATE

---Claimlodge
UPDATE AllIC_Settled_Cases_Of_QTY_Updated Set
[Treatment_type] = TYPE_TREAT
,[ICd_Code] = B.ICD_CODE
,[Secondary_treatment] = SEC_TREAT
,[Primary_diagnosis] = PRI_DIGNO
,[Br_CD_DOR] = B.Br_CD_DOR
,[HO_CD_DOR] = CD_DOR
,IPD_OPD = CASE WHEN ISNULL (TYPE_TREAT,'') IN ('OPD','DENTAL') THEN 'OPD' ELSE 'IPD' END
,CBAmt = IP_CB_AMT 
,PDIG = CASE WHEN ISNULL(PRI_DIGNO,'')='' THEN SEC_DIGNO ELSE PRI_DIGNO END 
,[Lodgeamt]= case when isnull(A.LodgeType,'')='RAL Lodged' then (Select sum(TotalAmt) from RAL with(nolock) where CCNNumber = A.CCN)
else CD_LODGE_AMT  end
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A
LEFT JOIN 
claimlodge AS B ON  
A.CCN = B.CCNNUMBER AND 
A.LODGETYPE = B.LODGETYPE AND 
A.LODGEDATE = B.LODGEDATE 


--Select ccn,Lodgetype,LodgeDate,Reasons from CRS where 

Update AllIC_Settled_Cases_Of_QTY_Updated Set 
Head = case when isnull([DD No.],'')<>'' and isnull([DD Date],'')<>'' then 'PAID'
	WHEN isnull(LodgeType,'') ='CI Received' then 'Claim Intimation Closed'
    When isnull(LodgeType,'') in ('RAL LODGED','RAL ISSUED') And  
	(isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%ADDITIONAL PAYMENT CLOSE & LODGE%' Or  
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS LODGED ON WRONG INSURED PERSON%' Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS LODGED ON WRONG POLICY%' Or  
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS THE INSURED PERSON HAS EXHAUSTED HIS APPLICABLE SUM INSURED%' Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS THE INSURED PERSON HAS EXHAUSTED HIS SUM INSURED%' Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS THE INSURED PERSON HAS EXHAUSTED HIS/HER SUM INSURED%' Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%BSI EXHAUSTED%' Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%CAN BE LODGED  AS ADDITIONAL%'Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%CASHLESS FACILITY NOT UTILISED BY PATIENT%' Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%CLAIM IS CLOSED%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%CLAIMCLOSED%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%DOUBLE LODGED%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%EXHAUSTED HIS/HER ILLNESS SUM INSURED%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%FILE CLOSED%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGE ON WRONG MDID%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGE WRONG%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGED AS ADDITIONAL%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGED AS FRESH CLAIM%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGED ON WRONG HOSPITAL%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGED ON WRONG POLICY%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%NON TPA POLICY%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%NOT AVAILED CASHLESS FACILITY%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%NOT UTILIZED CASHLESS FACILITY%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%POLICY IS CANCELLED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%POLICY IS NOT IN SERVICE PERIOD%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%POLICY NOT IN SERVICE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%POLICY STATUS CANCELLED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WITHDRAWN BY INSURED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WITHDRAWN BY THE INSURED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WROLG LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG  LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG ADDITIONAL PAYMENT LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG DEDUCTION PAYMENT LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG INSURED PERSON%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG LDOGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG LOADGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG LOGED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONGE LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONGLODGED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONGLY DOUBLE LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONGLY LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%THE CLAIM DOCUMENTS ARE NOT SUBMITTED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%STANDS CANCELLED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%THE CLAIM IS CLOSED, AS REQUISITE DOCUMENTS DOES NOT PROVIDED IN SPITE OF%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%THE CLAIM IS REPUDIATED, AS THE CLAIM DOCUMENT REQUESTED NOT SUBMITTED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AND REASON : WE ARE IN RECEIPT OF INCOMPLETE ADR REPLY%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%FILE CLOSE AS DATA ENTRY ERROR%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%FILE CLOSED AS DATA ENTRY ERROR%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG LODGED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%DATA ENTRY ERROR%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AND REASON : CLAIM SETTLED AT ZERO AMOUNT AS ON %'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AL CANCELLED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AND REASON : QUERY REPLY IS NOT RECEIVED HENCE FILE IS CLOSED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AL CLOSED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS CLAIM DOCUMENT ARE NOT PROVIDED IN SPIT OF REMINDER AND NOTICE.%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%ADDITIONAL PAYMENT CLOSE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%DEDUCTION PAYMENT CLOSE%'  Or 
	isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%IT SHOULD BE LODGED  AS ADDITIONAL%' )
         then 'Cash less Closure'
         when isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%ADDITIONAL PAYMENT CLOSE & LODGE%' Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS LODGED ON WRONG INSURED PERSON%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS LODGED ON WRONG POLICY%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS THE INSURED PERSON HAS EXHAUSTED HIS APPLICABLE SUM INSURED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS THE INSURED PERSON HAS EXHAUSTED HIS SUM INSURED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS THE INSURED PERSON HAS EXHAUSTED HIS/HER SUM INSURED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%BSI EXHAUSTED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%CAN BE LODGED  AS ADDITIONAL%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%CASHLESS FACILITY NOT UTILISED BY PATIENT%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%CLAIM IS CLOSED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%CLAIMCLOSED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%DOUBLE LODGED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%EXHAUSTED HIS/HER ILLNESS SUM INSURED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%FILE CLOSED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGE ON WRONG MDID%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGE WRONG%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGED AS ADDITIONAL%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGED AS FRESH CLAIM%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGED ON WRONG HOSPITAL%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGED ON WRONG POLICY%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%NON TPA POLICY%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%NOT AVAILED CASHLESS FACILITY%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%NOT UTILIZED CASHLESS FACILITY%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%POLICY IS CANCELLED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%POLICY IS NOT IN SERVICE PERIOD%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%POLICY NOT IN SERVICE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%POLICY STATUS CANCELLED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WITHDRAWN BY INSURED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WITHDRAWN BY THE INSURED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WROLG LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG  LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG ADDITIONAL PAYMENT LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG DEDUCTION PAYMENT LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG INSURED PERSON%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG LDOGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG LOADGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG LOGED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONGE LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONGLODGED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONGLY DOUBLE LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONGLY LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%THE CLAIM DOCUMENTS ARE NOT SUBMITTED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%STANDS CANCELLED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%THE CLAIM IS CLOSED, AS REQUISITE DOCUMENTS DOES NOT PROVIDED IN SPITE OF%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%THE CLAIM IS REPUDIATED, AS THE CLAIM DOCUMENT REQUESTED NOT SUBMITTED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AND REASON : WE ARE IN RECEIPT OF INCOMPLETE ADR REPLY%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%FILE CLOSE AS DATA ENTRY ERROR%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%FILE CLOSED AS DATA ENTRY ERROR%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONG LODGED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%DATA ENTRY ERROR%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AND REASON : CLAIM SETTLED AT ZERO AMOUNT AS ON %'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AL CANCELLED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AND REASON : QUERY REPLY IS NOT RECEIVED HENCE FILE IS CLOSED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AL CLOSED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS CLAIM DOCUMENT ARE NOT PROVIDED IN SPIT OF REMINDER AND NOTICE.%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%ADDITIONAL PAYMENT CLOSE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%DEDUCTION PAYMENT CLOSE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%IT SHOULD BE LODGED  AS ADDITIONAL%'  Or
            isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%AS LODGED ON WRONG%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%DOUBLE LODGED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGED AS%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%LODGE AS%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%CLAIM CLOSED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WITHDRAWN BY THE INSURED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONGLY LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%ALREADY PAID%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%ALREADY SETTLED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WRONGLY LODGE%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%EXHAUSTED HIS SUM INSURED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%CLAIM IS CLOSED%'  Or isnull((select top 1 Reasons from CRS  as TCRS where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'') like '%WROG LODGE%'
         then 'Claim Closed'
          when isnull(LodgeType,'') in ('RAL LODGED','RAL ISSUED') Then 'Cash less Denial'
       else 'Claim Repudiation'end 
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A

Update AllIC_Settled_Cases_Of_QTY_Updated set Provider_Code = B.Provider_Code
from AllIC_Settled_Cases_Of_QTY_Updated as A,claims_Master.dbo.empanell as B
where A.Hosp_Name = B.Hospital  and 
A.Hosp_City = B.City
and (isnull(A.Provider_Code,'')='' and  isnull(A.Provider_Code,0) = '0')

Update AllIC_Settled_Cases_Of_QTY_Updated set [Hospital_status] = 
  Case 
     When isnull(IsNetHosp,'')='Y' and isnull(EmpanelledFor_NIA,0)=1  then 'Network'
	 ELSE 'Non Network' End,
Hospital_Pin = B.Pin_No  
from AllIC_Settled_Cases_Of_QTY_Updated as A 
LEFT JOIN
 claims_Master.dbo.empanell  AS B ON 
 A.Provider_code = B.Provider_code

Update AllIC_Settled_Cases_Of_QTY_Updated set 
[Last_Document_Received] = 
Case when isnull((select Max(MxLDR) from #ADR where CCN = A.CCN and LodgeType = A.LodgeType and LodgeDate = A.LodgeDate),'')='' then A.LodgeDate else 
(select Max(MxLDR) from #ADR  where CCN = A.CCN and LodgeType = A.LodgeType and LodgeDate = A.LodgeDate) end
,ADR_Send_Date = SAVEDATE
,ADR_Recd_Date = DATEOFRECEIPT
,File_Closure_Dates = FILECLOSER
from AllIC_Settled_Cases_Of_QTY_Updated as A
LEFT JOIN 
#ADR AS B ON  
A.CCN = B.CCN AND 
A.LODGETYPE = B.LODGETYPE AND 
A.LODGEDATE = B.LODGEDATE 

Update AllIC_Settled_Cases_Of_QTY_Updated set
[PSU_PVT] = case when isnull(A.ICName,'') in ('United India Insurance Company Limited','The Oriental Insurance Company Ltd','The New India Assurance Company Limited','National Insurance Company Limited')
then 'PSU'ELSE 'PVT' END 
from AllIC_Settled_Cases_Of_QTY_Updated as A 

Update AllIC_Settled_Cases_Of_QTY_Updated set
strRepudationReason = B.strRepudationReason
from AllIC_Settled_Cases_Of_QTY_Updated as A 
left join 
CRS as B on 
A.CCN = B.CCN AND 
A.LODGETYPE = B.LODGETYPE AND 
A.LODGEDATE = B.LODGEDATE 

select * into #Corp from [MDICENTRALENROL].[Enrollment].dbo.[CorporatePolicyDetails_Web]

 update AllIC_Settled_Cases_Of_QTY_Updated set Group_Name = B.Group_Name
 from AllIC_Settled_Cases_Of_QTY_Updated as A, #Corp as B
 where A.pol_no = B.pol_no

  update AllIC_Settled_Cases_Of_QTY_Updated set Broker_Name = B.Broker_Name
 from AllIC_Settled_Cases_Of_QTY_Updated as A, #Corp as B
 where A.pol_no = B.pol_no

update AllIC_Settled_Cases_Of_QTY_Updated set Broker_Code = B.Broker_Code
 from AllIC_Settled_Cases_Of_QTY_Updated as A, #Corp as B
 where A.pol_no = B.pol_no


UPDATE AllIC_Settled_Cases_Of_QTY_Updated SET strRepudationReason = 'Denial'
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A
WHERE 
isnull(Head,'') ='Cash less Denial'

UPDATE AllIC_Settled_Cases_Of_QTY_Updated SET strRepudationReason = 'Intimation Closed'
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A
WHERE 
isnull(Head,'') ='Claim Intimation Closed'

UPDATE AllIC_Settled_Cases_Of_QTY_Updated SET strRepudationReason = 'Claim Repudiation'
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A
WHERE 
Head ='Claim Repudiation' and (strRepudationReason is null and isnull(strRepudationReason,'')='') and
	[DD No.] is null and [DD Date] is null

UPDATE AllIC_Settled_Cases_Of_QTY_Updated SET
[RAL LodgeDate]	= (select MIN(RAL_DOR) from RAL WHERE CCNNUMBER = A.CCN AND A.LODGETYPE IN ('RAL Lodged','RAL Issued','Cash Less')),

[AL Issued Date] = (select MAx(AL_DOD) from AL WHERE CCNNUMBER = A.CCN AND A.LODGETYPE IN ('Cash Less')),
[RAL Lodge Amt] = (select top 1 TotalAmt from RAL WHERE CCNNUMBER = A.CCN and RALNo =1 AND A.LODGETYPE IN ('RAL Lodged','RAL Issued','Cash Less')),
[AL Issued Amt] = (select Top 1 Alamt from CCNMAster WHERE CCNNUMBER = A.CCN AND A.LODGETYPE IN ('Cash Less')),
[First AL Issued Date] =(select min(AL_DOD) from AL WHERE CCNNUMBER = A.CCN AND A.LODGETYPE IN ('Cash Less'))
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A


UPDATE AllIC_Settled_Cases_Of_QTY_Updated SET
	[CI Lodge Date] = (select MIN(effect_date) from CCNMASTER WHERE CCNNUMBER = A.CCN AND LODGETYPE IN ('CI Received')),
	[CI Lodge Amt] = (select MIN(LodgeAmt) from CCNMASTER WHERE CCNNUMBER = A.CCN AND LODGETYPE IN ('CI Received'))
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A
Where A.LODGETYPE IN ('CI Received','Non Cash Less')


Update AllIC_Settled_Cases_Of_QTY_Updated set
[InwDt] =(select top 1 InwDt from #TblCM1 where CCNnumber = A.CCN and LodgeType = A.LodgeType and Effect_date = A.LodgeDate)
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A

Update AllIC_Settled_Cases_Of_QTY_Updated set [Repudiation / Closure Reason] = 
      Case  when LodgeType IN ('RAL Lodged','RAL Issued')  then +'Mediclaim| Claim Repudiated Date : '+convert(varchar,A.UTR_CRS_UpdateDate,103)+ '
	  and reason : '+ (select TOP 1 DALReason from DAL where CCNNumber = CAST(replace(A.CCN,'MDI','')AS int)) 
      when lodgetype in ('Deductions Payment','Additional Payment','Reconsideration','Health Checkup','Non Cash Less','Cash Less') and
      (select top 1 P_Status from #VCM where CCNnumber = A.CCN and LodgeType = A.LodgeType and Effect_date = A.LodgeDate)
	  in ('Paid','Settled','Under PRS') 
	  then +'Mediclaim| Claim Repudiated Date :'+convert(varchar,UTR_CRS_UpdateDate,103)+ ' and reason : '+ 'Claim settled at zero amount as on  '+convert(varchar,UTR_CRS_UpdateDate,103)
	  When isnull(LodgeType,'') ='CI Received' then +'Mediclaim| Claim Repudiated Date :'+convert(varchar,UTR_CRS_UpdateDate,103)+ ' and reason : '+ 'The Claim intimation is closed on  '+convert(varchar,UTR_CRS_UpdateDate,103)+'as claim document are not provided in spit of reminder and notice.'
      else  +'Mediclaim| Claim Repudiated Date :'+convert(varchar,UTR_CRS_UpdateDate,103)+ ' and reason : '+ (select top 1 Reasons from CRS  where CCN = A.CCN AND LodgeType = A.LodgeType and LodgeDate = A.LodgeDate) 
      end 
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A

DELETE FROM AllIC_Settled_Cases_Of_QTY_Updated
where ISNULL(pol_no,'')='' and isnull(ICName,'')='' and isnull(CCN,'')=''
--------------------------------------Provider_code-------------------------------------------------------
DROP TABLE IF EXISTS #CN1;
DROP TABLE IF EXISTS #P1;
Select distinct CCN INTO #CN1 from AllIC_Settled_Cases_Of_QTY_Updated Where ISNULL(Provider_Code,'')=''
select Provider_code,CCNNUMBER INTO #P1 from claimlodge where ccnNUMBER IN (SELECT CCN FROM #CN1) AND ISNULL(Provider_code,'')<>''
UPDATE AllIC_Settled_Cases_Of_QTY_Updated SET Provider_Code = B.Provider_code
from AllIC_Settled_Cases_Of_QTY_Updated as A , #P1 as B
where 
A.CCN = B.CCNnumber
and  (isnull(A.Provider_code,'')=''  or  A.Provider_code is null)

--------------------------------------ICDCode-------------------------------------------------------
DROP TABLE IF EXISTS #CN2;
DROP TABLE IF EXISTS #P2;
Select DISTINCT CCN INTO #CN2 from AllIC_Settled_Cases_Of_QTY_Updated Where (ISNULL(ICd_Code,'')='' OR ICd_Code IS NULL)
SELECT CCNNUMBER,ICD_CODE INTO #P2 FROM CLAIMLODGE WHERE CCNNUMBER IN (SELECT CCN FROM #CN2) AND ISNULL(ICD_CODE,'')<>''
UPDATE AllIC_Settled_Cases_Of_QTY_Updated SET ICd_Code = B.ICd_Code
from AllIC_Settled_Cases_Of_QTY_Updated as A , #P2 as B
where 
A.CCN = B.CCNnumber
and  (isnull(A.ICD_CODE,'')=''  or  A.ICD_CODE is null)
-----------------------------------------Inwdt-------------------------------------------------------

drop table if exists #Inw1;
drop table if exists #CN3;
drop table if exists #CMget1;
drop table if exists #CM4;
DROP TABLE IF EXISTS #CL1;
Select  CCN,lODGETYPE,InwDt into #CN3  from AllIC_Settled_Cases_Of_QTY_Updated Where (ISNULL(InwDt,'')='' OR InwDt IS NULL) 
select CCnnumber,Lodgetype,effect_date,claimsinwardnumber into #CMget1 from ccnmaster where ccnnumber in (select CCN from #CN3)

select InwardNo,EntryDate into #Inw1  from OnlineClaimProcess.dbo.Branch_inw_tran where InwardNo in (select claimsinwardnumber 
from #CMget1)

select claimsinwardnumber,(select top 1 EntryDate from #Inw1 where InwardNo = CCNMAster.claimsinwardnumber) 
as InwDt, ccnnumber,Lodgetype,effect_date into #CM4  from ccnmaster  Where  ccnnumber in (select CCN from #CN3)

Update AllIC_Settled_Cases_Of_QTY_Updated set InwDt = (
select top 1 InwDt from #CM4 where Lodgetype in ('Non Cash Less','Cash Less') and CCNnumber = A.CCN)
from AllIC_Settled_Cases_Of_QTY_Updated as A 
where isnull(A.Lodgetype,'') ='Additional Payment' and (isnull(A.InwDt,'')='' or A.InwDt is null)

SELECT CCNNUMBER,LODGETYPE,LODGEDATE,TYPE_TREAT,Br_CD_DOR INTO #CL1 FROM CLAIMLODGE 
	WHERE ccnnumber in (select CCN from #CN3) AND ISNULL(TYPE_TREAT,'') ='OPD'

UPDATE AllIC_Settled_Cases_Of_QTY_Updated SET InwDt = b.Br_CD_DOR
FROM AllIC_Settled_Cases_Of_QTY_Updated AS A , #CL1 AS B
WHERE A.CCN = B.CCNNumber AND 
A.LodgeType = B.LodgeType AND 
A.LodgeDate = B.LodgeDate AND 
(isnull(A.InwDt,'')='' or A.InwDt is null) AND A.CCN IN (SELECT CCNNUMBER FROM #CL1)

SELECT POL_NO,GMC_Category  into #GMcat FROM [MDICENTRALENROL].[ENROLLMENT].DBO.[eNROLLMENT_mASTER] WHERE IC_NAME='Aditya Birla Health Insurance Company'
and GMC_Category ='PSU'

UPDATE AllIC_Settled_Cases_Of_QTY_Updated SET GMC_Category = 'PSU'
where pol_no in (select pol_no from #GMcat)

drop table  if exists #prePol;
drop table  if exists #prePoldet;

Select distinct POL_NO into #prePol from AllIC_Settled_Cases_Of_QTY_Updated where Pre_policy is null
SELECT POL_NO,pre_pol_no  into #prePoldet FROM [MDICENTRALENROL].[ENROLLMENT].DBO.[eNROLLMENT_mASTER] where pre_pol_no>'0' 
and pol_no in (select POL_NO from #prePol)

Update AllIC_Settled_Cases_Of_QTY_Updated set Pre_policy = (select top 1 pre_pol_no from #prePoldet where pol_no = A.pol_no)
from AllIC_Settled_Cases_Of_QTY_Updated as A
where Pre_policy is null



--SELECT IC_NAME, * FROM CCNMASTER