USE [Claims_SLA]
GO
/****** Object:  StoredProcedure [dbo].[AllICSettled]    Script Date: 07/12/2024 9:22:42 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/****** Script for SelectTopNRows command from SSMS  ******/
ALTER procedure [dbo].[AllICSettled]
as begin

/*Update Age_band Using Age column on daily bais */
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET AGE_BAND = CASE WHEN AGE<=10 THEN '00-10'
					WHEN AGE>=11 and AGE<=20 THEN '11-20'
					WHEN AGE>=21 and AGE<=30 THEN '21-30'
					WHEN AGE>=31 and AGE<=40 THEN '31-40'
					WHEN AGE>=41 and AGE<=50 THEN '41-50'
					WHEN AGE>=51 and AGE<=60 THEN '51-60'
					WHEN AGE>=61 and AGE<=70 THEN '61-70'
				    WHEN AGE>=71 and AGE<=80 THEN '71-80'
                ELSE 'Above 80' END
                WHERE AGE_BAND is null AND  AGE IS NOT NULL
				and  CAST(UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date));


/*Update CCN_LT Using CCN and LodgeType column on daily bais */
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET CCN_LT = CONCAT(CCN,'-',(LodgeType))
WHERE CCN_LT IS NULL
and CAST(UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date));


/*Update IS_RECONSIDERED_CONCA_REF where Head is paid and CCN with LodgeType Reconsideration on daily bais */
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET IS_RECONSIDERED_CONCA_REF = CASE
WHEN Head <> 'Paid' THEN CONCAT(CCN,'-Reconsideration')
ELSE NULL END
WHERE IS_RECONSIDERED_CONCA_REF IS NULL
and CAST(UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date));


/*Insert CCN_LT from Qty and Out table for Updating IS_IT_RECONSIDERED */
IF OBJECT_ID('tempdb..#CCN_LT') IS NOT NULL
BEGIN
    DROP TABLE #CCN_LT;
END

SELECT CCN_LT INTO #CCN_LT
FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]  with(nolock)
union
SELECT CCN_LT
FROM Claims_SLA.[dbo].[AllICDailyOutstanding]  with(nolock)


UPDATE C
SET C.IS_IT_RECONSIDERED = 
    CASE
        WHEN CLT.CCN_LT IS NOT NULL THEN 'YES'
        ELSE 'NO'
    END
FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] C  WITH (ROWLOCK)
 JOIN #CCN_LT CLT
    ON C.IS_RECONSIDERED_CONCA_REF = CLT.CCN_LT
WHERE C.Head <> 'Paid'
  AND (C.IS_RECONSIDERED_CONCA_REF IS NULL OR CLT.CCN_LT IS NOT NULL)



IF OBJECT_ID('tempdb..#CCN') IS NOT NULL
BEGIN
    DROP TABLE #CCN;
END
CREATE TABLE #CCN (
    CCN VARCHAR(50) )
CREATE INDEX IX_CCN ON #CCN(CCN);

INSERT INTO #CCN (CCN)


SELECT CCN
FROM (
    SELECT CCN
    FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] WITH (NOLOCK) 
    WHERE LodgeType IN ('CI Received', 'RAL Lodged')

    UNION ALL

    SELECT CCN
    FROM Claims_SLA.[dbo].[AllICDailyOutstanding] WITH (NOLOCK) 
    WHERE [Lodge Type] IN ('CI Received', 'RAL Lodged')
) AS Combined
GROUP BY CCN;




IF OBJECT_ID('tempdb..#CCN1') IS NOT NULL
BEGIN
    DROP TABLE #CCN1;
END

CREATE TABLE #CCN1 (
    CCN VARCHAR(50) )
CREATE INDEX IX_CCN1 ON #CCN1(CCN);

INSERT INTO #CCN1 (CCN)


SELECT CCN
FROM (
SELECT C.CCN 
FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]  as c  with(nolock) 
join #CCN as #CCN 
on c.ccn = #CCN.ccn
where LodgeType='Non cashless' or LodgeType ='Non Cash Less'
and C.CCN in (select ccn from #CCN)

UNION ALL

SELECT D.CCN
    FROM Claims_SLA.[dbo].[AllICDailyOutstanding] as D WITH (NOLOCK) 
	join #CCN as #CCN 
on D.ccn = #CCN.ccn
where [Lodge Type]='Non cashless' or [Lodge Type] ='Non Cash Less'
and D.CCN in (select ccn from #CCN)
)AS Combined
GROUP BY CCN;


UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET CONSIDER_COUNT =  
				CASE 
                WHEN LodgeType IN ( 'Additional Payment' , 'Deductions Payment') THEN 0
                ELSE 1 
              END
  			  where  CAST(UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date))
			  and head='Paid';
;

UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET CONSIDER_COUNT =  
	    	CASE
       WHEN IS_IT_RECONSIDERED = 'YES' THEN 0
          ELSE 
            CASE
             WHEN LodgeType IN ('Additional Payment', 'Deductions Payment' )  THEN 0
			 WHEN LodgeType IN ('CI Received' ,'RAL Lodged') then case when ccn in (select CCN from #CCN1 ) then 0 else 1 end 			
             ELSE 1 
            END
       END 
	   where head<>'Paid';




UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET Actual_Lodge_Consider = case when lodgetype<>'Deductions Payment' then 1 else 0 end
where CAST(UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date))
and head='Paid';


UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET Actual_Lodge_Consider = 
case 
 when IS_IT_RECONSIDERED ='Yes' or lodgetype='Deductions Payment' then 0 
 else 
 case 
  WHEN LodgeType IN ('CI Received' ,'RAL Lodged') then 
   case 
    when ccn in (select CCN from #CCN1 ) then 0 else 1 end 
 else 1
 end
end
where head<>'Paid';


UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET Treatment_type =
case when Treatment_type IN ('Auyrvedic','Ayurveda','Ayurvedic','Ayrvedic') then 'Ayurvedic'
     when Treatment_type IN('Cinservative','Conservative','conserative') then 'Conservative'
	 when Treatment_type IN('Denture','Dental') then 'Dental'
	 when Treatment_type IN('Health Checkup','Health Check up') then 'Health Check up'
	 when Treatment_type IN('Home Care Treatment','home care') Then 'home care' 
	 else Treatment_type end
	 where CAST(UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date));


UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
set lodge_lodgeamt= concat(CCN,LodgeType,Lodgeamt)
where lodge_lodgeamt is null;


UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
set lodge_dedamt= concat(CCN,'Deductions Payment',DedAmt)
where lodge_dedamt is null;



 UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
 Set Actual_lodge_amt = Case when Actual_Lodge_Consider=0 then 0 else 
 case when Lodgeamt > BSI   then BSI else Lodgeamt end 
  end
where Actual_lodge_amt is null ;

--IF OBJECT_ID('tempdb..#Std_Disease_Category') IS NOT NULL
--BEGIN
--    DROP TABLE #Std_Disease_Category;
--END
--CREATE TABLE #Std_Disease_Category (Std_Disease_Category nVARCHAR(255),ICd_Code nvarchar(255))

--INSERT INTO #Std_Disease_Category(Std_Disease_Category,ICd_Code)
--SELECT d.[Disease Category],d.[ICD Codes]
--from  [Claims_SLA].[dbo].DiseaseCategories as d  with(nolock)


--UPDATE qty
--SET qty.[Std_Disease_Category] =std.Std_Disease_Category
--from  Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]  as qty  WITH (ROWLOCK)
--inner join #Std_Disease_Category as std
--on left(qty.ICd_Code,CHARINDEX('.',qty.ICd_Code+'.')-1)=std.ICd_Code
--where qty.[Std_Disease_Category] is null;
----and CAST(qty.UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date));



UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]  
SET [Std_Disease_Category] = 
Case 
when Left(ltrim(rtrim([ICd_Code])),3) in ('I10','I11') and [TotalClaimAmt] < 40000 then 'Conservative Rx of HTN'
when Left(ltrim(rtrim([ICd_Code])),3) in ('I20','I21','I22','I23','I24','I25') and [TotalClaimAmt] < 40000 then 'OTHER'                      
when Left(ltrim(rtrim([ICd_Code])),3) in ('I10','I11','I20','I21','I22','I23','I24','I25') and [TotalClaimAmt] >= 40000 
and [TotalClaimAmt] < 80000 then 'Conservative Rx of MI'
when Left(ltrim(rtrim([ICd_Code])),3) in ('I10','I11','I20','I21','I22','I23','I24','I25') and [TotalClaimAmt] >= 80000 
and [TotalClaimAmt] < 150000 then 'Angioplasty'                                                                                                      
when Left(ltrim(rtrim([ICd_Code])),3) in ('I10','I11','I16','I20','I21','I22','I23','I24','I25') and [TotalClaimAmt] >= 150000  and [Treatment_type] ='Surgical' then 'CABG'
when Left(ltrim(rtrim([ICd_Code])),3) in ('M00','M13','M14','M15','M17','M23','M84','M90','M26','M1A','M04') and [Treatment_type] ='Surgical' then 'TKR'
when Left(ltrim(rtrim([ICd_Code])),3) in ('I44','I45','I46','I47','I48','I49','I50','I51') and [Treatment_type] = 'Conservative' then 'Arrythmia Treatment Medical'
when Left(ltrim(rtrim([ICd_Code])),3) in ('I44','I45','I46','I47','I48','I49','I50','I51') and [Treatment_type] = 'Surgical' then 'Arrythmia Treatment Pacemaker'
when Left(ltrim(rtrim([ICd_Code])),3) in ('M43','M44','M45','M46','M47','M48','M49','M50','M51') and [Treatment_type] = 'Surgical' then 'Spinal Surgery'
when Left(ltrim(rtrim([ICd_Code])),3) in ('M43','M44','M45','M46','M47','M48','M49','M50','M51') and [Treatment_type] = 'Conservative' then 'Medical Mgt of Backache'
when Left(ltrim(rtrim([ICd_Code])),3) = 'K80' and [Treatment_type] = 'Surgical' then 'Cholecystectomy'
when Left(ltrim(rtrim([ICd_Code])),2) = 'M6' and [Treatment_type] = 'Conservative' then 'Arthritis Medical Mgt'
when Left(ltrim(rtrim([ICd_Code])),3) = 'M13' and [Treatment_type] = 'Conservative' then 'Arthritis Medical Mgt'
when Left(ltrim(rtrim([ICd_Code])),1) = ('J') then 'LRTI Mgt'
when PCSProcedure_1 ='Angiography procedure' then 'Angiography procedure'
when PCSProcedure_1 ='Angiography procedure' then 'TKR'
when PCSProcedure_1 ='Bilateral Total Knee Replacement' then 'TKR'
when PCSProcedure_1 in ('Chemotherapy Parentral','Chemotherapy Oral','Chemotherapy -Immunotherapy- Monoclonal Antibody','Chemotherapy -Immunotherapy- Monoclona','Chemotherapy -Immunotherapy- Monoclonal','Chemotherapy ParentralChemotherapy -Immunotherapy- Monoclonal','Chemotherapy','Chemotherapy- Immunotherapy- Monoclonal Antibody','Chemotherapy -Immunotherapy- Monoclonal Antibody + Iv Antiboitics','Chemotherapy -Immunotherapy- Monoclonal Antibod','Chemotherapy -Immunotherapy- Monoclonal Antibody + Chemotherapy Oral','Chemotherapy -Immunotherapy- Monoclonal Antibody + Chemotherapy Parentral','Chemotherapy -Immunotherapy','Chemotherapy Oral + Chemotherapy Parentral','Chemotherapy Oral + Hormonal Therapy','Chemotherapy Parentra','CHEMOPORT REMOVAL') then 'Chemotherapy'
when PCSProcedure_1 in ('Bilateral IOL with Phaco','Right Eye Cataract','Left Eye Cataract','Cataract Extraction','Intravetreal Inj.Avastin/Lucentis + Right Eye Cataract','Eye Cataract','Right  Eye Cataract','Right Eye Catarac','Right Eye Cataract +') then 'Cataract'
when PCSProcedure_1 ='Spinal Surgery' then 'Spinal Surgery'else
NULL end
where [Std_Disease_Category] IS NULL


create table #t2 ([Disease Category] nvarchar(255) null,
[ICD Codes]nvarchar(255) null)

CREATE INDEX idx_t2_ICDCodes ON #t2 ([ICD Codes]);

insert into #t2([Disease Category],[ICD Codes])
select D.[Disease Category], D.[ICD Codes]
from [dbo].[DiseaseCategories]  as D with (nolock)
join  Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] as qty  WITH (ROWLOCK)
on D.[ICD Codes]= left(qty.[ICd_Code],3)
where  qty.[Std_Disease_Category] IS NULL  


UPDATE   qty 
SET [Std_Disease_Category] = t2.[Disease Category]
from Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] as qty WITH (ROWLOCK)
join #t2 as t2
on t2.[ICD Codes]= left(qty.[ICd_Code],3)
where  qty.[Std_Disease_Category] IS NULL



UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET [Std_Disease_Category] = PCSProcedure_1
where(PCSProcedure_1=Secondary_treatment or isnull(Secondary_treatment,'')='')
AND [Std_Disease_Category] IS NULL


UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET [Std_Disease_Category] =D.Group_Desc
from [Masters].dbo.[ICD_Master] as D with (nolock)
join Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]   qty
on left(D.ICD10_Code,3)= left(qty.[ICd_Code],3)
where qty.[Std_Disease_Category] IS NULL
 


UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET [Std_Disease_Category] = Secondary_treatment
where [Std_Disease_Category] IS NULL




UPDATE B
SET B.REVISED_SERVICING_BRANCH =  CASE WHEN B.REVISED_SERVICING_BRANCH IS NULL THEN 
                CASE WHEN A.Servicing_Branch LIKE 'MDINDIA HEALTHCARE SERVICES PVT LTD -%' 
                    THEN SUBSTRING(UPPER(TRIM(A.Servicing_Branch)), LEN('MDINDIA HEALTHCARE SERVICES PVT LTD -') + 1, LEN(TRIM(A.Servicing_Branch)))
                    ELSE UPPER(TRIM(A.Servicing_Branch)) END
            ELSE TRIM(A.Servicing_Branch) 
        END
FROM  [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_Qty] B WITH (ROWLOCK)
JOIN  Enrollment.DBO.Enrollment_Master A WITH (ROWLOCK)
ON   A.Pol_No = B.POL_NO
WHERE  B.REVISED_SERVICING_BRANCH IS NULL 
    AND CAST(B.UTR_CRS_UpdateDate AS DATE) = DATEADD(DAY, -1, CAST(GETDATE() AS DATE));


--UPDATE [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_Qty]
--SET REVISED_SERVICING_BRANCH = trim(REVISED_SERVICING_BRANCH)
--WHERE CAST(UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date));



--IF OBJECT_ID('tempdb..#lodge_lodgeamt') IS NOT NULL
--BEGIN
--    DROP TABLE #lodge_lodgeamt;
--END
--CREATE TABLE #lodge_lodgeamt (lodge_lodgeamt VARCHAR(MAX))

--INSERT INTO #lodge_lodgeamt
--SELECT lodge_lodgeamt FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]  with(nolock)





--UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] 
--SET Actual_deduction = case when ccn IN (select CCN from #ccn2) then 
--(Lodgeamt/COUNT(CCN) OVER(PARTITION BY Lodge_LodgeAmt )  )-
--(SUM(SettledAmt)  OVER(PARTITION BY Lodge_LodgeAmt )/COUNT(CCN) OVER(PARTITION BY Lodge_LodgeAmt ) )  
--else  DedAmt end 
-- from [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_QTY] 

--IF OBJECT_ID('tempdb..#ccn2') IS NOT NULL
--DROP TABLE #ccn2;

--select CCN into #ccn2 from Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]   with(nolock)
--where
-- CAST(UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date))
--and head='paid'
--and [LodgeType]='Deductions Payment';



--if Object_id('tempdb..#temptable10') is not null
--begin
--drop table #temptable10
--end

--create table #temptable10(
--ccn varchar(50) null,
--[DeductionsRepeat] int null,
--[DeductionspaidAmt] Money null
--)
--insert into #temptable10 (ccn,[DeductionsRepeat],[DeductionspaidAmt])
--select ccn,
--COUNT(CCN) OVER(PARTITION BY Lodge_LodgeAmt),
--SUM(SettledAmt)  OVER(PARTITION BY Lodge_LodgeAmt )
--from [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_QTY] with(nolock)
--where CAST(UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date))




--UPDATE [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_QTY]
--SET Actual_deduction =case when qty.ccn IN (SELECT CCN FROM #ccn2) then 
--(Lodgeamt/t.DeductionsRepeat  )-(t.[DeductionspaidAmt]/t.DeductionsRepeat )  else  DedAmt end 
--from [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_QTY] as qty with(nolock)
--join #temptable10 as t
--on qty.ccn =t.ccn;



--UPDATE  [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_Qty] 
--SET REVISED_SERVICING_BRANCH = A.Servicing_Branch FROM Enrollment.DBO.Enrollment_Master A  WITH (ROWLOCK)
--JOIN [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_Qty] B WITH (ROWLOCK)
--ON A.Pol_No = B.POL_NO
--where REVISED_SERVICING_BRANCH is null and
--CAST(UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date))





--UPDATE [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_Qty]
--SET REVISED_SERVICING_BRANCH =
--CASE 
--    WHEN trim([REVISED_SERVICING_BRANCH]) LIKE 'MDINDIA HEALTHCARE SERVICES PVT LTD -%' 
--    THEN SUBSTRING(UPPER(trim([REVISED_SERVICING_BRANCH])), LEN('MDINDIA HEALTHCARE SERVICES PVT LTD -') + 1, LEN(trim([REVISED_SERVICING_BRANCH])))
--    ELSE UPPER(trim([REVISED_SERVICING_BRANCH]))
--  END
--  where CAST(UTR_CRS_UpdateDate AS date) = DATEADD(DAY, -1, CAST(GETDATE() AS date))







with cte as(

select *, ROW_NUMBER() OVER(PARTITION BY  CCN,LODGETYPE,LODGEAMT,LODGEDATE,utr_crs_Updatedate,Head,settledAmt ORDER BY CCN) as rn 
         from [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_Qty]  with(nolock)
		 )

 DELETE from cte where rn > 1;



end

