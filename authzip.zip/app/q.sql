DECLARE @TargetDate DATE = DATEADD(DAY, -1, CAST(GETDATE() AS DATE));

/* Update AGE_BAND Using AGE column on daily basis */
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET AGE_BAND = CASE 
    WHEN AGE <= 10 THEN '00-10'
    WHEN AGE BETWEEN 11 AND 20 THEN '11-20'
    WHEN AGE BETWEEN 21 AND 30 THEN '21-30'
    WHEN AGE BETWEEN 31 AND 40 THEN '31-40'
    WHEN AGE BETWEEN 41 AND 50 THEN '41-50'
    WHEN AGE BETWEEN 51 AND 60 THEN '51-60'
    WHEN AGE BETWEEN 61 AND 70 THEN '61-70'
    WHEN AGE BETWEEN 71 AND 80 THEN '71-80'
    ELSE 'Above 80'
END
WHERE AGE_BAND IS NULL 
  AND AGE IS NOT NULL
  AND CAST(UTR_CRS_UpdateDate AS DATE) = @TargetDate;





-- Create NonClustered Index for CCN_LodgeType (only if needed)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_CCN_LodgeType' AND object_id = OBJECT_ID('Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]'))
BEGIN
    CREATE NONCLUSTERED INDEX IX_CCN_LodgeType 
    ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty](CCN, LodgeType);
END

/* Update CCN_LT Using CCN and LodgeType column on daily basis */
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET CCN_LT = CONCAT(CCN, '-', LodgeType)
WHERE CCN_LT IS NULL
  AND CAST(UTR_CRS_UpdateDate AS DATE) = @TargetDate;




-- Create NonClustered Index for Head and CCN (if needed)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Head_CCN' AND object_id = OBJECT_ID('Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]'))
BEGIN
    CREATE NONCLUSTERED INDEX IX_Head_CCN 
    ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty](Head, CCN);
END

/* Update IS_RECONSIDERED_CONCA_REF where Head is paid and CCN with LodgeType Reconsideration on daily basis */
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET IS_RECONSIDERED_CONCA_REF = CASE
    WHEN Head <> 'Paid' THEN CONCAT(CCN, '-Reconsideration')
    ELSE NULL 
END
WHERE IS_RECONSIDERED_CONCA_REF IS NULL
  AND CAST(UTR_CRS_UpdateDate AS DATE) = @TargetDate;




/*Update IS_IT_RECONSIDERED for head is not equal to Paid */

-- Temporary table to hold CCN_LT values from AllIC_Settled_Cases_Of_Qty and AllICDailyOutstanding
IF OBJECT_ID('tempdb..#CCN_LT') IS NOT NULL DROP TABLE #CCN_LT;

CREATE TABLE #CCN_LT (CCN_LT NVARCHAR(MAX));

-- Insert data into #CCN_LT (use SELECT UNION for combined results)
INSERT INTO #CCN_LT (CCN_LT)
SELECT CCN_LT
FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] WITH (NOLOCK)
UNION
SELECT CCN_LT
FROM Claims_SLA.[dbo].[AllICDailyOutstanding] WITH (NOLOCK);

-- Index on #CCN_LT for faster lookups
CREATE NONCLUSTERED INDEX IX_CCN_LT ON #CCN_LT(CCN_LT);

-- Create NonClustered Index for performance on IS_RECONSIDERED_CONCA_REF and CCN_LT
CREATE NONCLUSTERED INDEX IDX_AllIC_Settled_LodgeType_CCN_Reconsidered
ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (LodgeType, IS_RECONSIDERED_CONCA_REF)
INCLUDE (CCN);

-- Declare batch size for incremental updates
DECLARE @BatchSize INT = 1000;

-- Update in batches (optimized using WHERE conditions and direct filtering)
WHILE 1 = 1
BEGIN
    UPDATE TOP (@BatchSize) C
    SET C.IS_IT_RECONSIDERED = 
        CASE
            WHEN CLT.CCN_LT IS NOT NULL THEN 'YES'
            ELSE 'NO'
        END
    FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] C
    JOIN #CCN_LT CLT
        ON C.IS_RECONSIDERED_CONCA_REF = CLT.CCN_LT
    WHERE C.Head <> 'Paid'
      AND (C.IS_RECONSIDERED_CONCA_REF IS NULL OR CLT.CCN_LT IS NOT NULL);

    -- Exit loop if no rows were updated
    IF @@ROWCOUNT = 0 BREAK;
END

-- Clean up the temporary table
DROP TABLE #CCN_LT;


-- Drop the temporary table if it exists
IF OBJECT_ID('tempdb..#CCN') IS NOT NULL
BEGIN
    DROP TABLE #CCN;
END

-- Create the temporary table with an index
CREATE TABLE #CCN (
    CCN VARCHAR(50)
);
CREATE INDEX IX_CCN ON #CCN(CCN);

-- Insert distinct CCNs from both tables
INSERT INTO #CCN (CCN)
SELECT DISTINCT CCN
FROM (
    SELECT CCN
    FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] WITH (NOLOCK) 
    WHERE LodgeType IN ('CI Received', 'RAL Lodged')

    UNION ALL

    SELECT CCN
    FROM Claims_SLA.[dbo].[AllICDailyOutstanding] WITH (NOLOCK) 
    WHERE [Lodge Type] IN ('CI Received', 'RAL Lodged')
) AS Combined;





IF OBJECT_ID('tempdb..#CCN1') IS NOT NULL
BEGIN
    DROP TABLE #CCN1;
END;

CREATE TABLE #CCN1 (
    CCN VARCHAR(50)
);
CREATE INDEX IX_CCN1 ON #CCN1(CCN);

INSERT INTO #CCN1 (CCN)
SELECT CCN
FROM (
    SELECT C.CCN
    FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] AS C WITH (NOLOCK)
    INNER JOIN #CCN AS Temp ON C.CCN = Temp.CCN
    WHERE C.LodgeType IN ('Non cashless', 'Non Cash Less')

    UNION ALL

    SELECT D.CCN
    FROM Claims_SLA.[dbo].[AllICDailyOutstanding] AS D WITH (NOLOCK)
    INNER JOIN #CCN AS Temp ON D.CCN = Temp.CCN
    WHERE D.[Lodge Type] IN ('Non cashless', 'Non Cash Less')
) AS Combined
GROUP BY CCN;

CREATE NONCLUSTERED INDEX IDX_Outstanding_LodgeType_CCN
ON Claims_SLA.[dbo].[AllICDailyOutstanding] ([Lodge Type], CCN);


UPDATE C
SET CONSIDER_COUNT = CASE
        WHEN IS_IT_RECONSIDERED = 'YES' THEN 0
        ELSE 
            CASE
                WHEN LodgeType IN ('Additional Payment', 'Deductions Payment') THEN 0
                WHEN LodgeType IN ('CI Received', 'RAL Lodged') AND Temp.CCN IS NOT NULL THEN 0
                ELSE 1
            END
    END
FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] AS C
LEFT JOIN #CCN1 AS Temp ON C.CCN = Temp.CCN
WHERE C.Head <> 'Paid';


CREATE NONCLUSTERED INDEX IDX_Settled_Head_CCN
ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (Head, CCN)
INCLUDE (LodgeType, IS_IT_RECONSIDERED, CONSIDER_COUNT);


/*Update IS_IT_RECONSIDERED for head is equal to Paid */
UPDATE C
SET CONSIDER_COUNT = CASE
        WHEN LodgeType IN ('Additional Payment', 'Deductions Payment') THEN 0
        ELSE 1
    END
FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] AS C
WHERE CAST(C.UTR_CRS_UpdateDate AS DATE) = @TargetDate
  AND C.Head = 'Paid';


CREATE NONCLUSTERED INDEX IDX_Settled_UpdateDate_Head
ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (UTR_CRS_UpdateDate, Head)
INCLUDE (LodgeType, CONSIDER_COUNT);

CREATE NONCLUSTERED INDEX IDX_Settled_LodgeType_CCN
ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (LodgeType, CCN);









/*Update Actual_Lodge_Consider for head is not equal to Paid */

-- Create a temporary table for the intermediate result of CCN filtering
IF OBJECT_ID('tempdb..#CCN_Filtered') IS NOT NULL
BEGIN
    DROP TABLE #CCN_Filtered;
END

CREATE TABLE #CCN_Filtered (CCN VARCHAR(50));

-- Insert relevant CCN data into the temporary table
INSERT INTO #CCN_Filtered (CCN)
SELECT CCN 
FROM #CCN1;


-- Update for non-'Paid' head rows
UPDATE C
SET Actual_Lodge_Consider = 
    CASE 
        WHEN IS_IT_RECONSIDERED = 'Yes' OR LodgeType = 'Deductions Payment' THEN 0
        ELSE 
            CASE 
                WHEN LodgeType IN ('CI Received', 'RAL Lodged') THEN 
                    CASE 
                        WHEN CF.CCN IS NOT NULL THEN 0 
                        ELSE 1 
                    END
                ELSE 1 
            END
    END
FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] C
LEFT JOIN #CCN_Filtered CF
    ON C.CCN = CF.CCN
WHERE C.head <> 'Paid';

-- Clean up the temporary table
DROP TABLE #CCN_Filtered;

CREATE NONCLUSTERED INDEX IDX_Head_LodgeType 
ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (head, LodgeType, IS_IT_RECONSIDERED);

CREATE NONCLUSTERED INDEX IDX_CCN 
ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (CCN);



/*Update Actual_Lodge_Consider for head is  equal to Paid */
-- Update for 'Paid' head rows
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET Actual_Lodge_Consider = 
    CASE 
        WHEN LodgeType <> 'Deductions Payment' THEN 1 
        ELSE 0 
    END
WHERE 
    CAST(UTR_CRS_UpdateDate AS date) = @TargetDate
    AND head = 'Paid';




--for treatment type --
-- Step 1: Create a mapping table using a CTE
WITH TreatmentMapping AS (
    SELECT 'Auyrvedic' AS OldType, 'Ayurvedic' AS NewType UNION ALL
    SELECT 'Ayurveda', 'Ayurvedic' UNION ALL
    SELECT 'Ayurvedic', 'Ayurvedic' UNION ALL
    SELECT 'Ayrvedic', 'Ayurvedic' UNION ALL
    SELECT 'Cinservative', 'Conservative' UNION ALL
    SELECT 'Conservative', 'Conservative' UNION ALL
    SELECT 'conserative', 'Conservative' UNION ALL
    SELECT 'Denture', 'Dental' UNION ALL
    SELECT 'Dental', 'Dental' UNION ALL
    SELECT 'Health Checkup', 'Health Check up' UNION ALL
    SELECT 'Health Check up', 'Health Check up' UNION ALL
    SELECT 'Home Care Treatment', 'home care' UNION ALL
    SELECT 'home care', 'home care'
)

-- Step 2: Perform the update using a JOIN
UPDATE C
SET Treatment_type = T.NewType
FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] C
JOIN TreatmentMapping T
    ON C.Treatment_type = T.OldType
WHERE CAST(C.UTR_CRS_UpdateDate AS date) = @TargetDate


CREATE NONCLUSTERED INDEX IDX_UTR_CRS_UpdateDate
ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (UTR_CRS_UpdateDate);





 -- Step 1: Create indexes on columns involved in WHERE conditions for faster filtering
CREATE NONCLUSTERED INDEX IDX_lodge_lodgeamt ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (lodge_lodgeamt);
CREATE NONCLUSTERED INDEX IDX_lodge_dedamt ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (lodge_dedamt);
CREATE NONCLUSTERED INDEX IDX_CCN_LodgeType_Lodgeamt ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (CCN, LodgeType, Lodgeamt);
CREATE NONCLUSTERED INDEX IDX_CCN_LodgeType_DedAmt ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (CCN, LodgeType, DedAmt);

-- Step 2: Update `lodge_lodgeamt` where it is NULL, optimized by reducing unnecessary computation
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET lodge_lodgeamt = CONCAT(CCN, LodgeType, Lodgeamt)
WHERE lodge_lodgeamt IS NULL
  AND CCN IS NOT NULL AND LodgeType IS NOT NULL AND Lodgeamt IS NOT NULL;

-- Step 3: Update `lodge_dedamt` where it is NULL, optimized by reducing unnecessary computation
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET lodge_dedamt = CONCAT(CCN, 'Deductions Payment', DedAmt)
WHERE lodge_dedamt IS NULL
  AND CCN IS NOT NULL AND DedAmt IS NOT NULL;


-- for actual lodge amt
-- Step 1: Create necessary indexes if they don't exist already
CREATE NONCLUSTERED INDEX IDX_AllIC_Settled_Actual_Lodge_Consider_Lodgeamt_BSI
ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] (Actual_Lodge_Consider, Lodgeamt, BSI);

-- Step 2: Perform the update with optimized CASE logic
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET Actual_lodge_amt = 
    CASE 
        WHEN Actual_Lodge_Consider = 0 THEN 0 
        ELSE 
            CASE 
                WHEN Lodgeamt > BSI THEN BSI 
                ELSE Lodgeamt 
            END 
    END
WHERE Actual_lodge_amt IS NULL
    AND Actual_Lodge_Consider IS NOT NULL  -- Avoid unnecessary rows
    AND Lodgeamt IS NOT NULL  -- Avoid unnecessary rows
    AND BSI IS NOT NULL; -- Avoid unnecessary rows




--for Std Disease Category 
-- Step 1: Create appropriate indexes (if not already done)
CREATE NONCLUSTERED INDEX IDX_ICD_Code_Treatment_Procedure_Amounts
ON Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] ([ICd_Code], [TotalClaimAmt], [Treatment_type], [PCSProcedure_1]);

-- Step 2: Reduce repetitive LTRIM/RTRIM and LEFT operations on [ICd_Code]
WITH CleanedData AS (
    SELECT 
        [ICd_Code],
        [TotalClaimAmt],
        [Treatment_type],
        [PCSProcedure_1],
        LTRIM(RTRIM([ICd_Code])) AS Cleaned_ICd_Code
    FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
    WHERE [Std_Disease_Category] IS NULL
)

UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET [Std_Disease_Category] = 
    CASE 
        -- HTN cases
        WHEN LEFT(Cleaned_ICd_Code, 3) IN ('I10', 'I11') AND [TotalClaimAmt] < 40000 THEN 'Conservative Rx of HTN'
        
        -- Other cardiovascular cases
        WHEN LEFT(Cleaned_ICd_Code, 3) IN ('I20', 'I21', 'I22', 'I23', 'I24', 'I25') AND [TotalClaimAmt] < 40000 THEN 'OTHER'
        
        -- Conservative Rx of MI
        WHEN LEFT(Cleaned_ICd_Code, 3) IN ('I10', 'I11', 'I20', 'I21', 'I22', 'I23', 'I24', 'I25') AND [TotalClaimAmt] >= 40000 AND [TotalClaimAmt] < 80000 THEN 'Conservative Rx of MI'
        
        -- Angioplasty
        WHEN LEFT(Cleaned_ICd_Code, 3) IN ('I10', 'I11', 'I20', 'I21', 'I22', 'I23', 'I24', 'I25') AND [TotalClaimAmt] >= 80000 AND [TotalClaimAmt] < 150000 THEN 'Angioplasty'
        
        -- CABG
        WHEN LEFT(Cleaned_ICd_Code, 3) IN ('I10', 'I11', 'I16', 'I20', 'I21', 'I22', 'I23', 'I24', 'I25') AND [TotalClaimAmt] >= 150000 AND [Treatment_type] = 'Surgical' THEN 'CABG'
        
        -- TKR
        WHEN LEFT(Cleaned_ICd_Code, 3) IN ('M00', 'M13', 'M14', 'M15', 'M17', 'M23', 'M84', 'M90', 'M26', 'M1A', 'M04') AND [Treatment_type] = 'Surgical' THEN 'TKR'
        
        -- Arrhythmia treatment
        WHEN LEFT(Cleaned_ICd_Code, 3) IN ('I44', 'I45', 'I46', 'I47', 'I48', 'I49', 'I50', 'I51') AND [Treatment_type] = 'Conservative' THEN 'Arrythmia Treatment Medical'
        WHEN LEFT(Cleaned_ICd_Code, 3) IN ('I44', 'I45', 'I46', 'I47', 'I48', 'I49', 'I50', 'I51') AND [Treatment_type] = 'Surgical' THEN 'Arrythmia Treatment Pacemaker'
        
        -- Spinal Surgery
        WHEN LEFT(Cleaned_ICd_Code, 3) IN ('M43', 'M44', 'M45', 'M46', 'M47', 'M48', 'M49', 'M50', 'M51') AND [Treatment_type] = 'Surgical' THEN 'Spinal Surgery'
        
        -- Medical Mgt of Backache
        WHEN LEFT(Cleaned_ICd_Code, 3) IN ('M43', 'M44', 'M45', 'M46', 'M47', 'M48', 'M49', 'M50', 'M51') AND [Treatment_type] = 'Conservative' THEN 'Medical Mgt of Backache'
        
        -- Cholecystectomy
        WHEN LEFT(Cleaned_ICd_Code, 3) = 'K80' AND [Treatment_type] = 'Surgical' THEN 'Cholecystectomy'
        
        -- Arthritis Medical Mgt
        WHEN LEFT(Cleaned_ICd_Code, 2) = 'M6' AND [Treatment_type] = 'Conservative' THEN 'Arthritis Medical Mgt'
        WHEN LEFT(Cleaned_ICd_Code, 3) = 'M13' AND [Treatment_type] = 'Conservative' THEN 'Arthritis Medical Mgt'
        
        -- LRTI Mgt
        WHEN LEFT(Cleaned_ICd_Code, 1) = 'J' THEN 'LRTI Mgt'
        
        -- Angiography procedure
        WHEN PCSProcedure_1 = 'Angiography procedure' THEN 'Angiography procedure'
        
        -- TKR
        WHEN PCSProcedure_1 = 'Bilateral Total Knee Replacement' THEN 'TKR'
        
        -- Chemotherapy
        WHEN PCSProcedure_1 IN ('Chemotherapy Parentral', 'Chemotherapy Oral', 'Chemotherapy -Immunotherapy- Monoclonal Antibody', 
                                'Chemotherapy -Immunotherapy- Monoclona', 'Chemotherapy -Immunotherapy- Monoclonal', 'Chemotherapy ParentralChemotherapy -Immunotherapy- Monoclonal', 
                                'Chemotherapy', 'Chemotherapy- Immunotherapy- Monoclonal Antibody', 'Chemotherapy -Immunotherapy- Monoclonal Antibody + Iv Antiboitics', 
                                'Chemotherapy -Immunotherapy- Monoclonal Antibod', 'Chemotherapy -Immunotherapy- Monoclonal Antibody + Chemotherapy Oral', 
                                'Chemotherapy -Immunotherapy- Monoclonal Antibody + Chemotherapy Parentral', 'Chemotherapy -Immunotherapy', 'Chemotherapy Oral + Chemotherapy Parentral', 
                                'Chemotherapy Oral + Hormonal Therapy', 'Chemotherapy Parentra', 'CHEMOPORT REMOVAL') THEN 'Chemotherapy'
        
        -- Cataract
        WHEN PCSProcedure_1 IN ('Bilateral IOL with Phaco', 'Right Eye Cataract', 'Left Eye Cataract', 'Cataract Extraction', 
                                'Intravetreal Inj.Avastin/Lucentis + Right Eye Cataract', 'Eye Cataract', 'Right  Eye Cataract', 'Right Eye Catarac', 
                                'Right Eye Cataract +') THEN 'Cataract'
        
        -- Spinal Surgery
        WHEN PCSProcedure_1 = 'Spinal Surgery' THEN 'Spinal Surgery'
        
        -- Default
        ELSE NULL 
    END
WHERE [Std_Disease_Category] IS NULL;

-- Create the temporary table and insert data
CREATE TABLE #t2 (
    [Disease Category] NVARCHAR(255) NULL,
    [ICD Codes] NVARCHAR(255) NULL
);

CREATE INDEX idx_t2_ICDCodes ON #t2 ([ICD Codes]);

-- Insert data into #t2
INSERT INTO #t2 ([Disease Category], [ICD Codes])
SELECT D.[Disease Category], D.[ICD Codes]
FROM [dbo].[DiseaseCategories] AS D WITH (NOLOCK)
JOIN Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] AS qty WITH (ROWLOCK)
    ON D.[ICD Codes] = LEFT(qty.[ICd_Code], 3)
WHERE qty.[Std_Disease_Category] IS NULL;



-- Update Std_Disease_Category using #t2 based on ICD Codes
UPDATE qty
SET [Std_Disease_Category] = t2.[Disease Category]
FROM Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] AS qty
JOIN #t2 AS t2 ON t2.[ICD Codes] = LEFT(qty.[ICd_Code], 3)
WHERE qty.[Std_Disease_Category] IS NULL;

-- Additional updates based on PCSProcedure_1 and secondary treatment
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET [Std_Disease_Category] = PCSProcedure_1
WHERE PCSProcedure_1 = Secondary_treatment OR ISNULL(Secondary_treatment, '') = ''
AND [Std_Disease_Category] IS NULL;

-- Update Std_Disease_Category based on ICD Master
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET [Std_Disease_Category] = D.Group_Desc
FROM [Masters].dbo.[ICD_Master] AS D WITH (NOLOCK)
JOIN Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty] AS qty
    ON LEFT(D.ICD10_Code, 3) = LEFT(qty.[ICd_Code], 3)
WHERE qty.[Std_Disease_Category] IS NULL;

-- Final update for missing Std_Disease_Category based on secondary treatment
UPDATE Claims_SLA.[dbo].[AllIC_Settled_Cases_Of_Qty]
SET [Std_Disease_Category] = Secondary_treatment
WHERE [Std_Disease_Category] IS NULL;

-- Drop the temporary table
DROP TABLE #t2;


----------REVISED_SERVICING_BRANCH

UPDATE B
SET B.REVISED_SERVICING_BRANCH = CASE
                                    WHEN B.REVISED_SERVICING_BRANCH IS NULL THEN
                                        CASE
                                            WHEN A.Servicing_Branch LIKE 'MDINDIA HEALTHCARE SERVICES PVT LTD -%' 
                                            THEN SUBSTRING(UPPER(TRIM(A.Servicing_Branch)), LEN('MDINDIA HEALTHCARE SERVICES PVT LTD -') + 1, LEN(TRIM(A.Servicing_Branch)))
                                            ELSE UPPER(TRIM(A.Servicing_Branch)) 
                                        END
                                    ELSE TRIM(A.Servicing_Branch) 
                                  END
FROM  [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_Qty] B WITH (ROWLOCK)
JOIN  Enrollment.DBO.Enrollment_Master A WITH (ROWLOCK)
ON   A.Pol_No = B.POL_NO
WHERE  B.REVISED_SERVICING_BRANCH IS NULL 
    AND CAST(B.UTR_CRS_UpdateDate AS DATE) =@TargetDate

--------------- Delete Duplicate Records 

WITH cte AS (
    SELECT 
        CCN, LODGETYPE, LODGEAMT, LODGEDATE, utr_crs_Updatedate, Head, settledAmt, 
        ROW_NUMBER() OVER(PARTITION BY CCN, LODGETYPE, LODGEAMT, LODGEDATE, utr_crs_Updatedate, Head, settledAmt 
                          ORDER BY CCN) AS rn
    FROM [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_Qty] WITH (NOLOCK)
)
DELETE B
FROM [Claims_SLA].[dbo].[AllIC_Settled_Cases_Of_Qty] B
INNER JOIN cte C ON B.CCN = C.CCN 
    AND B.LODGETYPE = C.LODGETYPE 
    AND B.LODGEAMT = C.LODGEAMT 
    AND B.LODGEDATE = C.LODGEDATE 
    AND B.utr_crs_Updatedate = C.utr_crs_Updatedate 
    AND B.Head = C.Head 
    AND B.settledAmt = C.settledAmt
WHERE C.rn > 1;
