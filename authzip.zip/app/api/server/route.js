import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";



// for user login and authentication 
export async function fetchApplicationdetails() {
    try {
        const response = await axios.post(`${API_BASE_URL}api/application-details/`, {
            name: process.env.APP_NAME
        });
        return response.data;
    } catch (error) {
        throw new Error("Failed to fetch application details");
    }
};


export async function validateTicket(serviceTicket, applicationId) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/validate-ticket/`, {
            service_ticket: serviceTicket,
            application_id: applicationId,
        });
        return response.data; // Ensure this returns the expected user details
    } catch (error) {
        console.error('Error validating ticket:', error);
        throw new Error('Error validating ticket');
    }
};


export async function validateSession(sessionKey) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/validate-session/`, {
            headers: {
                Authorization: `Bearer ${sessionKey}`,
            },
        });
        return response.status === 200;
    } catch (error) {
        console.error("Session validation error:", error);
        return false;
    }
};


// for user registration
export async function fetchDesignations() {
    try{
        const response = await axios.get(`${API_BASE_URL}api/designations/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch designation");
    }
};


export async function fecthDepartments() {
    try{
        const response = await axios.get(`${API_BASE_URL}api/departments/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch departments");
    }
};


export async function fetchOrgTypes() {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-type-list/`);
        console.log("Org types Data:", response.data)
        return response.data;

    } catch (error) {
        console.error("Error fetching Org types:", error);
        throw error;
    }
};


export async function fetchOrgNames(orgType) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-name-list/?orgType=${orgType}`);
        console.log("Org Names Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Org Names:", error );
        throw error;
    }
};


export async function fetchOrgSubTypes(orgType) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-subtypes/?orgType=${orgType}`);
        console.log("Org SubTypes Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Org SubTypes:", error);
        throw error;
    }
};


export async function fetchLocationTypes(orgName) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/location-type-list/?orgName=${orgName}`);
        console.log("Location Type Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Type:", error );
        throw error;
    }
};


export async function fetchLocationName(orgName, location_type) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/location-name-list/`, {
            params: {
                orgName: orgName,
                location_type: location_type,
            }
        });
        console.log("Location Name Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Name:", error);
        throw error;
    }
};


export async function fetchLocationCode(orgName, location_type, location_name) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/location-code-list/`, {
            params: {
                orgName: orgName,
                location_type: location_type,
                location_name: location_name
            }
        });
        console.log("Location Code Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Code:", error);
        throw error;
    }
};


export async function register(formData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/register/`, formData);
        console.log("userdetails:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error while registration:", error);
        throw error;
    }
};


// for user forgot password
export async function getpasswordResetRequest(userDetails) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/password-reset-request/`, userDetails);
        return response.data
    } catch(error) {
        console.error("Error while password rest :", error);
        throw error;
    }
};


export async function getResetPassword(userDetails) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/reset-password/`, userDetails);
        return response.data
    } catch(error) {
        console.error("Error while password rest :", error);
        throw error;
    }
};


// for users change password
export async function changePasswordForAuthenticatedUser(accessToken, formData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/change-password/`, formData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            
        });
        return response.data;
    } catch (error) {
        console.error("Error while changing new password:", error);
        throw error;
    }
};


// for user account details
export async function fetchUserAccountDetails(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/user-account/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching user account data:", error);
        throw error;
    }
};


// for user profile details
export async function fetchUserProfileDetails(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/user-profile/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }, 
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching profile data:", error);
        throw error;
    }
};


export async function updateUserProfileData (accessToken, profileData) {
  try {
    const response = await axios.patch(`${API_BASE_URL}api/user-profile/`, profileData, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error updating profile data:", error);
    throw error;
  }
};


// for users notifications

export async function fetchNotification(accessToken, applicationName) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/notifications/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            params: {
                application_name: applicationName, // Send application name as a query parameter
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error while fetching notifications:", error.response ? error.response.data : error.message);
        throw error;
    }
};

export async function fetchNotificationDetails(notificationId,accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/notifications/${notificationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching notifications data:", error);
        throw error;
    }
};


export async function markedasReadNotification(accessToken, notificationId) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/notifications/${notificationId}/mark-as-read/`,null, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error updating notifications  data:", error);
        throw error;
    }
};


export async function deleteNotificationDetails(accessToken,notificationId) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/notifications/${notificationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting applications data:", error);
        throw error;
    }
};



// for users teams details

export async function fetchUsersTeam(accessToken) {

};


// for administartor user related views 

export async function fetchOnlineUser(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/online-user-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            } 
        });
        console.log("user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching user count:", error);
        throw error;
    }
};


export async function fetchTotalUser(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/total-users-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
};


export async function fetchApplicationCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/application-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
};


export async function fectchApplicationWiseUserChartData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/user-application-status-chart/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
}


export async function fetchAdminUserCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/admin-user-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
};


export async function fetchAuthenticatorCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/authenticator-user-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
};


export async function fetchSiteAdminCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/site-admin-user-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
};


export async function fetchPendingVerificationCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/unverified-users-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total unverified count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total unverified user count:", error);
        throw error;
    }
};

// for authenticator user related views 

// for site admin user related views 





// for common views related functions with curd operations


// for user management related
export async function fetchUserListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/admin-user-list/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
              } 
        });
        console.log("User list Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching user details:", error);
        throw error;
    }
};

export async function fetchAuthenticatorFilteredUserListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/authenticator-user-list/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
              } 
        });
        console.log("User list Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching user details:", error);
        throw error;
    }
};


export default async function createNewUser(accessToken, userData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/admin-user-list/`, userData, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        });
        console.log("New user created:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error creating user:", error);
        throw error;
    }
};


export async function fetchUserDetails(userId, accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/admin-user-details/${userId}/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
              } 
        });
        console.log("User list Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching user details:", error);
        throw error;
    }
};


export async function updateUserDetails(accessToken, userId, userData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/admin-user-details/${userId}/`, userData, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        });
        console.log("User updated:", response.data);
        return response.data;
      } catch (error) {
        console.error("Error updating user:", error);
        throw error;
      }
    
};

export async function deleteUserDetails(accessToken, userId) {
    try {
      const response = await axios.delete(`${API_BASE_URL}api/admin-user-details/${userId}/`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      console.log("User deleted:", response.data);
      return response.data;
    } catch (error) {
      console.error("Error deleting user:", error);
      throw error;
    }
};

// for roles management

export async function fetchRolesListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/roles-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching roles list data:", error);
        throw error;
    }
};

export async function fetchRolesListByApplication(accessToken, applicationId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/roles/by-application/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            params: {
                application: applicationId, // Adding the application name as a query parameter
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching roles list by application:", error);
        throw error;
    }
};


export async function createNewRole(accessToken, roleData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/create-roles/`, roleData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new role data:", error);
        throw error;
    }
};

export async function fetchRoleDetails(accessToken, roleId ) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/roles/${roleId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching roles data:", error);
        throw error;
    }
};


export async function updateRoleDetails(accessToken, roleId, roleData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/roles/${roleId}/details/`, roleData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error updating roles data:", error);
        throw error;
    }
};

export async function deleteRoleDetails(roleId, accessToken) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/roles/${roleId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error deleting roles data:", error);
        throw error;
    }
};

// for permissions Management


export async function fetchPermissionListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/permissions-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
       console.error("Error fetching permission list data:", error);
        throw error;
    }
};


export async function fetchPermissionListByApplication(accessToken, applicationId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/permissions/by-application/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            params: {
                application: applicationId, // Adding the application name as a query parameter
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching permissions list by application:", error);
        throw error;
    }
};


export async function createNewPermission(accessToken, permissionData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/create-permissions/`, permissionData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new Permission data:", error);
        throw error;
    }
};


export async function fetchPermissionDetails(permissionId,accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/permissions/${permissionId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching permission data:", error);
        throw error;
    }
};


export async function updatePermissionDetails(accessToken, permissionId, permissionData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/permissions/${permissionId}/details/`, permissionData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error updating permissions  data:", error);
        throw error;
    }
};


export async function deletePermissionDetails(permissionId, accessToken) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/permissions/${permissionId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting permissions data:", error);
        throw error;
    }
};



// for application Management

export async function fetchApplicationListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/applications-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching application list data:", error);
        throw error;
    }
};


export async function createNewApplication(accessToken, appData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/create-applications/`, appData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new Application data:", error);
        throw error;
    }
};


export async function fetchApplicationDetails(applicationId,accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/applications/${applicationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching applications data:", error);
        throw error;
    }
};


export async function updateApplicationDetails(accessToken, applicationId, appData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/applications/${applicationId}/details/`, appData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error updating applications  data:", error);
        throw error;
    }
};


export async function deleteApplicationDetails(applicationId, accessToken) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/applications/${applicationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting applications data:", error);
        throw error;
    }
};

// for organization management


export async function fetchOrganizationListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/organization-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching organization list data:", error);
            throw error;
    }
};


export async function createNewOrganization(accessToken,  orgData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/organization-list/`, orgData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new Organization data:", error);
        throw error;
    }
};


export async function fetchOrganizationDetails(orgId,accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/organization/${orgId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching organization data:", error);
        throw error;
       
    }
};


export async function updateOrganizationDetails(accessToken,  orgId, orgData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/organization/${orgId}/details/`, orgData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
       
            console.error("Error updating organization  data:", error);
            throw error;
        
    }
};


export async function deleteOrganizationDetails(orgId, accessToken) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/organization/${orgId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error Deleting organization data:", error);
            throw error;
       
    }
};

//for organization subtype management

export async function fetchOrgSubTypeListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/org-subtype-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching org-subtype list data:", error);
            throw error;
        
    }
};


export async function createNewOrgSubType(accessToken, orgsubtypeData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/org-subtype-list/`, orgsubtypeData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
       
            console.error("Error creating new org-subtype data:", error);
            throw error;
        
    }
};


export async function fetchOrgSubTypeDetails(orgSubtypeId,accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/org-subtype/${orgSubtypeId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching org-subtype data:", error);
            throw error;
       
    }
};


export async function updateOrgSubTypeDetails(accessToken, orgSubtypeId, orgsubtypeData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/org-subtype/${orgSubtypeId}/details/`, orgsubtypeData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
       
            console.error("Error updating org-subtype  data:", error);
            throw error;
        
    }
};


export async function deleteOrgSubTypeDetails(orgSubtypeId, accessToken) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/org-subtype/${orgSubtypeId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting org-subtype data:", error);
        throw error;
    }
};


// for location management

export async function importLocationData(accessToken,formData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/import-locations/`, formData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'multipart/form-data',
            },
        });
        return response.data;
    }catch (error) {
        console.error('Error uploading file:', error);
        const errorMessage = error.response?.data?.error || error.message || 'Failed to upload file';
        throw new Error(errorMessage);
    }
};


export async function fetchLocationListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/locations-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching locations list data:", error);
            throw error;
        
    }
};


export async function createNewLocation(accessToken, locationsData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/locations-list/`, locationsData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        
            console.error("Error creating new locations data:", error);
            throw error;
        
    }
};


export async function fetchLocationDetails(locationId,accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/locations/${locationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching locations data:", error);
            throw error;
      
    }
};


export async function updateLocationDetails(accessToken, locationId, locationData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/locations/${locationId}/details/`, locationData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error updating locations  data:", error);
            throw error;
      
    }
};


export async function deleteLocationDetails(locationId, accessToken) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/locations/${locationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error Deleting locations data:", error);
            throw error;
       
    }
};


// for Department management


export async function fetchDepartmentListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/department-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching Department list data:", error);
            throw error;
       
    }
};


export async function createNewDepartment(accessToken, departmentData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/department-list/`, departmentData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
       
            console.error("Error creating new Department data:", error);
            throw error;
       
    }
};


export async function fetchDepartmentDetails(departmentId,accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/department/${departmentId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching Department data:", error);
            throw error;
       
    }
};


export async function updateDepartmentDetails(accessToken, departmentId, departmentData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/department/${departmentId}/details/`, departmentData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error updating Department  data:", error);
            throw error;
       
    }
};


export async function deleteDepartmentDetails(departmentId, accessToken) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/department/${departmentId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error Deleting Department data:", error);
            throw error;
        
    }
};


// for Designation Management

export async function fetchDesignationListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/designation-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching Designation list data:", error);
            throw error;
       
    }
};


export async function createNewDesignation(accessToken, designationData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/designation-list/`, designationData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        
            console.error("Error creating new Designation data:", error);
            throw error;
        
    }
};


export async function fetchDesignationDetails(designationId,accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/designation/${designationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching Designation data:", error);
            throw error;
       
    }
};


export async function updateDesignationDetails(accessToken, designationId, designationData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/designation/${designationId}/details/`, designationData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
       
            console.error("Error updating Designation  data:", error);
            throw error;
        
    }
};


export async function deleteDesignationDetails(designationId, accessToken) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/designation/${designationId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error Deleting Designation data:", error);
            throw error;
        
    }
};


// for Assign User Roles Management


export async function fetchUserRolesListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/user-roles-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching User Roles list data:", error);
            throw error;
       
    }
};


export async function createNewUserRoles(accessToken, userRoleData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/assign-user-roles/`, userRoleData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new User Roles data:", error);
        throw error;
    }
};


export async function fetchUserRolesDetails(accessToken, userRoleId) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/user-roles/${userRoleId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
        
    } catch (error) {
        
            console.error("Error fetching User Roles data:", error);
            throw error;
       
    }
};


export async function updateUserRolesDetails(accessToken, userRoleId, userRoleData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/user-roles/${userRoleId}/details/`, userRoleData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
       
            console.error("Error updating User Roles  data:", error);
            throw error;
        
    }
};


export async function deleteUserRolesDetails(accessToken, userRoleId) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/user-roles/${userRoleId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error Deleting User Roles data:", error);
            throw error;
        
    }
};

// Assign Roles for Auth Server Users Management

export async function fetchAuthServerUserRolesListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/auth-server-user-roles-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching User Roles list data:", error);
            throw error;
       
    }
};


export async function createNewAuthServerUserRoles(accessToken, userRoleData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/assign-auth-server-user-roles/`, userRoleData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new User Roles data:", error);
        throw error;
    }
};


export async function fetchAuthServerUserRolesDetails(accessToken, userRoleId) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/user-roles/${userRoleId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
        
    } catch (error) {
        
            console.error("Error fetching User Roles data:", error);
            throw error;
       
    }
};


export async function updateAuthServerUserRolesDetails(accessToken, userRoleId, userRoleData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/user-roles/${userRoleId}/details/`, userRoleData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
       
            console.error("Error updating User Roles  data:", error);
            throw error;
        
    }
};


export async function deleteAuthServerUserRolesDetails(accessToken, userRoleId) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/user-roles/${userRoleId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error Deleting User Roles data:", error);
            throw error;
        
    }
};


// for Teams Management
export async function fetchAllTeamsListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/teams-all-list/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data; 
    } catch(error){
        console.error("Error fetching teams list data");
        throw error;
    }
};


export async function createNewTeam(accessToken, teamData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/create-teams/`, teamData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        return response.data;
    } catch (error) {
        
            console.error("Error creating new team data:", error);
            throw error;
        
    }
};


export async function fetchTeamDetails(accessToken, teamId) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/teams/${teamId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error fetching team data:", error);
            throw error;
       
    }
};


export async function updateTeamDetails(accessToken, teamId, teamData) {
    try{
        const response = await axios.patch(`${API_BASE_URL}api/teams/${teamId}/details/`, teamData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
       
            console.error("Error updating team  data:", error);
            throw error;
        
    }
};


export async function deleteTeamDetails(accessToken, teamId) {
    try{
        const response = await axios.delete(`${API_BASE_URL}api/teams/${teamId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        
            console.error("Error Deleting team data:", error);
            throw error;
        
    }
};
