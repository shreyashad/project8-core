'use client'

import { useState, useEffect, useRef } from 'react'
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"
import { ScrollArea } from "@/components/ui/scroll-area"

// Mock data
const users = [
  { id: '1', name: 'Alice Johnson' },
  { id: '2', name: 'Bob Smith' },
  { id: '3', name: 'Charlie Brown' },
  { id: '4', name: 'David Lee' },
  { id: '5', name: 'Emma Watson' },
  { id: '6', name: 'Frank Ocean' },
  { id: '7', name: 'Grace Kelly' },
  { id: '8', name: 'Henry Ford' },
  { id: '9', name: 'Ivy Chen' },
  { id: '10', name: 'Jack Ma' },
]

const applications = [
  { id: '1', name: 'CRM System' },
  { id: '2', name: 'HR Portal' },
  { id: '3', name: 'Finance Dashboard' },
]

const roles = [
  { id: '1', name: 'Admin' },
  { id: '2', name: 'User' },
  { id: '3', name: 'Viewer' },
]

export default function UserRoleAssignment() {
  const [searchTerm, setSearchTerm] = useState('')
  const [searchResults, setSearchResults] = useState(users)
  const [selectedUser, setSelectedUser] = useState<{ id: string; name: string } | null>(null)
  const [selectedApplication, setSelectedApplication] = useState('')
  const [selectedRole, setSelectedRole] = useState('')
  const [isSearchFocused, setIsSearchFocused] = useState(false)
  const searchRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const filteredUsers = users.filter(user =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase())
    )
    setSearchResults(filteredUsers)
  }, [searchTerm])

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (selectedUser && selectedApplication && selectedRole) {
      // Here you would typically make an API call to assign the role
      console.log('Assigning role:', {
        user: selectedUser,
        application: selectedApplication,
        role: selectedRole,
      })
      toast({
        title: "Role Assigned",
        description: `User ${selectedUser.name} has been assigned the role of ${roles.find(r => r.id === selectedRole)?.name} for ${applications.find(a => a.id === selectedApplication)?.name}.`,
      })
    } else {
      toast({
        title: "Error",
        description: "Please select a user, application, and role.",
        variant: "destructive",
      })
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Assign User Role</CardTitle>
        <CardDescription>Search for a user, then select an application and role to assign.</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2" ref={searchRef}>
            <label htmlFor="user-search" className="text-sm font-medium text-gray-700">
              Search User
            </label>
            <Input
              id="user-search"
              type="text"
              placeholder="Start typing to search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
            />
            {isSearchFocused && searchResults.length > 0 && (
              <ScrollArea className="h-[200px] w-full rounded-md border">
                <div className="p-4">
                  {searchResults.map((user) => (
                    <div
                      key={user.id}
                      className="cursor-pointer p-2 hover:bg-gray-100 rounded"
                      onClick={() => {
                        setSelectedUser(user)
                        setSearchTerm(user.name)
                        setIsSearchFocused(false)
                      }}
                    >
                      {user.name}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </div>
          {selectedUser && (
            <div className="text-sm text-gray-500">
              Selected User: {selectedUser.name}
            </div>
          )}
          <div className="space-y-2">
            <label htmlFor="application-select" className="text-sm font-medium text-gray-700">
              Application
            </label>
            <Select value={selectedApplication} onValueChange={setSelectedApplication}>
              <SelectTrigger id="application-select">
                <SelectValue placeholder="Select an application" />
              </SelectTrigger>
              <SelectContent>
                {applications.map((app) => (
                  <SelectItem key={app.id} value={app.id}>
                    {app.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label htmlFor="role-select" className="text-sm font-medium text-gray-700">
              Role
            </label>
            <Select value={selectedRole} onValueChange={setSelectedRole}>
              <SelectTrigger id="role-select">
                <SelectValue placeholder="Select a role" />
              </SelectTrigger>
              <SelectContent>
                {roles.map((role) => (
                  <SelectItem key={role.id} value={role.id}>
                    {role.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full">Assign Role</Button>
        </CardFooter>
      </form>
    </Card>
  )
}