import { useState } from "react"
import { Bell, ChevronDown, Key, LogOut, Settings, Shield, User, UserCheck, UserCog, Users } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function AdminAuthDashboard() {
  const [twoFactor, setTwoFactor] = useState(false)

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <header className="border-b">
        <div className="container flex items-center justify-between h-16 px-4">
          <h1 className="text-2xl font-bold">Admin Auth Dashboard</h1>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
              <span className="sr-only">Notifications</span>
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Admin" />
                    <AvatarFallback>AD</AvatarFallback>
                  </Avatar>
                  <span>Admin User</span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <LogOut className="mr-2 h-4 w-4" />
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>
      <main className="flex-1 py-8">
        <div className="container px-4">
          <Tabs defaultValue="user-management" className="space-y-4">
            <TabsList>
              <TabsTrigger value="user-management">User Management</TabsTrigger>
              <TabsTrigger value="role-assignment">Role Assignment</TabsTrigger>
              <TabsTrigger value="password-management">Password Management</TabsTrigger>
              <TabsTrigger value="admin-actions">Admin Actions</TabsTrigger>
            </TabsList>
            <TabsContent value="user-management" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>User Authentication</CardTitle>
                  <CardDescription>Verify and manage user accounts</CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="email">User Email</Label>
                      <Input id="email" placeholder="user@example.com" type="email" />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="verified" />
                      <Label htmlFor="verified">Account Verified</Label>
                    </div>
                    <Button type="submit">Update User Status</Button>
                  </form>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Pending Verifications</CardTitle>
                  <CardDescription>Users awaiting account verification</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4">
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">alice@example.com</p>
                        <p className="text-sm text-muted-foreground">Registered: 2 days ago</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <UserCheck className="mr-2 h-4 w-4" />
                        Verify
                      </Button>
                    </li>
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">bob@example.com</p>
                        <p className="text-sm text-muted-foreground">Registered: 5 days ago</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <UserCheck className="mr-2 h-4 w-4" />
                        Verify
                      </Button>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="role-assignment" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Assign User Roles</CardTitle>
                  <CardDescription>Manage user permissions and access levels</CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="user-email">User Email</Label>
                      <Input id="user-email" placeholder="user@example.com" type="email" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="role">Role</Label>
                      <Select>
                        <SelectTrigger id="role">
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="user">User</SelectItem>
                          <SelectItem value="moderator">Moderator</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button type="submit">Assign Role</Button>
                  </form>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Current Role Assignments</CardTitle>
                  <CardDescription>Overview of user roles in the system</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4">
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">charlie@example.com</p>
                        <p className="text-sm text-muted-foreground">Current Role: Moderator</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <UserCog className="mr-2 h-4 w-4" />
                        Change Role
                      </Button>
                    </li>
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">david@example.com</p>
                        <p className="text-sm text-muted-foreground">Current Role: User</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <UserCog className="mr-2 h-4 w-4" />
                        Change Role
                      </Button>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="password-management" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>User Password Management</CardTitle>
                  <CardDescription>Reset or change user passwords</CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="reset-email">User Email</Label>
                      <Input id="reset-email" placeholder="user@example.com" type="email" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="new-password">New Password</Label>
                      <Input id="new-password" type="password" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="confirm-password">Confirm New Password</Label>
                      <Input id="confirm-password" type="password" />
                    </div>
                    <Button type="submit">
                      <Key className="mr-2 h-4 w-4" />
                      Reset Password
                    </Button>
                  </form>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Password Reset Requests</CardTitle>
                  <CardDescription>Users who have requested password resets</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4">
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">eve@example.com</p>
                        <p className="text-sm text-muted-foreground">Requested: 1 hour ago</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Key className="mr-2 h-4 w-4" />
                        Process Reset
                      </Button>
                    </li>
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">frank@example.com</p>
                        <p className="text-sm text-muted-foreground">Requested: 3 hours ago</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Key className="mr-2 h-4 w-4" />
                        Process Reset
                      </Button>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="admin-actions" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Administrative Actions</CardTitle>
                  <CardDescription>Log of recent actions taken by administrators</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4">
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">User Role Changed</p>
                        <p className="text-sm text-muted-foreground">charlie@example.com: User → Moderator</p>
                        <p className="text-sm text-muted-foreground">2 hours ago by admin@example.com</p>
                      </div>
                    </li>
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Account Verified</p>
                        <p className="text-sm text-muted-foreground">alice@example.com</p>
                        <p className="text-sm text-muted-foreground">1 day ago by admin@example.com</p>
                      </div>
                    </li>
                    <li className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Password Reset</p>
                        <p className="text-sm text-muted-foreground">bob@example.com</p>
                        <p className="text-sm text-muted-foreground">3 days ago by admin@example.com</p>
                      </div>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}