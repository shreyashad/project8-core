import { fetchApplicationCount, fetchOnlineUser, fetchTotalUser } from "@/app/api/server/route";
import { auth } from "@/auth";
import StatsCard from "@/components/dashboard/stats-card";
import { Card, CardHeader, CardTitle ,CardContent } from "@/components/ui/card";
import { Gamepad, UserCheck, UserPen, UserRoundCog } from "lucide-react";



export default async function AuthenticatorPage() {
    const session = await auth();

    if (!session) {
      return new Response("Unauthorized", { status: 401 });
    }
    const onlineUsers = await fetchOnlineUser(session.accessToken, session.refreshToken);
    const totalUsers = await fetchTotalUser(session.accessToken, session.refreshToken);
    const applicationCount = await fetchApplicationCount(session.accessToken, session.refreshToken);
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
         <div className="flex items-center justify-between space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Welcome, Administrator</h2>
         </div>
         <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-4">
          <StatsCard title="Total Users" value={totalUsers.total_user} description="Total number of user that are been registered"  icon={<UserRoundCog />}/>
          <StatsCard title="Active Users" value={onlineUsers.active_user} description="Total number of Active user" icon={<UserCheck /> } />
          <StatsCard title="Total Applications" value={applicationCount.apps_count} description="Total number of application been registered" icon={ <Gamepad /> }/>
          <StatsCard title="Pending Verifications" value={12} description="Total number of user pending for verifications" icon={ <UserPen /> } /> 
        </div>
         <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-10">
           <Card>
            <CardHeader>
              <CardTitle>

              </CardTitle>
            </CardHeader>
            <CardContent>

            </CardContent>
           </Card>
           <Card>
            
           </Card>
         </div>
        
      </div>
  
    );
}