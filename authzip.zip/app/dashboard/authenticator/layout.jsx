const { default: Header } = require("@/components/layout/header");
const { default: Sidebar } = require("@/components/layout/sidebar");


const AuthenticatorLayout = ({ children }) => {
    return(
        <>
            <Header dashboardType="Authenticator" />
            <div className="flex h-screen border-collapse overflow-hidden">
                <Sidebar dashboardType="Authenticator" />
                <main className="flex-1 overflow-y-auto overflow-x-hidden pt-16 bg-secondary/10 pb-1">
                    {children}
                </main>
            </div>
        </>
    );
}
export default AuthenticatorLayout;