import { fetchTeamDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { TeamForm } from "@/components/dashboard/teams-management/teams-form";

function getTeamId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode org ID');
        return data;
    }
}

export default async function EditTeam({ params }) {
    const { id } = params; // Get the organization ID from params
    console.log("params details: ", id);
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    let teamData = null;

    if (id === "new") {
        // Handle the case for creating a new organization
        teamData = {}; // Pass an empty object for a new organization
    } else {
        // Handle the case for editing an existing organization
        const teamId = getTeamId(id);
        teamData = await fetchTeamDetails( session.accessToken, teamId);
    }

    return (
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
                <TeamForm initialData={teamData || {}} />
            </div>
        </div>
    );
};