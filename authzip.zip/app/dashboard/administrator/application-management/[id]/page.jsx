import { fetchApplicationDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { ApplicationForm } from "@/components/admin/applications/application-form";


function getAppId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode org ID');
        return data;
    }
}


export default async function EditApplication({ params }) {
    const { id } = params; // Get the organization ID from params
    console.log("params details: ", id);
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    let appData = null;

    if (id === "new") {
        // Handle the case for creating a new organization
        appData = {}; // Pass an empty object for a new organization
    } else {
        // Handle the case for editing an existing organization
        const appId = getAppId(id);
        appData = await fetchApplicationDetails(appId, session.accessToken);
    }

    return (
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
                <ApplicationForm initialData={appData || {}} />
            </div>
        </div>
    );
};