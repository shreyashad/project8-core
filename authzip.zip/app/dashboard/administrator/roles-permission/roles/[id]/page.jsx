import { fetchRoleDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { RolesManagementForm } from "@/components/admin/roles/roles-form";

function getRoleId(data) {
    try {
        return decodeURIComponent(data)
    } catch( error) {
        console.error('failed to decode role id')
        return data
    }
};

export default async function EditRole({ params }) {
    const { id } = params;
    console.log("params details: ", id);
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    let roleData = null;

    if (id === "new") {
        roleData = {};
    } else {
        const roleId = getRoleId(id);
        roleData = await fetchRoleDetails( session.accessToken,roleId);
    }

    return(
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
              <RolesManagementForm initialData={ roleData || {}} />
            </div>
        </div>
    );
};