
import { fetchUserRolesListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import UserRoleClient from "@/components/admin/assigned-role/assigned-role-client";
import { UserRoleColumns } from "@/components/admin/assigned-role/assigned-role-columns";
import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";



export default async function UserRoleManagement() {
    const session = await auth();
    const userroledata = await fetchUserRolesListData(session.accessToken);
    console.log("userroledata:",userroledata);
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb
                homelink="/dashboard/administrator/"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/roles-permission/assigned-role/"
                mdipagetitle="Roles & Permissions"
                pagetitle="User Roles"
            />
            
            <UserRoleClient />
            <Separator />
            <div>
                <DataTable columns={UserRoleColumns} data={userroledata} />
            </div>
        </div>
    );
}
