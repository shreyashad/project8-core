import { fetchPermissionListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import PermissionClient from "@/components/admin/permissions/permission-client";
import { PermissionColumns } from "@/components/admin/permissions/permission-columns";
import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";



export default async function PermissionsManagement() {
    const session = await auth();
    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    const permissionData = await fetchPermissionListData(session.accessToken);
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb
                homelink="/dashboard/administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/roles-permission/roles"
                mdipagetitle="Roles & Permissions"
                pagetitle="Permission"
            />
            <PermissionClient />
            <Separator />
            <div>
                <DataTable columns={PermissionColumns} data={permissionData} />
            </div>
        </div>
    );
};