import { fetchOrgSubTypeListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import { OrgSubTypeColumns } from "@/components/admin/org-subtype/org-subtype-columns";
import OrgSubTypeClient from "@/components/admin/org-subtype/orgsubtype-client";
import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";



export default async function OrgSubTypeManagement() {
    const session = await auth();
    const orgsubtype = await fetchOrgSubTypeListData(session.accessToken);
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb
                 homelink="administrator/dashboard"
                 hometitle="Dashboard"
                 mdipagelink="administrator/org-management/"
                 mdipagetitle="Organization Management"
                 pagetitle="Organization-SubType"
            />
            
            <OrgSubTypeClient />
            <Separator />
            <div>
                <DataTable columns={OrgSubTypeColumns} data={orgsubtype} />
            </div>
        </div>

    );
}