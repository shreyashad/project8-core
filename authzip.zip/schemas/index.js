import * as z from "zod";

export const orgTypeEnum = z.enum([
  'MDIndia',
  'Insurance Company',
  'Broker',
  'Corporate'
]);


export const locationEnum = z.enum([
    'HO',
    'RO',
    'DO',
    'UO',
    'Branch',
]);


// schema for user login
export const LogingSchema = z.object({
  username: z.string().min(4, {
      message: "Username is required",
  }),
  password: z.string().min(1, {
      message:  "Password is required",
    }),
});


// schema for user registration

export const RegisterationSchema = z.object({
  first_name: z.string().nonempty({
    message: "First Name is required"
  }),
  last_name: z.string().nonempty({
    message: "Last Name is required"
  }),
  emp_code: z.string().nonempty({
    message: "Employee Code is required"
  }),
  designation: z.string().nonempty({
    message: "Designation is required"
  }),
  org_type: z.string().nonempty({
    message: "Organization Type is required"
  }),
  org_name: z.string().nonempty({
    message: "Organization Name is required"
  }),
  org_sub_type: z.string().nonempty({
    message: "Organization Subtype is required"
  }),
  assigned_details: z.string().max(1000, {
    message: "Must be 1000 characters or less"
  }).optional(),
  department: z.string().min(1, {
    message: "Department is required"
  }).max(250, { 
    message:  "Must be 250 characters or less"
  }).optional(), 
  location_type: z.string().nonempty({
    message: "Location Type is required"
  }),
  location_name: z.string().nonempty({
    message: "Location Name is required"
  }),
  location_code: z.string().nonempty({
    message: "Location Code is required"
  }),
  username: z.string().nonempty({
    message:  "Username is required"
  }),
  password: z.string().min(8, {
    message:  "Password must be at least 8 characters"
  }),
  confirm_password: z.string().min(8, {
    message:  "Password confirmation must be at least 8 characters"
  }),
  mobile: z.string().nonempty({
    message:"Mobile number is required"
  }),
}).refine((data) => data.password === data.confirm_password, {
  message: "Passwords must match",
  path: ["confirm_password"],
});




// schema for password reset request
export const PasswordResetRequestSchema = z.object({
  username: z.string().min(4,{ 
    message: "Username is required"
  }),
  emp_code: z.string().min(1, { 
    message: "Employee code is required"
  }),
  mobile: z.string().min(10, { 
    message: "Mobile number must be at least 10 characters long"
  }),
});


// schema for reset password
export const ResetPasswordSchema = z.object({
  new_password: z.string().min(8, {
    message: "Password must be at least 8 characters long"
  }),
  confirm_password: z.string().min(8, {
    message: "Confirm password must be at least 8 characters long"
  }),
}).refine(data => data.new_password === data.confirm_password, {
  message: "Passwords do not match",
  path: ["confirm_password"],  // Path to the field that should display the error
});



// schema for organization
export const OrgFormSchema = z.object({
  name: z.string().min(4, {
    message: "Username is required",
  })
  .max(250, {
    message: "Maximum of 250 characters is allowed"
  }),
  org_type: orgTypeEnum

});


// schema for organization subtype
export const OrgSubtypeFormSchema = z.object({
  subtype: z.string().min(3, {
    message: "SubType is required",
  })
  .max(250, {
     message: "Maximum of 250 characters is allowed"
  }),
  org_type: orgTypeEnum
});


// Schema for location
export const LocationFormSchema = z.object({
  org_type: orgTypeEnum,
  org_name: z.string().min(3, {
    message: "Orgnization Name is required",
  })
  .max(250, {
    message: "Maximum of 250 characters is allowed"
  }),
  location_type: locationEnum,
  location_name: z.string().min(1, {
    message: "location name is required"
  }).max(250, {
    message:  "must be 250 characters or less"
  }),
  location_code: z.string().min(1, {
    message:  "location code is required"
  }).max(250, {
    message: "must be 250 characters or less"
  }), 

});






// schema for Department
export const DepartmentFormSchema = z.object({
  name: z.string().min(3, {
    message: "Department Name is required",
  })
  .max(250, {
    message: "Maximum of 250 characters is allowed"
  }),
})

// schema for Designation
export const DesignationFormSchema = z.object({
  name: z.string().min(4, {
    message: "Designation is required",
})
.max(250,{
  message: "Maximum of 250 characters is allowed"
}),
});

// schema for User Management

export const UserManagementFormSchema = z.object({
  first_name: z.string().min(1, {
    message: "First name is required"
  }).max(150, {
    message: "Must be 150 characters or less"
  }),
  last_name: z.string().min(1, {
    message: "Last name is required"
  }).max(150, {
    message: "Must be 150 characters or less"
  }),
  org_type: orgTypeEnum, // Enum validation based on your application logic
  org_name: z.string().min(1, {
    message: "Organization name is required"
  }).max(250, {
    message: "Must be 250 characters or less"
  }),
  org_sub_type: z.string().min(1, {
    message: "Organization sub-type is required"
  }).max(150, "Must be 150 characters or less"),
  location_type: locationEnum, // Enum validation for location types
  location_name: z.string().min(1, {
    message: "Location name is required"
  }).max(250, {
    message:"Must be 250 characters or less"
  }),
  location_code: z.string().min(1, {
    message: "Location code is required"
  }).max(150, {
    message: "Must be 150 characters or less"
  }),
  emp_code: z.string().min(1, {
    message: "Employee code is required"
  }).max(150, {
    message:  "Must be 150 characters or less"
  }),
  department: z.string().min(1, {
    message: "Department is required"
  }).max(250, {
    message:  "Must be 250 characters or less"
  }),
  designation: z.string().min(1, {
    message: "Designation is required"
  }).max(250, { 
    message:  "Must be 250 characters or less"
  }).optional(),
  mobile: z.string().min(10, {
    message: "Mobile number is required"
  }).max(15, {
    message:  "Must be a valid phone number"
  }), 
  username: z.string().min(1, {
    message: "Username is required"
  }).max(150, {
    message:  "Must be 150 characters or less"
  }),
 assigned_pol_no: z.string().max(1000, {
    message: "Must be 1000 characters or less"
  }).optional(), 
  is_online: z.boolean().default(false), // Boolean field with default value
  is_verified: z.boolean().default(false),
});

// schema for application 

export const ApplicationFormSchema = z.object({
  name: z.string().min(4, {
    message: "department is required"
  })
  .max(255,{
      message: "must be 250 characters or less"
  }),
  description: z.string().min(4, {
      message: "Deparrment Description is required"
  }),
  base_url: z.string().min(4, {
      message: " Application url is required"
  }).url()
  .max(250, {
      message: "must be 250 characters or less"
  }),
  active: z.boolean({
    required_error: "isActive is required",
    invalid_type_error: "isActive must be a boolean",
  })
  .default(false)

});

// schema for permission 


export const PermissionFormSchema = z.object({
  name: z.string().min(1,{
    message: "Permission is required"
  }).max(250, {
    message: "must be 250 characters or less"
  }),
  description: z.string().min(4, {
    message: "Permission Description is required"
  })
  .max(250, {
      message: "must be 250 characters or less"
  }),
  application: z.string().min(1, {
    message:  "application is required"
  }).max(250, {
    message:  "must be 250 characters or less"
  }),
  can_create: z.boolean({
    required_error: "can_create is required",
    invalid_type_error: "can_create must be a boolean",
  })
  .default(false),
  can_read: z.boolean({
    required_error: "can_read is required",
    invalid_type_error: "can_read must be a boolean",
  })
  .default(false),
  can_update: z.boolean({
    required_error: "can_update is required",
    invalid_type_error: "can_update must be a boolean",
  })
  .default(false),
  can_delete: z.boolean({
    required_error: "can_delete is required",
    invalid_type_error: "can_delete must be a boolean",
  })
  .default(false),
});

// schema for role


export const RolesFormSchema = z.object({
  name: z.string().min(1, {
    message: "department is required"
  }).max(150, {
    message:  "must be 250 characters or less"
  }),
  description: z.string().optional(),
  application: z.string().min(1, {
    message:  "department is required"
  }).max(250, {
    message:  "must be 250 characters or less"
  }),
  permissions: z.array(PermissionFormSchema).optional(),
  default_for_application: z.boolean().optional(),
});




// for User Role 
export const UserRoleFormSchema = z.object({
  user: z.string().min(1, {
    message: "Username is required"
  }).max(250, {
    message:  "must be 250 characters or less"
  }),
  role: z.string().min(1, {
    message:  "Role is required"
  }).max(250, {
    message:  "must be 250 characters or less"
  }),
  application: z.string().min(1, {
    message:  "Application is required"
  }).max(250, {
    message:  "must be 250 characters or less"
  }),
});


// for Team
export const TeamFormSchema = z.object({
  name: z.string().min(3, {
    message: "Team name is required"
  }),
  description: z.string().optional(), 
});