"use client";

import { useEffect, useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Button } from "../ui/button";
import { Bell } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { fetchNotification } from "@/app/api/server/route";
import { useSession } from "next-auth/react";

export default function Notification() {
    const [notifications, setNotifications] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const { data: session } = useSession();
    const applicationName = process.env.APP_NAME

    useEffect(() => {
        const getNotifications = async () => {
            if (!session?.accessToken) return;  // Exit if accessToken is not available

            setIsLoading(true);
            setError(null);
            try {
                const data = await fetchNotification(session.accessToken, applicationName);
                // Filter notifications for today
                const today = new Date();
                const filteredNotifications = data.filter(notification => {
                    const notificationDate = new Date(notification.date); // Assuming notification has a date field
                    return (
                        notificationDate.getDate() === today.getDate() &&
                        notificationDate.getMonth() === today.getMonth() &&
                        notificationDate.getFullYear() === today.getFullYear()
                    );
                });
                setNotifications(filteredNotifications);
            } catch (err) {
                setError('Failed to fetch notifications');
            } finally {
                setIsLoading(false);
            }
        };

        getNotifications();
    }, [session?.accessToken]); // Add session.accessToken to the dependency array

    return (
        <Popover>
            <PopoverTrigger asChild>
                <Button variant="outline" size="icon" className="relative bg-blue border rounded-full">
                    <Bell className="h-[1.2rem] w-[1.2rem]" />
                    {notifications.length > 0 && (
                        <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500" />
                    )}
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80">
                <Card>
                    <CardHeader>
                        <CardTitle>Notifications</CardTitle>
                        <CardDescription>You have {notifications.length} unread messages</CardDescription>
                    </CardHeader>
                    <CardContent className="max-h-[300px] overflow-auto">
                        {isLoading ? (
                            <p>Loading notifications...</p>
                        ) : error ? (
                            <p className="text-red-500">{error}</p>
                        ) : (
                            notifications.length === 0 ? (
                                <p>No notifications for today.</p>
                            ) : (
                                notifications.map((notification) => (
                                    <div key={notification.id} className="mb-4 grid grid-cols-[25px_1fr] items-start pb-4 last:mb-0 last:pb-0">
                                        <span className="flex h-2 w-2 translate-y-1.5 rounded-full bg-sky-500" />
                                        <div className="space-y-1">
                                            <p className="text-sm font-medium leading-none">{notification.title}</p>
                                            <p className="text-sm text-muted-foreground">{notification.description}</p>
                                            <p className="text-xs text-muted-foreground">{notification.time}</p>
                                        </div>
                                    </div>
                                ))
                            )
                        )}
                    </CardContent>
                </Card>
            </PopoverContent>
        </Popover>
    );
}
