import { UserIcon } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";


export function UserAvatar({ user, ...props }) {
    return(
        <Avatar {...props} >
            {user.image ? (
                <AvatarImage alt="Profile Pic" src={user.profile_picture} />
            ) : (
                <AvatarFallback>
                    <span className="sr-only ">{user.first_name}</span>
                    <UserIcon className="h-4 w-4 bg-blue" />
                </AvatarFallback>
            )}
        </Avatar>
    )
}