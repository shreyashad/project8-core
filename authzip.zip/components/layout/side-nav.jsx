"use client";
import { useSidebar } from "@/hooks/useSidebar";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { buttonVariants } from "../ui/button";
import { ChevronDownIcon } from "lucide-react";
import Link from "next/link";
import { SidebarAccordion, SidebarAccordionContent, SidebarAccordionItem, SidebarAccordionTrigger } from "./subnav-accordion";

export default function SideNav({ items, setOpen, className }) {
    const path = usePathname();
    const { isOpen } = useSidebar();
    const [openItem, setOpenItem] = useState("");
    const [lastOpenItem, setLastOpenItem] = useState("");

    useEffect(()=> {
        if (isOpen) {
            setOpenItem(lastOpenItem);
        } else {
            setLastOpenItem(openItem);
            setOpenItem("");
        }
    }, [isOpen]);

    return(
        <nav className="space-y-2">
            {items.map((item) => 
                item.isChidren ? (
                <SidebarAccordion
                    type="single"
                    collapsible
                    className="space-y-2"
                    key={item.title}
                    value={openItem}
                    onValueChange={setOpenItem}
                
                >
                    <SidebarAccordionItem value={item.title} className="border-none">
                        <SidebarAccordionTrigger
                            className={cn(
                                buttonVariants({ variant: 'ghost'}),
                                'group relative flex h-12 justify-between px-4 py-2 text-base duration-200 hover:bg-muted hover:no-underline',
                            )}
                        
                        >
                            <div>
                                <item.icon className={cn('h-5 w-5', item.color)} />
                            </div>
                            <div
                                className={cn(
                                    'absolute left-12 text-base duration-200 ',
                                    !isOpen && className,
                                )}
                            >
                                {item.title}
                            </div>
                            {isOpen && (
                                <ChevronDownIcon className="h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" />
                            )}

                        </SidebarAccordionTrigger>
                        <SidebarAccordionContent className="mt-2 space-y-4 pb-1">
                            {item.children?.map((child) => (
                                <Link
                                    key={child.title}
                                    href={child.href}
                                    onClick={() => {
                                        if (setOpen) setOpen(false)
                                    }}
                                    className={cn(
                                        buttonVariants({ variant: 'ghost' }),
                                        'group relative flex h-12 justify-start gap-x-3',
                                        path === child.href &&
                                        'bg-muted font-bold hover:bg-muted',
                                    )}
                                    
                                
                                >
                                    <child.icon className={cn('h-5 w-5', child.color )} />
                                    <div
                                        className={cn(
                                            'absolute left-12 text-base duration-200',
                                            !isOpen && className,
                                        )}
                                    >
                                            {child.title}
                                    </div>
                                </Link>
                            ))}
                        </SidebarAccordionContent>
                    </SidebarAccordionItem>
                </SidebarAccordion>
            ) : (
                <Link
                        key={item.title}
                        href={item.href}
                        onClick={() => {
                            if (setOpen) setOpen(false)
                        }}
                        className={cn(
                            buttonVariants({ variant: 'ghost' }),
                            'group relative flex h-12 justify-start',
                            path === item.href && 'bg-muted font-bold hover:bg-muted',
                        )}
                    >
                        <item.icon className={cn('h-5 w-5', item.color)} />
                        <span
                            className={cn(
                                'absolute left-12 text-base duration-200',
                                !isOpen && className,
                            )}
                        >
                            {item.title}
                        </span>
                    </Link>
            ),
        )}
        </nav>
    );
}