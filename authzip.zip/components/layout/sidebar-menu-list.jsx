import { BookCheckIcon, BookOpenCheck, BookOpenText, BookUser, Briefcase, BriefcaseBusiness, Building2, FileClock, LayoutDashboard, MapPin, NotebookPen, Server, Settings, Shield, ShieldPlus, Trophy, UserCheck, UserRoundCog, UsersRound, Warehouse } from "lucide-react";


export const DashboardMenuConfig = {
    Administrator: [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/dashboard/administrator/",
            color: "text-sky-500",
        },
        {
            title: "User-Management",
            icon: UserRoundCog,
            href: "/dashboard/administrator/user-management",
            color: "text-sky-500",
            
        },
        {
            title: "Role and Permission",
            icon: ShieldPlus,
            href: "/dashboard/administrator/roles-permission",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Roles",
                    icon: UserCheck,
                    color: "text-red-500",
                    href: "/dashboard/administrator/roles-permission/roles",
                  },
                  {
                    
                    title: "Permissions",
                    icon: Shield,
                    color: "text-red-500",
                    href: "/dashboard/administrator/roles-permission/permissions",
                  },
                  {
                    
                    title: "Assign Roles",
                    icon: Shield,
                    color: "text-red-500",
                    href: "/dashboard/administrator/roles-permission/assign-roles",
                  },
                  {
                    title: "Auth Server Roles",
                    icon: Shield,
                    color: "text-red-500",
                    href: "/dashboard/administrator/roles-permission/auth-server-roles",
                  }
            ]
        },
        {
            title: "Organization",
            icon: Building2,
            href: "/dashboard/administrator/org-management",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Organization",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/dashboard/administrator/org-management/organizations",
                  },
                  {
                    
                    title: "Org-Subtype",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/dashboard/administrator/org-management/org-subtype",
                  },
                  {
                    title: "Locations",
                    icon: MapPin,
                    color: "text-red-500",
                    href: "/dashboard/administrator/org-management/location",
                  },
                  {
                    title: "Departments",
                    icon: Warehouse,
                    color: "text-red-500",
                    href: "/dashboard/administrator/org-management/department",
                  },
                  {
                    title: "Designations",
                    icon: BookUser,
                    color: "text-red-500",
                    href: "/dashboard/administrator/org-management/designation",
                  },
            ]
        },
        {
            title: "Teams Management",
            icon: UsersRound,
            href: "/dashboard/administrator/teams-management",
            color: "text-sky-500",
            isChidren: true,
            children: [
                  {
                    title: "Teams list",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/dashboard/administrator/teams-management/teams-list",
                  },
                  {
                    
                    title: "Team Member",
                    icon: BriefcaseBusiness,
                    color: "text-red-500",
                    href: "/dashboard/administrator/teams-management/teams-member",
                  },
            ]
        },
        {
            title: "Application Management",
            icon: Server,
            href: "/dashboard/administrator/application-management",
            color: "text-sky-500",
        },
        {
            title: "Logs and Reports",
            icon: FileClock,
            href: "/dashboard/administrator/logs_reports",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/dashboard/administrator/profile",
            color: "text-sky-500",
        },
    ],
    Authenticator : [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/dashboard/authenticator",
            color: "text-sky-500",
        },
       {
            title: "User-Management",
            icon: UserRoundCog,
            href: "/dashboard/authenticator/user-management",
            color: "text-sky-500",
            
        },
        {
            title: "Role and Permission",
            icon: ShieldPlus,
            href: "/dashboard/authenticator/roles-permission",
            color: "text-sky-500",
            isChidren: true,
            children: [
                {
                    title: "Roles",
                    icon: UserCheck,
                    color: "text-red-500",
                    href: "/dashboard/administrator/roles-permission/roles",
                  },
                  {
                    
                    title: "Permissions",
                    icon: Shield,
                    color: "text-red-500",
                    href: "/dashboard/administrator/roles-permission/permissions",
                  },
                  {
                    
                    title: "Assign Roles",
                    icon: Shield,
                    color: "text-red-500",
                    href: "/dashboard/administrator/roles-permission/assign-roles",
                  },
                  
            ]
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/dashboard/authenticator/teams",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/dashboard/authenticator/profile",
            color: "text-sky-500",
        },
    ],
    Siteadministrator : [
        {
            title: "Dashboard",
            icon: LayoutDashboard,
            href: "/employee/dashboard",
            color: "text-sky-500",
        },
        {
            title: "My-Course",
            icon: BookOpenText,
            href: "/employee/my-courses",
            color: "text-sky-500",
            
        },
        {
            title: "My-Exams",
            icon: NotebookPen,
            href: "/employee/exams",
            color: "text-sky-500",
        },
        {
            title: "My-Performance",
            icon: Trophy,
            href: "/employee/teams",
            color: "text-sky-500",
        },
        {
            title: "Teams",
            icon: UsersRound,
            href: "/employee/teams",
            color: "text-sky-500",
        },
        {
            title: "Profile",
            icon: Settings,
            href: "/employee/profile",
            color: "text-sky-500",
        },
    ]
    

};