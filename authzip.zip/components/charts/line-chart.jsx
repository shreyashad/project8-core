import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { ChartTooltip, ChartTooltipContent } from "../ui/chart";

export const CustomLineChart = ({
  title,
  description,
  chartData,
  chartConfig,
  dataKey = "value",   // Default key for data values
  nameKey = "name",    // Default key for data categories (X-axis)
  lineColor = "#8884d8",  // Configurable line color
  strokeWidth = 2,     // Customizable stroke width for the line
  showTooltip = true,  // Option to show or hide tooltip
  showGrid = true,     // Option to show or hide grid
}) => {
  return (
    <Card className="flex flex-col">
      <CardHeader className="items-center pb-0">
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 pb-0">
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData} {...chartConfig}>
            {showGrid && <CartesianGrid strokeDasharray="3 3" />}
            <XAxis dataKey={nameKey} />
            <YAxis />
            {showTooltip && (
              <Tooltip
                cursor={{ stroke: 'rgba(0, 0, 0, 0.1)' }}
                content={<ChartTooltipContent />}
              />
            )}
            <Line
              type="monotone"  // Smooth line
              dataKey={dataKey}
              stroke={lineColor}
              strokeWidth={strokeWidth}
              activeDot={{ r: 8 }}  // Custom size for active dots
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
