import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { ChartTooltip, ChartTooltipContent } from "../ui/chart";

export const CustomBarChart = ({
  title,
  description,
  chartData,
  chartConfig,
  dataKey = "value",  // Default key for data values
  nameKey = "name",   // Default key for data categories (X-axis)
  barColor = "#8884d8",  // Configurable bar color
  showTooltip = true,   // Option to show or hide tooltip
  showGrid = true,      // Option to show or hide grid
}) => {
  return (
    <Card className="flex flex-col">
      <CardHeader className="items-center pb-0">
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 pb-0">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData} {...chartConfig}>
            {showGrid && <CartesianGrid strokeDasharray="3 3" />}
            <XAxis dataKey={nameKey} />
            <YAxis />
            {showTooltip && (
              <Tooltip
                cursor={{ fill: 'rgba(0, 0, 0, 0.1)' }}
                content={<ChartTooltipContent />}
              />
            )}
            <Bar dataKey={dataKey} fill={barColor} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
