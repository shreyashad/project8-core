import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { ChartTooltip, ChartTooltipContent } from "../ui/chart";

export const CustomPieChart = ({
  title,
  description,
  chartData,
  chartConfig,
  dataKey = "value",   // Default key for data values
  nameKey = "name",    // Default key for pie segment names
  colors = [],         // Array of colors for pie segments
  innerRadius = 0,     // Configurable inner radius for donut effect
  outerRadius = 100,   // Configurable outer radius for pie size
  showTooltip = true,  // Option to show or hide tooltip
}) => {
  return (
    <Card className="flex flex-col">
      <CardHeader className="items-center pb-0">
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 pb-0">
        <ResponsiveContainer width="100%" height={300}>
          <PieChart {...chartConfig}>
            <Pie
              data={chartData}
              dataKey={dataKey}
              nameKey={nameKey}
              innerRadius={innerRadius}
              outerRadius={outerRadius}
              paddingAngle={5}
              fill="#8884d8"
            >
              {chartData?.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
              ))}
            </Pie>
            {showTooltip && (
              <Tooltip
                content={<ChartTooltipContent />}
                cursor={{ fill: 'rgba(0, 0, 0, 0.1)' }}
              />
            )}
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
