"use client";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { Checkbox } from "@/components/ui/checkbox";
import { ApplicationCellAction } from "../applications/cell-action";

export const ApplicationColumns = [
    {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={
              table.getIsAllPageRowsSelected() ||
              (table.getIsSomePageRowsSelected() && "indeterminate")
            }
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
            aria-label="Select all"
            className="translate-y-[2px]"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
            className="translate-y-[2px]"
          />
        ),
        enableSorting: false,
        enableHiding: false,
    },
    {
        accessorKey: "name",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Name"} />,
        cell: ({ row }) => {
            return <div className="flex items-center">{row.original.name}</div>;
        }
    },
    {
      accessorKey: "base_url",
      header: ({ column }) => <DataTableColumnHeader column={column} title={"URL"} />,
      cell: ({ row }) => {
          return <div className="flex items-center">{row.original.base_url}</div>;
      }
    },
    {
      accessorKey: "active",
      header: ({ column }) => <DataTableColumnHeader column={column} title={"active"} />,
      cell: ({ row }) => {
        return (
          <span>
            {row.original.active ? (
              <span className="text-green-500">🟢 Active</span>
            ) : (
              <span className="text-red-500">🔴 In-Active</span> 
            )}
          </span>
        );
      }
    },
    {
        id: "actions",
        enableSorting: false,
        cell: ({ row }) => <ApplicationCellAction data={row.original} />, 
      }
];