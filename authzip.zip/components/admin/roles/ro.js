"use client";

import {
    createNewRole,
    deleteRoleDetails,
    fetchApplicationListData,
    fetchPermissionListData,
    updateRoleDetails,
} from "@/app/api/server/route";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import MultiSelect from "@/components/ui/multi-select";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RolesFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";

export const RolesManagementForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const title = initialData && initialData.id ? "Edit Role" : "Create Role";
    const description = initialData && initialData.id ? "Edit a role" : "Create a new role";
    const toastMessage = initialData && initialData.id ? "Role updated successfully" : "Role created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const [applications, setApplications] = useState([]);
    const [permissions, setPermissions] = useState([]);
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false); // For AlertModal

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const appRes = await fetchApplicationListData(session.accessToken);
                const perRes = await fetchPermissionListData(session.accessToken);
                setApplications(appRes);
                setPermissions(perRes);
            } catch (error) {
                toast.error("Error fetching data");
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [session]);

    const form = useForm({
        resolver: zodResolver(RolesFormSchema),
        defaultValues: initialData || {
            name: "",
            permissions: [],
            application: "",
        },
    });

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData && initialData.id) {
                await updateRoleDetails(session.accessToken, initialData.id, values);
            } else {
                await createNewRole(session.accessToken, values);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/roles-permission/roles`);
        } catch (error) {
            toast.error(error.message || "An error occurred");
        } finally {
            setLoading(false);
        }
    };

    const onDelete = async () => {
        setLoading(true);
        try {
            await deleteRoleDetails(initialData.id, session.accessToken);
            toast.success("Role deleted successfully");
            router.push(`/dashboard/administrator/roles-permission/roles`);
        } catch (err) {
            toast.error(err.message || "An error occurred");
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <Card>
                <CardHeader>
                    <CardTitle>
                        <DashHeading title={title} description={description} />
                        {initialData && initialData.id && (
                            <Button
                                disabled={loading}
                                variant="destructive"
                                size="icon"
                                onClick={() => setOpen(true)}
                            >
                                <Trash className="h-4 w-4" />
                            </Button>
                        )}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <Form {...form}>
                        <form
                            onSubmit={form.handleSubmit(onSubmit)} 
                            className="w-full space-y-8"
                        >
                            <div className="grid-cols-2 gap-8 md:grid">
                                <FormField 
                                    control={form.control}
                                    name="name"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Name</FormLabel>
                                            <FormControl>
                                                <Input
                                                    {...field}
                                                    placeholder="Name"
                                                    disabled={loading}
                                                />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                /> 
                                <FormField
                                    control={form.control}
                                    name="application"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Application</FormLabel>
                                            <FormControl>
                                                <Select
                                                    onValueChange={field.onChange}
                                                    value={field.value}
                                                    disabled={loading}
                                                >
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select an application" />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {applications.map((app) => (
                                                            <SelectItem key={app.id} value={app.id}>
                                                                {app.name}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="permissions"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Permissions</FormLabel>
                                            <FormControl>
                                                <MultiSelect 
                                                    options={permissions.map((perm) => ({
                                                        label: perm.name,
                                                        value: perm.id,
                                                    }))}
                                                    onValueChange={field.onChange}
                                                    defaultValue={field.value}
                                                    placeholder="Select permissions"
                                                    animation={0.5}
                                                    disabled={loading}
                                                />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                            </div>
                            <div className="space-x-4">
                                <Button disabled={loading} className="ml-auto" type="submit">
                                    {action}
                                </Button>
                                <Button
                                    disabled={loading}
                                    className="ml-auto"
                                    type="button"
                                    onClick={() => {
                                        router.back();
                                    }}
                                >
                                    Cancel
                                </Button>
                            </div>
                        </form>
                    </Form>
                    {initialData && initialData.id && (
                        <AlertModal
                            title="Are you Sure"
                            description="This action cannot be undone."
                            name={initialData?.name}
                            isOpen={open}
                            onClose={() => setOpen(false)}
                            onConfirm={onDelete}
                            loading={loading}
                        />
                    )}
                </CardContent>
            </Card>
        </>
    );
};
