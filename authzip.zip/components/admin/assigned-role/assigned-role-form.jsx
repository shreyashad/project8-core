"use client";

import {
  createNewUserRoles,
  deleteUserRolesDetails,
  fetchApplicationListData,
  fetchRolesListByApplication,
  fetchUserListData,
  updateUserRolesDetails,
} from "@/app/api/server/route";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { UserRoleFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";

import { Trash } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";

export const UserRoleForm = ({ initialData }) => {
  const { data: session } = useSession();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const title = initialData?.id ? "Edit User Role" : "Create User Role";
  const description = initialData?.id ? "Edit a User Role" : "Create a new User Role";
  const toastMessage = initialData?.id ? "User Role updated successfully" : "User Role created successfully";
  const action = initialData?.id ? "Save Changes" : "Create";

  const form = useForm({
    resolver: zodResolver(UserRoleFormSchema),
    defaultValues: initialData || {
        application: "",
        role: "",
        user: "",
    }, 
    
  });
// defaultValues: initialData
    //   ? {
    //       user: initialData.user?.id || "", // Safe access to user id
    //       role: initialData.role?.id || "", // Safe access to role id
    //       application: initialData.application?.id || "", // Safe access to application id
    //     }
    //   : {
    //       user: "",
    //       role: "",
    //       application: "",
    //     },
  // useEffect(() => {
  //   if (initialData) {
  //     form.reset({
  //       user: initialData.user.id,
  //       role: initialData.role.id,
  //       application: initialData.application.id,
  //     });
  //     setSelectedApplication(initialData.application.id);
  //     handleApplicationChange(initialData.application.id);
  //   }
  // }, [initialData, form]);

  useEffect(() => {
    form.reset(initialData);
   
  }, [initialData, form]);
  
  
  
  const onSubmit = async (values) => {
    setLoading(true);
    try {
      if (initialData?.id) {
        await updateUserRolesDetails(session.accessToken, initialData.id, values);
      } else {
        await createNewUserRoles(session.accessToken, values);
      }
      toast.success(toastMessage);
      router.push('/dashboard/administrator/roles-permission/assign-roles');
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const onDelete = async () => {
    setLoading(true);
    try {
      await deleteUserRolesDetails(session.accessToken, initialData.id);
      toast.success("User Role deleted successfully");
      router.push("/dashboard/administrator/roles-permission/assign-roles");
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleApplicationChange = (value) => {
    setSelectedApplication(value);
    form.setValue("application", value);
    form.setValue("role", "");
  
    if (value) {
      fetchRoles(value);
    } else {
      setRoleData([]);
    }
  };

  const fetchRoles = async (applicationId) => {
    try {
      const rolesRes = await fetchRolesListByApplication(session.accessToken, applicationId);
      setRoleData(rolesRes);
    } catch (error) {
      toast.error("Error fetching roles");
    }
  };

  const [userData, setUserData] = useState([]);
  const [roleData, setRoleData] = useState([]);
  const [applicationsData, setApplicationsData] = useState([]);
  const [selectedApplication, setSelectedApplication] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredUserData, setFilteredUserData] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  

  useEffect(() => {
    const fetchData = async () => {
      if (session?.accessToken) {
        try {
          const userRes = await fetchUserListData(session.accessToken);
          const appRes = await fetchApplicationListData(session.accessToken);
          setUserData(userRes);
          setApplicationsData(appRes);
          setFilteredUserData(userRes);
        } catch (error) {
          toast.error("Error fetching data");
        }
      }
    };
    fetchData();
  }, [session]);

  // useEffect(() => {
  //   const fetchRoles = async (applicationId) => {
  //     try {
  //       const rolesRes = await fetchRolesListByApplication(session.accessToken, applicationId);
  //       setRoleData(rolesRes);
  //     } catch (error) {
  //       toast.error("Error fetching roles");
  //     }
  //   };

  //   if (selectedApplication) {
  //     fetchRoles(selectedApplication);
  //   } else {
  //     setRoleData([]);
  //   }
  // }, [selectedApplication, session]);

  
  useEffect(() => {
    if (searchTerm) {
        const filteredUsers = userData.filter(user =>
            user.username.toLowerCase().includes(searchTerm.toLowerCase())
        );
        setFilteredUserData(filteredUsers);
    } else {
        setFilteredUserData(userData);
    }
}, [searchTerm, userData]);





  return (
    <>
      <div className="flex items-center justify-between">
        <DashHeading title={title} description={description} />
        {initialData?.id && (
          <Button
            disabled={loading}
            variant="destructive"
            size="icon"
            onClick={() => setOpen(true)}
          >
            <Trash className="h-4 w-4" />
          </Button>
        )}
      </div>
      <Separator />
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="w-full space-y-8">
          <div className="grid-cols-2 gap-8 md:grid">
            <FormField
              control={form.control}
              name="application"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Application</FormLabel>
                  <FormControl>
                    <Select
                      onValueChange={(value) => {
                        handleApplicationChange(value);
                        field.onChange(value);
                      }}
                      value={field.value || ""}
                      disabled={loading}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select Applications" />
                      </SelectTrigger>
                      <SelectContent>
                        {applicationsData.map((app) => (
                          <SelectItem key={app.id} value={app.id}>
                            {app.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="role"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Roles</FormLabel>
                  <FormControl>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value || ""}
                      disabled={loading}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select Role" />
                      </SelectTrigger>
                      <SelectContent>
                        {roleData.map((role) => (
                          <SelectItem key={role.id} value={role.id}>
                            {role.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="user"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>User</FormLabel>
                  <FormControl>
                    <div className="relative">
                    <Input
                       placeholder="Search User..."
                       value={searchTerm}
                       onChange={(e) => setSearchTerm(e.target.value)}
                       disabled={loading}
                       className="mb-2"
                    />
                    <Select
                        onValueChange={field.onChange}
                        value={field.value || ""}
                        disabled={loading}
                    >
                        <SelectTrigger>
                            <SelectValue placeholder="Select a User" />
                        </SelectTrigger>
                        <SelectContent>
                            {filteredUserData.length > 0 ? (
                                filteredUserData.map((users) => (
                                    <SelectItem key={users.id} value={users.id}>
                                        {users.username}
                                    </SelectItem>
                                ))
                            ) : (
                                <SelectItem disabled>No users found</SelectItem>
                            )}
                        </SelectContent>
                    </Select>
                      
                    </div>
                  </FormControl>
                  {selectedUser && (
                    <div className="text-sm text-gray-500">
                      Selected User: {selectedUser.name}
                    </div>
                  )}
                </FormItem>
              )}
            />
          </div>
          <div className="space-x-4">
            <Button disabled={loading} className="ml-auto" type="submit">
              {action}
            </Button>
            <Button
              disabled={loading}
              className="ml-auto"
              type="button"
              onClick={() => router.back()}
            >
              Cancel
            </Button>
          </div>
        </form>
      </Form>
      {initialData?.id && (
        <AlertModal
          title="Are you sure?"
          description="This action cannot be undone."
          name={initialData.name}
          isOpen={open}
          onClose={() => setOpen(false)}
          onConfirm={onDelete}
          loading={loading}
        />
      )}
    </>
  );
};
