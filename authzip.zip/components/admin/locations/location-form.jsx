"use client";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";

import { Button } from "@/components/ui/button";
import { Trash } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { createNewLocation, updateLocationDetails, deleteLocationDetails, fetchOrgNames } from "@/app/api/server/route";
import { useSession } from "next-auth/react";
import { LocationFormSchema } from "@/schemas";

export const LocationForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [orgNamesData, setOrgNamesData] = useState([]);

    const title = initialData && initialData.id ?  "Edit Location" : "Create Location";
    const description = initialData && initialData.id ?  "Edit the location details" : "Create a new location";
    const toastMessage = initialData && initialData.id ?  "Location updated successfully" : "Location created successfully";
    const action = initialData && initialData.id ?  "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(LocationFormSchema),
        defaultValues: initialData || {
            org_type: "",
            org_name: "",
            location_type: "",
            location_name: "",
            location_code: "",
        },
    });

    const orgType = form.watch("org_type");
    console.log("selected orgtype:", orgType);
    // Listen for changes to `org_type` and fetch organization names dynamically
    useEffect(() => {
        const fetchOrganizationNames = async () => {
            if (orgType) {
                setLoading(true);
                try {
                    const orgNames = await fetchOrgNames(orgType);
                    setOrgNamesData(orgNames);  // Populate orgNamesData with API response
                } catch (err) {
                    toast.error("Error fetching organization names.");
                } finally {
                    setLoading(false);
                }
            }
        };
        
        console.log("orgnamds:", fetchOrganizationNames);
        fetchOrganizationNames();
    }, [orgType]);  // Trigger effect when org_type changes

    

    
   

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData && initialData.id) {
                await updateLocationDetails(session.accessToken, initialData.id, values);
            } else {
                await createNewLocation(session.accessToken, values);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/org-management/location`);
            router.refresh();
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };

    const onDelete = async () => {
        setLoading(true);
        try {
            await deleteLocationDetails(initialData.id, session.accessToken);
            toast.success("Location deleted successfully");
            router.push(`/dashboard/administrator/org-management/location`);
           
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };

    return (
        <>
            <div className="flex items-center justify-between">
                <DashHeading title={title} description={description} />
                {initialData?.id && (
                    <Button
                        disabled={loading}
                        variant="destructive"
                        size="icon"
                        onClick={() => setOpen(true)}
                    >
                        <Trash className="h-4 w-4" />
                    </Button>
                )}
            </div>
            <Separator />
            <Form {...form}>
                <form
                    onSubmit={form.handleSubmit(onSubmit)}
                    className="w-full space-y-8"
                >
                    <div className="grid-cols-2 gap-8 md:grid">
                        
                        <FormField
                            control={form.control}
                            name="org_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Organization Type</FormLabel>
                                    <Select
                                        disabled={loading}
                                        onValueChange={field.onChange}
                                        value={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue
                                                    placeholder="Organization Type"
                                                />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            <SelectItem value="MDIndia">MDIndia</SelectItem>
                                            <SelectItem value="Insurance Company">Insurance Company</SelectItem>
                                            <SelectItem value="Broker">Broker</SelectItem>
                                            <SelectItem value="Corporate">Corporate</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="org_name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Organization Name</FormLabel>
                                    <Select
                                        disabled={loading  || !orgNamesData.length}
                                        onValueChange={field.onChange}
                                        value={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue
                                                   placeholder={
                                                    orgNamesData.length > 0
                                                        ? "Organization Name"
                                                        : "No organizations available"
                                                }
                                                />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            {orgNamesData.length > 0 ? (
                                                orgNamesData.map((org) => (
                                                    <SelectItem key={org.id} value={org.name}>
                                                        {org.name}
                                                    </SelectItem>
                                                ))
                                            ) : (
                                                <SelectItem disabled>
                                                    No organizations found
                                                </SelectItem>
                                            )}
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="location_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Type</FormLabel>
                                    <Select
                                        disabled={loading}
                                        onValueChange={field.onChange}
                                        value={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue
                                                    placeholder="Location Type"
                                                />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            <SelectItem value="HO">HO</SelectItem>
                                            <SelectItem value="RO">RO</SelectItem>
                                            <SelectItem value="DO">DO</SelectItem>
                                            <SelectItem value="UO">UO</SelectItem>
                                            <SelectItem value="Branch">Branch</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="location_name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Location Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="location_code"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Code</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Location Code"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                    <div className="space-x-4">
                        <Button disabled={loading} className="ml-auto" type="submit">
                            {action}
                        </Button>
                        <Button
                            disabled={loading}
                            className="ml-auto"
                            type="button"
                            onClick={() => {
                                router.back();
                            }}
                        >
                            Cancel
                        </Button>
                    </div>
                </form>
            </Form>
            {initialData && initialData.id && (
                <AlertModal
                    title="Are you Sure"
                    description="This action cannot be undone."
                    name={initialData?.name}
                    isOpen={open}
                    onClose={() => setOpen(false)}
                    onConfirm={onDelete}
                    loading={loading}
                />
            )}
        </>
    );
};
