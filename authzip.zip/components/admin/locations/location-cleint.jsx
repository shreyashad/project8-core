
"use client";

import { importLocationData } from "@/app/api/server/route";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { Button } from "@/components/ui/button";
import { Plus, Upload } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";





const LocationClient = () => {
    const { data: session} = useSession();
    const router = useRouter();
    const [file, setFile] = useState(null);
    const [uploadStatus, setUploadStatus] = useState('');

    const handleFileChange = (e) => {
        setFile(e.target.files[0]); // Corrected this line
    };

    const handleSubmit  = async (e) => {
        e.preventDefault();

        if (!file) {
            alert('Please select a file to upload');
            return;
        }

        const formData = new FormData();
        formData.append('file', file);

        try {
            setUploadStatus('Uploading...');
            const response = await importLocationData(session.accessToken,formData);

            setUploadStatus('File uploaded successfully');
            console.log('Response:', response.data);
        } catch (error) {
            setUploadStatus('Error uploading file');
            console.error('Error:', error);
        }
    };
    return(
        <>
         <div className="flex items-center justify-between">
                <DashHeading 
                    title="Location List"
                />
                <Button
                    onClick={() => {
                        router.push("/dashboard/administrator/org-management/location/new");
                    }}
                >
                    <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
            </div>
            <div className="mb-4">
                <form onSubmit={handleSubmit}>
                    <input
                        type="file"
                        accept=".xlsx"
                        onChange={handleFileChange}
                        className="mr-2"
                    />
                    <Button type="submit" disabled={!file}>
                        <Upload className="mr-2 h-4 w-4" /> Upload
                    </Button>
                </form>
                <p>Status: {uploadStatus}</p>
            </div>
        </>
    );
}
export default LocationClient;