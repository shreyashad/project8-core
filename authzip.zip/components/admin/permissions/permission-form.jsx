"use client";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Trash } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { updatePermissionDetails, deletePermissionDetails, createNewPermission, fetchApplicationListData } from "@/app/api/server/route";
import { useSession } from "next-auth/react";

export const PermissionForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Permission" : "Create Permission";
    const description = initialData && initialData.id ? "Edit the permission details" : "Create a new permission";
    const toastMessage = initialData && initialData.id ? "Permission updated successfully" : "Permission created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const [applications, setApplications] = useState([]);
    
    useEffect(() => {
        const fetchData = async () => {
            try {
                const appRes = await fetchApplicationListData(session.accessToken);
                setApplications(appRes);
            } catch (error) {
                toast.error("Error fetching data");
            }
        };
        fetchData();
    },[session]);

    const form = useForm({
        resolver: zodResolver(),
        defaultValues: {
            name: "",
            description: "",
            application:  initialData?.application ?? "", // Handle application name here
        },
    });

    useEffect(() => {
        form.reset({
            name: initialData?.name || "",
            description: initialData?.description || "",
            application: initialData?.application?.id || "", // Set default value based on initialData
        });
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData && initialData.id) {
                await updatePermissionDetails(session.accessToken, initialData.id, values);
            } else {
                await createNewPermission(session.accessToken, values);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/roles-permission/permissions`);
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };

    const onDelete = async () => {
        setLoading(true);
        try {
            await deletePermissionDetails(initialData.id, session.accessToken);
            toast.success("Permission deleted successfully");
            router.push(`/dashboard/administrator/roles-permission/permissions`);
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };

    return (
        <>
            <div className="flex items-center justify-between">
                <DashHeading title={title} description={description} />
                {initialData && initialData.id && (
                    <Button
                        disabled={loading}
                        variant="destructive"
                        size="icon"
                        onClick={() => setOpen(true)}
                    >
                        <Trash className="h-4 w-4" />
                    </Button>
                )}
            </div>
            <Separator />
            <Form {...form}>
                <form
                    onSubmit={form.handleSubmit(onSubmit)}
                    className="w-full space-y-8"
                >
                    <div className="grid-cols-2 gap-8 md:grid">
                        <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Permission Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Description</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Permission Description"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="application"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Application</FormLabel>
                                    <FormControl>
                                    <Select 
                                        value={field.value} // Ensure the value is controlled
                                        onValueChange={(value) => field.onChange(value)} // Update value when changed
                                        disabled={loading}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select an application" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {applications.map((app) => (
                                                <SelectItem key={app.id} value={app.id}>
                                                    {app.name}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                    </div>
                    <div className="space-x-4">
                        <Button disabled={loading} className="ml-auto" type="submit">
                            {action}
                        </Button>
                        <Button
                            disabled={loading}
                            className="ml-auto"
                            type="button"
                            onClick={() => {
                                router.back();
                            }}
                        >
                            Cancel
                        </Button>
                    </div>
                </form>
            </Form>
            {initialData && initialData.id && (
                <AlertModal
                    title="Are you Sure"
                    description="This action cannot be undone."
                    name={initialData?.name}
                    isOpen={open}
                    onClose={() => setOpen(false)}
                    onConfirm={onDelete}
                    loading={loading}
                />
            )}
        </>
    );
};
