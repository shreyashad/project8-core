"use client";

import { deletePermissionDetails } from "@/app/api/server/route";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import { Pencil, Trash2 } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import toast from "react-hot-toast";


export function PermissionCellAction({ data }) {
    const { data: session } = useSession();
    const router = useRouter();
    const [alertModalOpen, setAlertModalOpen] = useState(false);

    const handleEdit = () => {
        router.push(`/dashboard/administrator/roles-permission/permissions/${data.id}`);
    };

    const deletePermission = async () => {
        try {
            await deletePermissionDetails(data.id, session.accessToken);
            toast.success("Permission deleted successfully");
            setAlertModalOpen(false);
            router.refresh();
        } catch (error) {
            toast.error("Error deleting permission");
        }
    };
    
    return (
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={handleEdit}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update Permission</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={() => setAlertModalOpen(true)}
                        >
                            <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete Permission</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <AlertModal
                title="Are you sure?"
                description="This action cannot be undone."
                isOpen={alertModalOpen}
                onClose={() => setAlertModalOpen(false)}
                onConfirm={deletePermission}
                loading={false} // Handle loading state as needed
            />
        </div>
    );

};