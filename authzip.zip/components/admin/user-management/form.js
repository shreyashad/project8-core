"use client";

import createNewUser, { deleteUserDetails, updateUserDetails } from "@/app/api/server/route";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { UserManagementFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import toast from "react-hot-toast";

export const UserManagementForm = ({ initialData }) => {
    const { data: session, status } = useSession();
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);

    const title = initialData && initialData.id ? "Edit User" : "Create User";
    const description = initialData && initialData.id ? "Edit a User" : "Create a User";
    const toastMessage = initialData && initialData.id ? "User updated Successfully" : "User created Successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(UserManagementFormSchema),
        defaultValues: initialData || {
            first_name: "",
            last_name: "",
            org_type: "",
            org_name: "",
            org_sub_type: "",
            location_type: "",
            location_name: "",
            location_code: "",
            emp_code: "",
            department: "",
            designation: "",
            mobile: "",
            username: "",
            assigned_pol_no: "",
            is_online: false,
            is_verified: false,
        }
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData && initialData.id) {
                await updateUserDetails(session.accessToken, initialData.id, values);
            } else {
                await createNewUser(session.accessToken, values);
            }
            toast.success(toastMessage);
            router.push(`dashboard/administrator/user-management`);
        } catch (error) {
            toast.error(error.message);
        }
        setLoading(false);
    };

    const onDelete = async () => {
        setLoading(true);
        try {
            await deleteUserDetails(session.accessToken, initialData.id);
            toast.success("User deleted successfully");
            router.push(`/administrator/user-management`);
        } catch (error) {
            toast.error(error.message);
        }
        setLoading(false);
    };

    return (
        <>
            <div className="flex items-center justify-between">
                <DashHeading title={title} description={description} />
                {initialData && initialData.id && (
                    <Button
                        disabled={loading}
                        variant="destructive"
                        size="icon"
                        onClick={() => setOpen(true)}
                    >
                        <Trash className="h-4 w-4" />
                    </Button>
                )}
            </div>
            <Separator />
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="w-full space-y-8">
                    <div className="grid-cols-2 gap-8 md:grid">
                        <FormField
                            control={form.control}
                            name="first_name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>First Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="First Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="last_name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Last Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Last Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="org_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Organization Type</FormLabel>
                                    <Select
                                        disabled={loading}
                                        onValueChange={field.onChange}
                                        value={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Organization Type" />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            <SelectItem value="MDIndia">MDIndia</SelectItem>
                                            <SelectItem value="Insurance Company">Insurance Company</SelectItem>
                                            <SelectItem value="Broker">Broker</SelectItem>
                                            <SelectItem value="Corporate">Corporate</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="org_name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Organization Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Organization Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="org_sub_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Organization Sub Type</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Organization Sub Type"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="location_name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Location Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="location_type"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Type</FormLabel>
                                    <Select
                                        disabled={loading}
                                        onValueChange={field.onChange}
                                        value={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Location Type" />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            <SelectItem value="HO">HO</SelectItem>
                                            <SelectItem value="RO">RO</SelectItem>
                                            <SelectItem value="DO">DO</SelectItem>
                                            <SelectItem value="UO">UO</SelectItem>
                                            <SelectItem value="Branch">Branch</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="location_code"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Location Code</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Location Code"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="emp_code"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Employee Code</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Employee Code"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="department"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Department</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Department"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="designation"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Designation</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Designation"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="mobile"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Mobile No.</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Mobile No."
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="username"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Username</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Username"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="assigned_pol_no"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Assigned Policy No.</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Assigned Policy No."
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="is_online"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Is Online</FormLabel>
                                    <FormControl>
                                        <Controller
                                            name="is_online"
                                            control={form.control}
                                            render={({ field: { onChange, onBlur, value, ref } }) => (
                                                <Checkbox
                                                    onChange={(e) => onChange(e.target.checked)}
                                                    onBlur={onBlur}
                                                    checked={value}
                                                    inputRef={ref}
                                                    disabled={loading}
                                                />
                                            )}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="is_verified"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Is Verified</FormLabel>
                                    <FormControl>
                                        <Controller
                                            name="is_verified"
                                            control={form.control}
                                            render={({ field: { onChange, onBlur, value, ref } }) => (
                                                <Checkbox
                                                    onChange={(e) => onChange(e.target.checked)}
                                                    onBlur={onBlur}
                                                    checked={value}
                                                    inputRef={ref}
                                                    disabled={loading}
                                                />
                                            )}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                    </div>
                    <div className="space-x-4">
                        <Button disabled={loading} className="ml-auto" type="submit">
                            {action}
                        </Button>
                        <Button
                            disabled={loading}
                            className="ml-auto"
                            type="button"
                            onClick={() => {
                                router.back();
                            }}
                        >
                            Cancel
                        </Button>
                    </div>
                </form>
            </Form>
            {initialData && initialData.id && (
                <AlertModal
                    title="Are you sure?"
                    description="This action cannot be undone."
                    name={initialData?.first_name}
                    isOpen={open}
                    onClose={() => setOpen(false)}
                    onConfirm={onDelete}
                    loading={loading}
                />
            )}
        </>
    );
};
