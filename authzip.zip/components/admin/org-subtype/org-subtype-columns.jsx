"use client";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { Checkbox } from "@/components/ui/checkbox";
import { OrgSubTypeCellAction } from "./cell-actions";


export const OrgSubTypeColumns = [
    {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={
              table.getIsAllPageRowsSelected() ||
              (table.getIsSomePageRowsSelected() && "indeterminate")
            }
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
            aria-label="Select all"
            className="translate-y-[2px]"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
            className="translate-y-[2px]"
          />
        ),
        enableSorting: false,
        enableHiding: false,
      },
    {
        accessorKey: "subtype",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Sub type"} />,
        cell: ({ row }) => {
            return <div className="flex items-center">{row.original.subtype}</div>;
        }
    },
    {
        accessorKey: "org_type",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Organization Type"} />
    },
    {
        id: "actions",
        enableSorting: false,
        cell: ({ row }) => <OrgSubTypeCellAction data={row.original} />,
      },
];