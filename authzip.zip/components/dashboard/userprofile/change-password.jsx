"use client";

import { changePasswordForAuthenticatedUser } from '@/app/api/server/route';
import { useSession } from 'next-auth/react';
import { useState } from 'react';


export const ChangePasswordForm = () => {
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const { data: session } = useSession();

  const handleSubmit = async (e) => {
      e.preventDefault();
      setError(null);
      setSuccess(null);

      // Validate inputs
      if (newPassword !== confirmPassword) {
          setError("New password and confirm password do not match.");
          return;
      }

      const formData = {
          old_password: oldPassword,
          new_password: newPassword,
          confirm_password: confirmPassword,
      };

      try {
          const data = await changePasswordForAuthenticatedUser(session.accessToken, formData);
          setSuccess(data.detail);
          // Clear form fields after success
          setOldPassword('');
          setNewPassword('');
          setConfirmPassword('');
      } catch (error) {
          setError(error.response?.data?.detail || 'An error occurred while changing the password.');
      }
  };

  return (
      <form onSubmit={handleSubmit} className="space-y-4">
          <h2 className="text-2xl font-bold">Change Password</h2>
          {error && <p className="text-red-500">{error}</p>}
          {success && <p className="text-green-500">{success}</p>}

          <div className="flex flex-col space-y-2">
              <label htmlFor="oldPassword" className="font-medium">Old Password</label>
              <input
                  type="password"
                  id="oldPassword"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  required
                  className="border rounded p-2"
              />
          </div>

          <div className="flex flex-col space-y-2">
              <label htmlFor="newPassword" className="font-medium">New Password</label>
              <input
                  type="password"
                  id="newPassword"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  className="border rounded p-2"
              />
          </div>

          <div className="flex flex-col space-y-2">
              <label htmlFor="confirmPassword" className="font-medium">Confirm New Password</label>
              <input
                  type="password"
                  id="confirmPassword"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="border rounded p-2"
              />
          </div>

          <button type="submit" className="bg-blue-500 text-white rounded p-2 hover:bg-blue-600">
              Change Password
          </button>
      </form>
  );
};


