"use client";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent, CardDescription, CardFooter, CardTitle } from "@/components/ui/card";
import { useState } from "react";
import { deleteNotificationDetails, markedasReadNotification } from "@/app/api/server/route";
import { useSession } from "next-auth/react";

export default function UserNotificationsDetails({ notificationsData }) {
    const [notifications, setNotifications] = useState(notificationsData || []);
    const { data: session } = useSession();

    // Mark notification as read
    const markAsRead = async (id) => {
        try {
            await markedasReadNotification(session.accessToken, id); // Pass the correct id
            setNotifications((prevNotifications) =>
                prevNotifications.map(notification =>
                    notification.id === id ? { ...notification, read: true } : notification
                )
            );
        } catch (error) {
            console.error("Error marking notification as read", error);
        }
    };

    // Delete notification
    const deleteNotification = async (id) => {
        try {
            await deleteNotificationDetails(session.accessToken, id);
            setNotifications((prevNotifications) =>
                prevNotifications.filter(notification => notification.id !== id)
            );
        } catch (error) {
            console.error("Error deleting notification", error);
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
                <CardDescription>Manage your notification settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <ul>
                    {notifications.map(notification => (
                        <li key={notification.id} style={{ textDecoration: notification.read ? 'line-through' : 'none' }}>
                            <span onClick={() => markAsRead(notification.id)} className="cursor-pointer">
                                {notification.message}
                            </span>
                            <Button onClick={() => deleteNotification(notification.id)} variant="destructive">
                                Delete
                            </Button>
                        </li>
                    ))}
                </ul>
            </CardContent>
        </Card>
    );
}
