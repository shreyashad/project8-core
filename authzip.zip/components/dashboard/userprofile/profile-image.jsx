"use client";
import { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { updateUserProfileData } from '@/app/api/server/route';
import { useSession } from 'next-auth/react';
import { Input } from '@/components/ui/input';
import { Edit, MapPin } from 'lucide-react';

export default function AvatarUpload({ initialImage, accountsData }) {
    const { data: session } = useSession();
    const [file, setFile] = useState(null);
    const [imagePreview, setImagePreview] = useState(initialImage || null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [successMessage, setSuccessMessage] = useState(null);

    const handleImageUpload = (event) => {
        const selectedFile = event.target.files[0];
        console.log("Selected file:", selectedFile); // Log the selected file
    
        if (selectedFile) {
            const validFormats = ['image/jpeg', 'image/png', 'image/gif', 'image/jpg'];
            if (!validFormats.includes(selectedFile.type)) {
                setError("Invalid file type. Please upload a JPG, PNG, or GIF.");
                return;
            }
            setImagePreview(URL.createObjectURL(selectedFile));
            setFile(selectedFile);
            setError(null);
        } else {
            setFile(null); // Reset the file if no file is selected
            setImagePreview(null);
        }
    };

    const handleSave = async () => {
        if (!file) {
            setError("Please select an image before saving.");
            return;
        }

        setLoading(true);
        setError(null);
        setSuccessMessage(null);

        const formData = new FormData();
        formData.append('profile_picture', file); // This should match your Django model field name

        try {
            const response = await updateUserProfileData(session.accessToken, formData)
            setSuccessMessage("Profile picture updated successfully!");
            setImagePreview(response.data.profile_picture); // Update preview with response data
        } catch (error) {
            console.error("Error updating profile picture:", error.response ? error.response.data : error.message);
            setError("Failed to update profile picture.");
        } finally {
            setLoading(false);
        }
    };

  return (
    <div className="px-6 pb-6">
    <div className="flex justify-between items-end -mt-16 relative">
        <div className="relative">
            <Avatar className="h-32 w-32 border-4 border-white cursor-pointer">
                {imagePreview ? (
                    <AvatarImage 
                        src={imagePreview} 
                        alt="User" 
                    />
                ) : (
                    <AvatarFallback>{accountsData.first_name}</AvatarFallback>
                )}
            </Avatar>
            <Input 
                type="file" 
                accept="image/*" 
                onChange={handleImageUpload} 
                className="absolute inset-0 opacity-0 cursor-pointer" 
                onClick={(e) => e.stopPropagation()} // Prevent the input click from bubbling up
            />
            <div className="absolute bottom-0 right-0 p-1 bg-white rounded-full shadow-md cursor-pointer">
                <Edit className="h-5 w-5 text-blue-600" onClick={(e) => { e.stopPropagation(); document.querySelector('input[type="file"]').click(); }} />
            </div>
        </div>
        
        <div className="space-x-2">
            <Button 
                onClick={handleSave} 
                variant="outline"
                disabled={loading}
            >
                {loading ? 'Saving...' : 'Save'}
            </Button>
            {error && <p className="text-red-500">{error}</p>}
            {successMessage && <p className="text-green-500">{successMessage}</p>}
        </div>
    </div>
    <div className="mt-4">
        <h1 className="text-2xl font-bold">{accountsData.first_name} {accountsData.last_name}</h1>
        <p className="text-gray-600">{accountsData.designation}</p>
        <p className="text-gray-600 flex items-center mt-1">
            <MapPin className="h-4 w-4 mr-1" /> {accountsData.location_name}
        </p>
    </div>
</div>

  );
}
