"use client";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";

import { Button } from "@/components/ui/button";
import { Trash } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { useSession } from "next-auth/react";
import { Textarea } from "@/components/ui/textarea";
import { createNewTeam, updateTeamDetails } from "@/app/api/server/route";
import { TeamFormSchema } from "@/schemas";

export const TeamForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Team" : "Create Team";
    const description = initialData && initialData.id ? "Edit an Team" : "Create a new Team";
    const toastMessage = initialData && initialData.id ? "Team updated successfully" : "Team created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(TeamFormSchema),
        defaultValues: initialData || {
            name: "",
            description: "",
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData && initialData.id) {
                await updateTeamDetails(session.accessToken,  initialData.id, values);
                router.refresh(); 
            } else {
                await createNewTeam(session.accessToken,  values);
                router.refresh(); 
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/teams-management/teams-list`);
            router.refresh();
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };

    const onDelete = async () => {
        setLoading(true);
        try {
            await deleteOrganizationDetails(initialData.id, session.accessToken);
            toast.success("Team deleted successfully");
            router.push(`/dashboard/administrator/teams-management/teams-list`);
           
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };

    return (
        <>
            <div className="flex items-center justify-between">
                <DashHeading title={title} description={description} />
                {initialData && initialData.id && (
                    <Button
                        disabled={loading}
                        variant="destructive"
                        size="icon"
                        onClick={() => setOpen(true)}
                    >
                        <Trash className="h-4 w-4" />
                    </Button>
                )}
            </div>
            <Separator />
            <Form {...form}>
                <form
                    onSubmit={form.handleSubmit(onSubmit)}
                    className="w-full space-y-8"
                >
                    <div className="grid-cols-2 gap-8 md:grid">
                        <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Team Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Team Descriptions</FormLabel>
                                    <FormControl>
                                        <Textarea
                                            {...field}
                                            placeholder="Team Description"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        
                    </div>
                    <div className="space-x-4">
                        <Button disabled={loading} className="ml-auto" type="submit">
                            {action}
                        </Button>
                        <Button
                            disabled={loading}
                            className="ml-auto"
                            type="button"
                            onClick={() => {
                                router.back();
                            }}
                        >
                            Cancel
                        </Button>
                    </div>
                </form>
            </Form>
            {initialData && initialData.id && (
                <AlertModal
                    title="Are you Sure"
                    description="This action cannot be undone."
                    name={initialData?.name}
                    isOpen={open}
                    onClose={() => setOpen(false)}
                    onConfirm={onDelete}
                    loading={loading}
                />
            )}
        </>
    );
};
