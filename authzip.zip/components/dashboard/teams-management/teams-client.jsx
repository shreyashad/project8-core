"use client";

import { DashHeading } from "@/components/dashboard/dash-heading";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useRouter } from "next/navigation";





const TeamsClient = () => {
    const router = useRouter();
    return(
        <>
         <div className="flex items-center justify-between">
                <DashHeading 
                    title="All Teams List"
                />
                <Button
                    onClick={() => {
                        router.push("/dashboard/administrator/teams-management/teams-list/new");
                    }}
                >
                    <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
            </div>
        
        </>
    );
}
export default TeamsClient;