from django.shortcuts import render, redirect
from .models import Course, Module, VideoLesson
from .forms import CourseForm, ModuleForm, VideoLessonForm
from django.forms import inlineformset_factory

def create_course(request):
    if request.method == 'POST':
        course_form = CourseForm(request.POST, request.FILES)
        module_formset = inlineformset_factory(Course, Module, form=ModuleForm, extra=1)
        video_formset = inlineformset_factory(Module, VideoLesson, form=VideoLessonForm, extra=1)

        if course_form.is_valid():
            course = course_form.save(commit=False)
            course.created_by = request.user
            course.update_by = request.user
            course.save()

            if module_formset.is_valid() and video_formset.is_valid():
                modules = module_formset.save(commit=False)
                for module in modules:
                    module.course = course
                    module.save()

                videos = video_formset.save(commit=False)
                for video in videos:
                    video.module = modules[0]  # Assuming you want to associate videos with the first module
                    video.save()

                return redirect('course_list')
    else:
        course_form = CourseForm()
        module_formset = inlineformset_factory(Course, Module, form=ModuleForm, extra=1)
        video_formset = inlineformset_factory(Module, VideoLesson, form=VideoLessonForm, extra=1)

    return render(
        request,
        'course/create_course.html',
        {'course_form': course_form, 'module_formset': module_formset, 'video_formset': video_formset}
    )
=-----------------------------------------------
from django import forms
from django.forms import inlineformset_factory
from .models import Course, Module, VideoLesson

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['title', 'description', 'category', 'image', 'duration', 'difficulty_level']

ModuleFormSet = inlineformset_factory(Course, Module, fields=['title', 'description', 'image', 'order'], extra=1, can_delete=True)

VideoLessonFormSet = inlineformset_factory(Module, VideoLesson, fields=['title', 'video_file', 'cover_image', 'order'], extra=1, can_delete=True)
--------------------------------------------------
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Course, Module, VideoLesson
from django.forms import inlineformset_factory
from django.db import transaction

def create_course(request):
    if request.method == 'POST':
        # Process the course data
        course = Course(
            title=request.POST['title'],
            description=request.POST['description'],
            category_id=request.POST['category'],
            image=request.FILES['image'],
            duration=request.POST['duration'],
            difficulty_level=request.POST['difficulty_level'],
            created_by=request.user,
            update_by=request.user
        )
        course.save()

        # Process the modules data
        num_modules = int(request.POST['num_modules'])
        for i in range(num_modules):
            module = Module(
                course=course,
                title=request.POST[f'module_title_{i}'],
                description=request.POST[f'module_description_{i}'],
                image=request.FILES.get(f'module_image_{i}'),
                order=request.POST[f'module_order_{i}'],
                created_by=request.user,
                update_by=request.user
            )
            module.save()

            # Process the video lessons data for each module
            num_videos = int(request.POST[f'num_videos_{i}'])
            for j in range(num_videos):
                video = VideoLesson(
                    module=module,
                    title=request.POST[f'video_title_{i}_{j}'],
                    video_file=request.FILES.get(f'video_file_{i}_{j}'),
                    cover_image=request.FILES.get(f'cover_image_{i}_{j}'),
                    order=request.POST[f'video_order_{i}_{j}'],
                    created_by=request.user,
                    update_by=request.user
                )
                video.save()

        messages.success(request, 'Course created successfully.')
        return redirect('course_list')
    else:
        # Render the form with empty fields
        return render(request, 'course/create_course.html')
--------------------------------------------------------
<!DOCTYPE html>
<html>
<head>
    <title>Create Course</title>
</head>
<body>

<h1>Create Course</h1>

<form method="post" enctype="multipart/form-data">
    {% csrf_token %}
    <!-- Course details -->
    <label for="title">Course Title:</label>
    <input type="text" id="title" name="title" required>

    <label for="description">Description:</label>
    <textarea id="description" name="description" required></textarea>

    <!-- Add other course fields as needed -->

    <!-- Modules -->
    <input type="hidden" name="num_modules" value="1">
    <div class="module-section">
        <h2>Module 1</h2>
        <label for="module_title_0">Module Title:</label>
        <input type="text" id="module_title_0" name="module_title_0" required>

        <label for="module_description_0">Module Description:</label>
        <textarea id="module_description_0" name="module_description_0" required></textarea>

        <!-- Add other module fields as needed -->

        <!-- Video Lessons for Module 1 -->
        <input type="hidden" name="num_videos_0" value="1">
        <div class="video-section">
            <h3>Video Lesson 1</h3>
            <label for="video_title_0_0">Video Title:</label>
            <input type="text" id="video_title_0_0" name="video_title_0_0" required>

            <!-- Add other video fields as needed -->
        </div>
    </div>

    <!-- Add buttons to dynamically add/remove modules and video lessons -->

    <button type="submit">Create Course</button>
</form>

</body>
</html>
-----------------------------------------------------------------
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import CustomUser, Branches, Designation, Departments
from .models import UserProfile

def register(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        branch_id = request.POST.get('branch')  # Assuming branch is an ID, adjust if needed
        department = request.POST.get('department')
        designation_id = request.POST.get('designation')  # Assuming designation is an ID, adjust if needed
        emp_id = request.POST.get('emp_id')
        mobile = request.POST.get('mobile')
        username = request.POST.get('username')
        password = request.POST.get('password')
        password1 = request.POST.get('password1')

        if password1 == password:
            if CustomUser.objects.filter(username=username).exists():
                messages.info(request, 'Username already taken..')
                return render(request, 'accounts/register.html')

            if CustomUser.objects.filter(emp_id=emp_id).exists():
                messages.info(request, 'Employee already registered. Please login to your account!')
                return render(request, 'accounts/register.html')

            try:
                branch = Branches.objects.get(pk=branch_id)
                designation = Designation.objects.get(pk=designation_id)
            except Branches.DoesNotExist:
                messages.error(request, 'Selected branch does not exist.')
                return render(request, 'accounts/register.html')
            except Designation.DoesNotExist:
                messages.error(request, 'Selected designation does not exist.')
                return render(request, 'accounts/register.html')

            user = CustomUser.objects.create_user(
                first_name=first_name, last_name=last_name, branch=branch,
                department=department, designation=designation, emp_id=emp_id,
                mobile=mobile, username=username, password=password
            )

            profile_obj = UserProfile.objects.create(user=user)
            messages.success(request, 'Your account is successfully created.')
            return redirect('login')
        else:
            messages.error(request, 'Password not matching...')
            return render(request, 'accounts/register.html')
    else:
        branches = Branches.objects.all()
        designations = Designation.objects.all()
        departments = Departments.objects.all()
        my_context = {
            'branches': branches,
            'departments': departments,
            'designations': designations,
        }
        return render(request, 'accounts/register.html', context=my_context)
