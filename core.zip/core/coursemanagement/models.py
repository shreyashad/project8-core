from django.db import models
from accounts.models import CustomUser
from django.db.models import Sum
from django.urls import reverse
from autoslug import AutoSlugField
import subprocess
# Create your models here.

class Category(models.Model):
    CATEGORY_STATUS = [
        ('Inactive', 'Inactive'),
        ('Published', 'Published'),

    ]
    name = models.CharField(max_length=100, unique=True)
    slug = AutoSlugField(populate_from='name', unique=True)
    image = models.ImageField(upload_to='course_category_images/', null=True, blank=True)
    description = models.TextField(null=True)
    category_status = models.CharField(max_length=50, choices=CATEGORY_STATUS, default='Inactive')

    def __str__(self):
        return self.name



class Course(models.Model):
    DIFFICULTY_LEVEL = [
        ('Beginner', 'Beginner'),
        ('Intermediate', 'Intermediate'),
        ('Advanced', 'Advanced'),
        ('Expert', 'Expert'),
        ('All Levels', 'All Levels'),
        ('Foundation', 'Foundation'),
        ('Specialization', 'Specialization'),
        ('Certification/Professional', 'Certification/Professional'),
        ('Refresher/Review', 'Refresher/Review'),
        ('Elective', 'Elective')
    ]

    title = models.CharField(max_length=200)
    slug = AutoSlugField(populate_from='title', unique=True)
    description = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.DO_NOTHING)
    image = models.ImageField(upload_to='course_images/', null=True, blank=True)
    duration = models.DurationField()
    difficulty_level = models.CharField(max_length=50,choices=DIFFICULTY_LEVEL)
    is_published = models.BooleanField(default=False)
    created_by = models.ForeignKey(CustomUser, on_delete=models.DO_NOTHING, null=True, related_name='course_created_by')
    created_at = models.DateTimeField(auto_now_add=True)
    update_by = models.ForeignKey(CustomUser, on_delete=models.DO_NOTHING, related_name='course_updated_by')
    last_updated = models.DateTimeField(auto_now=True)


    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reversed('course_details', args=[str(self.slug)])


    def calculate_total_duration(self):
        total_duration = self.module_set.annotate(
            total_duration=Sum('videolesson__duration')
        ).aggregate(total=Sum('total_duration'))['total']
        return total_duration or 0

    def enrollment_count(self):
        return self.course_enroll_set.count()

    def average_rating(self):
        reviews = set.course_review_set.all()
        if reviews:
            total_rating = sum(review.rating for review in reviews)
            return total_rating / len(reviews)
        else:
            return 0

class Module(models.Model):
    course = models.ForeignKey(Course,on_delete=models.CASCADE)
    title = models.CharField(max_length=250)
    description = models.TextField()
    image = models.ImageField(upload_to='module_images/', blank=True, null=True)
    order = models.PositiveIntegerField(default=0)
    created_by = models.ForeignKey(CustomUser, on_delete=models.DO_NOTHING, null=True, related_name='module_created_by')
    created_at = models.DateTimeField(auto_now_add=True)
    update_by = models.ForeignKey(CustomUser, on_delete=models.DO_NOTHING, related_name='module_updated_by')
    last_updated = models.DateTimeField(auto_now=True)
    def __str__(self):
        return f"{self.title}"

    class Meta:
        ordering = ['order']

def get_video_duration(video_file):
    try:
        result = subprocess.run(
            ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1',
             video_file.path],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True
        )
        return float(result.stdout)
    except Exception as e:
        print("Error:",e)
        return 0.0


class VideoLesson(models.Model):
    title = models.CharField(max_length=250)
    video_file = models.FileField(upload_to='lesson_videos',null=True,blank=True)
    cover_image = models.ImageField(upload_to='video_covers',null=True,blank=True)
    duration = models.DurationField(default=0.0)
    module = models.ForeignKey(Module, on_delete=models.CASCADE)
    upload_date = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.DO_NOTHING, related_name='video_lesson_created_by')
    order = models.PositiveIntegerField(default=0)
    update_by = models.ForeignKey(CustomUser, on_delete=models.DO_NOTHING, related_name='video_lesson_updated_by')
    last_updated = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.pk:
            self.duration = get_video_duration(self.video_file)
        super().save(*args,**kwargs)
    class Meta:
        ordering = ['order']


class ModuleResource(models.Model):
    title = models.CharField(max_length=250)
    resource_file = models.FileField(upload_to='lesson_resource')
    module = models.ForeignKey(Module,on_delete=models.CASCADE)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    uploaded_by = models.ForeignKey(CustomUser,on_delete=models.DO_NOTHING, related_name='module_resource_uploaded_by')

    def __str__(self):
        return f"{self.title} - {self.module}"

class Assignment(models.Model):
    title = models.CharField(max_length=255)
    file = models.FileField(upload_to='assignments/')
    module = models.ForeignKey(Module, on_delete=models.CASCADE, related_name='assignments')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    uploaded_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='assignment_uploaded_by')



class UserCourseProgress(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    completed = models.BooleanField(default=False)

class UserModuleProgress(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    module = models.ForeignKey(Module, on_delete=models.CASCADE)
    completed = models.BooleanField(default=False)

class UserVideoProgress(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    video_lesson = models.ForeignKey(VideoLesson, on_delete=models.CASCADE)
    completed = models.BooleanField(default=False)




class Enrollment(models.Model):
    LEARNING_TYPES = [
        ('self_learning', 'Self-learning'),
        ('online_learning', 'Online learning'),
        ('offline_learning', 'Offline learning'),
    ]

    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='course_enrollment_user')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='enrollment_for_course')
    learning_type = models.CharField(max_length=20, choices=LEARNING_TYPES)
    enrolled_at = models.DateTimeField(auto_now_add=True)
    completed = models.BooleanField(default=False)

    class Meta:
        unique_together = ('user', 'course', 'learning_type')


class CourseRating(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    employee = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    rating = models.PositiveBigIntegerField(default=0)
    reviews = models.TextField(null=True)
    review_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "7. Student Rating"

    def __str__(self):
        return f"{self.course}-{self.employee}-{self.rating}"



