from django.urls import path
from . import views
urlpatterns = [
    path('badges-list', views.badges, name='add_badges'),
    path('badges/edit/<int:badge_id>/', views.edit_badge, name='edit_badge'),
    path('badges/delete/<int:badge_id>/', views.delete_badge, name='delete_badge'),
]