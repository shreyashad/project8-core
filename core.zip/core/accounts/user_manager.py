from django.contrib.auth.models import BaseUserManager
from django.db import models

class CustomUserManager(BaseUserManager):
    def create_user(self, username, password, **extr_fields):
        if not username:
            raise ValueError('Username field must be set')
        user = self.model(username=username, **extr_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user


    def create_superuser(self, username, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.pop('branch', None)
        extra_fields.pop('department', None)
        extra_fields.pop('designation', None)

        return self.create_user(username, password, **extra_fields)