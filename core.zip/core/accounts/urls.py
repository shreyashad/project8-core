from django.urls import path
from . import views
urlpatterns = [
    path('', views.custom_login, name='custom_login'),
    path('register', views.register, name='register'),
    path('custom_logout', views.cust_logout, name='custom_logout'),
]
