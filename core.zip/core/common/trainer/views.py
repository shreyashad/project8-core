from accounts.models import CustomUser, UserProfile, Skill
from common.models import *
from accounts.decorators import login_required_as_role
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from datetime import datetime


@login_required_as_role('hod')
def dashboard(request):
    return render(request, 'hod/dashboard.html')