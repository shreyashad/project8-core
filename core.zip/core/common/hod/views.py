from accounts.models import *
from common.models import *
from accounts.decorators import login_required_as_role
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from datetime import datetime


@login_required_as_role('hod')
def dashboard(request):
    hod = request.user
    active_user = CustomUser.objects.filter(branch=hod.branch,department=hod.department,is_active=True).count()
    today_wisdom = DailyWise.objects.latest('created_date')
    my_context = {
        'active_user': active_user,
        'today_wisdom': today_wisdom,
    }
    return render(request, 'hod/dashboard.html',context=my_context)


# def training_request(request):
#     user = request.user
#     training_data = (
#         TrainingRequest.objects
#         .filter(sender=user)
#         .order_by('-request_date')
#         .select_related('requested_program')  # Use select_related to fetch related Course objects in a single query
#         .prefetch_related('training_reply')  # Use prefetch_related to fetch related TrainingRequestReply objects
#     )
#     return render(request, 'hod/all_training_request.html', {'training_data': training_data})

@login_required_as_role('hod')
def training_request(request):
    employees = CustomUser.objects.filter(roles='employee')
    admin_trainers = CustomUser.objects.filter(roles='trainers_admin')
    training_name = Course.objects.values('title')
    my_context = {
        'employees': employees,
        'admin_trainers': admin_trainers,
        'training_name': training_name,

    }
    return render(request, 'hod/all_training_request.html',context=my_context)



@login_required_as_role('hod')
def training_inbox(request):
    user = request.user
    training_data = (TrainingRequest.objects
                     .filter(sender=user)
                     .order_by('-request_date')

                     )
    return render(request, 'hod/allinbox.html', {'training_data': training_data})



@login_required_as_role('hod')
def create_training_request(request):
    if request.method == 'POST':
        training_type = request.POST.get('training_type')
        receiver = request.POST.get('receiver')
        receiver_type = request.POST.get('receiver_type')
        request_program = request.POST.get('requested_program')
        message = request.POST.get('message')
        employees_ids = request.POST.getlist('employees')

        try:
            requested_program = Course.objects.get(pk=request_program)
        except Course.DoesNotExist:
            message.error('Invalid requested program')
            return render(request, 'hod/new_training_request.html')

        training_request = TrainingRequest.objects.create(
            sender=request.user.username,
            receiver_type=receiver_type,
            training_type=training_type,
            receiver=receiver,
            requested_program=requested_program,
            message=message
        )
        training_request.emloyees.set(employees_ids)
        messages.success(request,'Training request sent successfully!')
        return redirect('hod_dashboard')


    return render(request,'hod/all_training_request.html')

@login_required_as_role('hod')
def user_list(request):
    return render(request,'hod/user_list.html')



@login_required_as_role('hod')
def change_password(request):
    if request.method == 'POST':
        old_password = request.POST.get('old_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')
        if not request.user.check_password(old_password):
            messages.error(request,'Old password is incorrect')
            return redirect('change_password_hod')
        if new_password != confirm_password:
            messages.error(request, 'New password and confirmation do not match.')
            return redirect('change_password_hod')

        request.user.set_password(new_password)
        request.user.save()

        update_session_auth_hash(request, request.user)
        messages.success(request, 'Password changed successfully')
        return redirect('change_password_hod')
    return render(request, 'hod/change_password.html')


@login_required_as_role('hod')
def my_profile(request):
    user = request.user
    profile = get_object_or_404(UserProfile, user=user)
    hod_teams = Team.objects.filter(hod=user)
    team_info_list = []
    for team in hod_teams:
        member_count = team.members.count()
        team_info_list.append({'name': team.name, 'member_count': member_count})
    user_skills = profile.skills.all()

    my_context = {
        'user_profile': profile,
        'hod_teams': team_info_list,
        'user_skills': user_skills,
    }
    return render(request, 'hod/my_profile.html', context=my_context)



@login_required_as_role('hod')
def update_profile(request):
    user = request.user
    profile = get_object_or_404(UserProfile, user=user)
    if request.method == 'POST':
        date_of_birth = request.POST.get('date_of_birth')
        gender = request.POST.get('gender')
        email = request.POST.get('email')
        bio = request.POST.get('bio')
        address = request.POST.get('address')
        photo = request.FILES.get('photo')
        skills = request.POST.getlist('skills')

        if date_of_birth and not date_of_birth_valid(date_of_birth):
            messages.error(request,'Invalid date of birth format.')
            return redirect('update_profile_hod')

        if gender and gender not in ['male', 'female', 'other']:
            messages.error(request, 'Invalid gender value.')
            return redirect('update_profile')

        if email and not email_valid(email):
            messages.error(request, 'Invalid email address.')
            return redirect('update_profile')


        if date_of_birth != profile.date_of_birth:
            profile.date_of_birth = date_of_birth

        if gender != profile.gender:
            profile.gender = gender

        if email != profile.email:
            profile.email = email

        if bio != profile.bio:
            profile.bio = bio

        if address != profile.address:
            profile.address = address

        if photo:
            profile.photo = photo

        if skills != [str(skill.id) for skill in profile.skills.all()]:
            profile.skills.set(skills)

        profile.save()
        messages.success(request, 'Profile updated Successfully')
        return redirect('hod_profile')
    skills = Skill.objects.all()

    return render(request,'update_profile.html',{'user_profile': profile, 'skills': skills})




@login_required_as_role('hod')
def date_of_birth_valid(date_str):
    try:
        datetime.datetime.strptime(date_str, '%Y-%m-%d')
        return True
    except ValueError:
        return False

def email_valid(email):
    try:
        validators.validate_email(email)
        return True
    except ValidationError:
        return False


@login_required_as_role('hod')
def executive_list(request):
    # to display online users
    hod_branch = request.user.branch
    hod_department = request.user.department
    all_users = CustomUser.objects.filter(branch=hod_branch, department=hod_department, is_verified=True).values()
    new_users = CustomUser.objects.filter(branch=hod_branch, department=hod_department, is_verified=False).values()

    mycontext = {
        'new_users':new_users,
        'all_users': all_users,

        'active_page': 'dashboard',
    }
    return render(request, 'hod/executive_list.html', context=mycontext)





@login_required_as_role('tariners_admin')
def approve_user(request,user_id):
    try:
        emp = CustomUser.objects.get(id=user_id)
    except CustomUser.DoesNotExist:
        # Handle the case when the video lesson does not exist
        messages.error(request, 'User does not exist')
        return redirect('executive_list')  # Redirect to a course list view or another appropriate page
    if request.method =='POST':
        role = request.POST.get('role')
        is_verified = request.POST.get('is_verified')
        emp.role = role
        emp.is_verified = is_verified
        emp.save()
        messages.success(request, 'user has been approved')
        return redirect('executive_list')
    return render(request, 'groupLeader/approve_user.html', {'emp': emp})
