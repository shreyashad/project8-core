from accounts.models import *
from common.models import *
from accounts.decorators import login_required_as_role
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from datetime import datetime


@login_required_as_role('trainers_admin')
def dashboard(request):
    today_wisdom = DailyWise.objects.latest('created_date')
    available_trainer = CustomUser.objects.filter(roles='trainer').count()
    online_user = CustomUser.objects.filter(is_online=True).count()

    my_context = {
        'today_wisdom': today_wisdom,
        'available_trainer': available_trainer,
        'online_user': online_user,
    }
    return render(request, 'trainers_admin/dashboard.html', context=my_context)

@login_required_as_role('trainers_admin')
def todays_wisdom(request):
    if request.method == 'POST':
        topic = request.POST.get('today_wisdom')
        if topic:
            daily_wisdom = DailyWise.objects.create(topic=topic,created_by=request.user)
            daily_wisdom.save()
    return redirect('trainers_admin_dashboard')


@login_required_as_role('trainers_admin')
def my_profile(request):
    user = request.user
    profile = get_object_or_404(UserProfile, user=user)
    return render(request, 'trainers_admin/my_profile.html', {'user_profile': profile})