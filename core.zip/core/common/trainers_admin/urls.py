from django.urls import path
from . import views
urlpatterns = [
    path('trainers-admin-dashboard', views.dashboard, name='trainers_admin_dashboard'),
    path('todays-wisdom', views.todays_wisdom, name='todays_wisdom'),

]