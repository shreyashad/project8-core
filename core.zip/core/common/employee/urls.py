from django.urls import path
from . import views
urlpatterns = [
    path('employee-dashboard', views.dashboard, name='employee_dashboard'),
    path('my-learnings', views.my_learning, name='my_learnings'),

]