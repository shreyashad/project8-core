from django.db import models
from accounts.models import CustomUser
from coursemanagement.models import Course
from django.utils import timezone
# Create your models here.

class TrainingRequest(models.Model):
    STATUS_CHOICES =[
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    TrainingType = [
        ('online', 'Online'),
        ('classroom', 'Classroom'),
        ('self-learning', 'self-learning')
    ]
    sender = models.ForeignKey(CustomUser,on_delete=models.DO_NOTHING,related_name='request_sender')
    receiver = models.ForeignKey(CustomUser,on_delete=models.DO_NOTHING, related_name='request_receiver')
    subject = models.CharField(max_length=250,blank=True,)
    training_type = models.CharField(max_length=20, choices=TrainingType)
    requested_program = models.ForeignKey(Course, on_delete=models.CASCADE)
    message = models.TextField()
    employees = models.ManyToManyField(CustomUser, related_name='training_requests_for')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    request_date = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)
    def __str__(self):
        return f"Request from {self.sender} to {self.receiver} for {self.requested_program}"

class TrainingRequestReply(models.Model):
    request = models.ForeignKey(TrainingRequest,on_delete=models.CASCADE,related_name='training_reply')
    sender = models.ForeignKey(CustomUser,on_delete=models.CASCADE, related_name='reply_by_user')
    message = models.TextField()
    reply_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Reply from {self.sender} to Request{self.request}"



class TrainingRoom(models.Model):
    name = models.CharField(max_length=100,unique=True)
    capacity = models.PositiveIntegerField()
    is_booked = models.BooleanField(default=False)

    def __str__(self):
         return self.name



class RoomAvailability(models.Model):
    room = models.ForeignKey(TrainingRoom, on_delete=models.CASCADE)
    date = models.DateField()
    is_available = models.BooleanField(default=True)
    description = models.TextField()

    def __str__(self):
        status = "Available" if self.is_available else "Not Available"
        return f"{self.room} - {self.date} - {status}"



class TrainingScheduling(models.Model):
    training_request = models.OneToOneField(TrainingRequest, on_delete=models.CASCADE)
    room = models.ForeignKey(TrainingRoom, on_delete=models.CASCADE)
    trainer = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    start_date_time = models.DateTimeField()
    end_date_time = models.DateTimeField()
    agenda = models.TextField()
    created_date = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(CustomUser,on_delete=models.DO_NOTHING,related_name='scheduling_request')

    def __str__(self):
        return f"Scheduled Training for {self.training_request.requested_program} on {self.start_date_time}"



class TrainingExecution(models.Model):
    training_schedule = models.OneToOneField(TrainingScheduling, on_delete=models.CASCADE)
    actual_start_time = models.DateTimeField(default=timezone.now)
    actual_end_time = models.DateTimeField(null=True, blank=True)
    attendance = models.ManyToManyField(CustomUser, related_name='attended_trainings')
    feedback = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Training Execution for {self.training_schedule.training_request.requested_program} on {self.actual_start_time}"






class Certification(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.name


class Trainer(CustomUser):
    is_trainer = models.BooleanField(default=True)
    specialization = models.CharField(max_length=100)
    certifications = models.ManyToManyField('Certification')

class TrainerAdmin(CustomUser):
    admin_level = models.IntegerField()
    is_trainer_admin = models.BooleanField(default=True)

class HOD(CustomUser):
    department_head = models.BooleanField(default=True)
    office_location = models.CharField(max_length=255)

class Examiner(CustomUser):
    examiner_id = models.CharField(max_length=15, unique=True)
    evaluation_criteria = models.TextField()



class DailyWise(models.Model):
    topic = models.TextField()
    created_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    created_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.topic}"