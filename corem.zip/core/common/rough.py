# views.py
from django.shortcuts import render, redirect
from .models import TrainingRequest, CustomUser, Course
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseBadRequest

@login_required
def send_training_request(request):
    if request.method == 'POST':
        receiver_type = request.POST.get('receiver_type')
        training_type = request.POST.get('training_type')
        requested_program_id = request.POST.get('requested_program')
        message = request.POST.get('message')
        employee_ids = request.POST.getlist('employees')

        # Validate the form data as needed

        try:
            requested_program = Course.objects.get(pk=requested_program_id)
        except Course.DoesNotExist:
            return HttpResponseBadRequest("Invalid requested program.")

        training_request = TrainingRequest.objects.create(
            sender=request.user,
            receiver_type=receiver_type,
            training_type=training_type,
            requested_program=requested_program,
            message=message,
        )

        training_request.employees.set(employee_ids)

        messages.success(request, 'Training request sent successfully!')
        return redirect('employee_dashboard')  # Replace with your employee dashboard URL

    # Fetch employees for the form
    employees = CustomUser.objects.filter(user_type='employee')  # Adjust based on your model

    return render(request, 'send_training_request.html', {'employees': employees})



def change_password(request):
    if request.method == 'POST':
        old_password = request.POST['old_password']
        new_password = request.POST['new_password']
        confirm_password = request.POST['confirm_password']

        # Check if the old password matches the user's current password
        if not request.user.check_password(old_password):
            messages.error(request, 'Old password is incorrect.')
            return redirect('change_password')

        # Check if the new password and confirmation match
        if new_password != confirm_password:
            messages.error(request, 'New password and confirmation do not match.')
            return redirect('change_password')

        # Change the user's password
        request.user.set_password(new_password)
        request.user.save()

        # Update the user's session to prevent them from being logged out
        update_session_auth_hash(request, request.user)
        messages.success(request, 'Password changed successfully.')
        return redirect('change_password')

    return render(request, 'groupLeader/change_password.html')



def updateProfile(request):
    user = request.user
    profile = get_object_or_404(Profile, user=user)
    if request.method == 'POST':
        imobile_no = request.POST.get('mobile_no')
        if not imobile_no:
            imobile_no = profile.mobile_no if profile else None
        iaddress = request.POST.get('address')
        if not iaddress:
            iaddress = profile.address if profile else None

        profile.mobile_no = imobile_no
        profile.address = iaddress
        profile.save()

        messages.success(request, 'Profile updated Successfully..!')
    else:
        messages.error(request, 'Error in updating your profile')
        return render(request, 'groupLeader/profile.html')
    context = {
        'profile': profile,
    }
    return render(request, 'groupLeader/profile.html', context=context)

from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseBadRequest
from .models import UserProfile, Skill

@login_required
def update_profile(request):
    user_profile = request.user.profile

    if request.method == 'POST':
        date_of_birth = request.POST.get('date_of_birth', '')
        gender = request.POST.get('gender', '')
        email = request.POST.get('email', '')
        bio = request.POST.get('bio', '')
        address = request.POST.get('address', '')
        photo = request.FILES.get('photo')
        skills = request.POST.getlist('skills')

        # Validate the form data
        if date_of_birth and not date_of_birth_valid(date_of_birth):
            messages.error(request, 'Invalid date of birth format. Use YYYY-MM-DD.')
            return redirect('update_profile')

        if gender and gender not in ['male', 'female', 'other']:
            messages.error(request, 'Invalid gender value.')
            return redirect('update_profile')

        if email and not email_valid(email):
            messages.error(request, 'Invalid email address.')
            return redirect('update_profile')

        # Other validation as needed

        # Update the profile fields only if they have changed
        if date_of_birth != user_profile.date_of_birth:
            user_profile.date_of_birth = date_of_birth

        if gender != user_profile.gender:
            user_profile.gender = gender

        if email != user_profile.email:
            user_profile.email = email

        if bio != user_profile.bio:
            user_profile.bio = bio

        if address != user_profile.address:
            user_profile.address = address

        if photo:
            user_profile.photo = photo

        if skills != [str(skill.id) for skill in user_profile.skills.all()]:
            user_profile.skills.set(skills)

        user_profile.save()

        messages.success(request, 'Profile updated successfully!')
        return redirect('profile')  # Replace with your profile view URL

    skills = Skill.objects.all()  # Fetch all available skills

    return render(request, 'update_profile.html', {'user_profile': user_profile, 'skills': skills})

def date_of_birth_valid(date_str):
    try:
        datetime.datetime.strptime(date_str, '%Y-%m-%d')
        return True
    except ValueError:
        return False

def email_valid(email):
    try:
        validators.validate_email(email)
        return True
    except ValidationError:
        return False
