from django.contrib import admin
from .models import *
# Register your models here.
@admin.register(TrainingRequest)
class TrainingRequestAdmin(admin.ModelAdmin):
    list_display = ['sender', 'receiver', 'requested_program', 'training_type', 'is_read']

@admin.register(TrainingRoom)
class TrainingRoomAdmin(admin.ModelAdmin):
    list_display = ['name', 'is_booked']

@admin.register(TrainingRequestReply)
class TrainingRequestReply(admin.ModelAdmin):
    list_display = ['request','sender','reply_date']


@admin.register(TrainingScheduling)
class ScheduleTrainingAdmin(admin.ModelAdmin):
    list_display = ['room', 'start_date_time', 'end_date_time', 'trainer']

@admin.register(DailyWise)
class DailyWiseAdmin(admin.ModelAdmin):
    list_display = ['topic','created_by','created_date']