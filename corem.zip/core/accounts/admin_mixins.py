# myapp/admin_mixins.py
from import_export import resources

class ImportExportModelAdminMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.resource_class = resources.ModelResource
