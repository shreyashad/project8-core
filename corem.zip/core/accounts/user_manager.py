from django.contrib.auth.models import BaseUserManager
from django.db import models
from accounts.models import Branches,Designation,Departments
