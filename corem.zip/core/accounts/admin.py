from django.contrib import admin
from django import forms
from .models import *
from import_export.admin import ImportExportActionModelAdmin
# Register your models here.


class CustomUserAdminForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = '__all__'

    roles = forms.ModelChoiceField(queryset=Roles.objects.all(), to_field_name='name')

class CustomUserAdmin(ImportExportActionModelAdmin,admin.ModelAdmin):
    form = CustomUserAdminForm
    list_display = ['username', 'is_online', 'is_verified', 'roles']

class UserProfileAdmin(ImportExportActionModelAdmin,admin.ModelAdmin):
    list_display = ['user', 'photo','gender']

class BranchAdmin(ImportExportActionModelAdmin,admin.ModelAdmin):
    list_display = ['name']

class DepartmentAdmin(ImportExportActionModelAdmin,admin.ModelAdmin):
    list_display = ['name']

class DesignationAdmin(ImportExportActionModelAdmin,admin.ModelAdmin):
    list_display = ['name']


class RolesAdmin(ImportExportActionModelAdmin,admin.ModelAdmin):
    list_display = ['name']


class TeamsAdmin(ImportExportActionModelAdmin,admin.ModelAdmin):
    list_display = ['name']

class SkillsAdmin(ImportExportActionModelAdmin,admin.ModelAdmin):
    list_display = ['name']


admin.site.register(CustomUser, CustomUserAdmin)
admin.site.register(UserProfile, UserProfileAdmin)
admin.site.register(Branches, BranchAdmin)
admin.site.register(Departments, DepartmentAdmin)
admin.site.register(Designation, DesignationAdmin)
admin.site.register(Roles, RolesAdmin)
admin.site.register(Team, TeamsAdmin)
admin.site.register(Skill, SkillsAdmin)
