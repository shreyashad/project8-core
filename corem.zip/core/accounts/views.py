from django.shortcuts import render, redirect,get_object_or_404
from .models import *
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import SetPasswordForm

# Create your views here.




def register(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        branch_name = request.POST.get('branch')
        department_name = request.POST.get('department')
        designation_name = request.POST.get('designation')
        emp_id = request.POST.get('emp_id')
        mobile = request.POST.get('mobile')
        username = request.POST.get('username')
        password = request.POST.get('password')
        password1 = request.POST.get('password1')

        # Check if passwords match
        if password != password1:
            messages.error(request, 'Passwords do not match.')
            return redirect('register')

        # Check if username already exists
        if CustomUser.objects.filter(username=username).exists():
            messages.error(request, 'Username already taken.')
            return redirect('register')

        # Attempt to create the user
        try:
            user = CustomUser.objects.create_user(
                username=username, password=password, first_name=first_name, last_name=last_name,
                branch_name=branch_name, department_name=department_name, designation_name=designation_name,
                emp_id=emp_id, mobile=mobile
            )
            messages.success(request, 'Your account has been successfully created.')
            return redirect('custom_login')
        except (ValueError, Branches.DoesNotExist, Departments.DoesNotExist, Designation.DoesNotExist) as e:
            messages.error(request, str(e))
            return redirect('register')
    else:
        branches = Branches.objects.all()
        designations = Designation.objects.all()
        departments = Departments.objects.all()
        return render(request, 'accounts/register.html', {'branches': branches, 'departments': departments, 'designations': designations})


#
# def custom_login(request):
#     if request.method == 'POST':
#         username = request.POST.get('username')
#         password = request.POST.get('password')
#
#         user = authenticate(username=username,password=password)
#         if user is not None:
#             if not user.is_verified:
#                 messages.info(request,'Profile is not verified please contact your hod')
#                 return render(request,'accounts/login.html')
#
#             user.is_online = True
#             user.save()
#
#             role = user.roles
#             if role == 'administrator':
#                 login(request, user)
#                 return redirect('admin_dashboard')
#             elif role == 'hod':
#                 login(request, user)
#                 return redirect('hod_dashboard')
#             elif role == 'trainers_admin':
#                 login(request, user)
#                 return redirect('trainers_admin_dashboard')
#             elif role == 'trainer':
#                 login(request, user)
#                 return redirect('trainers_dashboard')
#             else:
#                 login(request, user)
#                 return redirect('employee_dashboard')
#         else:
#             messages.error(request,'Invalid username or password. Please try again')
#             return render(request, 'accounts/login.html')
#     else:
#         return render(request, 'accounts/login.html')




def custom_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        if user is not None:
            if not user.is_verified:
                messages.info(request, 'Profile is not verified. Please contact your HOD.')
                return render(request, 'accounts/login.html')

            user.is_online = True
            user.save()

            role_dashboard_mapping = {
                'Administrator': 'admin_dashboard',
                'HOD': 'hod_dashboard',
                'Trainers Admin': 'trainers_admin_dashboard',
                'Trainer': 'trainers_dashboard',
                'Examiner': 'examiners_dashboard',
            }
            default_dashboard = 'employee_dashboard'
            role = user.roles
            dashboard_url = role_dashboard_mapping.get(role, default_dashboard)
            login(request, user)
            return redirect(dashboard_url)
        else:
            messages.error(request, 'Invalid username or password. Please try again.')
            return render(request, 'accounts/login.html')
    else:
        return render(request, 'accounts/login.html')



def cust_logout(request):
    user = request.user
    user.is_online = False
    user.save()
    logout(request)
    return redirect('custom_login')


def forgot_password(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        emp_id = request.POST.get('emp_id')
        mobile = request.POST.get('mobile')

        try:
            user = CustomUser.objects.get(username=username,emp_id=emp_id,mobile=mobile)
        except CustomUser.DoesNotExist:
            messages.error(request, 'Invalid credentials. Please try again')
            return render(request, 'accounts/forget_password.html')

        request.session['reset_user_id'] = user.id
        return redirect('reset_password')
    return render(request,'accounts/forget_password.html')

def rest_password(request):
    user_id = request.session.get('reset_user_id')
    if not user_id:
        return redirect('forget_password')
    user = CustomUser.objects.get(pk=user_id)
    if request.method == 'POST':
        form = SetPasswordForm(user, request.POST)
        if form.is_valid():
            form.save()
            del request.session['reset_user_id']
            messages.success(request,'Your password has been reset successfully ')
            return redirect('custom_login')
        else:
            form = SetPasswordForm(user)
        return render(request, 'accounts/reset_password.html', {'form': form})