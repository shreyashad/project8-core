from django.contrib import admin
from .models import *
from import_export.admin import ImportExportActionModelAdmin

# Register your models here.

class NotificationAdmin(ImportExportActionModelAdmin,admin.ModelAdmin):
    list_display = ['user','message','timestamp','is_read']


admin.site.register(Notification, NotificationAdmin)