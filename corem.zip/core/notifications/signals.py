from django.db.models.signals import post_save
from django.dispatch import receiver
from coursemanagement.models import Course
from common.models import TrainingRequest
from notifications.models import Notification
from accounts.models import CustomUser




@receiver(post_save, sender=TrainingRequest)
def create_training_request_notification(sender, instance, created, **kwargs):
    if created:
        message = f"New training request submitted: {instance.message}"
        Notification.objects.create(user=instance.receiver, message=message)


@receiver(post_save, sender=CustomUser)
def send_user_verification_notification(sender, instance, created, **kwargs):
    if created:
        # Find the custom admin user
        custom_admin = CustomUser.objects.filter(roles='Administrator').first()

        if custom_admin:
            # Create the notification message
            message = f"New user '{instance.username}' has registered. Please verify the user."

            # Create the notification object
            Notification.objects.create(user=custom_admin, message=message)


@receiver(post_save, sender=CustomUser)
def notify_hod_of_new_user(sender, instance, created, **kwargs):
    if created:
        # Get the teams associated with the user
        user_teams = instance.teams.all()

        # Iterate over each team and send notification to its HOD
        for team in user_teams:
            hod = team.hod
            if hod:
                message = f"New user '{instance.username}' has registered. Please verify the user."
                Notification.objects.create(user=hod, message=message)