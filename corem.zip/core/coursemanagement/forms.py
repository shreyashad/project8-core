from django import forms
from django.forms import inlineformset_factory
from .models import *




class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['title', 'description', 'category', 'image', 'difficulty_level']

ModuleFormSet = inlineformset_factory(Course, Module, fields=['title', 'description', 'image', 'order'], extra=1,can_delete=True)

VideoLessonFormSet = inlineformset_factory(Module, VideoLesson, fields=['title', 'video_file', 'cover_image', 'order'], extra=1, can_delete=True)





class ModuleForm(forms.ModelForm):
    class Meta:
        model = Module
        fields = ['title', 'description', 'image', 'order','course']



class VideoLessonForm(forms.ModelForm):
    class Meta:
        model = VideoLesson
        fields = ['title', 'video_file', 'cover_image', 'order', 'module']

