from django.urls import path
from . import views
urlpatterns = [
    # Course Category related
    path('course-category-list', views.course_category_list, name='course_category_list'),
    path('add-course-category', views.create_course_category, name='create_course_category'),
    path('course_category/<int:category_id>/delete', views.delete_course_category, name='delete_course_category'),
    path('course_category/<int:category_id>/update', views.update_course_category, name='update_course_category'),
    # Course related
    path('create-course', views.create_course, name='create_course'),
    path('course-list', views.course_list, name='course_list'),

]