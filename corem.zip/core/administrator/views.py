from accounts.models import *
from common.models import *
from accounts.decorators import login_required_as_role
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from datetime import datetime
# Create your views here.


def dashboard(request):
    online_users = CustomUser.objects.filter(is_online=True).count()

    my_context = {
        'online_users': online_users,
    }
    return render(request, 'administrator/dashboard.html', context=my_context)

# Organization Menu

# Branch related
def branch_list(request):
    branches = Branches.objects.all()
    return render(request, 'administrator/branch_list.html', {'branches': branches})


def create_branch(request):
    if request.method == 'POST':
        name = request.POST.get('branch_name')
        branch = Branches.objects.create(name=name)
        branch.save()
    return redirect('branch_list')


def delete_branch(request, branch_id):
    branch = get_object_or_404(Branches, pk=branch_id)
    if request.method == 'POST':
        branch.delete()
        messages.success(request, "Branch deleted successfully.")
    return redirect('branch_list')


def update_branch(request, branch_id):
    branch = get_object_or_404(Branches, pk=branch_id)
    if request.method == 'POST':
        name = request.POST.get('branch_name')
        branch.name = name
        branch.save()
        messages.success(request, "Branch updated successfully.")
    return redirect('branch_list')

# Department related
def department_list(request):
    department = Departments.objects.all()
    return render(request, 'administrator/department_list.html', {'departments': department})


def create_department(request):
    if request.method == 'POST':
        name = request.POST.get('department')
        department = Departments.objects.create(name=name)
        department.save()
    return redirect('department_list')


def delete_department(request, dept_id):
    department = get_object_or_404(Departments, pk=dept_id)
    if request.method == 'POST':
        department.delete()
        messages.success(request, "Department deleted successfully.")
    return redirect('department_list')


def update_department(request, dept_id):
    department = get_object_or_404(Departments, pk=dept_id)
    if request.method == 'POST':
        name = request.POST.get('branch_name')
        department.name = name
        department.save()
        messages.success(request, "Department updated successfully.")
        return redirect('department_list')
    return render(request, 'administrator/update_department.html', {'department': department})

# Designation related
def designation_list(request):
    designation = Designation.objects.all()
    return render(request, 'administrator/designation_list.html', {'designation_list': designation})


def create_designation(request):
    if request.method == 'POST':
        name = request.POST.get('designation')
        designation = Designation.object.create(name=name)
        designation.save()
        return redirect('designation_list')


def delete_designation(request, designation_id):
    designation = get_object_or_404(Designation, pk=designation_id)
    if request.method == 'POST':
        designation.delete()
        messages.success(request, "Designation deleted successfully.")
    return redirect('designation_list')


def update_designation(request, designation_id):
    designation = get_object_or_404(Designation, pk=designation_id)
    if request.method == 'POST':
        name = request.POST.get('designation_name')
        designation.name = name
        designation.save()
        messages.success(request, "Designation updated successfully.")
        return redirect('designation_list')
    return render(request, 'administrator/update_designation.html', {'designation': designation})

# User Roles related
def roles_list(request):
    roles = Roles.objects.all()
    return render(request, 'administrator/roles_list.html', {'roles': roles})


def create_roles(request):
    if request.method == 'POST':
        name = request.POST.get('branch_name')
        roles = Roles.objects.create(name=name)
        roles.save()

    return redirect('roles_list')


def delete_roles(request, roles_id):
    roles = get_object_or_404(Branches, pk=roles_id)
    if request.method == 'POST':
        roles.delete()
        messages.success(request, "Role deleted successfully.")
    return redirect('roles_list')


def update_roles(request, roles_id):
    roles = get_object_or_404(Roles, pk=roles_id)
    if request.method == 'POST':
        name = request.POST.get('roles_name')
        roles.name = name
        roles.save()
        messages.success(request, "Roles updated successfully.")
        return redirect('roles_list')
    return render(request, 'administrator/update_roles.html', {'roles': roles})

# user Permissions related
def permission_list(request):
    permission = Permission.objects.all()
    return render(request, 'administrator/permission_list.html', {'permission': permission})


def create_permission(request):
    if request.method == 'POST':
        name = request.POST.get('permission_name')
        permission = Permission.objects.create(name=name)
        permission.save()

    return redirect('permission_list')


def delete_permission(request, permission_id):
    permission = get_object_or_404(Permission, pk=permission_id)
    if request.method == 'POST':
        permission.delete()
        messages.success(request, "Permission deleted successfully.")
    return redirect('permission_list')


def update_permission(request, permission_id):
    permission = get_object_or_404(Permission, pk=permission_id)
    if request.method == 'POST':
        name = request.POST.get('permission_name')
        permission.name = name
        permission.save()
        messages.success(request, "Permission updated successfully.")
        return redirect('permission_list')
    return render(request, 'administrator/update_permission.html', {'permission': permission})


# skills related
def skills_list(request):
    skill = Skill.objects.all()
    return render(request, 'administrator/skill_list.html', {'skill': skill})


def create_skill(request):
    if request.method == 'POST':
        name = request.POST.get('skill_name')
        skill = Skill.objects.create(name=name)
        skill.save()

    return redirect('skill_list')


def delete_skill(request, skill_id):
    skill = get_object_or_404(Skill, pk=skill_id)
    if request.method == 'POST':
        skill.delete()
        messages.success(request, "Skill deleted successfully.")
    return redirect('skill_list')


def update_skill(request, skill_id):
    skill = get_object_or_404(Skill, pk=skill_id)
    if request.method == 'POST':
        name = request.POST.get('skill_name')
        skill.name = name
        skill.save()
        messages.success(request, "Skill updated successfully.")
        return redirect('skill_list')
    return render(request, 'administrator/update_skill.html', {'skill': skill})


# Teams related
def team_list(request):
    team = Team.objects.all()
    return render(request, 'administrator/team_list.html', {'team': team})


def create_team(request):
    if request.method == 'POST':
        name = request.POST.get('team_name')
        employees_usernames = request.POST.getlist('employee_list')
        hod_username = request.POST.get('hod')

        try:
            hod = CustomUser.objects.get(username=hod_username)
        except Course.DoesNotExist:
            messages.error('Invalid hod')
            return redirect('team_list')

        employees = CustomUser.objects.filter(username__in=employees_usernames)
        team = Team.objects.create(name=name,hod=hod)
        team.employee.set(employees)
        team.save()

    return redirect('team_list')


def delete_team(request, team_id):
    team = get_object_or_404(Team, pk=team_id)
    if request.method == 'POST':
        team.delete()
        messages.success(request, "Team deleted successfully.")
    return redirect('skill_list')


def update_team(request, team_id):
    team = get_object_or_404(Team, pk=team_id)

    if request.method == 'POST':
        name = request.POST.get('team_name')
        employees_usernames = request.POST.getlist('employee_list')
        hod_username = request.POST.get('hod')

        try:
            hod = CustomUser.objects.get(username=hod_username)
        except CustomUser.DoesNotExist:
            messages.error(request, 'Invalid hod')
            return redirect('team_list')

        employees = CustomUser.objects.filter(username__in=employees_usernames)

        team.name = name
        team.hod = hod
        team.employee.set(employees)
        team.save()

        messages.success(request, "Team updated successfully.")
        return redirect('team_list')

    return render(request, 'administrator/update_team.html', {'team': team})




# Users menu  verification of user after registrations

def users_list(request):
    user_list = CustomUser.objects.all().exclude(is_superuser=True)
    unverified_users = CustomUser.objects.filter(is_verified=False).count()
    hods_count = CustomUser.objects.filter(roles='HOD').count()
    trainers_admin_count = CustomUser.objects.filter(roles='Trainers Admin').count()
    trainers_count = CustomUser.objects.filter(roles='Trainers').count()
    active_users = CustomUser.objects.exclude(is_superuser=True).filter(is_active=True).count()
    roles = Roles.objects.all()
    my_context = {
        'user_list': user_list,
        'unverified_users': unverified_users,
        'hods_count': hods_count,
        'trainers_count': trainers_count,
        'trainers_admin_count': trainers_admin_count,
        'active_users': active_users,
        'roles': roles,


    }
    return render(request, 'administrator/users_list.html',context=my_context)


def verify_user(request,user_id):
    try:
        emp = CustomUser.objects.get(id=user_id)
    except CustomUser.DoesNotExist:
        # Handle the case when the video lesson does not exist
        messages.error(request, 'User does not exist')
        return redirect('executive_list')  # Redirect to a course list view or another appropriate page
    if request.method =='POST':
        role = request.POST.get('role')
        is_verified = request.POST.get('is_verified')
        emp.role = role
        emp.is_verified = is_verified
        emp.save()
        messages.success(request, 'user has been approved')
        return redirect('executive_list')
    return render(request, 'administrator/approve_user.html', {'emp': emp})

# Personal Profile Related
def change_password(request):
    if request.method == 'POST':
        old_password = request.POST.get('old_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')
        if not request.user.check_password(old_password):
            messages.error(request,'Old password is incorrect')
            return redirect('admin_change_password')
        if new_password != confirm_password:
            messages.error(request, 'New password and confirmation do not match.')
            return redirect('admin_change_password')

        request.user.set_password(new_password)
        request.user.save()

        update_session_auth_hash(request, request.user)
        messages.success(request, 'Password changed successfully')
        return redirect('admin_change_password')
    return render(request, 'administrator/change_password.html')

def update_profile(request):
    user = request.user
    profile = get_object_or_404(UserProfile, user=user)
    if request.method == 'POST':
        date_of_birth = request.POST.get('date_of_birth')
        gender = request.POST.get('gender')
        email = request.POST.get('email')
        bio = request.POST.get('bio')
        address = request.POST.get('address')
        photo = request.FILES.get('photo')
        skills = request.POST.getlist('skills')

        if date_of_birth and not date_of_birth_valid(date_of_birth):
            messages.error(request,'Invalid date of birth format.')
            return redirect('update_profile_hod')

        if gender and gender not in ['male', 'female', 'other']:
            messages.error(request, 'Invalid gender value.')
            return redirect('update_profile')

        if email and not email_valid(email):
            messages.error(request, 'Invalid email address.')
            return redirect('update_profile')


        if date_of_birth != profile.date_of_birth:
            profile.date_of_birth = date_of_birth

        if gender != profile.gender:
            profile.gender = gender

        if email != profile.email:
            profile.email = email

        if bio != profile.bio:
            profile.bio = bio

        if address != profile.address:
            profile.address = address

        if photo:
            profile.photo = photo

        if skills != [str(skill.id) for skill in profile.skills.all()]:
            profile.skills.set(skills)

        profile.save()
        messages.success(request, 'Profile updated Successfully')
        return redirect('hod_profile')
    skills = Skill.objects.all()

    return render(request,'update_profile.html',{'user_profile': profile, 'skills': skills})




def date_of_birth_valid(date_str):
    try:
        datetime.datetime.strptime(date_str, '%Y-%m-%d')
        return True
    except ValueError:
        return False

def email_valid(email):
    try:
        validators.validate_email(email)
        return True
    except ValidationError:
        return False
