from django.urls import path
from . import views
urlpatterns = [
    # admin related
    path('dashboard', views.dashboard, name='admin_dashboard'),
    path('change-password', views.change_password, name='admin_change_password'),
    path('update-profile', views.update_profile, name='admin_update_profile'),
    # Organization related
    # branch
    path('branch-list', views.branch_list, name='branch_list'),
    path('add-branch', views.create_branch, name='create_branch'),
    path('branch/<int:branch_id>/delete/', views.delete_branch, name='delete_branch'),
    path('branch/<int:branch_id>/update/', views.update_branch, name='update_branch'),
    # department
    path('department-list', views.department_list, name='department_list'),
    path('add-department', views.create_department, name='create_department'),
    path('department/<int:department_id>/delete/', views.delete_department, name='delete_department'),
    path('department/<int:department_id>/update/', views.update_department, name='update_department'),
    # designation
    path('designation-list', views.designation_list, name='designation_list'),
    path('add-designation', views.create_designation, name='create_designation'),
    path('designation/<int:designation_id>/delete/', views.delete_designation, name='delete_designation'),
    path('designation/<int:designation_id>/update/', views.update_designation, name='update_designation'),
    # roles
    path('roles-list', views.roles_list, name='roles_list'),
    path('add-roles', views.create_branch, name='create_roles'),
    path('roles/<int:roles_id>/delete/', views.delete_roles, name='delete_roles'),
    path('roles/<int:roles_id>/update/', views.update_roles, name='update_roles'),
    # permissions
    path('permission-list', views.permission_list, name='permission_list'),
    path('add-permission', views.create_permission, name='create_permission'),
    path('permission/<int:permission_id>/delete/', views.delete_permission, name='delete_permission'),
    path('permission/<int:permission_id>/update/', views.update_permission, name='update_permission'),
    # Teams
    path('teams-list', views.team_list, name='team_list'),
    path('add-teams', views.create_team, name='create_team'),
    path('teams/<int:teams_id>/delete/', views.delete_team, name='delete_team'),
    path('teams/<int:teams_id>/update/', views.update_team, name='update_team'),
    # Skills
    path('skill-list', views.skills_list, name='skills_list'),
    path('add-skill', views.create_skill, name='create_skill'),
    path('skill/<int:skill_id>/delete/', views.delete_skill, name='delete_skill'),
    path('skill/<int:skill_id>/update/', views.update_skill, name='update_skill'),
    # User list and verification
    path('users-list', views.users_list, name='users_list'),
    path('verify-users', views.verify_user, name='verify_user_admin'),

]