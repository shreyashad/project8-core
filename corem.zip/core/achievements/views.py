from django.shortcuts import render,redirect, get_object_or_404
from .models import *
from accounts.decorators import login_required_as_role
from django.contrib import messages
# Create your views here.


@login_required_as_role('Trainers Admin')
def badges(request):
    badges_list = Badge.objects.all()

    if request.method =='POST':
        title = request.POST.get('badge_title')
        description = request.POST.get('badge_description')
        image = request.FILES.get('badge_image')

        if Badge.objects.filter(title=title).exists():
            messages.info(request, 'Badge is already registered.')
        else:
            badge = Badge.objects.create(
                title=title, image=image, description=description,
            )

            badge.save()
            messages.success(request, 'Your Badge is successfully created.')
            return redirect('add_badges')

    return render(request, 'trainers_admin/badges_list.html', {'badges_list': badges_list})


@login_required_as_role('Trainers Admin')
def edit_badge(request, badge_id):
    badge = get_object_or_404(Badge, id=badge_id)
    if request.method == 'POST':
        # Handle form submission to update badge details
        # You can use the same form as in the modal
        # Update badge details and save
        badge.title = request.POST.get('badge_title')
        badge.description = request.POST.get('badge_description')
        badge.image = request.FILES.get('badge_image')
        badge.save()
        return redirect('add_badges')  # Redirect to badges page after editing
    return render(request, 'trainers_admin/badges_list.html', {'badge': badge})

@login_required_as_role('Trainers Admin')
def delete_badge(request, badge_id):
    badge = get_object_or_404(Badge, id=badge_id)
    if request.method == 'POST':
        # Handle badge deletion
        badge.delete()
        return redirect('add_badges')  # Redirect to badges page after deletion
    return render(request, 'trainers_admin/badges_list.html', {'badge': badge})