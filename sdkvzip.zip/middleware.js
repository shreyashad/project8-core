
import { NextResponse } from "next/server";
import { auth } from "./auth";

const routeRoleMap = {
    "/dashboard/administrator": "Administrator",
    "/dashboard/authenticator": "Authenticator",
    "/dashboard/site-admin": "Site-Admin",
};

export async function middleware(req) {
    const { token } = await auth(req);

    if (!token) {
        return NextResponse.redirect(new URL("/login", req.url));
    }

    const userRole = token.role;
    const { pathname } = req.nextUrl;

    for (const [route, requiredRole] of Object.entries(routeRoleMap)) {
        if (pathname.startsWith(route) && userRole !==requiredRole) {
            return NextResponse.redirect(new URL("/unauthrorized", req.url));
        }
    }
    return NextResponse.next();
}

export const config = {
    matcher: Object.keys(routeRoleMap).map((route) => `${route}/:path*`),
};