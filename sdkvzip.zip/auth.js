import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { fetchApplicationDetails, validateTicket } from "./app/api/common/auth";
import axios from "axios";


const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";


export const { handlers, signIn, signOut, auth } = NextAuth({
    providers: [
        CredentialsProvider({
            name:"Credentials",
            credentials: {
                username: { label: "Username", type: "text" },
                password: { label: "Password", type: "password" },
            },
            async authorize (credentials) {
                try {
                    const application = await fetchApplicationDetails();
                    const applicationId = application.app.id;

                    const response = await axios.post(`${API_BASE_URL}api/login/`, {
                        username: credentials.username,
                        password: credentials.password,
                        application_id: applicationId,
                    });

                    if (response.status !== 200) {
                        throw new Error("Invalid credentials or application issue");
                    }
                    const user = response.data;
                    const userDetails = await validateTicket(user.service_ticket, applicationId);

                    if (userDetails) {
                        return {
                            id: userDetails.id || user.id,
                            roles: userDetails.roles,
                            permissions: userDetails.permissions,
                            profile_picture: userDetails.profile_picture,
                            first_name: userDetails.first_name,
                            last_name: userDetails.last_name,
                            org_type: userDetails.org_type,
                            org_name: userDetails.org_name,
                            org_sub_type: userDetails.org_sub_type,
                            location_type: userDetails.location_type,
                            location_name: userDetails.location_name,
                            location_code: userDetails.location_code,
                            emp_code: userDetails.emp_code,
                            department: userDetails.department,
                            designation: userDetails.designation,
                            accessToken: user.access, // Include the access token
                            refreshToken: user.refresh,
                            sessionKey: user.session_key,
                            service_ticket: user.service_ticket,
                            sessionExp: new Date(user.session_expires_at).getTime(),
                        };
                    } else {
                        throw new Error ("Invalid service ticket");
                    }
                } catch (error) {
                    console.error("Authentication failed:", error.message);
                    throw new Error(getCustomErrorMessage(error.message));
                }
            },
        }),
    ],

    pages:{
        signIn:'/login',
        error:'/error',
        signOut: '/login',    
    },
    callbacks: {
        async jwt({ token, user }) {
            if (user) {
                token.accessToken = user.accessToken;
                token.refreshToken = user.refreshToken;
                token.sessionKey = user.sessionKey;
                token.sessionExp = user.sessionExp;
                token.user = user;
            }
            // Token refresh logic when the session has expired
            if (Date.now() > token.sessionExp) {
                try {
                const response = await axios.post(`${API_BASE_URL}api/token/refresh/`, {
                    refresh: token.refreshToken,
                });

                if (response.status === 200) {
                    token.accessToken = response.data.access;
                    token.refreshToken = response.data.refresh;
                    token.sessionExp = Date.now() + 60 * 60 * 1000; // Refresh session expiration (1 hour)
                } else {
                    throw new Error("Token refresh failed");
                }
                } catch (error) {
                console.error("Error refreshing token:", error);
                throw new Error("Session expired, please log in again.");
                }
            }

            return token;
    
        },
        async session({ session, token }) {
            if (!token || !token.accessToken) {
              // If there's no valid token, handle as expired
              session.error = "Session expired, please log in again.";
              return session;
            }
      
            session.accessToken = token.accessToken;
            session.refreshToken = token.refreshToken;
            session.sessionKey = token.sessionKey;
            session.sessionExp = token.sessionExp;
            session.user = token.user;
      
            return session;
          },
    },
    session: {
        strategy: 'jwt', // Use JWT for session management in SSO setups
    },
    server: {
    trustedHosts: ['localhost:3000', 'http://authserver.mdindia.com:8002/'], // Add production domain here
    },
    events: {
    // Handle events like signIn, signOut, etc. for analytics, logging, etc.
    async signIn(message) {
        console.log('User signed in:', message);
    },
    async signOut(message) {
        console.log('User signed out:', message);
    },
    },
    debug: true,

      
    

});