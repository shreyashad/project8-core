import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";

// for administrator dashboard related functions

export async function fetchOnlineUser(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/online-user-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            } 
        });
        console.log("user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching user count:", error);
        throw error;
    }
};


export async function fetchTotalUser(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/total-users-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
};


export async function fetchApplicationCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/application-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
};


export async function fectchApplicationWiseUserChartData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/user-application-status-chart/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
}


export async function fetchAdminUserCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/admin-user-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
};


export async function fetchAuthenticatorCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/authenticator-user-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
};


export async function fetchSiteAdminCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/site-admin-user-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total user count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total user count:", error);
        throw error;
    }
};


export async function fetchPendingVerificationCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/unverified-users-count/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`, 
            } 
        });
        console.log("total unverified count:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching total unverified user count:", error);
        throw error;
    }
};
