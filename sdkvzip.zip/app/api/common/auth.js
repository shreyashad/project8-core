import axios from "axios";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";

export async function fetchApplicationDetails() {
    try {
        const response = await axios.post(`${API_BASE_URL}api/application-details/`, {
            name: process.env.APP_NAME,
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching application details:', error.response ? error.response.data : error.message);
        throw new Error('Failed to fetch application details');
    }
};


export async function validateTicket(serviceTicket, applicationId) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/validate-ticket/`, {
            service_ticket: serviceTicket,
            application_id: applicationId,
        });

    } catch (error) {
        console.error('Error validating ticket:',  error.response ? error.response.data : error.message);
        throw new Error('Error validating ticket');
    }
};


export async function validateSession(sessionKey) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/validate-session/`, {
            headers: {
                Authorization: `Bearer ${sessionKey}`,
            },
        });
        return response.status === 200;
    } catch (error) {
        console.error("Session validation error:", error);
        return false;
    }
};



export async function fetchDesignations() {
    try{
        const response = await axios.get(`${API_BASE_URL}api/designations/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch designation");
    }
};


export async function fecthDepartments() {
    try{
        const response = await axios.get(`${API_BASE_URL}api/departments/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch departments");
    }
};


export async function fetchOrgTypes() {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-type-list/`);
        console.log("Org types Data:", response.data)
        return response.data;

    } catch (error) {
        console.error("Error fetching Org types:", error);
        throw error;
    }
};


export async function fetchOrgNames(orgType) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-name-list/?orgType=${orgType}`);
        console.log("Org Names Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Org Names:", error );
        throw error;
    }
};


export async function fetchOrgSubTypes(orgType) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/org-subtypes/?orgType=${orgType}`);
        console.log("Org SubTypes Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Org SubTypes:", error);
        throw error;
    }
};


export async function fetchLocationTypes(orgName) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/location-type-list/?orgName=${orgName}`);
        console.log("Location Type Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Type:", error );
        throw error;
    }
};


export async function fetchLocationName(orgName, location_type) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/location-name-list/`, {
            params: {
                orgName: orgName,
                location_type: location_type,
            }
        });
        console.log("Location Name Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Name:", error);
        throw error;
    }
};


export async function fetchLocationCode(orgName, location_type, location_name) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/location-code-list/`, {
            params: {
                orgName: orgName,
                location_type: location_type,
                location_name: location_name
            }
        });
        console.log("Location Code Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Code:", error);
        throw error;
    }
};


export async function register(formData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/register/`, formData);
        console.log("userdetails:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error while registration:", error);
        throw error;
    }
};


// for user forgot password
export async function getpasswordResetRequest(userDetails) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/password-reset-request/`, userDetails);
        return response.data
    } catch(error) {
        console.error("Error while password rest :", error);
        throw error;
    }
};


export async function getResetPassword(userDetails) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/reset-password/`, userDetails);
        return response.data
    } catch(error) {
        console.error("Error while password rest :", error);
        throw error;
    }
};
