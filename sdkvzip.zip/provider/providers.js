"use client";
import { SonnToaster } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "next-themes";


const Providers = ({ childern }) => {
    return(
        <ThemeProvider attribute="class" enableSystem={false} defaultTheme="light">
            <div>
                <Toaster />
                {childern}
            </div>
            <SonnToaster />
        </ThemeProvider>
    );
};

export default Providers;