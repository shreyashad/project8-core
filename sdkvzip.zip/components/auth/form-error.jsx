export const FormError = ({ message }) => {
    return (
      <div style={{ color: "red", fontWeight: "bold", margin: "20px 0" }}>
        {message}
      </div>
    );
  };
  