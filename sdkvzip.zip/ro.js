import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import axios from "axios";

const NEXT_PUBLIC_API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;

const authOptions = {
  providers: [
    CredentialsProvider({
      id: "credentials",
      name: "Credentials",
      credentials: {
        username: { label: "Username", type: "text" },
        password: { label: "Password", type: "password" },
        application_id: { label: "Application ID", type: "text" },
      },
      async authorize(credentials) {
        try {
          const res = await axios.post(`${NEXT_PUBLIC_API_BASE_URL}/login/`, {
            username: credentials.username,
            password: credentials.password,
            application_id: credentials.application_id,
          });

          if (res.status === 200) {
            return res.data;
          }
          return null;
        } catch (error) {
          console.error("Login error:", error.response?.data || error.message);
          return null;
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.accessToken = user.access;
        token.refreshToken = user.refresh;
        token.sessionKey = user.session_key;
      }
      return token;
    },
    async session({ session, token }) {
      session.accessToken = token.accessToken;
      session.refreshToken = token.refreshToken;
      session.sessionKey = token.sessionKey;
      return session;
    },
  },
  session: {
    strategy: "jwt",
  },
  secret: process.env.NEXTAUTH_SECRET,
};

export default NextAuth(authOptions);
--------
import { auth } from "next-auth/middleware";
import { NextResponse } from "next/server";

export async function middleware(req) {
  const { token } = await auth(req);

  if (!token) {
    // Redirect to login if no token is found
    return NextResponse.redirect(new URL("/login", req.url));
  }

  const userRole = token.role; // Ensure role is part of the token
  const { pathname } = req.nextUrl;

  // Role-based access control
  if (pathname.startsWith("/dashboard/administrator") && userRole !== "Administrator") {
    return NextResponse.redirect(new URL("/unauthorized", req.url));
  }

  if (pathname.startsWith("/dashboard/authenticator") && userRole !== "Authenticator") {
    return NextResponse.redirect(new URL("/unauthorized", req.url));
  }

  if (pathname.startsWith("/dashboard/site-admin") && userRole !== "Site-Admin") {
    return NextResponse.redirect(new URL("/unauthorized", req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*"],
};
-------
import { auth } from "next-auth/middleware";
import { NextResponse } from "next/server";

// Define a mapping between routes and roles
const routeRoleMap = {
  "/dashboard/administrator": "Administrator",
  "/dashboard/authenticator": "Authenticator",
  "/dashboard/site-admin": "Site-Admin",
};

export async function middleware(req) {
  const { token } = await auth(req);

  if (!token) {
    // Redirect to login if no token is found
    return NextResponse.redirect(new URL("/login", req.url));
  }

  const userRole = token.role; // Ensure the role is included in the token
  const { pathname } = req.nextUrl;

  // Check each route and role
  for (const [route, requiredRole] of Object.entries(routeRoleMap)) {
    if (pathname.startsWith(route) && userRole !== requiredRole) {
      return NextResponse.redirect(new URL("/unauthorized", req.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: Object.keys(routeRoleMap).map((route) => `${route}/:path*`),
};
