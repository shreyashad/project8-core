from pydoc import resolve
from django.db.models import Prefetch
from urllib3 import request

from accounts.authentication import CustomCASAuthentication
from course.serializers import *
from course.models import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status, generics
# Create your views here.


class DifficultyLevelListCreateView(generics.ListCreateAPIView):
    queryset = DifficultyLevel.objects.all()
    serializer_class = DifficultyLevelSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class DifficultyLevelDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = DifficultyLevel.objects.all()
    serializer_class = DifficultyLevelSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for Course Category
class CourseCategoryListView(generics.ListAPIView):
    queryset = CourseCategory.objects.all()
    serializer_class = CourseCategorySerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class CourseCategoryCreateView(generics.CreateAPIView):
    queryset = CourseCategory.objects.all()
    serializer_class =  CourseCategorySerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


    def perform_create(self, serializer):
        if serializer.is_valid():
            serializer.save(created_by=self.request.user, updated_by=self.request.user)
        else:
            print(serializer.errors)

class CourseCategoryDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = CourseCategory.objects.all()
    serializer_class = CourseCategorySerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)

class CourseListView(generics.ListAPIView):
    serializer_class = CourseSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Course.objects.prefetch_related(
            'module_set__video_lessons',
            'module_set__materials',
            'reviews',
        ).select_related(
            'category',  # Use select_related for ForeignKey relations
            'difficulty_level'
        ).all()

class EnrolledCourseListView(generics.ListAPIView):
    serializer_class = CourseSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user_id

        enrolled_courses = CourseEnrollment.objects.filter(user=user).values_list('course', flat=True)

        return Course.objects.filter(id__in=enrolled_courses).prefetch_related(
            'module_set__video_lessons',
            'module_set__materials',
            'reviews',
        ).select_related(
            'category',  # Use select_related for ForeignKey relations
            'difficulty_level'
        ).all()





class CourseCreateView(generics.CreateAPIView):
    queryset = Course.objects.all()
    serializer_class =  CourseSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user, updated_by=user)


class CourseDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)
#
#
# # for Module
# class ModuleListView(generics.ListAPIView):
#     queryset = Module.objects.all()
#     serializer_class = ModuleSerializer
#     authentication_classes = [CustomCASAuthentication]
#     permission_classes = [IsAuthenticated]
#
#
# class ModuleCreateView(generics.CreateAPIView):
#     queryset = Module.objects.all()
#     serializer_class =  ModuleSerializer
#     authentication_classes = [CustomCASAuthentication]
#     permission_classes = [IsAuthenticated]
#
#     def perform_create(self, serializer):
#         user = self.request.user
#         serializer.save(created_by=user.username, updated_by=user.username)
#
#
# class ModuleDetailView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = Module.objects.all()
#     serializer_class = ModuleSerializer
#     authentication_classes = [CustomCASAuthentication]
#     permission_classes = [IsAuthenticated]
#
#     def perform_update(self, serializer):
#         user = self.request.user
#         serializer.save(updated_by=user.username)
#
#
# # for VideoLesson
#
# class VideoLessonListView(generics.ListAPIView):
#     queryset = VideoLesson.objects.all()
#     serializer_class = VideoLessonSerializer
#     authentication_classes = [CustomCASAuthentication]
#     permission_classes = [IsAuthenticated]
#
#
# class VideoLessonCreateView(generics.CreateAPIView):
#     queryset = VideoLesson.objects.all()
#     serializer_class =  VideoLessonSerializer
#     authentication_classes = [CustomCASAuthentication]
#     permission_classes = [IsAuthenticated]
#
#     def perform_create(self, serializer):
#         user = self.request.user
#         serializer.save(created_by=user.username, updated_by=user.username)
#
#
# class VideoLessonDetailView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = VideoLesson.objects.all()
#     serializer_class = VideoLessonSerializer
#     authentication_classes = [CustomCASAuthentication]
#     permission_classes = [IsAuthenticated]
#
#     def perform_update(self, serializer):
#         user = self.request.user
#         serializer.save(updated_by=user.username)
#
#
# # for Material
#
# class MaterialListView(generics.ListAPIView):
#     queryset = Material.objects.all()
#     serializer_class = MaterialSerializer
#     authentication_classes = [CustomCASAuthentication]
#     permission_classes = [IsAuthenticated]
#
#
# class MaterialCreateView(generics.CreateAPIView):
#     queryset = Material.objects.all()
#     serializer_class =  MaterialSerializer
#     authentication_classes = [CustomCASAuthentication]
#     permission_classes = [IsAuthenticated]
#
#     def perform_create(self, serializer):
#         user = self.request.user
#         serializer.save(created_by=user.username, updated_by=user.username)
#
#
# class MaterialDetailView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = Material.objects.all()
#     serializer_class = MaterialSerializer
#     authentication_classes = [CustomCASAuthentication]
#     permission_classes = [IsAuthenticated]
#
#     def perform_update(self, serializer):
#         user = self.request.user
#         serializer.save(updated_by=user.username)
#

# for Dynamic view for Course which will handle all course, module, videos
# and material all at once's
# class CourseListView(generics.ListAPIView):
#     queryset = Course.objects.prefetch_related('module_set__video_lessons', 'module_set__materials').all()
#     serializer_class = CourseSerializer
#     authentication_classes = [CustomCASAuthentication]
#     permission_classes = [IsAuthenticated]


# class CourseCreateView(APIView):
#     def post(self, request, *args, **kwargs):
#         course_data = request.data.get('course')
#         modules_data = request.data.get('modules',[])
#
#         course_serializer = CourseSerializer(data=course_data)
#         if course_serializer.is_valid():
#             course = course_serializer.save()
#
#             #Create Modules
#             for module_data in modules_data:
#                 module_data['course'] = course.id # Associate module with the created course
#                 module_serializer = ModuleSerializer(data=module_data)
#                 if module_serializer.is_valid():
#                     module_serializer.save()
#
#                     # Create Video Lessons
#                     videos_data = module_data.get('video_lessons', [])
#                     for video_data in videos_data:
#                         video_data['module'] = module_serializer.instance.id # Associate video with the created module
#                         video_serializer = VideoLessonSerializer(data=video_data)
#                         if video_serializer.is_valid():
#                             video_serializer.save()
#
#                         # Create Materials
#                     materials_data = module_data.get('materials', [])
#                     for material_data in materials_data:
#                         material_data[
#                             'module'] = module_serializer.instance.id  # Associate material with the created module
#                         material_serializer = MaterialSerializer(data=material_data)
#                         if material_serializer.is_valid():
#                             material_serializer.save()
#                 else:
#                     return Response(module_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#
#             return Response(course_serializer.data, status=status.HTTP_201_CREATED)
#         return Response(course_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# for Course








#
#
