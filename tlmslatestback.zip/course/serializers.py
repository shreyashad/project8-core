# serializers.py
from PIL.DdsImagePlugin import module
from django.template.defaultfilters import title
from rest_framework import serializers

from common.models import CourseEnrollment
from .models import *

class DifficultyLevelSerializer(serializers.ModelSerializer):
    class Meta:
        model = DifficultyLevel
        fields = ['id', 'name']

    def validate_name(self, value):
        if DifficultyLevel.objects.filter(name__iexact=value).exists():
            raise serializers.ValidationError("Difficulty level with this name already exists.")
        return value


class CourseCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CourseCategory
        fields = ['id', 'name', 'image', 'description', 'category_status']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']

    def validate_name(self, value):
        if CourseCategory.objects.filter(name__iexact=value).exists():
            raise serializers.ValidationError("Course category with this name already exists.")
        return value

class CourseReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = CourseReview
        fields = ['id', 'user', 'rating', 'comment', 'created_at']


class VideoLessonSerializer(serializers.ModelSerializer):
    class Meta:
        model = VideoLesson
        fields = ['id', 'title', 'video_url', 'cover_image', 'description', 'duration', 'order', 'status']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']

    def validate_video_url(self, value):
        if value.size > 50 * 1024 * 1024:
            raise  serializers.ValidationError("Video file size cannot exceed 50MB.")
        return value

    def validate(self, data):
        if data['order'] < 0:
            raise serializers.ValidationError("Order cannot be negative.")
        return data


class MaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = Material
        fields = ['id', 'title', 'file', 'description', 'status']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']

    def validate_file(self, value):
        if value.size > 10 * 1024 * 1024:
            raise serializers.ValidationError("File size cannot exceed 10MB.")
        return value


class CourseListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Course
        fields = ['id', 'title', 'slug', 'description','category','cover_image','duration','difficulty_level','status',
                  'prerequisites','certification','learning_objectives','created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']





# serializers.py

class ModuleSerializer(serializers.ModelSerializer):
    video_lessons = VideoLessonSerializer(many=True, required=False)
    materials = MaterialSerializer(many=True, required=False)

    class Meta:
        model = Module
        fields = ['id', 'title', 'description', 'cover_image', 'order','course', 'status', 'video_lessons', 'materials']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']

    def validate_order(self, value):
        if value < 0:
            raise serializers.ValidationError("Order cannot be negative.")
        return value

    def create(self, validated_data):
        video_lessons_data = validated_data.pop('video_lessons', [])
        materials_data = validated_data.pop('materials', [])
        module = Module.objects.create(**validated_data)

        for lesson_data in video_lessons_data:
            VideoLesson.objects.create(module=module, **lesson_data)

        for material_data in materials_data:
            Material.objects.create(module=module, **material_data)

        return module

    def update(self, instance, validated_data):
        video_lessons_data = validated_data.pop('video_lessons', [])
        materials_data = validated_data.pop('materials', [])

        instance = super().update(instance, validated_data)
        # Update video lessons
        for lesson_data in video_lessons_data:
            lesson_id = lesson_data.get('id')
            if lesson_id:
                lesson_instance = VideoLesson.objects.get(id=lesson_id, module=instance)
                for attr, value in lesson_data.items():
                    setattr(lesson_instance, attr, value)
                lesson_instance.save()
            else:
                VideoLesson.objects.create(module=instance, **lesson_data)


        # Update materials
        for material_data in materials_data:
            material_id = material_data.get('id')
            if material_id:
                material_instance = Material.objects.get(id=material_id, module=instance)
                for attr, value in material_data.items():
                    setattr(material_instance, attr, value)
                material_instance.save()
            else:
                Material.objects.create(module=instance, **material_data)

        return instance


class CourseSerializer(serializers.ModelSerializer):
    category = CourseCategorySerializer()
    difficulty_level = DifficultyLevelSerializer()
    course_reviews = CourseReviewSerializer(many=True, source='reviews')
    modules = ModuleSerializer(many=True, source='module_set')
    prerequisites = serializers.CharField(  # Handle rich text content (HTML)
        required=False,
        allow_blank=True,
        write_only=True,  # Allows users to input HTML or plain text
    )
    enrollment_count = serializers.SerializerMethodField()
    class Meta:
        model = Course
        fields = [
            'id', 'title', 'slug', 'description', 'category','cover_image','duration',
            'difficulty_level','prerequisites','has_certificate', 'certification',
             'learning_objectives','status', 'modules', 'course_reviews','enrollment_count'

        ]

        read_only_fields = ['id','slug','created_at', 'updated_at', 'created_by', 'updated_by']

    def validate_title(self, value):
        if Course.objects.filter(title__iexact=value).exists():
            raise  serializers.ValidationError("A course with this title already exists.")
        return value

    def get_enrollment_count(self, obj):
        # Accessing the related `CourseEnrollment` model to count enrollments for the course
        return CourseEnrollment.objects.filter(course=obj).count()

    def create(self, validated_data):
        modules_data = validated_data.pop('modules', [])
        prerequisites_data = validated_data.pop('prerequisites', '')

        course = Course.objects.create(**validated_data)
        course.prerequisites = prerequisites_data
        course.save()

        for module_data in modules_data:
            ModuleSerializer().create({**module_data, 'course': course})

        return course

    def update(self, instance, validated_data):
        modules_data = validated_data.pop('modules', [])
        prerequisites_data = validated_data.pop('prerequisites', '')


        instance = super().update(instance, validated_data)
        instance.prerequisites = prerequisites_data
        instance.save()

        for module_data in modules_data:
            module_id = module_data.get('id')
            if module_id:
                module_instance = Module.objects.get(id=module_id, course=instance)
                ModuleSerializer().update(module_instance, module_data)
            else:
                ModuleSerializer().create({**module_data, 'course': instance})

        return instance