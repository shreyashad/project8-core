from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from course.serializers import *
from course.models import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
# Create your views here.

# for Course category related
class CourseCategoryListView(APIView):
    def get(self, request):
        categories = CourseCategory.objects.all()
        serializer = CourseCategorySerializer(categories, many=True)
        return Response(serializer.data)

class CourseCategoryCreateView(APIView):
    #permission_classes = (IsAuthenticated,)
    model = CourseCategory
    serializer_class = CourseCategorySerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            category_obj = serializer.save(created_by=request.user, updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "New category is created",
                    "category": self.serializer_class(category_obj).data,
                    "status": status.HTTP_201_CREATED,
                }
            )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )

class CourseCategoryDetailView(APIView):
    #permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return CourseCategory.objects.get(pk=pk)
        except CourseCategory.DoesNotExist:
            return None



    def get(self, request, pk):
        category = self.get_object(pk)
        if not category:
            return Response(
                {
                    "error": True,
                    "errors": "Course Category Dose not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }
            )
        if self.request.userprofile.roles != "ADMINISTRATOR"  and not self.request.userprofile.roles != "TRAINERS ADMIN"  and not self.request.user.is_superuser:
            if not (
                    (self.request.user == self.object.created_by)
            ):
                return Response(
                    {
                        "error": True,
                        "errors": "You don not have Permission to perform this action",
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )



    def delete(self, request, pk, format=None):
        category = self.get_object(pk)
        if not category:
            return Response(
                {
                    "error": True,
                    "errors": "Course Category does not exist"
                    ,
                },
                status=status.HTTP_403_FORBIDDEN,

            )
        category.delete()
        return Response(
            {
                "error": False,
                "message": "Wisdom deleted Successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        category = self.get_object(pk)
        params = request.data
        if not category:
            return Response(
                {
                    "error": True,
                    "errors": "Wisdom does not exist"
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = CourseCategorySerializer(category, params)
        if serializer.is_valid():
            serializer.save(updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "Course Category Updated Successfully"
                },
                status=status.HTTP_200_OK
            )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )


# for Course related

class CourseListView(APIView):
    def get(self, request):
        course = Course.objects.all()
        serializer = CourseCategorySerializer(course, many=True)
        return Response(serializer.data)

class CourseCreateView(APIView):
    #permission_classes = (IsAuthenticated,)
    model = Course
    serializer_class = CourseSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            course_obj = serializer.save(created_by=request.user, updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "New course is created",
                    "course": self.serializer_class(course_obj).data,
                    "status": status.HTTP_201_CREATED,
                }
            )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )

class CourseCategoryDetailView(APIView):
    #permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return Course.objects.get(pk=pk)
        except Course.DoesNotExist:
            return None



    def get(self, request, pk):
        course = self.get_object(pk)
        if not course:
            return Response(
                {
                    "error": True,
                    "errors": "Course Dose not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }
            )
        if self.request.userprofile.roles != "ADMINISTRATOR" and not self.request.userprofile.roles != "TRAINERS ADMIN"  and not self.request.user.is_superuser:
            if not (
                    (self.request.user == self.object.created_by)
            ):
                return Response(
                    {
                        "error": True,
                        "errors": "You don not have Permission to perform this action",
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )



    def delete(self, request, pk, format=None):
        course = self.get_object(pk)
        if not course:
            return Response(
                {
                    "error": True,
                    "errors": "Course does not exist"
                    ,
                },
                status=status.HTTP_403_FORBIDDEN,

            )
        course.delete()
        return Response(
            {
                "error": False,
                "message": "Course deleted Successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        course = self.get_object(pk)
        params = request.data
        if not course:
            return Response(
                {
                    "error": True,
                    "errors": "Course does not exist"
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = CourseSerializer(course, params)
        if serializer.is_valid():
            serializer.save(updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "Course Updated Successfully"
                },
                status=status.HTTP_200_OK
            )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )


# for module related

class ModuleListView(APIView):
    def get(self, request):
        modules = Module.objects.all()
        serializer = ModuleSerializer(modules, many=True)
        return Response(serializer.data)

class ModuleCreateView(APIView):
    #permission_classes = (IsAuthenticated,)
    model = Module
    serializer_class = ModuleSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            module_obj = serializer.save(created_by=request.user, updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "New module is created",
                    "category": self.serializer_class(module_obj).data,
                    "status": status.HTTP_201_CREATED,
                }
            )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                    "status": status.HTTP_400_BAD_REQUEST,
                }
            )

class ModuleDetailView(APIView):
    #permission_classes = (IsAuthenticated,)

    def get_object(self, pk):
        try:
            return Module.objects.get(pk=pk)
        except Module.DoesNotExist:
            return None



    def get(self, request, pk):
        module = self.get_object(pk)
        if not module:
            return Response(
                {
                    "error": True,
                    "errors": "Module Dose not exist",
                    "status": status.HTTP_403_FORBIDDEN
                }
            )
        if self.request.userprofile.roles != "ADMINISTRATOR"  and not self.request.userprofile.roles != "TRAINERS ADMIN"  and not self.request.user.is_superuser:
            if not (
                    (self.request.user == self.object.created_by)
            ):
                return Response(
                    {
                        "error": True,
                        "errors": "You don not have Permission to perform this action",
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )



    def delete(self, request, pk, format=None):
        module = self.get_object(pk)
        if not module:
            return Response(
                {
                    "error": True,
                    "errors": "Module does not exist"
                    ,
                },
                status=status.HTTP_403_FORBIDDEN,

            )
        module.delete()
        return Response(
            {
                "error": False,
                "message": "Module deleted Successfully"
            },
            status=status.HTTP_200_OK,
        )

    def put(self, request, pk, format=None):
        category = self.get_object(pk)
        params = request.data
        if not category:
            return Response(
                {
                    "error": True,
                    "errors": "Wisdom does not exist"
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = CourseCategorySerializer(category, params)
        if serializer.is_valid():
            serializer.save(updated_by=request.user)
            return Response(
                {
                    "error": False,
                    "message": "Course Category Updated Successfully"
                },
                status=status.HTTP_200_OK
            )
        return Response(
            {"error": True, "errors": serializer.errors},
            status=status.HTTP_400_BAD_REQUEST,
        )


# all below are serializers
from rest_framework import serializers
from course.models import *

class DifficultyLevelSerializer(serializers.ModelSerializer):
    class Meta:
        model = DifficltyLevel
        fields = ['id', 'name', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']




class CourseCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CourseCategory
        fields = ['id', 'name', 'description', 'image', 'category_status', 'created_at', 'updated_at', 'created_by',
                  'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class VideoLessonSerializer(serializers.ModelSerializer):

    class Meta:
        model = VideoLesson
        fields = ['id', 'title', 'description', 'image', 'status', 'created_at', 'updated_at', 'created_by',
                  'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class MaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = Material
        fields = ['id', 'title', 'description', 'image', 'status', 'created_at', 'updated_at', 'created_by',
                  'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class ModuleSerializer(serializers.ModelSerializer):
    video_lessons = VideoLessonSerializer(many=True, read_only=True)
    materials = MaterialSerializer(many=True, read_only=True)

    class Meta:
        model = Module
        fields = ['id', 'title', 'description', 'cover_image', 'status', 'created_at', 'updated_at', 'created_by',
                  'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class CourseSerializer(serializers.ModelSerializer):

    class Meta:
        model = Course
        fields = ['id', 'title', 'description', 'cover_image', 'status', 'created_at', 'updated_at', 'created_by',
                  'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class CourseDetailSerializer(serializers.ModelSerializer):
    modules = ModuleSerializer(many=True, read_only=True)

    class Meta:
        model = Course
        fields = "__all__"
        depth = 1



--------------


class CourseSerializer(serializers.ModelSerializer):
    modules = ModuleSerializer(many=True, required=False)

    class Meta:
        model = Course
        fields = [
            'id', 'title', 'slug', 'description', 'category',
            'cover_image', 'duration', 'difficulty_level',
            'prerequisites', 'certification', 'learning_objectives',
            'status', 'modules', 'created_at', 'updated_at', 'created_by', 'updated_by'
        ]
        read_only_fields = ['id', 'slug', 'created_at', 'updated_at', 'created_by', 'updated_by']

    def create(self, validated_data):
        modules_data = validated_data.pop('modules', [])
        course = Course.objects.create(**validated_data)

        for module_data in modules_data:
            # Directly create the module and associate it with the course
            ModuleSerializer.create(ModuleSerializer(), validated_data=module_data)

        return course

    def update(self, instance, validated_data):
        modules_data = validated_data.pop('modules', [])

        # Update the basic fields of the course
        instance.title = validated_data.get('title', instance.title)
        instance.description = validated_data.get('description', instance.description)
        instance.cover_image = validated_data.get('cover_image', instance.cover_image)
        instance.duration = validated_data.get('duration', instance.duration)
        instance.difficulty_level = validated_data.get('difficulty_level', instance.difficulty_level)
        instance.prerequisites.set(validated_data.get('prerequisites', instance.prerequisites.all()))
        instance.certification = validated_data.get('certification', instance.certification)
        instance.learning_objectives = validated_data.get('learning_objectives', instance.learning_objectives)
        instance.status = validated_data.get('status', instance.status)
        instance.save()

        for module_data in modules_data:
            module_id = module_data.get('id')
            if module_id:
                # If the module exists, update it
                module = Module.objects.get(id=module_id)
                ModuleSerializer.update(ModuleSerializer(), instance=module, validated_data=module_data)
            else:
                # If no module_id, create new module
                ModuleSerializer.create(ModuleSerializer(), validated_data=module_data)

        return instance


class ModuleSerializer(serializers.ModelSerializer):
    video_lessons = VideoLessonSerializer(many=True, required=False)
    materials = MaterialSerializer(many=True, required=False)

    class Meta:
        model = Module
        fields = ['id', 'title', 'description', 'cover_image', 'order', 'status', 'video_lessons', 'materials',
                  'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']

    def create(self, validated_data):
        video_lessons_data = validated_data.pop('video_lessons', [])
        materials_data = validated_data.pop('materials', [])
        module = Module.objects.create(**validated_data)

        for video_data in video_lessons_data:
            VideoLesson.objects.create(module=module, **video_data)

        for material_data in materials_data:
            Material.objects.create(module=module, **material_data)

        return module

    def update(self, instance, validated_data):
        video_lessons_data = validated_data.pop('video_lessons', [])
        materials_data = validated_data.pop('materials', [])

        # Update the basic fields of the module
        instance.title = validated_data.get('title', instance.title)
        instance.description = validated_data.get('description', instance.description)
        instance.cover_image = validated_data.get('cover_image', instance.cover_image)
        instance.order = validated_data.get('order', instance.order)
        instance.status = validated_data.get('status', instance.status)
        instance.save()

        # Update or create video lessons
        for video_data in video_lessons_data:
            video_title = video_data.get('title')
            VideoLesson.objects.update_or_create(
                module=instance,
                title=video_title,
                defaults={k: v for k, v in video_data.items() if k != 'title'}
            )

        # Update or create materials
        for material_data in materials_data:
            material_title = material_data.get('title')
            Material.objects.update_or_create(
                module=instance,
                title=material_title,
                defaults={k: v for k, v in material_data.items() if k != 'title'}
            )

        return instance
-----------
from rest_framework import serializers
from django.db import transaction
from .models import Course, Module, VideoLesson, Material, CourseCategory, DifficultyLevel


class VideoLessonSerializer(serializers.ModelSerializer):
    class Meta:
        model = VideoLesson
        fields = ['id', 'title', 'video_url', 'order']
        extra_kwargs = {'id': {'read_only': False, 'required': False}}

    def validate_video_url(self, value):
        if not value.startswith('http'):
            raise serializers.ValidationError("Video URL must be a valid URL.")
        return value


class MaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = Material
        fields = ['id', 'name', 'file_url', 'order']
        extra_kwargs = {'id': {'read_only': False, 'required': False}}

    def validate_file_url(self, value):
        if not value.startswith('http'):
            raise serializers.ValidationError("File URL must be a valid URL.")
        return value


class ModuleSerializer(serializers.ModelSerializer):
    video_lessons = VideoLessonSerializer(many=True, required=False)
    materials = MaterialSerializer(many=True, required=False)

    class Meta:
        model = Module
        fields = ['id', 'title', 'description', 'order', 'video_lessons', 'materials']
        extra_kwargs = {'id': {'read_only': False, 'required': False}}

    def validate_order(self, value):
        if value <= 0:
            raise serializers.ValidationError("Order must be a positive integer.")
        return value

    def create(self, validated_data):
        video_lessons_data = validated_data.pop('video_lessons', [])
        materials_data = validated_data.pop('materials', [])
        module = Module.objects.create(**validated_data)
        self._create_nested_objects(video_lessons_data, materials_data, module)
        return module

    def update(self, instance, validated_data):
        video_lessons_data = validated_data.pop('video_lessons', [])
        materials_data = validated_data.pop('materials', [])

        instance.title = validated_data.get('title', instance.title)
        instance.description = validated_data.get('description', instance.description)
        instance.order = validated_data.get('order', instance.order)
        instance.save()

        self._update_nested_objects(video_lessons_data, materials_data, instance)
        return instance

    def _create_nested_objects(self, video_lessons_data, materials_data, module):
        for video_lesson_data in video_lessons_data:
            VideoLesson.objects.create(module=module, **video_lesson_data)
        for material_data in materials_data:
            Material.objects.create(module=module, **material_data)

    def _update_nested_objects(self, video_lessons_data, materials_data, module):
        for video_lesson_data in video_lessons_data:
            video_lesson_id = video_lesson_data.pop('id', None)
            if video_lesson_id:
                video_lesson_instance = VideoLesson.objects.get(id=video_lesson_id, module=module)
                for attr, value in video_lesson_data.items():
                    setattr(video_lesson_instance, attr, value)
                video_lesson_instance.save()
            else:
                VideoLesson.objects.create(module=module, **video_lesson_data)

        for material_data in materials_data:
            material_id = material_data.pop('id', None)
            if material_id:
                material_instance = Material.objects.get(id=material_id, module=module)
                for attr, value in material_data.items():
                    setattr(material_instance, attr, value)
                material_instance.save()
            else:
                Material.objects.create(module=module, **material_data)


class CourseSerializer(serializers.ModelSerializer):
    modules = ModuleSerializer(many=True, required=False)
    category = serializers.PrimaryKeyRelatedField(queryset=CourseCategory.objects.all())
    difficulty_level = serializers.PrimaryKeyRelatedField(queryset=DifficultyLevel.objects.all())

    class Meta:
        model = Course
        fields = ['id', 'title', 'description', 'category', 'difficulty_level', 'modules']

    def validate_title(self, value):
        if Course.objects.filter(title__iexact=value).exists():
            raise serializers.ValidationError("Course with this title already exists.")
        return value

    @transaction.atomic
    def create(self, validated_data):
        modules_data = validated_data.pop('modules', [])
        course = Course.objects.create(**validated_data)
        for module_data in modules_data:
            module_data['course'] = course
            ModuleSerializer().create(module_data)
        return course

    @transaction.atomic
    def update(self, instance, validated_data):
        modules_data = validated_data.pop('modules', [])

        instance.title = validated_data.get('title', instance.title)
        instance.description = validated_data.get('description', instance.description)
        instance.category = validated_data.get('category', instance.category)
        instance.difficulty_level = validated_data.get('difficulty_level', instance.difficulty_level)
        instance.save()

        self._update_modules(instance, modules_data)
        return instance

    def _update_modules(self, course, modules_data):
        for module_data in modules_data:
            module_id = module_data.pop('id', None)
            if module_id:
                module_instance = Module.objects.get(id=module_id, course=course)
                ModuleSerializer().update(module_instance, module_data)
            else:
                module_data['course'] = course
                ModuleSerializer().create(module_data)
