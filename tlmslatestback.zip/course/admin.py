from django.contrib import admin
from .models import *
# Register your models here.


@admin.register(DifficultyLevel)
class DifficltyLevelAdmin(admin.ModelAdmin):
    list_display = ["name"]


@admin.register(CourseCategory)
class CourseCategoryAdmin(admin.ModelAdmin):
    list_display = ["name", "category_status"]


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ["title","category","status"]


@admin.register(Module)
class ModuleAdmin(admin.ModelAdmin):
    list_display = ["title","status","order"]


@admin.register(VideoLesson)
class VideoLessonAdmin(admin.ModelAdmin):
    list_display = ["title","status","order"]


@admin.register(Material)
class MaterialAdmin(admin.ModelAdmin):
    list_display = ["title","status","file"]


