from django.db import models

class StatusChoice(models.TextChoices):
    INACTIVE = 'Inactive', 'Inactive'
    PUBLISHED = 'Published', 'Published'
