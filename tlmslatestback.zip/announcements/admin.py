from django.contrib import admin
from .models import *
# Register your models here.

@admin.register(AnnouncementCategory)
class AnnouncementCategoryAdmin(admin.ModelAdmin):
    list_display = ["name",  "description"]


@admin.register(Announcement)
class AnnouncementAdmin(admin.ModelAdmin):
    list_display = ["title", "published_date","expiration_date" ,"is_active"]
