from datetime import timezone
from django.db import models
from accounts.models import BaseModel


# Create your models here.


class AnnouncementCategory(BaseModel):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)


    class Meta:
        verbose_name = "Announcement Category"
        verbose_name_plural = "Announcement Categories"
        db_table = "announcement_category"

    def __str__(self):
        return self.name



class Announcement(BaseModel):
    title = models.CharField(max_length=200)
    content = models.TextField()
    category = models.ForeignKey(AnnouncementCategory, on_delete=models.SET_NULL, null=True, related_name='announcements')
    published_date = models.DateTimeField(auto_now_add=True)
    expiration_date = models.DateTimeField(null=True, blank=True)  # Optional: to set an expiration date
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Announcement"
        verbose_name_plural = "Announcements"
        db_table = "announcement"
        ordering = ['-published_date']

    def __str__(self):
        return self.title

    def is_expired(self):
        """Check if the announcement is expired based on the expiration date."""
        if self.expiration_date:
            return self.expiration_date < timezone.now()
        return False
