from tkinter.font import names

from django.urls import path
from .views import *

urlpatterns = [
    path('latest-today-wisdom/', LatestToDaysWisdomView.as_view(), name='latest_today_wisdom'),
    path('todays-wisdom-list/', TodaysWisdomListView.as_view(), name='todays-wisdom-list' ),
    path('todays-wisdom-create/', TodaysWisdomCreateView.as_view(), name='todays-wisdom-create'),
    path('todays-wisdom/<uuid:pk>/details/', TodaysWisdomDetailView.as_view(), name='todays-wisdom-details'),
    path('training-rooms-list/', TrainingRoomListView.as_view(), name='training-rooms-list' ),
    path('training-rooms-create/', TrainingRoomCreateView.as_view(), name='training-rooms-create'),
    path('training-rooms/<uuid:pk>/details/', TrainingRoomDetailView.as_view(), name='training-rooms-details'),
    path('room-availability-list/', RoomAvailabilityListView.as_view(), name='room-availability-list'),
    path('room-availability/create/', RoomAvailabilityCreateView.as_view(), name='room-availability-create'),
    path('room-availability/<uuid:pk>/details/', RoomAvailabilityDetailView.as_view(), name='room-availability-detail'),



    path('create-new-trainings-request/', TrainingRequestCreateView.as_view(), name='create-training-request'),
    path('hod/training-requests/', HODTrainingRequestListView.as_view(), name='hod-training-request-list'),
    path('training-request/', AllTrainingRequestListView.as_view(), name='training-request'),
    path('training-request/<uuid:pk>/details/', TrainingRequestDetailView.as_view(), name='training-request-details'),

    path('course-enrollment/', CourseEnrollmentView.as_view(), name='course-enrollment'),
    path('course-enrollment-status/<uuid:courseId>/', EnrollmentStatusView.as_view(), name='enrollment-status'),
    path('update-progress/<uuid:course_id>/<uuid:module_id>/<uuid:video_id>/', UpdateProgressView.as_view(), name='update-progress'),


]