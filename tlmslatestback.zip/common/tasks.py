from celery import shared_task
import time

@shared_task
def send_training_notification(training_id):
    # This is just an example task
    time.sleep(10)  # Simulate a time-consuming operation
    print(f"Notification sent for training {training_id}")
    return f"Notification sent for training {training_id}"

@shared_task
def fetch_user_info_from_centralized_system(user_id):
    # Fetch user data from the centralized system (you can use requests)
    print(f"Fetching user info for user {user_id}")
    return {"user_id": user_id, "status": "fetched"}


@shared_task
def send_training_request_notification_trainersadmin()