# your_app/auth_client.py

import requests
from django.conf import settings
from rest_framework.exceptions import AuthenticationFailed

class AuthServerClient:
    @staticmethod
    def get_user_info(user_id, request):
        """Fetch user information from the auth_server."""
        token = request.headers.get('Authorization')
        if not token:
            return None

        if token.startswith('Bearer '):
            token = token[7:]
        else:
            raise AuthenticationFailed('Invalid token header')
        try:
            response = requests.get(
                f"{settings.AUTH_SERVER_BASE_URL}/api/admin-user-details/{user_id}/",
                headers={"Authorization": f"Bearer {token}"}
            )
            response.raise_for_status()
            return response.json()  # Return user data as a dictionary
        except requests.RequestException as e:
            print(f"Error fetching user info: {str(e)}")
            return None

    @staticmethod
    def get_team_info(team_id, request):
        """Fetch team information from the auth_server."""
        token = request.headers.get('Authorization')
        if not token:
            return None

        if token.startswith('Bearer '):
            token = token[7:]
        else:
            raise AuthenticationFailed('Invalid token header')
        try:
            response = requests.get(
                f"{settings.AUTH_SERVER_BASE_URL}/api/teams/{team_id}/details/",
                headers={"Authorization": f"Bearer {token}"}
            )
            response.raise_for_status()
            return response.json()  # Return team data as a dictionary
        except requests.RequestException as e:
            print(f"Error fetching team info: {str(e)}")
            return None
