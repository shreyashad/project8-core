from django.contrib import admin
from .models import *
# Register your models here.




@admin.register(TrainingRooms)
class TrainingRoomsAdmin(admin.ModelAdmin):
    list_display = ["name","capacity"]


@admin.register(RoomAvailability)
class RoomAvailabilityAdmin(admin.ModelAdmin):
    list_display = ["room","date" ,"is_available"]


@admin.register(CourseEnrollment)
class CourseEnrollmentAdmin(admin.ModelAdmin):
    list_display = ["user", "course", "enrollment_date"]