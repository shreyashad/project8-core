from django.db import models
from uuid import uuid4
from accounts.models import BaseModel
from common.auth_client import AuthServerClient
from course.models import *
from ckeditor.fields import RichTextField


# model define for today's wisdom
class ToDaysWisdom(BaseModel):
    topic = RichTextField(blank=True, null=True)

    class Meta:
        verbose_name = "Today's Wisdom"
        verbose_name_plural = "Today's Wisdoms"
        db_table = "today's_wisdom"
        ordering = ("-created_at",)

    def __str__(self):
        return self.topic


class TrainingRooms(BaseModel):
    name = models.CharField(max_length=100, unique=True)
    capacity = models.PositiveIntegerField()

    def __str__(self):
        return self.name


class RoomAvailability(BaseModel):
    room = models.ForeignKey(TrainingRooms, on_delete=models.CASCADE)
    date = models.DateField()
    is_available = models.BooleanField(default=True)
    description = models.TextField(blank=True)

    def __str__(self):
        status = "Available" if self.is_available else "Not Available"
        return f"{self.room} - {self.date} - {status}"

    def save(self, *args, **kwargs):
        if self.is_available is False:
            # Prevent multiple bookings for the same room on the same date
            existing_booking = RoomAvailability.objects.filter(room=self.room, date=self.date, is_available=False)
            if existing_booking.exists():
                raise ValueError(f"The room '{self.room}' is already booked for this date.")
        super().save(*args, **kwargs)


class TrainerAvailability(models.Model):
    trainer = models.CharField(max_length=255)
    scheduled_date = models.DateField()
    is_available = models.BooleanField(default=True)

    class Meta:
        unique_together = ['trainer', 'scheduled_date']



class TrainingMode(BaseModel):
    MODE_CHOICES = [
        ('online', 'Online'),
        ('offline', 'Offline'),
        ('self-learning', 'Self-Learning'),
    ]

    name = models.CharField(max_length=20, choices=MODE_CHOICES, unique=True)

    def __str__(self):
        return self.name



class TrainingRequest(BaseModel):

    REQUEST_STATUS = [
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected')
    ]

    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    requester = models.CharField(max_length=255)  # Store CAS user ID
    receiver = models.CharField(max_length=255)   # Store CAS user ID
    preferred_mode = models.CharField(max_length=20, help_text="Requested training mode")
    employees = models.TextField(help_text="Comma-separated list of Participants requested for training")
    additional_notes = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=REQUEST_STATUS, default='pending')

    def get_employee_list(self):
        """Convert the comma-separated string back to a list."""
        return self.employees.split(',')

    def get_requester_info(self):
        return AuthServerClient.get_user_info(self.requester_username)

    def get_receiver_info(self):
        return AuthServerClient.get_user_info(self.receiver_username)

    def get_employee_info(self, request):
        """Fetch information for all employees from the auth server."""
        employee_ids = self.get_employee_list()
        employee_info_list = []

        for employee_id in employee_ids:
            employee_info = AuthServerClient.get_user_info(employee_id.strip(), request)
            if employee_info:
                employee_info_list.append(employee_info)

        return employee_info_list

    def __str__(self):
        return f"{self.course.name} - {self.requester_username} - {self.get_mode_display()}"


class TrainingSchedule(models.Model):
    MODE_CHOICES = [
        ('online', 'Online'),
        ('offline', 'Offline'),
        ('self-learning', 'Self-learning')
    ]

    training_request = models.OneToOneField(
        TrainingRequest, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="scheduled_session", help_text="Related request if initiated by HOD"
    )
    course = models.CharField(max_length=255)
    preferred_mode = models.CharField(max_length=20, choices=MODE_CHOICES, help_text="Requested training mode")

    # Store employee IDs as a comma-separated string
    employee_ids = models.TextField(help_text="Comma-separated list of employee IDs")
    trainers = models.CharField(max_length=255)
    # For offline training
    room = models.ForeignKey(
        TrainingRooms, related_name='scheduled_trainings', on_delete=models.SET_NULL, null=True, blank=True,
        help_text="Room for offline training"
    )

    # For online training
    online_platform = models.CharField(max_length=255, blank=True, help_text="Online platform for training")
    online_link = models.URLField(blank=True, help_text="Link to the online training session")

    scheduled_date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    duration_hours = models.PositiveIntegerField()
    additional_notes = models.TextField(blank=True)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)

        # Mark room as not available for the scheduled date if offline
        if self.preferred_mode == 'offline' and self.room:
            RoomAvailability.objects.update_or_create(
                room=self.room,
                date=self.scheduled_date,
                defaults={'is_available': False}
            )

        # Mark trainers as not available for the scheduled date
        for trainer in self.trainers.all():
            TrainerAvailability.objects.update_or_create(
                trainer=trainer,
                scheduled_date=self.scheduled_date,
                defaults={'is_available': False}
            )

    def get_employee_list(self):
        """Convert the comma-separated string back to a list."""
        return self.employee_ids.split(',')

    def get_employee_info(self, request):
        """Fetch information for all employees from the auth server."""
        employee_ids = self.get_employee_list()
        employee_info_list = []

        for employee_id in employee_ids:
            employee_info = AuthServerClient.get_user_info(employee_id.strip(), request)
            if employee_info:
                employee_info_list.append(employee_info)

        return employee_info_list

    def __str__(self):
        return f"{self.course} - {self.preferred_mode} - {self.scheduled_date} - {', '.join(self.get_employee_list())}"




class TrainingSession(models.Model):
    schedule = models.ForeignKey(TrainingSchedule,on_delete=models.CASCADE)
    start_time = models.DateTimeField()
    location = models.CharField(max_length=100)
    additional_notes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.schedule.request.course.name} - {self.date_time}"


class AttendanceRecord(models.Model):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE, related_name="attendances")
    participant = models.CharField(max_length=1024, help_text="Employee attending the training")
    attendance_time = models.DateTimeField(null=True, blank=True)
    departure_time = models.DateTimeField(null=True, blank=True)
    is_present = models.BooleanField(default=False)
    late_arrival = models.BooleanField(default=False)
    toggled_by_trainer = models.BooleanField(default=False)  # Indicates if attendance was toggled by the trainer

    def mark_attendance(self, attendance_time):
        self.attendance_time = attendance_time
        self.toggled_by_trainer = True
        self.save()

    def mark_departure(self, departure_time):
        self.departure_time = departure_time
        self.save()


class BreakTime(models.Model):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    duration_minutes = models.PositiveIntegerField()


class TaskExecution(models.Model):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE)
    task_name = models.CharField(max_length=100)
    executor = models.CharField(max_length=255)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    status = models.CharField(max_length=20)  # e.g., "completed", "pending"



class CourseEnrollment(models.Model):
    user = models.CharField(max_length=150)  # Store user ID that is fetched from the centralized system
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='course_enrollment')
    enrollment_date = models.DateTimeField(auto_now_add=True)

    # Track course progress
    is_completed = models.BooleanField(default=False)  # Whether the user has completed the course
    last_completed_module = models.ForeignKey(Module, on_delete=models.SET_NULL, null=True, blank=True)
    last_completed_video = models.ForeignKey(VideoLesson, on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        unique_together = ('user', 'course')


class VideoCompletion(models.Model):
    user = models.CharField(max_length=255)
    video = models.ForeignKey(VideoLesson, on_delete=models.CASCADE)
    is_completed = models.BooleanField(default=False)
    completion_time = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'video')



class ModuleCompletion(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    module = models.ForeignKey(Module, on_delete=models.CASCADE)
    is_completed = models.BooleanField(default=False)
    completion_time = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'module')
