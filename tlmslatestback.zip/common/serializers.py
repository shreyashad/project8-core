from rest_framework import serializers
from common.models import *

class CourseSerializerCommon(serializers.ModelSerializer):
    class Meta:
        model = Course
        fields = ['id', 'title']


class CourseEnrollmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = CourseEnrollment
        fields = ['user', 'course', 'enrollment_date', 'is_completed', 'last_completed_module', 'last_completed_video']


class ToDaysWisdomSerializer(serializers.ModelSerializer):
    class Meta:
        model = ToDaysWisdom
        fields = ['id', 'topic']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']



class TrainingRoomsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainingRooms
        fields = ['id', 'name', 'capacity']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class RoomAvailabilitySerializer(serializers.ModelSerializer):
    room_name = serializers.CharField(source='room.name', read_only=True)

    class Meta:
        model = RoomAvailability
        fields = ['id', 'room', 'room_name', 'date', 'is_available', 'description']

    def validate(self, attrs):
        # Ensure that room is available for the selected date
        room = attrs.get('room')
        date = attrs.get('date')

        if RoomAvailability.objects.filter(room=room, date=date, is_available=False).exists():
            raise serializers.ValidationError(f"The room {room.name} is already booked for this date.")

        return attrs


class TrainingModeSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainingMode
        fields = ['id', 'name']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class TrainingRequestSerializer(serializers.ModelSerializer):
    # Nested serializer for the course
    course = serializers.PrimaryKeyRelatedField(queryset=Course.objects.all())
    # Fields for status display and user info
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    requester_info = serializers.SerializerMethodField()
    receiver_info = serializers.SerializerMethodField()
    employee_info = serializers.SerializerMethodField()
    course_info = serializers.SerializerMethodField()

    class Meta:
        model = TrainingRequest
        fields = [
            'id', 'course', 'requester', 'receiver', 'preferred_mode', 'employees', 'additional_notes',
            'status', 'status_display', 'requester_info', 'receiver_info', 'employee_info', 'course_info', 'created_at'
        ]
        read_only_fields = ['id','created_at' ,'status_display', 'requester_info', 'receiver_info', 'employee_info', 'course_info']

    def get_requester_info(self, obj):
        """Fetch the requester's info, assuming `requester` is a user ID."""
        # Use the AuthServerClient to get user info from the auth server
        user_info = AuthServerClient.get_user_info(obj.requester, self.context['request'])
        return user_info if user_info else {}

    def get_course_info(self, obj):
        """Fetch the course info, assuming `course` is a ForeignKey to the Course model."""
        # Fetch course details based on the related course ID
        course = obj.course  # This gets the related Course instance
        # Return the details you need from the Course model
        return {
            'id': course.id,
            'title': course.title,

        }

    def get_receiver_info(self, obj):
        """Fetch the receiver's info, assuming `receiver` is a user ID."""
        # Use the AuthServerClient to get user info from the auth server
        user_info = AuthServerClient.get_user_info(obj.receiver, self.context['request'])
        return user_info if user_info else {}

    def get_employee_info(self, obj):
        """Fetch employee info, assuming `employees` is a comma-separated string of user IDs."""
        employee_ids = obj.get_employee_list()
        employee_info_list = []
        for emp_id in employee_ids:
            user_info = AuthServerClient.get_user_info(emp_id.strip(), self.context['request'])
            if user_info:
                employee_info_list.append(user_info)
        return employee_info_list

    def validate(self, attrs):
        """Custom validation for mode and other fields."""
        # Ensure the mode is valid
        if attrs.get('preferred_mode') not in ['online', 'offline', 'self-learning']:
            raise serializers.ValidationError({"preferred_mode": "Invalid mode selected."})
        return attrs