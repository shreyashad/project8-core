from django.shortcuts import render
from rest_framework.views import APIView

from common.auth_client import AuthServerClient
from common.models import *
from accounts.authentication import CustomCASAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import status, generics,filters
from django_filters.rest_framework import DjangoFilterBackend
from common.serializers import *
from rest_framework.response import Response

# Create your views here.


# for todays wisdom

class TodaysWisdomListView(generics.ListAPIView):
    """
    to get all the today's Wisdom list that are been created
    """
    queryset = ToDaysWisdom.objects.all()
    serializer_class = ToDaysWisdomSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class TodaysWisdomCreateView(generics.CreateAPIView):
    """
    to create a new today's wisdom
    """
    queryset = ToDaysWisdom.objects.all()
    serializer_class =  ToDaysWisdomSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class TodaysWisdomDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    to retrieve update and delete today's wisdom

    """
    queryset = ToDaysWisdom.objects.all()
    serializer_class = ToDaysWisdomSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)

class LatestToDaysWisdomView(generics.ListAPIView):
    """
    to display the latest's today's wisdom which will be displayed
    to all user's
    """
    serializer_class = ToDaysWisdomSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        # Return the latest wisdom entry
        return ToDaysWisdom.objects.order_by('-created_at')[:1]

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)




# for Training room

class TrainingRoomListView(generics.ListAPIView):
    """
    to get all the training rooms list that are created
    """
    queryset = TrainingRooms.objects.all()
    serializer_class = TrainingRoomsSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class TrainingRoomCreateView(generics.CreateAPIView):
    """
    to create a new training room
    """
    queryset = TrainingRooms.objects.all()
    serializer_class =  TrainingRoomsSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class TrainingRoomDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    to retrieve update and delete the training room
    """
    queryset = TrainingRooms.objects.all()
    serializer_class = TrainingRoomsSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)




class RoomAvailabilityListView(generics.ListAPIView):
    """
    To get all room availability entries, optionally filtered by room or date.
    """
    serializer_class = RoomAvailabilitySerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        """
        Optionally filter by room and/or date.
        """
        queryset = RoomAvailability.objects.all()

        room_id = self.request.query_params.get('room_id', None)
        date = self.request.query_params.get('date', None)

        if room_id:
            queryset = queryset.filter(room_id=room_id)

        if date:
            queryset = queryset.filter(date=date)

        return queryset


class RoomAvailabilityCreateView(generics.CreateAPIView):
    """
    To create a new room availability entry (mark a room available or unavailable).
    """
    queryset = RoomAvailability.objects.all()
    serializer_class = RoomAvailabilitySerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        """
        Automatically save the current user as the creator of the availability record.
        """
        user = self.request.user
        serializer.save(created_by=user.user_id, updated_by=user.user_id)



class RoomAvailabilityDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    To retrieve, update, or delete a room availability entry.
    """
    queryset = RoomAvailability.objects.all()
    serializer_class = RoomAvailabilitySerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        """
        Automatically save the current user as the updater of the availability record.
        """
        user = self.request.user
        serializer.save(updated_by=user.user_id)

    def perform_destroy(self, instance):
        """
        Automatically handle any cleanup before deleting the availability entry.
        """
        # Optional: You can implement any cleanup logic before deleting
        instance.delete()




class TrainingRequestCreateView(generics.CreateAPIView):
    """
    to create a new training request by HOD's to the Trainers Admin
    requesting for conducting a training sessions for a specific course
    """
    queryset = TrainingRequest.objects.all()
    serializer_class = TrainingRequestSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [CustomCASAuthentication]  # Custom authentication class for CAS user

    def perform_create(self, serializer):
        """
        Override the perform_create method to ensure the requester is set to the authenticated user.
        """
        requester = self.request.user

        requester_id = getattr(requester, 'id', None) or getattr(requester, 'user_id',
                                                                 None)  # Adjust this based on your model

        if not requester_id:
            raise AttributeError("Authenticated user does not have a valid ID attribute")

        # Set the requester to the authenticated user's ID
        serializer.save(requester=requester_id)

    def create(self, request, *args, **kwargs):
        user = request.user
        requester_id = getattr(user, 'user_id', None)
        if not requester_id:
            raise AttributeError("Authenticated user does not have a valid user_id attribute")

        # Ensure the request includes valid data for course, receiver, employees, etc.
        data = request.data
        data['requester'] = requester_id  # Automatically set the requester to the authenticated user

        # We expect employees to be a list of IDs, so we'll join it into a comma-separated string
        if 'employees' in data:
            data['employees'] = ','.join(
                map(str, data['employees']))  # Convert list of employee IDs to a comma-separated string

        # If a receiver is provided, fetch their info from the auth server
        receiver_id = data.get('receiver')
        if receiver_id:
            receiver_info = AuthServerClient.get_user_info(receiver_id, request)
            if not receiver_info:
                return Response({"error": "Receiver not found."}, status=status.HTTP_400_BAD_REQUEST)

        # Validate and save the data via the serializer
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)

        # Return the created training request data as the response
        return Response(serializer.data, status=status.HTTP_201_CREATED)





class HODTrainingRequestListView(generics.ListAPIView):
    serializer_class = TrainingRequestSerializer
    permission_classes = [IsAuthenticated]  # Ensure the user is authenticated
    authentication_classes = [CustomCASAuthentication]

    def get_queryset(self):
        return TrainingRequest.objects.filter(requester=self.request.user.user_id)


class AllTrainingRequestListView(generics.ListAPIView):
    queryset = TrainingRequest.objects.all()
    serializer_class = TrainingRequestSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [CustomCASAuthentication]




# class TrainingRequestListView(generics.ListAPIView):
#     queryset = TrainingRequest.objects.all()
#     serializer_class = TrainingRequestSerializer
#     filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
#     filterset_fields = ['status', 'mode', 'requester_id', 'team_id']  # Fields you want to filter on
#     ordering_fields = ['status', 'course', 'requester_id', 'created_at']  # Adjust to your model fields
#     ordering = ['-created_at']  # Default ordering
#
#     def list(self, request, *args, **kwargs):
#         queryset = self.get_queryset()
#         serializer = self.get_serializer(queryset, many=True)
#         return Response(serializer.data)




class TrainingRequestDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = TrainingRequest.objects.all()
    serializer_class = TrainingRequestSerializer

    def update(self, request, *args, **kwargs):
        # Additional validation logic can be added here if needed
        return super().update(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        # Optionally, you can add any custom behavior before deletion
        return super().destroy(request, *args, **kwargs)



class CourseEnrollmentView(generics.CreateAPIView):
    serializer_class = CourseEnrollmentSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [CustomCASAuthentication]

    def create(self, request, *args, **kwargs):
        # Get the course id from the request data
        course_id = request.data.get('course')
        user_id = request.user_id  # Access the user_id from request (set by the authentication class)

        # Check if the course exists
        try:
            course = Course.objects.get(id=course_id)
        except Course.DoesNotExist:
            return Response({"detail": "Course not found."}, status=status.HTTP_404_NOT_FOUND)

        # Check if the user is already enrolled in this course
        if CourseEnrollment.objects.filter(user=user_id, course=course).exists():
            return Response({"detail": "You are already enrolled in this course."}, status=status.HTTP_400_BAD_REQUEST)

        # Create the CourseEnrollment record
        enrollment = CourseEnrollment.objects.create(user=user_id, course=course)

        # Optionally serialize and return the course enrollment details
        serializer = CourseEnrollmentSerializer(enrollment)
        return Response(serializer.data, status=status.HTTP_201_CREATED)



class EnrollmentStatusView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [CustomCASAuthentication]

    def get(self, request, courseId):
        user = request.user_id

        try:
            print(f"Checking enrollment for course_id: {courseId} and user: {user}")
            # Get the user's enrollment record for the course
            enrollment = CourseEnrollment.objects.get(user=user, course=courseId)
        except CourseEnrollment.DoesNotExist:
            return Response({"detail": "You are not enrolled in this course."}, status=status.HTTP_404_NOT_FOUND)

            # Get the last completed module and video
        last_completed_module = enrollment.last_completed_module
        last_completed_video = enrollment.last_completed_video

        # Return progress data
        progress_data = {
            "enrolled": True,
            "last_completed_module": last_completed_module.id if last_completed_module else None,
            "last_completed_video": last_completed_video.id if last_completed_video else None,
            "is_completed": enrollment.is_completed
        }

        return Response(progress_data, status=status.HTTP_200_OK)


class UpdateProgressView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [CustomCASAuthentication]

    def post(self, request, course_id, module_id, video_id=None):
        user = request.user_id

        # Get the enrollment, module, and video details
        try:
            enrollment = CourseEnrollment.objects.get(user=user, course_id=course_id)
            module = Module.objects.get(id=module_id, course_id=course_id)
            video = VideoLesson.objects.get(id=video_id) if video_id else None
        except (CourseEnrollment.DoesNotExist, Module.DoesNotExist, VideoLesson.DoesNotExist):
            return Response({"detail": "Invalid data."}, status=status.HTTP_400_BAD_REQUEST)

        # Mark module as completed
        module_completion, created = ModuleCompletion.objects.get_or_create(user=user, module=module)
        module_completion.is_completed = True
        module_completion.save()

        # Mark video as completed if applicable
        if video:
            video_completion, created = VideoCompletion.objects.get_or_create(user=user, video=video)
            video_completion.is_completed = True
            video_completion.save()

        # Update the user's enrollment to reflect the last completed module/video
        enrollment.last_completed_module = module
        if video:
            enrollment.last_completed_video = video

        # Check if the user has completed the entire course
        enrollment.is_completed = all(m.is_completed for m in module.course.modules.all())
        enrollment.save()

        return Response({"detail": "Progress updated."}, status=status.HTTP_200_OK)
