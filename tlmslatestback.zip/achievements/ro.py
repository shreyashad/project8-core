from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
import random
import string
from django.db.models.signals import pre_save
from django.dispatch import receiver
from course.utils import StatusChoice


# Function to generate a random certificate code
def generate_certificate_code():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))

class CertificateType(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    template_file = models.FileField(upload_to='certificate_templates/', validators=[validate_certificate_template])
    background_image = models.ImageField(upload_to='certificate_backgrounds/', blank=True, null=True)

    def __str__(self):
        return self.title


# Validator function for template files (e.g., ensuring they are PDFs)
def validate_certificate_template(value):
    if not value.name.endswith('.pdf'):
        raise ValidationError("Template file must be a PDF.")

class Certificate(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    certificate_type = models.ForeignKey(CertificateType, on_delete=models.CASCADE)
    issue_date = models.DateTimeField(auto_now_add=True)
    certificate_code = models.CharField(max_length=255, unique=True, default=generate_certificate_code)
    criteria_value = models.JSONField(default=dict)  # Store specific criteria for issuing the certificate
    is_generated = models.BooleanField(default=False)  # To track if the certificate has been generated

    # Generic relation to allow linking the certificate to any model (Course, Module, Badge, etc.)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')

    class Meta:
        unique_together = ('user', 'certificate_type', 'content_type', 'object_id')  # Ensures a user can only have one certificate of a type per related entity

    def __str__(self):
        return f"{self.user.username} - {self.certificate_type.title} Certificate"

# Optionally, add a signal to ensure certificate code is generated before saving
@receiver(pre_save, sender=Certificate)
def set_certificate_code(sender, instance, **kwargs):
    if not instance.certificate_code:  # Only generate if it's not already set (i.e., for new certificates)
        instance.certificate_code = generate_certificate_code()
