from django.contrib import admin
from .models import *
# Register your models here.

@admin.register(Badge)
class BadgeAdmin(admin.ModelAdmin):
    list_display = ["title",  "description", "status"]


@admin.register(UserBadge)
class UserBadgeAdmin(admin.ModelAdmin):
    list_display = ["user",  "badge", "earned_at"]
