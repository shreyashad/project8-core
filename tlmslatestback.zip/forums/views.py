from django.shortcuts import render
from rest_framework import generics
from rest_framework.response import Response

from .models import *
from .serializers import *
from rest_framework.permissions import IsAuthenticated
from accounts.authentication import CustomCASAuthentication
# Create your views here.


class ForumCategoryListView(generics.ListAPIView):
    """
    to get forum category list
    """
    queryset = ForumCategory.objects.all()
    authentication_classes = [CustomCASAuthentication]
    serializer_class = ForumCategorySerializer

class ForumCategoryCreateView(generics.CreateAPIView):
    """
    to create a new forum category
    """
    queryset = ForumCategory.objects.all()
    authentication_classes = [CustomCASAuthentication]
    serializer_class = ForumCategorySerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user.id)


class ForumCategoryDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    to retrieve update and delete forum category
    """
    queryset = ForumCategory.objects.all()
    authentication_classes = [CustomCASAuthentication]
    serializer_class = ForumCategorySerializer

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user.id)


class FormPostListView(generics.ListAPIView):
    """
    to get all the forum post list
    """
    queryset = ForumPost.objects.all().select_related('category').prefetch_related('tags')
    serializer_class = ForumPostSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class FormPostCreateView(generics.CreateAPIView):
    """
    to create a new forum post
    """
    queryset = ForumPost.objects.all()
    serializer_class = ForumPostSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user.id)


class FormPostDetailsView(generics.RetrieveUpdateDestroyAPIView):
    """
    to retrieve update and delete forum post
    """
    queryset = ForumPost.objects.all()
    serializer_class = ForumPostSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user.id)

class ForumPostIncreaseViews(generics.UpdateAPIView):
    """
    to update the views count of the post
    """
    queryset = ForumPost.objects.all()
    serializer_class = ForumPostSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.views +=1
        instance.save()
        return Response({ 'status': 'views increased'})


class PostAnswersListView(generics.ListAPIView):
    """
    to get post related answers list
    """
    queryset = Answers.objects.all()
    serializer_class = AnswerSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class PostAnswerCreateView(generics.CreateAPIView):
    """
    to create a new answer for post
    """
    queryset = Answers.objects.all()
    serializer_class = AnswerSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user.id)



class PostAnswerDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    to retrieve update and delete the answer of the post
    """
    queryset = Answers.objects.all()
    serializer_class = AnswerSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user.id)



class PostCommentListView(generics.ListAPIView):
    """
    to get the list of all the comments related to the post
    """

    queryset = Comments.objects.all()
    serializer_class = CommentSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class PostCommentCreateView(generics.CreateAPIView):
    """
    to create a new comment for a post or an answer
    """
    queryset = Comments.objects.all()
    serializer_class = CommentSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user.id)


class PostCommentDetails(generics.RetrieveUpdateDestroyAPIView):
    """
    to retrieve update and delete the comment related to the post or answer
    """
    queryset = Comments.objects.all()
    serializer_class = CommentSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user.id)

class  PostAnswerVoteListView(generics.ListAPIView):
    """
    to get the votes for post and answers
    """
    queryset = Vote.objects.all()
    serializer_class = VoteSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class PostAnswerVoteCreateView(generics.CreateAPIView):
    """
    to create a new vote for any post or answers
    """
    queryset = Vote.objects.all()
    serializer_class = VoteSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user.id)


class PostAnswerVoteDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    to retrieve update and delete the votes for any post or answers
    """

    queryset = Vote.objects.all()
    serializer_class = VoteSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user.id)
