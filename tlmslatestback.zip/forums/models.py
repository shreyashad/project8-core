from django.db import models
from django.template.defaulttags import comment

from accounts.models import BaseModel
from common.auth_client import AuthServerClient


# Create your models here.
class ForumCategory(BaseModel):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Tag(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name

class ForumPost(BaseModel):
    title = models.CharField(max_length=255)
    content = models.TextField()
    category = models.ForeignKey(ForumCategory, on_delete=models.CASCADE)
    is_answered = models.BooleanField(default=False)
    views = models.PositiveIntegerField(default=0)
    tags = models.ManyToManyField('Tag', related_name='posts')

    def __str__(self):
        return self.title

    def get_author_details(self):
        # Use the user_id to fetch the author details from the centralized system API
        return AuthServerClient.get_user_info(self.created_by)

    def get_updater_details(self):
        # Use the user_id to fetch the updater details from the centralized system API
        return AuthServerClient.get_user_info(self.updated_by)


class Answers(BaseModel):
    post = models.ForeignKey(ForumPost, related_name="post_answers", on_delete=models.CASCADE)
    content = models.TextField()
    author = models.CharField(max_length=255)
    upvotes = models.IntegerField(default=0)
    downvotes = models.IntegerField(default=0)

    def __str__(self):
        return f"Answered by {self.author} on {self.post.title}"

    def get_author_details(self):
        return AuthServerClient.get_user_info(self.author)



class Comments(BaseModel):
    content = models.TextField()
    post = models.ForeignKey(ForumPost, related_name='comments', null=True,blank=True, on_delete=models.CASCADE)
    answer = models.ForeignKey(Answers, related_name='comments', null=True,blank=True, on_delete=models.CASCADE)
    commenter = models.CharField(max_length=255)

    def __str__(self):
        return  f"Comment by {self.commenter}"

    def get_commenter_details(self):
        return AuthServerClient.get_user_info(self.commenter)




class Vote(BaseModel):
    VOTE_TYPE = (
        (1, 'Upvote'),
        (-1, 'Downvote'),
    )
    user = models.CharField(max_length=255)
    post = models.ForeignKey(ForumPost, related_name='votes', null=True,blank=True, on_delete=models.CASCADE)
    answer = models.ForeignKey(Answers, related_name='votes', null=True, blank=True, on_delete=models.CASCADE)
    vote_type = models.IntegerField(choices=VOTE_TYPE)

    class Meta:
        unique_together = ('user', 'post', 'answer')  # A user can only vote once on a post or answer

    def __str__(self):
        return f"{self.user.username} voted on {self.post.title if self.post else self.answer.id}"

    def get_voter_details(self):
        return AuthServerClient.get_user_info(self.user)

