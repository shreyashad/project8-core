import uuid
import requests
from django.conf import settings
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed
from django.contrib.auth import get_user_model


class AutheticatedUser:
    def __init__(self, user_data):
        self.user_data = user_data
        self.is_authenticated = True

    @property
    def username(self):
        return self.user_data.get('username','')

    @property
    def user_id(self):
        return self.user_data.get('user_id', '')

    @property
    def roles(self):
        return self.user_data.get('roles', [])  # Assuming roles are provided

    @property
    def teams(self):
        return self.user_data.get('teams', [])



class CustomCASAuthentication(BaseAuthentication):
    def authenticate(self, request):
        token = request.headers.get('Authorization')
        if not token:
            return None

        if token.startswith('Bearer '):
            token = token[7:]
        else:
            raise AuthenticationFailed('Invalid token header')

        try:
            response = requests.get(
                f"{settings.AUTH_SERVER_BASE_URL}api/token/introspect/",
                params={'token': token}
            )
            response.raise_for_status()
        except requests.RequestException as e:
            raise AuthenticationFailed(f'Token introspection failed: {str(e)}')

        user_data = response.json()
        if not user_data.get('user_id'):
            raise AuthenticationFailed('Invalid token data')

        user = AutheticatedUser(user_data)
        request.user_id = user.user_id
        request.username = user.username
        return (user, token)

    def authenticate_header(self, request):
        return 'Bearer realm="api"'
