from django.db import models
from uuid import uuid4
# Create your models here.


# Create your models here.
class BaseModel(models.Model):
    id = models.UUIDField(default=uuid4, unique=True, editable=False, db_index=True, primary_key=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.CharField(max_length=150)  # Store user ID that is fetched from the centralized system
    updated_by = models.CharField(max_length=150) # Store user ID of the updater

    class Meta:
        abstract = True
