from django.shortcuts import render
from accounts.authentication import CustomCASAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import status, generics
from .models import *
from .serializers import *
# Create your views here.

# for question type
class QuestionTypeListView(generics.ListAPIView):
    """
    to get Question Types list
    """
    queryset = QuestionType.objects.all()
    serializer_class = QuestionTypeSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class QuestionTypeCreateView(generics.CreateAPIView):
    """
    to create new Question type
    """
    queryset = QuestionType.objects.all()
    serializer_class = QuestionTypeSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.user_id, updated_by=user.user_id)


class QuestionTypeDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    to retrieve update and delete any question type
    """
    queryset = QuestionType.objects.all()
    serializer_class = QuestionTypeSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for quiz related
class QuizListAPIView(generics.ListAPIView):

    queryset = Quiz.objects.all()
    serializer_class = QuizSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

class QuizCreateAPIView(generics.CreateAPIView):
    queryset = Quiz.objects.all()
    serializer_class = QuizSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class QuizDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Quiz.objects.all()
    serializer_class = QuizSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for question

class QuestionListAPIView(generics.ListAPIView):
    queryset = Question.objects.all()
    serializer_class = QuestionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

class QuestionCreateAPIView(generics.CreateAPIView):
    queryset = Question.objects.all()
    serializer_class = QuestionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class QuestionDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Question.objects.all()
    serializer_class = QuestionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for multiple choice questions
class MultipleChoiceListAPIView(generics.ListAPIView):
    queryset = MultipleChoiceOption.objects.all()
    serializer_class = MultipleChoiceOptionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]



class MultipleChoiceCreateAPIView(generics.CreateAPIView):
    queryset = MultipleChoiceOption.objects.all()
    serializer_class = MultipleChoiceOptionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class MultipleChoiceDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = MultipleChoiceOption.objects.all()
    serializer_class = MultipleChoiceOptionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for fill in the blanks questions

class FillInTheBlanksListAPIView(generics.ListAPIView):
    queryset = FillInTheBlanksAnswer.objects.all()
    serializer_class = FillInTheBlanksAnswerSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]



class FillInTheBlanksCreateAPIView(generics.CreateAPIView):
    queryset = FillInTheBlanksAnswer.objects.all()
    serializer_class = FillInTheBlanksAnswerSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class FillInTheBlanksDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = FillInTheBlanksAnswer.objects.all()
    serializer_class = FillInTheBlanksAnswerSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for true or false questions

class TrueFalseListAPIView(generics.ListAPIView):
    queryset = TrueFalseAnswer.objects.all()
    serializer_class = TrueFalseAnswerSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]



class TrueFalseCreateAPIView(generics.CreateAPIView):
    queryset = TrueFalseAnswer.objects.all()
    serializer_class = TrueFalseAnswerSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class TrueFalseDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = TrueFalseAnswer.objects.all()
    serializer_class = TrueFalseAnswerSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for Ordering Item questions

class OrderingItemListAPIView(generics.ListAPIView):
    queryset = OrderingItem.objects.all()
    serializer_class = OrderingItemSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]



class OrderingItemCreateAPIView(generics.CreateAPIView):
    queryset = OrderingItem.objects.all()
    serializer_class = OrderingItemSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class OrderingItemDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = OrderingItem.objects.all()
    serializer_class = OrderingItemSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for Ordering Item questions

class ShortAnswerListAPIView(generics.ListAPIView):
    queryset = ShortAnswerResponse.objects.all()
    serializer_class = ShortAnswerResponseSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]



class ShortAnswerCreateAPIView(generics.CreateAPIView):
    queryset = ShortAnswerResponse.objects.all()
    serializer_class = ShortAnswerResponseSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class ShortAnswerDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = ShortAnswerResponse.objects.all()
    serializer_class = ShortAnswerResponseSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


class StudentSubmissionCreateAPIView(generics.CreateAPIView):
    queryset = StudentSubmission.objects.all()
    serializer_class = StudentSubmissionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        quiz_id = self.request.data.get('quiz')
        # Check if the quiz exists and is active, handle logic here
        # Optionally: Check if the student already has a submission
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class StudentAnswerCreateAPIView(generics.CreateAPIView):
    queryset = StudentAnswer.objects.all()
    serializer_class = StudentAnswerSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        submission_id = self.request.data.get('submission')
        # You can add additional validations here
        serializer.save()  # Save the answer


class StudentSubmissionRetrieveAPIView(generics.RetrieveAPIView):
    queryset = StudentSubmission.objects.all()
    serializer_class = StudentSubmissionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class StudentSubmissionListAPIView(generics.ListAPIView):
    serializer_class = StudentSubmissionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        quiz_id = self.kwargs['quiz_id']
        return StudentSubmission.objects.filter(quiz_id=quiz_id, student_id=self.request.user.id)


class StudentSubmissionSubmitAnswersAPIView(generics.UpdateAPIView):
    queryset = StudentSubmission.objects.all()
    serializer_class = StudentSubmissionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def update(self, request, *args, **kwargs):
        submission = self.get_object()
        answers_data = request.data.get('answers', [])

        # Process each answer and save it
        for answer_data in answers_data:
            question_id = answer_data.get('question')
            answer_text = answer_data.get('answer_text')
            StudentAnswer.objects.create(
                submission=submission,
                question_id=question_id,
                answer_text=answer_text
            )

        # Calculate marks and update the submission record
        self.calculate_marks(submission)
        return Response({'status': 'answers submitted'}, status=status.HTTP_201_CREATED)

    def calculate_marks(self, submission):
        # Logic to calculate total marks based on answers
        total_marks = 0
        # Example: Loop through answers and calculate marks
        for answer in submission.answers.all():
            # Implement your scoring logic here
            # e.g., if answer is correct, add to total_marks
            pass

        submission.marks_obtained = total_marks
        submission.graded = True
        submission.save()

