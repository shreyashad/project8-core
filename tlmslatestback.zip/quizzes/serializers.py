from rest_framework import serializers
from quizzes.models import *


class MultipleChoiceOptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = MultipleChoiceOption  # Correct model reference
        fields = ['id', 'question', 'text', 'is_correct', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class FillInTheBlanksAnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = FillInTheBlanksAnswer  # Correct model reference
        fields = ['id', 'question', 'correct_answer', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class TrueFalseAnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrueFalseAnswer  # Correct model reference
        fields = ['id', 'question', 'is_true', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class OrderingItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderingItem  # Correct model reference
        fields = ['id', 'question', 'text', 'order', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class ShortAnswerResponseSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShortAnswerResponse  # Correct model reference
        fields = ['id', 'question', 'correct_response', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class QuestionTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuestionType  # Correct model reference
        fields = ['id', 'name', 'description', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class QuestionSerializer(serializers.ModelSerializer):
    options = MultipleChoiceOptionSerializer(many=True, required=False)
    answers = FillInTheBlanksAnswerSerializer(many=True, required=False)
    true_false_answer = TrueFalseAnswerSerializer(required=False)
    ordering_items = OrderingItemSerializer(many=True, required=False)
    short_answer_responses = ShortAnswerResponseSerializer(many=True, required=False)

    class Meta:
        model = Question
        fields = ['id','quiz','question_type', 'question', 'marks','options', 'answers', 'true_false_answer', 'ordering_items', 'short_answer_responses']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']





class QuizSerializer(serializers.ModelSerializer):
    questions = QuestionSerializer(many=True, required=False)

    class Meta:
        model = Quiz
        fields = ['id', 'title','course','duration','description','total_marks','pass_marks','questions','created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


    def create(self, validated_data):
        questions_data = validated_data.pop('questions', [])
        # Creating Quiz object
        quiz = Quiz.objects.create(**validated_data)
        # handling questions and its associated answers/options while creating
        for question_data in questions_data:
            question_type_data = question_data.pop('question_type')
            question_type, _ = QuestionType.objects.get_or_create(**question_type_data) # creating or getting existing Question Type
            # Creating Question objects
            question = Question.objects.create(quiz=quiz, question_type=question_type, **question_data)

            # handling different types of questions and their associated data
            if question_type.name == 'Multiple Choice Question':
                options_data = question_data.get('options', [])
                # handling Multiple Choice question -> create options
                for option_data in options_data:
                    MultipleChoiceOption.objects.create(question=question, **option_data)

            elif question_type.name == 'Fill In The Blanks':
                answers_data = question_data.get('answers', [])
                for answer_data in answers_data:
                    FillInTheBlanksAnswer.objects.create(question=question, **answer_data)
            elif question_type.name == 'True or False':
                # True/False question - create the true/false answer
                true_false_data = question_data.get('true_false_answer', {})
                TrueFalseAnswer.objects.create(question=question, **true_false_data)

            elif question_type.name == 'Ordering question types':
                # Ordering question - create ordering items
                ordering_items_data = question_data.get('ordering_items', [])
                for ordering_item_data in ordering_items_data:
                    OrderingItem.objects.create(question=question, **ordering_item_data)

            elif question_type.name == 'Short Answer Questions':
                # Short Answer question - create the correct response
                short_answer_responses_data = question_data.get('short_answer_responses', [])
                for short_answer_data in short_answer_responses_data:
                    ShortAnswerResponse.objects.create(question=question, **short_answer_data)
        return quiz






class StudentAnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentAnswer
        fields = ['id', 'submission', 'question', 'answer_text']
        read_only_fields = ['id']

    def validate_submission(self, value):
        """Check if the submission exists."""
        if not StudentSubmission.objects.filter(id=value.id).exists():
            raise serializers.ValidationError("The specified submission does not exist.")
        return value

    def validate_question(self, value):
        """Check if the question exists."""
        if not Question.objects.filter(id=value.id).exists():
            raise serializers.ValidationError("The specified question does not exist.")
        return value

    def validate_answer_text(self, value):
        """Ensure answer text is not empty."""
        if not value.strip():
            raise serializers.ValidationError("Answer text cannot be empty.")
        return value



# serializers.py



class StudentSubmissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentSubmission
        fields = ['id', 'quiz', 'student_id', 'submitted_at', 'marks_obtained', 'graded']
        read_only_fields = ['id', 'submitted_at', 'marks_obtained', 'graded']

    def validate_quiz(self, value):
        """Check if the quiz exists and is active."""
        if not Quiz.objects.filter(id=value.id).exists():
            raise serializers.ValidationError("The specified quiz does not exist.")
        # Optionally: Check if the quiz is active
        return value

    def validate_student_id(self, value):
        """Ensure that the student ID is valid."""
        # Implement any specific logic to validate student ID format or existence
        # For example, check if it matches a certain UUID format or exists in the user table
        return value
