from django.db import models
from datetime import timedelta
from accounts.models import BaseModel
from course.models import Course
from django.utils import timezone
from fuzzywuzzy import fuzz
from django.core.exceptions import ValidationError

# Create your models here.


class QuestionType(BaseModel):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField()


    def __str__(self):
        return self.name

class Quiz(BaseModel):
    title = models.CharField(max_length=250)
    course = models.ForeignKey(Course, related_name='quizzes', on_delete=models.CASCADE)
    duration = models.DurationField(help_text="Duration of the quiz in HH:MM:SS format", null=True, blank=True)
    description = models.TextField()
    total_marks = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    pass_marks = models.DecimalField(max_digits=5, decimal_places=2)

    def __str__(self):
        return self.title

    def calculate_total_marks(self):
        """Calculate total marks based on the sum of marks of all questions."""
        return sum(question.marks for question in self.questions.all()) if self.questions.exists() else 0

    def save(self, *args, **kwargs):
        # Calculate total marks based on associated questions
        self.total_marks = self.calculate_total_marks()

        super().save(*args, **kwargs)




class Question(BaseModel):
    quiz = models.ForeignKey(Quiz, related_name='questions', on_delete=models.CASCADE)
    question_type = models.CharField(max_length=255)
    question = models.TextField()
    marks = models.DecimalField(max_digits=5, decimal_places=2)

    def __str__(self):
        return self.question



class MultipleChoiceOption(models.Model):
    question = models.ForeignKey(Question, related_name='options', on_delete=models.CASCADE)
    text = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        # Ensure that only one option can be correct
        if self.is_correct:
            MultipleChoiceOption.objects.filter(question=self.question, is_correct=True).update(is_correct=False)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.text


class FillInTheBlanksAnswer(models.Model):
    question = models.ForeignKey(Question, related_name='answers', on_delete=models.CASCADE)
    correct_answer = models.CharField(max_length=255)

    def __str__(self):
        return self.correct_answer


class TrueFalseAnswer(models.Model):
    question = models.OneToOneField(Question, related_name='true_false_answer', on_delete=models.CASCADE)
    is_true = models.BooleanField()

    def __str__(self):
        return f"{'True' if self.is_true else 'False'}"

class OrderingItem(models.Model):
    question = models.ForeignKey(Question, related_name='ordering_items', on_delete=models.CASCADE)
    text = models.CharField(max_length=255)
    order = models.PositiveIntegerField()

    def __str__(self):
        return self.text

class ShortAnswerResponse(models.Model):
    question = models.ForeignKey(Question, related_name='short_answer_responses', on_delete=models.CASCADE)
    correct_response = models.TextField()

    def __str__(self):
        return self.correct_response


class StudentSubmission(BaseModel):
    quiz = models.ForeignKey(Quiz, related_name='submissions', on_delete=models.CASCADE)
    student_id = models.UUIDField()  # Reference to user's ID from auth_server
    started_at = models.DateTimeField(null=True, blank=True)  # When the student starts the quiz
    submitted_at = models.DateTimeField(null=True, blank=True)
    marks_obtained = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    graded = models.BooleanField(default=False)
    time_up = models.BooleanField(default=False)  # Whether the time for the quiz has expired

    class Meta:
        indexes = [
            models.Index(fields=['student_id', 'quiz']),  # Common queries may filter by student and quiz
        ]

    def __str__(self):
        return f"Submission by {self.student_id} for {self.quiz.title}"

    def start_quiz(self):
        """Marks the quiz as started."""
        self.started_at = timezone.now()
        self.time_up = False  # Reset time-up status on start
        self.save()

    def submit_quiz(self):
        """Marks the quiz as submitted."""
        self.submitted_at = timezone.now()
        self.marks_obtained = self.calculate_marks()  # Calculate marks when submitted
        self.save()

    def calculate_marks(self):
        """Calculate marks for the student's submission (based on answers)."""
        total_marks = 0
        for answer in self.answers.all():
            if answer.is_graded:  # Only consider graded answers
                total_marks += answer.marks_awarded
        return total_marks

    def is_time_up(self):
        """Check if the quiz time has expired based on the duration of the quiz."""
        if self.started_at:
            end_time = self.started_at + self.quiz.duration
            return timezone.now() > end_time
        return False

    def save(self, *args, **kwargs):
        # Automatically update the time_up flag based on the quiz duration
        if not self.submitted_at:  # If quiz hasn't been submitted yet
            self.time_up = self.is_time_up()

        super().save(*args, **kwargs)


class StudentAnswer(BaseModel):
    submission = models.ForeignKey(StudentSubmission, related_name='answers', on_delete=models.CASCADE)
    question = models.ForeignKey(Question, related_name='student_answers', on_delete=models.CASCADE)
    answer_text = models.TextField()  # For storing text responses or selected option text
    is_graded = models.BooleanField(default=False)  # Whether the answer has been graded
    marks_awarded = models.DecimalField(max_digits=5, decimal_places=2, null=True,
                                        blank=True)  # Marks awarded for this answer
    correct = models.BooleanField(default=False)  # Whether the answer is correct or not

    def __str__(self):
        return f"Answer for {self.question.text}"

    def grade_answer(self):
        """Grades the answer based on the correct response."""
        if self.question.question_type.name == "MultipleChoice":
            correct_option = self.question.options.filter(is_correct=True).first()
            self.correct = (self.answer_text == correct_option.text)
        elif self.question.question_type.name == "FillInTheBlanks":
            correct_answer = self.question.answers.first()
            student_answer_normalized = self.answer_text.strip().lower()
            correct_answer_normalized = correct_answer.correct_answer.strip().lower()
            # **Method 1: Case-insensitive comparison**
            if student_answer_normalized == correct_answer_normalized:
                self.correct = True
            else:
                # **Method 2: Fuzzy matching for more lenient matching (with a threshold)**
                similarity_score = fuzz.ratio(student_answer_normalized, correct_answer_normalized)

                # Set a threshold for similarity (e.g., 80%)
                if similarity_score >= 80:
                    self.correct = True
                else:
                    self.correct = False
        elif self.question.question_type.name == "TrueFalse":
            correct_answer = self.question.true_false_answer
            self.correct = (self.answer_text.lower() == ("true" if correct_answer.is_true else "false"))
        # Add other question types (e.g., short answer, ordering) here if needed

        # Set the awarded marks
        self.marks_awarded = self.calculate_marks()
        self.is_graded = True
        self.save()

    def calculate_marks(self):
        """Assign marks based on whether the answer is correct or not."""
        if self.correct:
            return self.question.marks  # Full marks for correct answer
        else:
            return 0  # Zero marks for incorrect answer


# for quiz model
 # def clean(self):
    #     # Check for overlapping quizzes
    #     if self.start_time and self.end_time:
    #         overlapping_quizzes = Quiz.objects.filter(
    #             course=self.course,
    #             start_time__lt=self.end_time,
    #             end_time__gt=self.start_time
    #         )
    #         if overlapping_quizzes.exists():
    #             raise ValidationError('This quiz overlaps with another quiz for the same course.')

    # def calculate_duration(self):
    #     """Calculate duration based on start and end time."""
    #     if self.start_time and self.end_time:
    #         return self.end_time - self.start_time
    #     return timedelta(0)
    #
    # def calculate_total_marks(self):
    #     """Calculate total marks based on the sum of marks of all questions."""
    #     return sum(question.marks for question in self.questions.all())
    #
    # def save(self, *args, **kwargs):
    #     # Calculate duration
    #     self.duration = self.calculate_duration()
    #
    #     # Calculate total marks
    #     self.total_marks = self.calculate_total_marks()
    #
    #     super().save(*args, **kwargs)
# class QuestionType(models.TextChoices):
#     MULTIPLE_CHOICE = 'Multiple Choice', 'Multiple Choice'
#     FILL_IN_THE_BLANKS = 'Fill in the Blanks', 'Fill in the Blanks'
#     TRUE_FALSE = 'True or False', 'True or False'
#     ORDERING = 'Ordering', 'Ordering'
#     SHORT_ANSWER = 'Short Answer', 'Short Answer'