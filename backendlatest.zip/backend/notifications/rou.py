# notifications/views.py

from rest_framework import generics, permissions
from .models import Notification
from .serializers import NotificationSerializer, CreateNotificationSerializer

class NotificationListView(generics.ListCreateAPIView):
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """
        Optionally restricts the returned notifications to the current user's notifications.
        """
        queryset = super().get_queryset()
        user = self.request.user
        return queryset.filter(user=user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class NotificationDetailView(generics.RetrieveUpdateAPIView):
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """
        Optionally restricts the returned notifications to the current user's notifications.
        """
        queryset = super().get_queryset()
        user = self.request.user
        return queryset.filter(user=user)


# notifications/views.py

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status


class MarkNotificationAsReadView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            notification = Notification.objects.get(pk=pk, user=request.user)
        except Notification.DoesNotExist:
            return Response({'detail': 'Not found.'}, status=status.HTTP_404_NOT_FOUND)

        notification.mark_as_read()
        return Response({'status': 'Notification marked as read'}, status=status.HTTP_200_OK)


# notifications/consumers.py

import json
from channels.generic.websocket import AsyncWebsocketConsumer

class NotificationConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.group_name = f"user_{self.scope['user'].id}"

        # Join user group
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        # Leave user group
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name
        )

    async def send_notification(self, event):
        # Send notification to WebSocket
        await self.send(text_data=json.dumps({
            'title': event['title'],
            'message': event['message'],
            'notification_type': event['notification_type'],
            'created_at': event['created_at'],
            'application': event['application']
        }))


# notifications/routing.py

from django.urls import path
from . import consumers

websocket_urlpatterns = [
    path('ws/notifications/', consumers.NotificationConsumer.as_asgi()),
]


# your_project/urls.py

from django.urls import path, include
from rest_framework import routers
from notifications.views import NotificationListView, NotificationDetailView, MarkNotificationAsReadView

router = routers.DefaultRouter()
# You can add more viewsets if needed

urlpatterns = [
    path('api/notifications/', NotificationListView.as_view(), name='notification-list'),
    path('api/notifications/<int:pk>/', NotificationDetailView.as_view(), name='notification-detail'),
    path('api/notifications/<int:pk>/mark-as-read/', MarkNotificationAsReadView.as_view(), name='mark-notification-as-read'),
    path('ws/notifications/', include('notifications.routing.websocket_urlpatterns')),
]

from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework import status
from .models import Notification
from .serializers import NotificationSerializer  # Make sure to create a serializer for your Notification model

class NotificationListView(generics.ListAPIView):
    serializer_class = NotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user)

class NotificationDetailView(generics.RetrieveAPIView):
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        notification = super().get_object()
        if notification.user != self.request.user:
            raise PermissionDenied("You do not have permission to access this notification.")
        return notification

class MarkNotificationAsReadView(generics.UpdateAPIView):
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer  # Ensure this serializer only updates 'read' field
    permission_classes = [permissions.IsAuthenticated]

    def update(self, request, *args, **kwargs):
        notification = self.get_object()
        if notification.user != request.user:
            return Response({"detail": "You do not have permission to mark this notification as read."}, status=status.HTTP_403_FORBIDDEN)
        notification.mark_as_read()
        return Response({"detail": "Notification marked as read."}, status=status.HTTP_200_OK)

class DeleteNotificationView(generics.DestroyAPIView):
    queryset = Notification.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def perform_destroy(self, instance):
        if instance.user != self.request.user:
            raise PermissionDenied("You do not have permission to delete this notification.")
        instance.delete()

from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.generics import CreateAPIView
from .models import Notification
from .serializers import NotificationSerializer
from roles.models import Application

class NotificationCreateView(CreateAPIView):
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]  # Ensure this is correctly set to your auth system

    def perform_create(self, serializer):
        user = self.request.user
        application_id = self.request.data.get('application_id')

        # Ensure that the application exists before saving the notification
        try:
            application = Application.objects.get(id=application_id)
        except Application.DoesNotExist:
            # Raising a validation error so DRF can return the appropriate response
            raise serializers.ValidationError({"detail": "Application not found."})

        # Save the notification
        notification = serializer.save(user=user, application=application)

        # Optional: If you want to return custom data or any additional logic, you can handle it here
        return notification

    # No need to override post method unless needed. DRF handles it.
