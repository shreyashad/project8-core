import logging
import time
from importlib.metadata import metadata

from django.utils.timezone import now
from django.conf import settings

from audit.models import *



class RequestMetricsMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        start_time = time.time()
        response = self.get_response(request)
        end_time = time.time()

        self.capture_metrics(request, response, start_time, end_time)
        return response

    def capture_metrics(self, request, response, start_time, end_time):
        # Calculate the duration of the request in seconds
        duration = end_time - start_time
        # Extract application info if available
        application = Application.objects.filter(name="Auth Server").first()

        # create RequestMetrics data
        request_metrics_data = {
            'application' : application,
            'endpoint': request.path,
            'method': request.method,
            'status_code': response.status_code,
            'duration': duration,
            'timestamp': now(),
            'metadata': {
                'method': request.method,
                'status_code': response.status_code,
                'ip_address': self.get_client_ip(request),
                'user_agent': request.META.get('HTTP_USER_AGENT', ''),
                'query_params': request.GET.dict(),
            }
        }

        try:
            RequestMetrics.objects.create(
                application=request_metrics_data['application'],
                endpoint=request_metrics_data['endpoint'],
                method=request_metrics_data['method'],
                status_code=request_metrics_data['status_code'],
                duration=request_metrics_data['duration'],
                timestamp=request_metrics_data['timestamp'],
                metadata=request_metrics_data['metadata']
            )
        except Exception as e:
            self.logger.error(f"Failed to create request metrics entry: {e}")


    @staticmethod
    def get_client_ip(request):
        """Extract client IP address from request."""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            return x_forwarded_for.split(',')[0]
        return request.META.get('REMOTE_ADDR')


class LogEnrtyMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        self.logger = logging.getLogger(__name__)

    def __call__(self, request):
        response = self.get_response(request)
        self.capture_log(request, response)
        return response

    def capture_log(self, request, response):
        # Handle non-HTTP responses
        if not hasattr(response, 'status_code'):
            return
        # Fetch the Application instance
        application = Application.objects.filter(name="Auth Server").first()
        if not application:
            self.logger.error("Application 'Auth Server' not found.")
            return
        # Determine log level
        if response.status_code < 400:
            level = 'INFO'
        elif response.status_code < 500:
            level = 'WARNING'
        else:
            level = 'ERROR'

        # Log entry data
        log_data = {
            'application': application,
            'level' : level,
            'message': f"{request.method} request to {request.path} returned status {response.status_code}",
            'metadata': {
                'method': request.method,
                'path': request.path,
                'status_code': response.status_code,
                'ip_address': self.get_client_ip(request),
                'user_agent': request.META.get('HTTP_USER_AGENT', ''),
                'query_params': request.GET.dict(),
            },
            'timestamp': now(),

        }
        # Store the log entry in the LogEntry model
        try:
            LogEntry.objects.create(
                application=log_data['application'],
                level=log_data['level'],
                message=log_data['message'],
                metadata=log_data['metadata'],
                timestamp=log_data['timestamp'],
            )
        except Exception as e:
            self.logger.error(f"Failed to create log entry: {e}")

    @staticmethod
    def get_client_ip(request):
        """Extract client IP address from request."""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            return x_forwarded_for.split(',')[0]
        return request.META.get('REMOTE_ADDR')