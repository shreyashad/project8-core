from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from .models import *
from django.contrib.auth.hashers import make_password
from django.contrib.auth.password_validation import validate_password



#for user registrations serializers
class CustomUserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})
    confirm_password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})
    application_name = serializers.CharField(write_only=True, required=True)


    class Meta:
        model = CustomUser
        fields = [
            'first_name', 'last_name', 'emp_code', 'designation','department', 'org_type',
            'org_name', 'org_sub_type', 'assigned_details', 'location_type', 'location_name', 'location_code',
            'username', 'password', 'confirm_password','mobile', 'application_name'
        ]

    def validate(self, data):
        if data['password'] !=data['confirm_password']:
            raise serializers.ValidationError("Password do not match")
        if CustomUser.objects.filter(username=data['username']).exists():
            raise serializers.ValidationError({"username": "This username is already taken."})
        if CustomUser.objects.filter(mobile=data['mobile']).exists():
            raise serializers.ValidationError({"mobile": "This mobile number is already registered."})
        if CustomUser.objects.filter(emp_code=data['emp_code']).exists():
            raise serializers.ValidationError({"emp_code": "This employee code is already in use."})

        return data

    def create(self, validated_data):
        validated_data.pop('confirm_password')
        raw_password = validated_data.pop('password')
        hashed_password = make_password(raw_password)

        application_name = validated_data.pop('application_name', None)

        user = CustomUser.objects.create(
            **validated_data,
            password=hashed_password,
            last_password_change=timezone.now(),
            password_history_json=json.dumps([hashed_password])
        )
        user.save()
        return user


#for user account related serializer
class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = [
            'id', 'first_name', 'last_name', 'org_type', 'org_name',
            'org_sub_type', 'location_type', 'location_name', 'location_code',
            'emp_code', 'department', 'designation', 'mobile', 'username',
            'password', 'assigned_details', 'is_online', 'is_staff', 'is_verified',

        ]

        extra_kwargs = {
            'password': {'write_only': True}
        }

    def create(self, validated_data):
        user = CustomUser.objects.create_user(**validated_data)
        return user

    def update(self, instance, validated_data):
        if 'password' in validated_data:
            password = validated_data.pop('password')
            instance.set_password(password)
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance



# for user profile related serializer
class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = [
            'id', 'user', 'address', 'city', 'state', 'country', 'postal_code',
            'phone_number', 'date_of_birth', 'profile_picture', 'bio'
        ]

    def update(self, instance, validated_data):
        # If a new profile picture is provided, handle it appropriately
        if 'profile_picture' in validated_data:
            # Optionally, handle any cleanup of old files if necessary
            instance.profile_picture = validated_data.pop('profile_picture')

        # Update other fields
        instance = super().update(instance, validated_data)
        instance.save()
        return instance

# for forgot password related serializer part 1
class PasswordResetRequestSerializer(serializers.Serializer):
    username = serializers.CharField(required=True)
    emp_code = serializers.CharField(required=True)
    mobile = serializers.CharField(required=True)

    def validate(self, data):
        """
        Validate the combination of username, emp_code, and mobile.
        """
        username = data.get('username')
        emp_code = data.get('emp_code')
        mobile = data.get('mobile')

        try:
            # Assuming User is your user model and it has these fields
            user = CustomUser.objects.get(username=username, emp_code=emp_code, mobile=mobile)
        except CustomUser.DoesNotExist:
            raise serializers.ValidationError("Invalid combination of username, employee code, and mobile number.")

        # Optionally, you can add more validation or return the user instance
        return data


# for forgot password related serializer part 2
class PasswordResetSerializer(serializers.Serializer):
    token = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)
    confirm_password = serializers.CharField()

    def validate(self, data):
        if data['new_password'] != data['confirm_password']:
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})

        # Validate password strength
        try:
            validate_password(data['new_password'])
        except ValidationError as e:
            raise serializers.ValidationError({"new_password": e.messages})

        return data


# for user changing their password related serializers
class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True, write_only=True)
    new_password = serializers.CharField(required=True, write_only=True)
    confirm_password = serializers.CharField(required=True, write_only=True)

    def validate(self, attrs):
        user = self.context['request'].user

        # Validate old password
        if not user.check_password(attrs['old_password']):
            raise serializers.ValidationError({"old_password": "Old password is incorrect."})

        # Check if new password and confirm password match
        if attrs['new_password'] != attrs['confirm_password']:
            raise serializers.ValidationError({"confirm_password": "New password and confirm password do not match."})

        # Check if the new password is the same as the old password or in history
        if user.is_password_in_history(attrs['new_password']):
            raise serializers.ValidationError({"new_password": "New password cannot be same as old passwords."})

        return attrs




# for admin changing any users
class ChangePasswordUserSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    def validate(self, data):
        user = self.context['request'].user
        old_password = data.get('old_password')
        new_password = data.get('new_password')

        if not user.check_password(old_password):
            raise serializers.ValidationError("Old password is incorrect.")
        if old_password == new_password:
            raise serializers.ValidationError("New password must be different from the old password.")

        if user.is_password_in_history(new_password):
            raise serializers.ValidationError("New password cannot be the same as any of the last 3 passwords.")

        return data

    def save(self):
        user = self.context['request'].user
        new_password = self.validated_data['new_password']
        user.set_password(new_password)
        user.save()


class AuthenticatorFilterSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuthenticatorFilterSettings
        fields = [
            'filter_org_type', 'filter_org_name', 'filter_org_sub_type',
            'filter_location_type', 'filter_location_name', 'filter_department'
        ]
