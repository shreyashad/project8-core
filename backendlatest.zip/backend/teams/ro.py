from datetime import timezone

from django.shortcuts import render
from rest_framework import status, generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.authentication import JWTAuthentication

from .models import *
from .serializers import *
from rest_framework.permissions import IsAuthenticated
# Create your views here.


# Team Views
class AllTeamListAPIView(generics.ListAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializerList

class UserTeamsView(generics.ListAPIView):
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        # Get the current user
        user = self.request.user
        # Filter teams based on membership
        return Team.objects.filter(users=user)

class CreatedTeamsView(generics.ListAPIView):
    serializer_class = TeamSerializerList
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        # Get the current user
        user = self.request.user
        # Filter teams where the user is the creator
        return Team.objects.filter(created_by=user)




class TeamCreateAPIView(generics.CreateAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]


    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)


class TeamRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer



class TeamMembersAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        try:
            team = Team.objects.get(pk=pk)
            memberships = TeamMembership.objects.filter(team=team)
            serializer = TeamMembershipSerializer(memberships, many=True)
            return Response(serializer.data)
        except Team.DoesNotExist:
            return Response({'error': 'Team not found'}, status=status.HTTP_404_NOT_FOUND)

# Team Membership Views
class TeamMembershipListCreateAPIView(generics.ListAPIView):
    queryset = TeamMembership.objects.all()
    serializer_class = TeamMembershipSerializer
    permission_classes = [IsAuthenticated]

class TeamMembershipRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = TeamMembership.objects.all()
    serializer_class = TeamMembershipSerializer
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        try:
            memberships = TeamMembership.objects.filter(team=pk)
            serializer = TeamMembershipSerializer(memberships, many=True)
            return Response(serializer.data)
        except TeamMembership.DoesNotExist:
            return Response({'error': 'TeamMembership not found'}, status=status.HTTP_404_NOT_FOUND)

# # Team Invite Views
# class TeamInviteListCreateAPIView(generics.ListCreateAPIView):
#     queryset = TeamInvite.objects.all()
#     serializer_class = TeamInviteSerializer
#     permission_classes = [IsAuthenticated]
#
# class TeamInviteRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = TeamInvite.objects.all()
#     serializer_class = TeamInviteSerializer
#     permission_classes = [IsAuthenticated]
#
#     def post(self, request, pk):
#         try:
#             invite = TeamInvite.objects.get(pk=pk)
#             status = request.data.get('status')
#             if status in ['Accepted', 'Declined']:
#                 invite.status = status
#                 invite.responded_at = timezone.now()
#                 invite.save()
#                 return Response({'status': 'Invitation responded'})
#             return Response({'error': 'Invalid status'}, status=status.HTTP_400_BAD_REQUEST)
#         except TeamInvite.DoesNotExist:
#             return Response({'error': 'TeamInvite not found'}, status=status.HTTP_404_NOT_FOUND)
#
# # Team Notification Views
# class TeamNotificationListCreateAPIView(generics.ListCreateAPIView):
#     queryset = TeamNotification.objects.all()
#     serializer_class = TeamNotificationSerializer
#     permission_classes = [IsAuthenticated]
#
# class TeamNotificationRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = TeamNotification.objects.all()
#     serializer_class = TeamNotificationSerializer
#     permission_classes = [IsAuthenticated]
#
#     def get(self, request, pk):
#         try:
#             notifications = TeamNotification.objects.filter(team=pk)
#             serializer = TeamNotificationSerializer(notifications, many=True)
#             return Response(serializer.data)
#         except TeamNotification.DoesNotExist:
#             return Response({'error': 'TeamNotification not found'}, status=status.HTTP_404_NOT_FOUND)
