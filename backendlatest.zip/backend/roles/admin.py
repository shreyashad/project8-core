from django.contrib import admin
from .models import *
# Register your models here.

@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ["name",  "description", "base_url","active" ]


@admin.register(Permission)
class PermissionAdmin(admin.ModelAdmin):
    list_display = ["name",  "description", "application" ]


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ["name",  "description", "application"]


@admin.register(UserRole)
class UserRoleAdmin(admin.ModelAdmin):
    list_display = ["user",  "role", "application"]


