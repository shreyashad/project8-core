from  rest_framework.permissions import BasePermission

from backend.wsgi import application
from roles.models import Application, UserRole


class HasApplicationUserPermission(BasePermission):
    """
    Custom permission to check if the user has the required permission
    for a specific application
    """

    def has_permission(self, request, view):
        """
        Check if the user has permission for the view they are trying to access.
        the view should define a `permission_name` attribute that is used for permission lookup.
        """
        application_name = view.kwargs.get("application_name") # Get application_name
        try:
            application = Application.objects.get(name=application_name)
        except Application.DoesNotExist:
            return False

        # Use the view's `permission_name` attribute for permission lookup
        permission_name = getattr(view, "permission_name", None)

        if not permission_name:
            return False
        # Check if the user has a role for the given application
        user_roles = UserRole.objects.filter(user=request.user, application=application)

        if not user_roles.exists():
            return False  # User does not have any role for this application

        # Check if any of the user's roles has the permission matching the `permission_name`
        for user_role in user_roles:
            permissions = user_role.role.permissions.all()
            if permissions.filter(name=permission_name).exists():
                return True  # User has permission for this view

        return False  # User does not have permission for this view
