# tests.py
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from django.core.files.base import ContentFile
from import_export import resources
from .models import Locations  # Replace with your actual model
from openpyxl import Workbook
import io

class ExcelImportViewLocationTests(APITestCase):
    def setUp(self):
        self.url = reverse('import-locations/')  # Replace with your actual URL name for the view

    def create_excel_file(self):
        # Create a dummy Excel file
        wb = Workbook()
        ws = wb.active
        ws.append(['Column1', 'Column2'])  # Add header
        ws.append([1, 'A'])  # Add a row
        ws.append([2, 'B'])  # Add another row

        excel_file = io.BytesIO()
        wb.save(excel_file)
        excel_file.name = 'test.xlsx'
        excel_file.seek(0)
        return ContentFile(excel_file.getvalue(), name='test.xlsx')

    def test_successful_file_upload(self):
        excel_file = self.create_excel_file()

        response = self.client.post(self.url, {'file': excel_file}, format='multipart')

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('status', response.data)
        self.assertEqual(response.data['status'], 'File processed successfully')

    def test_no_file_provided(self):
        response = self.client.post(self.url, {}, format='multipart')

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('error', response.data)
        self.assertEqual(response.data['error'], 'No file provided')

    def test_invalid_file_format(self):
        text_file = ContentFile(b'This is not a valid Excel file.', name='test.txt')

        response = self.client.post(self.url, {'file': text_file}, format='multipart')

        self.assertEqual(response.status_code, status.HTTP_500_INTERNAL_SERVER_ERROR)  # Adjust based on your error handling logic
        self.assertIn('error', response.data)
