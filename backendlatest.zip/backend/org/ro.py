from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated,AllowAny
from rest_framework_simplejwt.authentication import JWTAuthentication
from .serializers import *
from .resources import *
from import_export.formats.base_formats import XLSX


class OrganizationTypeListCreateAPIView(generics.ListCreateAPIView):
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)


class OrganizationRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)





class OrganizationListCreateAPIView(generics.ListCreateAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)


class OrganizationRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


class OrganizationSubTypeListCreateAPIView(generics.ListCreateAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    # permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class OrganizationSubTypeRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    # permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


class LocationsListCreateAPIView(generics.ListCreateAPIView):
    queryset = Locations.objects.all()
    serializer_class = LocationsSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class LocationsRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Locations.objects.all()
    serializer_class = LocationsSerializer
    # permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


import logging

logger = logging.getLogger(__name__)
# class ExcelImportViewLocation(APIView):
#     def post(self, request, *args, **kwargs):
#         if 'file' not in request.FILES:
#             return Response({'error': 'No file provided'}, status=status.HTTP_400_BAD_REQUEST)
#
#         file = request.FILES['file']
#         file_path = default_storage.save('temp.xlsx', ContentFile(file.read()))
#
#         try:
#             resource = LocationsResource()  # Ensure this is defined
#             dataset = resource.import_data(file_path, format=XLSX)  # Check that XLSX is defined
#
#             result = resource.import_data(dataset, user_id=str(request.user.id), dry_run=False)
#             print(type(result))
#             return Response({'status': 'File processed successfully', 'import_result': result.summary},
#                             status=status.HTTP_200_OK)
#         except Exception as e:
#             logger.error("Error during import: %s", str(e))
#             return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
#
#         finally:
#             default_storage.delete(file_path)


class ExcelImportViewLocation(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        if 'file' not in request.FILES:
            return Response({'error': 'No file provided'}, status=status.HTTP_400_BAD_REQUEST)

        file = request.FILES['file']
        file_path = default_storage.save('temp.xlsx', ContentFile(file.read()))

        try:
            resource = LocationsResource()
            dataset = resource.import_data(file_path, format=XLSX)
            print("Dataset:", dataset)
            result = resource.import_data(dataset, user_id=str(request.user.id), dry_run=False)

            # Check the type of result before proceeding
            if isinstance(result, str):
                raise ValueError("Result is a string, expected an object with headers.")

            return Response({'status': 'File processed successfully', 'import_result': result.summary},
                            status=status.HTTP_200_OK)
        except Exception as e:
            print("Error in import_data:", e)
            logger.error("Error during import: %s", str(e))
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        finally:
            default_storage.delete(file_path)




class DepartmentListCreateAPIView(generics.ListCreateAPIView):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class DepartmentListAPIView(generics.ListAPIView):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer




class DepartmentRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)


class DesignationListCreateAPIView(generics.ListCreateAPIView):
    queryset = Designation.objects.all()
    serializer_class = DesignationSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)



class DesignationListAPIView(generics.ListAPIView):
    queryset = Designation.objects.all()
    serializer_class = DesignationSerializer
    permission_classes = [AllowAny]




class DesignationRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Designation.objects.all()
    serializer_class = DesignationSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)




class OrgTypeListView(APIView):
    def get(self, request, *args, **kwargs):
        org_types = Organization.objects.values_list('org_type', flat=True).distinct()
        return Response(org_types, status=status.HTTP_200_OK)


class OrgNameList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_type = request.query_params.get('orgType')
        if org_type:
            organizations = Organization.objects.filter(org_type=org_type)
        else:
            organizations = Organization.objects.filter(org_type=org_type)
        serializer = OrganizationSerializer(organizations, many=True)
        return Response(serializer.data)



class OrgSubTypeList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_type = request.query_params.get('orgType')
        print("ptr orgtype",org_type)
        if org_type:
            subtypes = OrganizationSubType.objects.filter(org_type=org_type)
        else:
            subtypes = OrganizationSubType.objects.filter(org_type=org_type)
        serializer = OrgSubTypeSerializer(subtypes, many=True)
        return Response(serializer.data)



class LocationTypeList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        if org_name:
            location_type = Locations.objects.filter(org_name=org_name).values_list('location_type', flat=True).distinct()
        else:
            location_type = Locations.objects.values_list('location_type', flat=True).distinct()

        return Response(location_type, status=status.HTTP_200_OK)

class LocationNameList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        location_type = request.query_params.get('location_type')

        if org_name and location_type:
            location_queryset = Locations.objects.filter(org_name=org_name, location_type=location_type).values('location_name')
        else:
            location_queryset = Locations.objects.filter(org_name=org_name).values('location_name')

        location_names = list(location_queryset)  # Convert queryset to a list of dictionaries

        return Response(location_names, status=status.HTTP_200_OK)



class LocationCodeList(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        org_name = request.query_params.get('orgName')
        location_type = request.query_params.get('location_type')
        location_name = request.query_params.get('location_name')

        if org_name and location_type and location_name:
            location_type = Locations.objects.filter(org_name=org_name, location_type=location_type, location_name=location_name).values_list('location_code', flat=True).distinct()
        else:
            location_type = Locations.objects.filter(org_name=org_name,location_name=location_name).values_list('location_code', flat=True).distinct()

        return Response(location_type, status=status.HTTP_200_OK)


from openpyxl import load_workbook
from django.core.files.storage import default_storage
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Organization, AuditLogEntry, ActionType
from .serializers import OrganizationSerializer
from rest_framework.permissions import IsAuthenticated
from django.utils.timezone import now
from django.contrib.contenttypes.models import ContentType


class OrganizationExcelImportView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        # Ensure a file is provided in the request
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file provided"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Save the file temporarily
            file_path = default_storage.save(f"temp/{file.name}", file)

            # Load the Excel workbook and sheet
            wb = load_workbook(file_path)
            sheet = wb.active

            # List to hold new organizations
            new_organizations = []

            # Skip the header row (min_row=2) and process each row
            for row in sheet.iter_rows(min_row=2, values_only=True):  # Assuming first row is the header
                org_name, org_type = row  # Assuming the first column is name and second column is org_type

                if org_name and org_type:  # Check if both columns are present
                    new_organizations.append(Organization(
                        name=org_name,
                        org_type=org_type,
                        created_at=now(),
                        updated_at=now(),
                        created_by=request.user,  # Assuming the user is logged in
                        updated_by=request.user,
                    ))

            # Bulk create organizations
            Organization.objects.bulk_create(new_organizations)

            # Create the audit log entry for the action
            content_type = ContentType.objects.get_for_model(Organization)  # Get ContentType for Organization
            audit_details = f"Created {len(new_organizations)} organizations from Excel file."

            # Create an audit log for the organization creation
            AuditLogEntry.objects.create(
                user=request.user,  # Logged in user
                action_type=ActionType.CREATE,  # Action type is CREATE
                object_type=content_type,  # The type of object (Organization)
                object_id=str(len(new_organizations)),  # The number of created organizations as the object_id
                content_object=None,  # No specific object being targeted (bulk creation)
                details=audit_details  # The details of the action
            )

            # Return success response with the count of new organizations created
            return Response({
                "message": "File processed successfully",
                "created_count": len(new_organizations)
            }, status=status.HTTP_201_CREATED)

        except Exception as e:
            # Handle any errors during file processing and log the error in audit log
            AuditLogEntry.objects.create(
                user=request.user,
                action_type=ActionType.ERROR,
                object_type=None,
                object_id=None,
                content_object=None,
                details=f"Error processing Excel file: {str(e)}"
            )
            return Response({"error": f"Error processing file: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
