from django.contrib.auth.decorators import permission_required
from django.core.files.storage import default_storage
from openpyxl.reader.excel import load_workbook
from tutorial.asgi import application

from roles.permissions import HasApplicationUserPermission
from .serializers import *
from rest_framework import generics,status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.contrib.contenttypes.models import ContentType
from audit.models import *
from django.utils.timezone import now
from rest_framework.views import APIView



class OrgTypeListView(generics.ListAPIView):
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name = "fetch org_type list"

    def list(self, request, *args, **kwargs):
        application = Application.objects.get(name="Auth Server")
        # List OrgTypes and log this action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of OrgTypes"
        )
        return super().list(request, *args, **kwargs)


class OrgTypeCreateView(generics.CreateAPIView):
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name =""

    def perform_create(self, serializer):
        # Perform the normal creation
        org_type = serializer.save()
        application = Application.objects.get(name="Auth Server")
        # Log the create action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(org_type.id),
            object_type=content_type,
            content_object=org_type,
            details=f"Created OrgType: {org_type.org_type}"
        )

class OrgTypeRetrieveView(generics.RetrieveUpdateDestroyAPIView):
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    # Define permission names for each action
    permission_name_retrieve = "retrieve organization"
    permission_name_update = "update organization"
    permission_name_delete = "delete organization"

    def perform_retrieve(self, request, *args, **kwargs):
        self.permission_name = self.permission_name_retrieve
        self.check_permissions(request)

        application = Application.objects.get(name="Auth Server")
        # Log the 'READ' action for this specific OrgType retrieval
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched OrgType: {instance.org_type}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        self.permission_name = self.permission_name_update
        self.check_permissions(self.request)

        # Perform the normal update
        org_type = serializer.save()

        application = Application.objects.get(name="Auth Server")
        # Log the update action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(org_type.id),
            object_type=content_type,
            content_object=org_type,
            details=f"Updated OrgType: {org_type.org_type}"
        )

    def perform_destroy(self, instance):
        # Log the delete action
        application = Application.objects.get(name="Auth Server")
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted OrgType: {instance.org_type}"
        )
        super().perform_destroy(instance)




class OrganizationListView(generics.ListAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    permission_name = ""

    def list(self, request, *args, **kwargs):
        application = Application.objects.get(name="Auth Server")
        # List Organizations and log this action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of Organizations"
        )
        return super().list(request, *args, **kwargs)


class OrganizationCreateView(generics.CreateAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    def perform_create(self, serializer):
        # Perform the normal creation
        organization = serializer.save()

        application = Application.objects.get(name="Auth Server")
        # Log the create action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(organization.id),
            object_type=content_type,
            content_object=organization,
            details=f"Created Organization: {organization.org_name}"
        )


class OrganizationRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated, HasApplicationUserPermission]

    # Define permission names for each action
    permission_name_retrieve = "retrieve organization"
    permission_name_update = "update organization"
    permission_name_delete = "delete organization"

    def perform_retrieve(self, request, *args, **kwargs):
        # Set permission_name for retrieve action
        self.permission_name = self.permission_name_retrieve

        # Permission check will happen here through the permission classes
        self.check_permissions(request)



        # Log the 'READ' action for this specific Organization retrieval
        instance = self.get_object()
        application = Application.objects.get(name="Auth Server")
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched Organization: {instance.org_name}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        # Set permission_name for update action
        self.permission_name = self.permission_name_update

        # Permission check will happen here through the permission classes
        self.check_permissions(self.request)

        # Perform the normal update
        organization = serializer.save()
        application = Application.objects.get(name="Auth Server")
        # Log the update action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(organization.id),
            object_type=content_type,
            content_object=organization,
            details=f"Updated Organization: {organization.org_name}"
        )

    def perform_destroy(self, instance):
        application = Application.objects.get(name="Auth Server")
        # Log the delete action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted Organization: {instance.org_name}"
        )
        super().perform_destroy(instance)


class OrganizationExcellImportView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        application = Application.objects.get(name="Auth Server")
        file = request.FILES.get("file")
        if not file:
            return Response({"error": "No file provided"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            file_path = default_storage.save(f"temp/{file.name}", file)

            wb = load_workbook(file_path)
            sheet = wb.active

            new_organizations = []

            for row in sheet.iter_rows(min_row=2, values_only=True):
                org_name, org_type = row

                if org_name and org_type:
                    new_organizations.append(Organization(
                        name=org_name,
                        org_type=org_type,
                        created_at=now(),
                        updated_at=now(),
                        created_by=request.user,  # Assuming the user is logged in
                        updated_by=request.user,
                    ))

            Organization.objects.bulk_create(new_organizations)

            content_type = ContentType.objects.get_for_model(Organization)
            audit_details = f"Created {len(new_organizations)} organization from Excel file."

            AuditLogEntry.objects.create(
                user= request.user,
                appliaction=application,
                action_type=ActionType.CREATE,
                object_type=content_type,
                object_id=str(len(new_organizations)),
                content_object=None,
                details=audit_details
            )
            return Response({
                "message": "File processed successfully",
                "created_count": len(new_organizations)
            }, status=status.HTTP_201_CREATED)

        except Exception as e:
            # Handle any errors during file processing and log the error in audit log
            AuditLogEntry.objects.create(
                user=request.user,
                application=application,
                action_type=ActionType.ERROR,
                object_type=None,
                object_id=None,
                content_object=None,
                details=f"Error processing Excel file: {str(e)}"
            )
            return Response({"error": f"Error processing file: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class OrganizationSubTypeListView(generics.ListAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        # List OrganizationSubTypes and log this action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of OrganizationSubTypes"
        )
        return super().list(request, *args, **kwargs)


class OrganizationSubTypeCreateView(generics.CreateAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        # Perform the normal creation
        organization_subtype = serializer.save()

        # Log the create action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(organization_subtype.id),
            object_type=content_type,
            content_object=organization_subtype,
            details=f"Created OrganizationSubType: {organization_subtype.org_sub_type}"
        )


class OrganizationSubTypeRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    permission_classes = [IsAuthenticated]

    def perform_retrieve(self, request, *args, **kwargs):
        # Log the 'READ' action for this specific OrganizationSubType retrieval
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched OrganizationSubType: {instance.org_sub_type}"
        )
        return super().retrieve(request, *args, **kwargs)


    def perform_update(self, serializer):
        # Perform the normal update
        organization_subtype = serializer.save()

        # Log the update action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(organization_subtype.id),
            object_type=content_type,
            content_object=organization_subtype,
            details=f"Updated OrganizationSubType: {organization_subtype.org_sub_type}"
        )

    def perform_destroy(self, instance):
        # Log the delete action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted OrganizationSubType: {instance.org_sub_type}"
        )
        super().perform_destroy(instance)

