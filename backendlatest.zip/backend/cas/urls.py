from django.urls import path
from .views import *
from rest_framework_simplejwt.views import TokenRefreshView

urlpatterns = [
    path('login/',LoginAPIView.as_view(), name='login'),
    path('user-logout/',LogoutView.as_view(), name='logout'),
    path('validate-ticket/', ValidateServiceTicketAPIView.as_view(), name='validate-ticket'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('token/introspect/', TokenIntrospectionAPIView.as_view(), name='token_introspect'),
    path('validate-session/', ValidateSessionView.as_view(), name='validate_session'),
]