/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ["127.0.0.1", "localhost","127.0.0.1:9001"], // Add any other domains as necessary
    },
    // webpack(config) {
    //     // Enabling WebAssembly support
    //     config.experiments = {
    //       asyncWebAssembly: true,
    //       topLevelAwait: true, // Ensure top-level await is supported
    //     };
    
    //     // Return updated config
    //     return config;
    // },
};

export default nextConfig;
