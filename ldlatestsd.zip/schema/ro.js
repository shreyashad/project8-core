import { z } from "zod";

// Fetch question types dynamically from the backend (e.g., ['MultipleChoice', 'TrueFalse', 'FillInTheBlanks'])
const questionTypes = ["MultipleChoice", "TrueFalse", "FillInTheBlanks", "Ordering", "ShortAnswer"];

// Validate the correct format of duration (HH:MM:SS)
const durationSchema = z.string().regex(/^([0-9]{1,2}):([0-5][0-9]):([0-5][0-9])$/, "Duration must be in HH:MM:SS format");

// Question Type Schema (you can extend this to be dynamic based on the database)
const QuestionTypeSchema = z.enum(questionTypes, "Invalid question type");

// Multiple Choice Option Schema (for `MultipleChoice` questions only)
const MultipleChoiceOptionSchema = z.object({
  text: z.string().min(1, "Option text cannot be empty"),
  isCorrect: z.boolean(),
});

// Question Schema
const QuestionSchema = z.object({
  question_text: z.string().min(1, "Question text is required"), // The text of the question
  question_type: QuestionTypeSchema, // Type of question (e.g., MultipleChoice, TrueFalse, etc.)
  marks: z.number().positive("Marks must be a positive number"), // Marks for this question
  options: z
    .array(MultipleChoiceOptionSchema)
    .min(2, "Multiple choice questions must have at least two options")
    .optional(), // Options for MultipleChoice questions (optional for others)
  correct_answer: z
    .string()
    .min(1, "Correct answer is required") 
    .optional(), // Correct answer (required for FillInTheBlanks, TrueFalse, etc.)
});

// Quiz Schema
const QuizSchema = z.object({
  title: z.string().min(1, "Quiz title is required"), // Title of the quiz
  description: z.string().optional(), // Optional description
  duration: durationSchema, // Duration of the quiz in HH:MM:SS format
  pass_marks: z.number().positive("Pass marks must be a positive number"), // Pass marks required
  questions: z
    .array(QuestionSchema)
    .min(1, "Quiz must have at least one question"), // Ensure that there are questions in the quiz
});
