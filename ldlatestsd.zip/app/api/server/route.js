import axios from "axios";



const API_CAS_URL = process.env.NEXT_PUBLIC_AUTH_SERVER_API_BASE_URL || "";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";



// All auth server related url functions
// for user reset password
export async function getpasswordResetRequest(userDetails) {
    try {
        const response = await axios.post(`${API_CAS_URL}api/password-reset-request/`, userDetails);
        return response.data
    } catch(error) {
        console.error("Error while password rest :", error);
        throw error;
    }
};

export async function getResetPassword(userDetails) {
    try {
        const response = await axios.post(`${API_CAS_URL}api/reset-password/`, userDetails);
        return response.data
    } catch(error) {
        console.error("Error while password rest :", error);
        throw error;
    }
};

// for user notifications
export async function fetchNotification(accessToken, application_name) {
    try{
        const response = await axios.get(`${API_CAS_URL}api/notifications/?application_name=${application_name}`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data
    } catch(error) {
        console.error("Error while fetching notifications` :", error);
        throw error;
    }
};


// for user login
export async function fetchApplicationdetails() {
    try {
        const response = await axios.post(`${API_CAS_URL}api/application-details/`, {
            name: process.env.APP_NAME
        });
        return response.data;
    } catch (error) {
        throw new Error("Failed to fetch application details");
    }
};

export async function validateTicket(serviceTicket, applicationId) {
    try {
        const response = await axios.post(`${API_CAS_URL}api/validate-ticket/`, {
            service_ticket: serviceTicket,
            application_id: applicationId,
        });
        return response.data; // Ensure this returns the expected user details
    } catch (error) {
        console.error('Error validating ticket:', error);
        throw new Error('Error validating ticket');
    }
};

export async function validateSession(sessionKey) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/validate-session/`, {
            headers: {
                Authorization: `Bearer ${sessionKey}`,
            },
        });
        return response.status === 200;
    } catch (error) {
        console.error("Session validation error:", error);
        return false;
    }
};



// for user registration

export async function fetchDesignations() {
    try{
        const response = await axios.get(`${API_CAS_URL}api/designations/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch designation");
    }
};

export async function fecthDepartments() {
    try{
        const response = await axios.get(`${API_CAS_URL}api/departments/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch departments");
    }
};


export async function fetchOrgTypes() {
    try {
        const response = await axios.get(`${API_CAS_URL}api/org-type-list/`);
        console.log("Org types Data:", response.data)
        return response.data;

    } catch (error) {
        console.error("Error fetching Org types:", error);
        throw error;
    }
};

export async function fetchOrgNames(orgType) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/org-name-list/?orgType=${orgType}`);
        console.log("Org Names Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Org Names:", error );
        throw error;
    }
};

export async function fetchOrgSubTypes(orgType) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/org-subtypes/?orgType=${orgType}`);
        console.log("Org SubTypes Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Org SubTypes:", error);
        throw error;
    }
};

export async function fetchLocationTypes(orgName) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/location-type-list/?orgName=${orgName}`);
        console.log("Location Type Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Type:", error );
        throw error;
    }
};



export async function fetchLocationName(orgName, location_type) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/location-name-list/`, {
            params: {
                orgName: orgName,
                location_type: location_type,
            }
        });
        console.log("Location Name Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Name:", error);
        throw error;
    }
};

export async function fetchLocationCode(orgName, location_type, location_name) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/location-code-list/`, {
            params: {
                orgName: orgName,
                location_type: location_type,
                location_name: location_name
            }
        });
        console.log("Location Code Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Code:", error);
        throw error;
    }
};


export async function register(formData) {
    try {
        const response = await axios.post(`${API_CAS_URL}api/register/`, formData);
        console.log("userdetails:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error while registration:", error);
        throw error;
    }
};

// common functions required from auth_server projec 



export async function fetchUserByAppRole(accessToken,application_name,role) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/users/${application_name}/${role}/by-apps/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        console.log("users list:", response.data);
        return response.data;
    }  catch (error) {
        console.error('Error fetching users:', error.response ? error.response.data : error.message);
        return null;
    }
}


export async function fetchAdminTrainersUsername(accessToken) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/online-users-by-application/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            params: {
                application_name: applicationName, // Pass the application name as a query parameter
            },
        });
        console.log("onlineusers:", response.data.active_user);
        return response.data.online_count;
        
    } catch (error) {
        console.error('Error fetching total user count:', error.response ? error.response.data : error.message);
        return null;
    }
}


// for common views related functions

export async function fetchUserAccountDetails(accessToken) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/user-account/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching user account data:", error);
        throw error;
    }
};



export async function fetchUserProfileDetails(accessToken) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/user-profile/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }, 
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching profile data:", error);
        throw error;
    }
};



export async function updateUserProfileData (accessToken, profileData) {
  try {
    const response = await axios.put(`${API_CAS_URL}api/user-profile/`, profileData, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error updating profile data:", error);
    throw error;
  }
};
// for teams related 

export async function fetchAllTeamlist(accessToken) {
    // to get all the team list 
    try {
        const response = await axios.get(`${API_CAS_URL}api/teams-all-list/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching all team list:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function fetchTeamlistByUser(accessToken) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/team-list-by-user/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching team list by users:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function fetchTeamlistByRole(accessToken, role) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/team-list-by-role/`, { 
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            params: {
                role: role,  // Adding the role as a query parameter
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching self team list:', error.response ? error.response.data : error.message);
        return null;
    }
};


export async function createNewTeam(accessToken, TeamData) {
    try {
        // Format the TeamData to ensure users have user ID and role
        const formattedData = {
            ...TeamData,
            users: TeamData.users.map(user => ({
                user: user.user,  // User ID
                role: user.role || 'Member'  // Role: Leader or Member
            }))
        };

        const response = await axios.post(`${API_CAS_URL}api/create-teams/`, formattedData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });

        console.log("Team created successfully:", response.data);
        return response.data;
    } catch (error) {
        console.error('Error creating new team:', error.response ? error.response.data : error.message);
        throw error;
    }
};


export async function fetchTeamDetails(accessToken, teamId) {
    try{
        const response = await axios.get(`${API_CAS_URL}api/teams/${teamId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch(error) {
        console.error('Error fetching teams details:', error.response ? error.response.data : error.message);
        throw error;
    }
};


export async function updateTeamDetails(accessToken, teamId, teamData) {
    try{
        const response = await axios.get(`${API_CAS_URL}api/teams/${teamId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch(error) {
        console.error('Error fetching teams details:', error.response ? error.response.data : error.message);
        throw error;
    }
}; 





export async function fetchSimilarDeptUsersList(accessToken) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/similar-department-users/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data; // Make sure to return the data from the response
    } catch (error) {
        console.error('Error fetching similar user details:', error.response ? error.response.data : error.message);
        throw error; // Rethrow the error to be caught by the caller
    }
};


// Trainers Admin Dashboard related
export async function fetchTotalOnlineUserCount(accessToken, applicationName) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/online-users-by-application/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            params: {
                application_name: applicationName, // Pass the application name as a query parameter
            },
        });
        console.log("onlineusers:", response.data);
        return response.data.online_count;
        
    } catch (error) {
        console.error('Error fetching total user count:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function fetchUserbyRoleAppCount(accessToken, applicationName, roleName) {
    try {
        // Make sure to pass both application_name and role_name as query params
        const response = await axios.get(`${API_CAS_URL}api/user-count-role-app/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`, // Pass the access token in the header
            },
            params: {
                app_name: applicationName, // Pass the application name as a query parameter
                role_name: roleName,               // Pass the role name as a query parameter
            },
        });

        console.log("onlineusers:", response.data); // Log the response from the backend
        return response.data.user_count;  // Assuming the response returns 'online_count'

    } catch (error) {
        console.error('Error fetching total user count by role and app:', error.response ? error.response.data : error.message);
        return null;  // Return null in case of an error
    }
};




export async function fetchTotalTrainersCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/trainer-count/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        console.log("onlineusers:", response.data.active_user);
        return response.data.trainer_count;
        
    } catch (error) {
        console.error('Error fetching total user count:', error.response ? error.response.data : error.message);
        return null;
    }
};

// Course Category Management Related 
// for Course Difficulty Level related functions

export async function fetchDifficultyLevelListData(accessToken) {
    try{
        const response = await axios.get(`${API_BASE_URL}api/difficulty-level-list/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data
    }catch (error) {
        console.error('Error fetching Difficulty Leve:', error.response ? error.response.data : error.message);
        return null;
    }

};

export async function createNewDifficultyLevel(accessToken, levelData) {
    try{
        const response = await axios.post(`${API_BASE_URL}api/difficulty-level-list/`, levelData,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data
    }catch (error) {
        console.error('Error fetching Difficulty Leve:', error.response ? error.response.data : error.message);
        return null;
    }

};

export async function fetchDifficultyLevelDetails(accessToken, diffLevelId) {
    if (!diffLevelId) {
        throw new Error("level Id is required");
    }
    
    try {
        const response = await axios.get(`${API_BASE_URL}api/difficulty-level/${diffLevelId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching Difficulty Leve details:", error.response ? error.response.data : error.message);
        throw error;
    }
};

export async function deleteDifficultyLevelDetails(accessToken, diffLevelId) {
    if (!diffLevelId) {
        throw new Error("level Id is required");
    }
    
    try {
        const response = await axios.delete(`${API_BASE_URL}api/difficulty-level/${diffLevelId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error deleting Difficulty Leve details:", error.response ? error.response.data : error.message);
        throw error;
    }
};

export async function updateDifficultyLevelDetails(accessToken, diffLevelId, diffLevelData) {
    if (!diffLevelId) {
        throw new Error("level Id is required");
    }
    
    try {
        const response = await axios.put(`${API_BASE_URL}api/difficulty-level/${diffLevelId}/details/`, diffLevelData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error Updating Difficulty Leve details:", error.response ? error.response.data : error.message);
        throw error;
    }
};


// for Course Category related 
export async function fetchCategoryData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/course-category-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data
    } catch (error) {
        console.error('Error fetching Category request:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function createNewCategory(accessToken, categoryData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/create-course-category/`, categoryData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'multipart/form-data',
            },
        });
        console.log("submited category data:", categoryData);
        console.log("new category data:", response.data);
        return response.data
        
    } catch (error) {
        console.error('Error while creating Category request:', error.response ? error.response.data : error.message);
        throw new Error(error.response?.data || "An error occurred while creating the category.");
    }
};

export async function fetchCourseCategoryDetails(accessToken, categoryid) {
    if (!categoryid) {
        throw new Error("courseId is required");
    }
    
    try {
        const response = await axios.get(`${API_BASE_URL}api/course-category/${categoryid}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching course details:", error.response ? error.response.data : error.message);
        throw error;
    }
};

export async function deleteCourseCategory(accessToken, categoryid ) {
    try {
      const response = await axios.delete(`${API_BASE_URL}api/course-category/${categoryid}/details/`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error while deleting category details:", error);
      throw error;
    }
};
  
export async function updateCourseCategory(accessToken, categoryid, categoryData) {
    try {
      const response = await axios.put(`${API_BASE_URL}api/course-category/${categoryid}/details/`, categoryData, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error while updating category details:", error);
      throw error;
    }
};
  
// for Course Related 
export async function fetchCourseListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/course-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        console.log("course data:", response);
        return response.data
    } catch (error) {
        console.error('Error fetching Course request:', error.response ? error.response.data : error.message);
        return null;
    }
};


export async function fetchCourseEnrolledListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/enrolled-course-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        console.log("course data:", response);
        return response.data
    } catch (error) {
        console.error('Error fetching Course request:', error.response ? error.response.data : error.message);
        return null;
    }
};


export async function createNewCourse(accessToken, courseData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/create-course/`, courseData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            // Log detailed error message from backend
            console.error("Backend Error:", error.response.data);
        }
        throw error.response ? error.response.data : { status: ["An unexpected error occurred."] };
    }
};



export async function fetchCourseDetails(accessToken, courseId) {
    if (!courseId) {
        throw new Error("courseId is required");
    }
    
    try {
        const response = await axios.get(`${API_BASE_URL}api/course/${courseId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching course details:", error.response ? error.response.data : error.message);
        throw error;
    }
}

export async function updateCourseDetails(accessToken, courseId, courseData) {
    if (!courseId) {
        throw new Error("courseId is required");
    }
    
    try {
        const response = await axios.patch(`${API_BASE_URL}api/course/${courseId}/`, courseData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        
        return response.data;
    } catch (error) {
        console.error("Error updating course data:", error.response ? error.response.data : error.message);
        throw error;
    }
}


export async function deleteCourse(accessToken, courseId ) {
    try {
        const response = await axios.delete(`${API_BASE_URL}api/course/${courseId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error deleting category data:", error);
        throw error;
    }
};




export async function courseEnrollment(accessToken, courseId) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/course-enrollment/`, 
            { 
                course: courseId,  // Course ID
                  
            },
            {
                headers: {
                    Authorization: `Bearer ${accessToken}`,
                }
            }
        );
        return response.data;
    } catch (error) {
        console.error("Error enrolling in course:", error);
        throw new Error("Failed to enroll. Please try again later.");
    }
};


export async function checkEnrollmentStatus(accessToken, courseId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/course-enrollment-status/${courseId}/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`, // Pass the auth token
            },
        });

        // Return the data if successful
        return response.data;
    } catch (error) {
        console.error("Error checking enrollment status:", error);

        // Optionally, you can differentiate errors based on the status code
        if (error.response) {
            // The request was made, and the server responded with a status code
            console.error("Server responded with:", error.response.status);
        } else if (error.request) {
            // The request was made but no response was received
            console.error("No response received:", error.request);
        } else {
            // Some other error
            console.error("Error:", error.message);
        }

        // Throw a user-friendly error message
        throw new Error("Could not fetch enrollment status. Please try again later.");
    }
};


// for Training Management

// for training request

export async function fetchHODTrainingRequest(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/hod/training-requests/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data
    } catch (error) {
        console.error('Error fetching HOD Training request:', error.response ? error.response.data : error.message);
        return null;
    }
};


export async function fetchTrainingRequest(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/training-request/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data
    } catch (error) {
        console.error('Error fetching Training request:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function createTrainingRequest(accessToken,trainingRequestData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/create-new-trainings-request/`, trainingRequestData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error creating training request:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function fetchTrainingRequestDetails(accessToken,trainingRequestId ) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/training-request/${trainingRequestId}/details/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
                
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching training request details:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function updateTrainingRequest(trainingRequestId, updatedData, accessToken) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/training-requests/${trainingRequestId}/`, updatedData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error updating training request:', error.response ? error.response.data : error.message);
        return null;
    }
};


export async function deleteTrainingRequest(trainingRequestId, accessToken) {
    try {
        await axios.delete(`${API_BASE_URL}api/training-requests/${trainingRequestId}/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return true;
    } catch (error) {
        console.error('Error deleting training request:', error.response ? error.response.data : error.message);
        return false;
    }
};


export async function fetchComments(trainingRequestId, accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/training-requests/${trainingRequestId}/comments/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching comments:', error.response ? error.response.data : error.message);
        return null;
    }
};


export async function createComment(trainingRequestId, commentData, accessToken) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/training-requests/${trainingRequestId}/comments/`, commentData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error creating comment:', error.response ? error.response.data : error.message);
        return null;
    }
};


export async function updateComment(trainingRequestId, commentId, updatedData, accessToken) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/training-requests/${trainingRequestId}/comments/${commentId}/`, updatedData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error updating comment:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function deleteComment(trainingRequestId, commentId, accessToken) {
    try {
        await axios.delete(`${API_BASE_URL}api/training-requests/${trainingRequestId}/comments/${commentId}/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return true;
    } catch (error) {
        console.error('Error deleting comment:', error.response ? error.response.data : error.message);
        return false;
    }
};


// for announcement category management

export async function fetchAnnouncementCategoryListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement-category-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching Announcement category list data:", error);
        throw error;
    }
};

export async function createNewAnnouncementCategory(accessToken, announcementData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/create-announcement-category/`, announcementData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new  Announcement category data:", error);
        throw error;
    }
};

export async function fetchAnnouncementCategoryDetails(accessToken, announcementCatId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement-category/${announcementCatId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  Announcement category details:", error);
        throw error;
    }
};

export async function updateAnnouncementCategoryDetails(accessToken, announcementCatId, announcementData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/announcement-category/${announcementCatId}/details/`, announcementData,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  Announcement category  details:", error);
        throw error;
    }
};

export async function deleteAnnouncementCategoryDetails(accessToken, announcementCatId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement-category/${announcementCatId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting  Announcement category details:", error);
        throw error;
    }
};

// for announcement management

export async function fetchAnnouncementListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching Announcement list data:", error);
        throw error;
    }
};

export async function createNewAnnouncement(accessToken, announcementData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/create-announcement/`, announcementData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new  Announcement  data:", error);
        throw error;
    }
};

export async function fetchAnnouncementDetails(accessToken, announcementId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement/${announcementId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  Announcement  details:", error);
        throw error;
    }
};

export async function updateAnnouncementDetails(accessToken, announcementId, announcementData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/announcement/${announcementId}/details/`, announcementData,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  Announcement  details:", error);
        throw error;
    }
};

export async function deleteAnnouncementDetails(accessToken, announcementId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement/${announcementId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting  Announcement  details:", error);
        throw error;
    }
};

// for Todays wisdom

export async function fetchLatestTodaysWisdom(accessToken){
    try {
        const response = await axios.get(`${API_BASE_URL}api/latest-today-wisdom/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        console.log("todays wisdom data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching todays wisdom list data:", error);
        throw error;
    }
};

export async function fetchTodaysWisdomListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/todays-wisdom-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching todays wisdom list data:", error);
        throw error;
    }
};

export async function createNewTodaysWisdom(accessToken, todaysWisdomData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/todays-wisdom-create/`, todaysWisdomData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new  todays wisdom  data:", error);
        throw error;
    }
};

export async function fetchTodaysWisdomDetails(accessToken, todaysWisdomId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/todays-wisdom/${todaysWisdomId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  todays wisdom  details:", error);
        throw error;
    }
};

export async function updateTodaysWisdomDetails(accessToken, todaysWisdomId, todaysWisdomData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/todays-wisdom/${todaysWisdomId}/details/`, todaysWisdomData,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  todays wisdom  details:", error);
        throw error;
    }
};

export async function deleteTodaysWisdomDetails(accessToken, todaysWisdomId) {
    try {
        const response = await axios.delete(`${API_BASE_URL}api/todays-wisdom/${todaysWisdomId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting  todays wisdom  details:", error);
        throw error;
    }
};

// for Training Room

export async function fetchTrainingRoomListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/training-rooms-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching training room list data:", error);
        throw error;
    }
};

export async function createNewTrainingRoom(accessToken, trainingRoomData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/training-rooms-create/`, trainingRoomData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new  training room  data:", error);
        throw error;
    }
};

export async function fetchTrainingRoomDetails(accessToken, trainingRoomId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/training-rooms/${trainingRoomId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  training-rooms details:", error);
        throw error;
    }
};

export async function updateTrainingRoomDetails(accessToken, trainingRoomId, trainingRoomData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/training-rooms/${trainingRoomId}/details/`, trainingRoomData,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  training-rooms  details:", error);
        throw error;
    }
};

export async function deleteTrainingRoomDetails(accessToken, trainingRoomId) {
    try {
        const response = await axios.delete(`${API_BASE_URL}api/training-rooms/${trainingRoomId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting  training-rooms  details:", error);
        throw error;
    }
};
// for Training Room Availability
export async function fetchRoomAvailabilityListData(accessToken, roomId = null, date = null) {
    try {
        // Prepare the query parameters
        let params = {};
        if (roomId) {
            params.room_id = roomId;
        }
        if (date) {
            params.date = date;
        }

        // Make the request with optional query parameters
        const response = await axios.get(`${API_BASE_URL}api/room-availability-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            params: params, // Pass the query parameters to filter by room or date
        });

        return response.data;  // The data contains the list of available rooms for that date
    } catch (error) {
        console.error("Error fetching room availability data:", error);
        throw error;
    }
};

// for Examination related functions

export async function fetchExaminationListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/quizzes-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching exam list data:", error);
        throw error;
    }
};

export async function createNewExamination(accessToken, trainingRoomData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/training-rooms-create/`, trainingRoomData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new  training room  data:", error);
        throw error;
    }
};

export async function fetchExaminationDetails(accessToken, trainingRoomId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/training-rooms/${trainingRoomId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  training-rooms details:", error);
        throw error;
    }
};

export async function updateExaminationDetails(accessToken, trainingRoomId, trainingRoomData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/training-rooms/${trainingRoomId}/details/`, trainingRoomData,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  training-rooms  details:", error);
        throw error;
    }
};

export async function deleteExaminationDetails(accessToken, trainingRoomId) {
    try {
        const response = await axios.delete(`${API_BASE_URL}api/training-rooms/${trainingRoomId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting  training-rooms  details:", error);
        throw error;
    }
};


// for QuestionType related function

export async function fetchQuestionTypeListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/question-type-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching question Type list data:", error);
        throw error;
    }
};

export async function createNewQuestionType(accessToken, queTypeData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/question-type/create/`, queTypeData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new Question Type data:", error);
        throw error;
    }
};

export async function fetchQuestionTypeDetails(accessToken, queTypeId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/question-type/${queTypeId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  Question Type details:", error);
        throw error;
    }
};

export async function updateQuestionTypeDetails(accessToken, queTypeId, queTypeData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/question-type/${queTypeId}/details/`, queTypeData,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  Question Type  details:", error);
        throw error;
    }
};

export async function deleteQuestionTypeDetails(accessToken, queTypeId) {
    try {
        const response = await axios.delete(`${API_BASE_URL}api/question-type/${queTypeId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting  Question Type  details:", error);
        throw error;
    }
};

