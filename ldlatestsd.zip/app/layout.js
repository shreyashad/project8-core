import localFont from "next/font/local";
import "./globals.css";
import { SessionProvider } from "next-auth/react";
import TanstackProvider from "@/components/provider/provider.client";
import Providers from "@/components/provider/providers";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export const metadata = {
  title: "MDIndia Learning and Training ",
  description: "Learning and training management system for Mdindia Employees",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <SessionProvider>
          <TanstackProvider>
            <Providers> {children} </Providers>
          </TanstackProvider>
        </SessionProvider>
      </body>
    </html>
  );
}
