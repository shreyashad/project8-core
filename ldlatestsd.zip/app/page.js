import LoginPage from "./(auth)/login/page";

export default function Home() {
  return (
    <LoginPage />
  );
}
