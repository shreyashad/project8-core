import { fetchCourseListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import CourseListCard from "@/components/course/course-list-card";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export default async function HodCoursePage() {
    const session = await auth();
    const courseData = await fetchCourseListData(session.accessToken);
    console.log("course data:", courseData);
    return(
        <div className="flex flex-col gap-4 p-4  md:gap-8 md:p-8">
            {/* <DashboardBreadCrumb 
                homelink="/dashboard/hod/" 
                hometitle="Home" 
                mdipagelink="/dashboard/hod/courses/" 
                mdipagetitle="Course Management" 
                pagetitle="Course "
            /> */}
            <Card className="shadow-2xl mt-10 relative">
                <CardHeader className="pb-3">
                    <CardTitle>Course </CardTitle>
                </CardHeader>
                <Separator />
                <CardContent>
                    <div class="min-h-screen bg-gradient-to-tr from-red-300 to-yellow-200 flex justify-center items-center py-20">
                        <div class="md:px-4 md:grid md:grid-cols-2 lg:grid-cols-3 gap-5 space-y-4 md:space-y-0">
                            {courseData.map((course) => (
                                <CourseListCard key={course.id} course={course} userId={session.user.id} />
                            ))}
                        </div>
                    </div>
                </CardContent>
           </Card>
        </div>
    );
}

export default function Example() {
    return (
      <div className="bg-gray-50 py-24 sm:py-32">
        <div className="mx-auto max-w-2xl px-6 lg:max-w-7xl lg:px-8">
          <h2 className="text-center text-base/7 font-semibold text-indigo-600">Deploy faster</h2>
          <p className="mx-auto mt-2 max-w-lg text-balance text-center text-4xl font-semibold tracking-tight text-gray-950 sm:text-5xl">
            Everything you need to deploy your app
          </p>
          <div className="mt-10 grid gap-4 sm:mt-16 lg:grid-cols-3 lg:grid-rows-2">
            <div className="relative lg:row-span-2">
              <div className="absolute inset-px rounded-lg bg-white lg:rounded-l-[2rem]"></div>
              <div className="relative flex h-full flex-col overflow-hidden rounded-[calc(theme(borderRadius.lg)+1px)] lg:rounded-l-[calc(2rem+1px)]">
                <div className="px-8 pb-3 pt-8 sm:px-10 sm:pb-0 sm:pt-10">
                  <p className="mt-2 text-lg font-medium tracking-tight text-gray-950 max-lg:text-center">
                    Mobile friendly
                  </p>
                  <p className="mt-2 max-w-lg text-sm/6 text-gray-600 max-lg:text-center">
                    Anim aute id magna aliqua ad ad non deserunt sunt. Qui irure qui lorem cupidatat commodo.
                  </p>
                </div>
                <div className="relative min-h-[30rem] w-full grow [container-type:inline-size] max-lg:mx-auto max-lg:max-w-sm">
                  <div className="absolute inset-x-10 bottom-0 top-10 overflow-hidden rounded-t-[12cqw] border-x-[3cqw] border-t-[3cqw] border-gray-700 bg-gray-900 shadow-2xl">
                    <img
                      className="size-full object-cover object-top"
                      src="https://tailwindui.com/plus/img/component-images/bento-03-mobile-friendly.png"
                      alt=""
                    />
                  </div>
                </div>
              </div>
              <div className="pointer-events-none absolute inset-px rounded-lg shadow ring-1 ring-black/5 lg:rounded-l-[2rem]"></div>
            </div>
            <div className="relative max-lg:row-start-1">
              <div className="absolute inset-px rounded-lg bg-white max-lg:rounded-t-[2rem]"></div>
              <div className="relative flex h-full flex-col overflow-hidden rounded-[calc(theme(borderRadius.lg)+1px)] max-lg:rounded-t-[calc(2rem+1px)]">
                <div className="px-8 pt-8 sm:px-10 sm:pt-10">
                  <p className="mt-2 text-lg font-medium tracking-tight text-gray-950 max-lg:text-center">Performance</p>
                  <p className="mt-2 max-w-lg text-sm/6 text-gray-600 max-lg:text-center">
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit maiores impedit.
                  </p>
                </div>
                <div className="flex flex-1 items-center justify-center px-8 max-lg:pb-12 max-lg:pt-10 sm:px-10 lg:pb-2">
                  <img
                    className="w-full max-lg:max-w-xs"
                    src="https://tailwindui.com/plus/img/component-images/bento-03-performance.png"
                    alt=""
                  />
                </div>
              </div>
              <div className="pointer-events-none absolute inset-px rounded-lg shadow ring-1 ring-black/5 max-lg:rounded-t-[2rem]"></div>
            </div>
            <div className="relative max-lg:row-start-3 lg:col-start-2 lg:row-start-2">
              <div className="absolute inset-px rounded-lg bg-white"></div>
              <div className="relative flex h-full flex-col overflow-hidden rounded-[calc(theme(borderRadius.lg)+1px)]">
                <div className="px-8 pt-8 sm:px-10 sm:pt-10">
                  <p className="mt-2 text-lg font-medium tracking-tight text-gray-950 max-lg:text-center">Security</p>
                  <p className="mt-2 max-w-lg text-sm/6 text-gray-600 max-lg:text-center">
                    Morbi viverra dui mi arcu sed. Tellus semper adipiscing suspendisse semper morbi.
                  </p>
                </div>
                <div className="flex flex-1 items-center [container-type:inline-size] max-lg:py-6 lg:pb-2">
                  <img
                    className="h-[min(152px,40cqw)] object-cover"
                    src="https://tailwindui.com/plus/img/component-images/bento-03-security.png"
                    alt=""
                  />
                </div>
              </div>
              <div className="pointer-events-none absolute inset-px rounded-lg shadow ring-1 ring-black/5"></div>
            </div>
            <div className="relative lg:row-span-2">
              <div className="absolute inset-px rounded-lg bg-white max-lg:rounded-b-[2rem] lg:rounded-r-[2rem]"></div>
              <div className="relative flex h-full flex-col overflow-hidden rounded-[calc(theme(borderRadius.lg)+1px)] max-lg:rounded-b-[calc(2rem+1px)] lg:rounded-r-[calc(2rem+1px)]">
                <div className="px-8 pb-3 pt-8 sm:px-10 sm:pb-0 sm:pt-10">
                  <p className="mt-2 text-lg font-medium tracking-tight text-gray-950 max-lg:text-center">
                    Powerful APIs
                  </p>
                  <p className="mt-2 max-w-lg text-sm/6 text-gray-600 max-lg:text-center">
                    Sit quis amet rutrum tellus ullamcorper ultricies libero dolor eget sem sodales gravida.
                  </p>
                </div>
                <div className="relative min-h-[30rem] w-full grow">
                  <div className="absolute bottom-0 left-10 right-0 top-10 overflow-hidden rounded-tl-xl bg-gray-900 shadow-2xl">
                    <div className="flex bg-gray-800/40 ring-1 ring-white/5">
                      <div className="-mb-px flex text-sm/6 font-medium text-gray-400">
                        <div className="border-b border-r border-b-white/20 border-r-white/10 bg-white/5 px-4 py-2 text-white">
                          NotificationSetting.jsx
                        </div>
                        <div className="border-r border-gray-600/10 px-4 py-2">App.jsx</div>
                      </div>
                    </div>
                    <div className="px-6 pb-14 pt-6">{/* Your code example */}</div>
                  </div>
                </div>
              </div>
              <div className="pointer-events-none absolute inset-px rounded-lg shadow ring-1 ring-black/5 max-lg:rounded-b-[2rem] lg:rounded-r-[2rem]"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }
  
  import { useState } from 'react';

export default function Courses({ categories }) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCategories = categories.filter(category =>
    category.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex flex-col h-screen">
      {/* Sticky Header */}
      <header className="sticky top-0 bg-white shadow-md z-10 p-4">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold text-gray-800">Course Categories</h1>
          <div className="w-1/3 relative">
            <input
              type="text"
              className="w-full p-2 border rounded-lg"
              placeholder="Search for courses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <span className="absolute right-3 top-2 text-gray-500">🔍</span>
          </div>
        </div>
      </header>

      {/* Scrollable Content */}
      <main className="flex-1 overflow-y-auto bg-gray-100 p-4">
        <div className="container mx-auto">
          {filteredCategories.length === 0 ? (
            <p>No courses found</p>
          ) : (
            filteredCategories.map((category) => (
              <div key={category.id} className="mb-6">
                <h2 className="text-2xl font-semibold text-gray-700">{category.name}</h2>
                <ul className="mt-2">
                  {category.courses.map((course) => (
                    <li key={course.id} className="py-2">
                      <a
                        href={`/courses/${course.id}`}
                        className="text-blue-500 hover:text-blue-700"
                      >
                        {course.title}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))
          )}
        </div>
      </main>
    </div>
  );
}

// Fetching course categories server-side
export async function getServerSideProps() {
  // Simulating fetching course data from an API
  const categories = [
    {
      id: 1,
      name: 'Web Development',
      courses: [
        { id: 1, title: 'React for Beginners' },
        { id: 2, title: 'Next.js Advanced' },
        { id: 3, title: 'Node.js Basics' },
      ],
    },
    {
      id: 2,
      name: 'Data Science',
      courses: [
        { id: 4, title: 'Python for Data Science' },
        { id: 5, title: 'Machine Learning 101' },
      ],
    },
    {
      id: 3,
      name: 'Design',
      courses: [
        { id: 6, title: 'UI/UX Design Fundamentals' },
        { id: 7, title: 'Graphic Design for Beginners' },
      ],
    },
    // Add more categories as needed
  ];

  return {
    props: {
      categories,
    },
  };
}
"use client";
import Image from "next/image";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../ui/card";
import { Star } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../ui/dialog";
import { useState } from "react";
import { Button } from "../ui/button";
import { ScrollArea } from "../ui/scroll-area";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";
import { courseEnrollment, getCourseProgress } from "@/app/api/server/route";
import { useSession } from "next-auth/react";

export default function CourseListCard({ course, userId }) {
    const { data: session } = useSession();
    const [selectedCourse, setSelectedCourse] = useState(null);
    const [isEnrolled, setIsEnrolled] = useState(false);
    const [isLoading, setIsLoading] = useState(false); // For loading state
    const [error, setError] = useState(null); // For error state
    const [progress, setProgress] = useState(null); // For tracking user progress

    // Check if the user is already enrolled and retrieve progress if available
    const checkEnrollmentStatus = async () => {
        try {
            const response = await getCourseProgress(session.accessToken, course.id, userId);
            setIsEnrolled(response.isEnrolled); // Set enrollment status
            setProgress(response.progress); // Set user's progress (e.g., last module they completed)
        } catch (err) {
            console.error("Error checking enrollment status:", err);
        }
    };

    // Handle the course enrollment action
    const handleEnroll = async () => {
        setIsLoading(true);
        setError(null); // Reset error state
        try {
            const response = await courseEnrollment(session.accessToken, course.id, userId);
            setIsEnrolled(true); // Set enrollment status to true
            setIsLoading(false);
        } catch (err) {
            setIsLoading(false);
            setError("Failed to enroll. Please try again later."); // Show error if enrollment fails
        }
    };

    // Handle course continuation action
    const handleContinue = () => {
        if (progress) {
            // Redirect user to the module they were last working on
            // For now, we'll log the progress; in a real app, we would use routing or a modal to show the last lesson/module
            console.log("Continuing from:", progress);
            // Example: Redirect to the progress or show the last visited module
        }
    };

    // Check enrollment and progress on component mount
    useState(() => {
        checkEnrollmentStatus();
    }, [course.id, userId]);

    return (
        <Card key={course.id} className="flex flex-col">
            <CardHeader>
                <img src={course.cover_image} alt={course.title} className="w-full h-48 object-cover rounded-t-lg" />
            </CardHeader>
            <CardContent className="flex-grow">
                <CardTitle className="mb-2">{course.title}</CardTitle>
                <p className="text-sm text-gray-600 mb-2">{course.description}</p>
                <div className="flex items-center mb-2">
                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                    <span className="text-sm font-medium">{course.course_reviews.rating}</span>
                    <span className="text-sm text-gray-600 ml-2">({course.enrollment_count} enrolled)</span>
                </div>
            </CardContent>
            <CardFooter className="flex justify-between">
                <Dialog>
                    <DialogTrigger asChild>
                        <Button variant="outline" onClick={() => setSelectedCourse(course)}>View Details</Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-3xl">
                        <DialogHeader>
                            <DialogTitle>{course.title}</DialogTitle>
                        </DialogHeader>
                        <ScrollArea className="max-h-[60vh]">
                            <div className="space-y-4">
                                <img src={course.cover_image} alt={course.title} className="w-full h-64 object-cover rounded-lg" />
                                <p>{course.description}</p>
                                <div className="flex items-center">
                                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                                    <span className="font-medium">{course.course_reviews.rating}</span>
                                    <span className="text-gray-600 ml-2">({course.enrollment_count} enrolled)</span>
                                </div>

                                <Accordion type="single" collapsible className="w-full">
                                    {course.modules.map((module, index) => (
                                        <AccordionItem value={`module-${index}`} key={module.id}>
                                            <AccordionTrigger>{module.title}</AccordionTrigger>
                                            <AccordionContent>
                                                <p>{module.description}</p>
                                                {module.cover_image && <img src={module.cover_image} alt={module.title} className="w-full h-auto" />}
                                                <ul className="space-y-2 mt-4">
                                                    {module.video_lessons && module.video_lessons.length > 0 ? (
                                                        module.video_lessons.map((video, vIndex) => (
                                                            <li key={video.id} className="flex justify-between items-center">
                                                                <div className="flex flex-col">
                                                                    <span>{video.title}</span>
                                                                    <span className="text-sm text-gray-600">{video.duration}</span>
                                                                </div>
                                                                <a href={video.video_url} className="text-blue-500 text-sm" target="_blank" rel="noopener noreferrer">
                                                                    Watch Video
                                                                </a>
                                                            </li>
                                                        ))
                                                    ) : (
                                                        <li>No video lessons available</li>
                                                    )}
                                                </ul>
                                            </AccordionContent>
                                        </AccordionItem>
                                    ))}
                                </Accordion>
                            </div>
                        </ScrollArea>
                    </DialogContent>
                </Dialog>
                <Button onClick={isEnrolled ? handleContinue : handleEnroll} disabled={isLoading}>
                    {isLoading ? "Enrolling..." : isEnrolled ? "Continue" : "Enroll Now"}
                </Button>
            </CardFooter>
        </Card>
    );
}

"use client";
import Image from "next/image";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../ui/card";
import { Star } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../ui/dialog";
import { useState, useEffect } from "react";
import { Button } from "../ui/button";
import { ScrollArea } from "../ui/scroll-area";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";
import { courseEnrollment, checkEnrollmentStatus } from "@/app/api/server/route";
import { useSession } from "next-auth/react";
import { useRouter } from 'next/router'; // Importing useRouter for redirection

export default function CourseListCard({ course, userId }) {
    const { data: session } = useSession();
    const router = useRouter(); // Next.js router for navigation
    const [selectedCourse, setSelectedCourse] = useState(null);
    const [isEnrolled, setIsEnrolled] = useState(false);
    const [isLoading, setIsLoading] = useState(false); // For loading state
    const [error, setError] = useState(null); // For error state
    const [lastCompletedModule, setLastCompletedModule] = useState(null); // To track user's progress

    // Fetch user's enrollment status and progress on initial load
    useEffect(() => {
        const fetchEnrollmentStatus = async () => {
            try {
                const response = await checkEnrollmentStatus(session.accessToken, course.id);
                setIsEnrolled(response.data.enrolled);
                setLastCompletedModule(response.data.last_completed_module); // Assuming backend sends last completed module
            } catch (err) {
                console.error("Error fetching enrollment status:", err);
            }
        };
        if (session?.accessToken) {
            fetchEnrollmentStatus();
        }
    }, [session, course.id]);

    // Handle the course enrollment action
    const handleEnroll = async () => {
        setIsLoading(true);
        setError(null); // Reset error state
        try {
            const response = await courseEnrollment(session.accessToken, course.id, userId);
            setIsEnrolled(true); // Set enrollment status to true
            setIsLoading(false);
        } catch (err) {
            setIsLoading(false);
            setError("Failed to enroll. Please try again later."); // Show error if enrollment fails
        }
    };

    // Handle the "Continue" action, navigating to the last completed module/video
    const handleContinue = () => {
        if (lastCompletedModule) {
            // Navigate to the last completed module/video
            const moduleId = lastCompletedModule.module_id; // Assuming you have the module ID
            const videoId = lastCompletedModule.video_id; // Assuming you have the video ID
            const route = videoId ? `/course/${course.slug}/module/${moduleId}/video/${videoId}` : `/course/${course.slug}/module/${moduleId}`;
            
            // Redirect to the appropriate URL for the module/video
            router.push(route);
        } else {
            // If no progress found, start from the first module
            router.push(`/course/${course.slug}/module/1`); // Redirect to the first module
        }
    };

    return (
        <Card key={course.id} className="flex flex-col">
            <CardHeader>
                <img src={course.cover_image} alt={course.title} className="w-full h-48 object-cover rounded-t-lg" />
            </CardHeader>
            <CardContent className="flex-grow">
                <CardTitle className="mb-2">{course.title}</CardTitle>
                <p className="text-sm text-gray-600 mb-2">{course.description}</p>
                <div className="flex items-center mb-2">
                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                    <span className="text-sm font-medium">{course.course_reviews.rating}</span>
                    <span className="text-sm text-gray-600 ml-2">({course.enrollment_count} enrolled)</span>
                </div>
            </CardContent>
            <CardFooter className="flex justify-between">
                <Dialog>
                    <DialogTrigger asChild>
                        <Button variant="outline" onClick={() => setSelectedCourse(course)}>View Details</Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-3xl">
                        <DialogHeader>
                            <DialogTitle>{course.title}</DialogTitle>
                        </DialogHeader>
                        <ScrollArea className="max-h-[60vh]">
                            <div className="space-y-4">
                                <img src={course.cover_image} alt={course.title} className="w-full h-64 object-cover rounded-lg" />
                                <p>{course.description}</p>
                                <div className="flex items-center">
                                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                                    <span className="font-medium">{course.course_reviews.rating}</span>
                                    <span className="text-gray-600 ml-2">({course.enrollment_count} enrolled)</span>
                                </div>

                                <Accordion type="single" collapsible className="w-full">
                                    {course.modules.map((module, index) => (
                                        <AccordionItem value={`module-${index}`} key={module.id}>
                                            <AccordionTrigger>{module.title}</AccordionTrigger>
                                            <AccordionContent>
                                                <p>{module.description}</p>
                                                {module.cover_image && <img src={module.cover_image} alt={module.title} className="w-full h-auto" />}
                                                <ul className="space-y-2 mt-4">
                                                    {module.video_lessons && module.video_lessons.length > 0 ? (
                                                        module.video_lessons.map((video, vIndex) => (
                                                            <li key={video.id} className="flex justify-between items-center">
                                                                <div className="flex flex-col">
                                                                    <span>{video.title}</span>
                                                                    <span className="text-sm text-gray-600">{video.duration}</span>
                                                                </div>
                                                                <a href={video.video_url} className="text-blue-500 text-sm" target="_blank" rel="noopener noreferrer">
                                                                    Watch Video
                                                                </a>
                                                            </li>
                                                        ))
                                                    ) : (
                                                        <li>No video lessons available</li>
                                                    )}
                                                </ul>
                                            </AccordionContent>
                                        </AccordionItem>
                                    ))}
                                </Accordion>
                            </div>
                        </ScrollArea>
                    </DialogContent>
                </Dialog>
                <div>
                    {/* Show "Continue" button if enrolled and have progress */}
                    {isEnrolled && lastCompletedModule ? (
                        <Button onClick={handleContinue}>Continue</Button>
                    ) : (
                        <Button onClick={handleEnroll} disabled={isEnrolled || isLoading}>
                            {isLoading ? "Enrolling..." : isEnrolled ? "Enrolled" : "Enroll Now"}
                        </Button>
                    )}
                </div>
            </CardFooter>
        </Card>
    );
}

import { useRouter } from 'next/router'; // Importing the useRouter hook

const CourseListCard = ({ course, lastCompletedModule, userRole }) => {
  const router = useRouter();

  // Handle the "Continue" action, navigating to the last completed module/video
  const handleContinue = () => {
    if (lastCompletedModule) {
      // Navigate to the last completed module/video
      const moduleId = lastCompletedModule.module_id; // Assuming you have the module ID
      const videoId = lastCompletedModule.video_id; // Assuming you have the video ID

      // Set dynamic base path based on user role
      let basePath = '';
      switch (userRole) {
        case "Trainers Admin":
          basePath = "/dashboard/trainers-admin";
          break;
        case "Trainer":
          basePath = "/dashboard/trainer";
          break;
        case "HOD's":
          basePath = "/dashboard/hod";
          break;
        case "Employee":
          basePath = "/dashboard/employee";
          break;
        default:
          console.error("Unknown user role:", userRole);
          return; // Don't proceed if the role is unknown
      }

      // Construct the route with dynamic user role and course information
      const route = videoId
        ? `${basePath}/my-learning/course/${course.slug}/module/${moduleId}/video/${videoId}`
        : `${basePath}/my-learning/course/${course.slug}/module/${moduleId}`;

      // Redirect to the appropriate URL for the module/video
      router.push(route);
    } else {
      // If no progress found, start from the first module
      let basePath = '';
      switch (userRole) {
        case "Trainers Admin":
          basePath = "/dashboard/trainers-admin";
          break;
        case "Trainer":
          basePath = "/dashboard/trainer";
          break;
        case "HOD's":
          basePath = "/dashboard/hod";
          break;
        case "Employee":
          basePath = "/dashboard/employee";
          break;
        default:
          console.error("Unknown user role:", userRole);
          return; // Don't proceed if the role is unknown
      }

      // Redirect to the first module for the course
      router.push(`${basePath}/my-learning/course/${course.slug}/module/1`);
    }
  };

  return (
    <div className="course-card">
      <h3>{course.title}</h3>
      <p>{course.description}</p>
      <button onClick={handleContinue}>Continue</button>
    </div>
  );
};

export default CourseListCard;
