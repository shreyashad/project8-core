import { fetchCourseListData, fetchUserByAppRole, fetchUsersTeamlist } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import HODTrainingRequestSystem from "@/components/hod/hod-training-request";
import { Separator } from "@/components/ui/separator";

export default async function HODTrainingRequestPage() {
    const session = await auth();

    const application_name = process.env.APP_NAME;
    const role = "Trainers Admin";
    const receivername = await fetchUserByAppRole(session.accessToken, application_name, role);
    console.log("receivers name details:", receivername);

    const teamslist = await fetchUsersTeamlist(session.accessToken);
    const courses = await fetchCourseListData(session.accessToken);
    
    

    return(
        
        <HODTrainingRequestSystem  courseslist={courses} receiverData={receivername} teamsData={teamslist} />
            
       
    );
};