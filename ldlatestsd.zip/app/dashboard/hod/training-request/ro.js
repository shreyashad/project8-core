"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { PlusCircle, Send, Inbox, Clock, CalendarIcon } from "lucide-react"
import { cn } from "@/lib/utils"

export default function HODTrainingRequestSystem() {
  const [activeView, setActiveView] = useState("new")
  const [selectedItem, setSelectedItem] = useState(null)
  const [requests, setRequests] = useState([
    { id: 1, subject: "React Training", status: "Pending", content: "Request for React training session for the frontend team.", date: "2023-06-15" },
    { id: 2, subject: "Python Workshop", status: "Scheduled", content: "Python workshop for the data science team.", date: "2023-06-10", scheduledDate: "2023-07-01", scheduledTime: "10:00 AM", trainer: "Jane Doe", room: "Training Room 1" },
  ])

  const handleRequestSubmit = (e) => {
    e.preventDefault()
    const newRequest = {
      id: requests.length + 1,
      subject: e.target.subject.value,
      content: e.target.content.value,
      status: "Pending",
      date: new Date().toISOString().split('T')[0]
    }
    setRequests([newRequest, ...requests])
    setActiveView("sent")
  }

  const NavItem = ({ icon: Icon, label, view }) => (
    <button
      className={cn(
        "flex items-center gap-2 px-4 py-2 w-full text-left hover:bg-accent rounded-md",
        activeView === view && "bg-accent"
      )}
      onClick={() => {
        setActiveView(view)
        setSelectedItem(null)
      }}
    >
      <Icon className="h-5 w-5" />
      <span>{label}</span>
    </button>
  )

  const RequestList = ({ items }) => (
    <div className="space-y-2">
      {items.map(item => (
        <div
          key={item.id}
          className={cn(
            "p-2 border rounded-md cursor-pointer hover:bg-accent",
            selectedItem?.id === item.id && "bg-accent"
          )}
          onClick={() => setSelectedItem(item)}
        >
          <div className="font-semibold">{item.subject}</div>
          <div className="text-sm text-muted-foreground">{item.date}</div>
          <Badge variant={item.status === "Pending" ? "secondary" : "success"}>{item.status}</Badge>
        </div>
      ))}
    </div>
  )

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="w-64 border-r p-4 flex flex-col">
        <h1 className="text-2xl font-bold mb-6">HOD Dashboard</h1>
        <nav className="space-y-2">
          <NavItem icon={PlusCircle} label="New Request" view="new" />
          <NavItem icon={Send} label="Sent Requests" view="sent" />
          <NavItem icon={Inbox} label="Replies" view="replies" />
          <NavItem icon={Clock} label="Pending" view="pending" />
          <NavItem icon={CalendarIcon} label="Scheduled" view="scheduled" />
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Request List */}
        <div className="w-1/3 border-r p-4 overflow-auto">
          <h2 className="text-xl font-semibold mb-4">
            {activeView === "new" ? "New Training Request" : 
             activeView === "sent" ? "Sent Requests" :
             activeView === "replies" ? "Replies" :
             activeView === "pending" ? "Pending Requests" :
             "Scheduled Trainings"}
          </h2>
          {activeView !== "new" && <RequestList items={requests.filter(r => 
            (activeView === "sent") ||
            (activeView === "replies" && r.status !== "Pending") ||
            (activeView === "pending" && r.status === "Pending") ||
            (activeView === "scheduled" && r.status === "Scheduled")
          )} />}
        </div>

        {/* Request Details / New Request Form */}
        <div className="flex-1 p-4 overflow-auto">
          {activeView === "new" ? (
            <Card>
              <CardHeader>
                <CardTitle>New Training Request</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleRequestSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="subject">Subject</Label>
                    <Input id="subject" name="subject" required />
                  </div>
                  <div>
                    <Label htmlFor="content">Description</Label>
                    <Textarea id="content" name="content" required rows={5} />
                  </div>
                  <Button type="submit">Send Request</Button>
                </form>
              </CardContent>
            </Card>
          ) : selectedItem ? (
            <div>
              <h2 className="text-2xl font-semibold mb-4">{selectedItem.subject}</h2>
              <div className="mb-2">
                <Badge variant={selectedItem.status === "Pending" ? "secondary" : "success"}>
                  {selectedItem.status}
                </Badge>
              </div>
              <div className="mb-4">
                <span className="font-semibold">Date Requested:</span> {selectedItem.date}
              </div>
              <div className="mb-4">{selectedItem.content}</div>
              {selectedItem.status === "Scheduled" && (
                <Card>
                  <CardHeader>
                    <CardTitle>Training Details</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div><span className="font-semibold">Date:</span> {selectedItem.scheduledDate}</div>
                      <div><span className="font-semibold">Time:</span> {selectedItem.scheduledTime}</div>
                      <div><span className="font-semibold">Trainer:</span> {selectedItem.trainer}</div>
                      <div><span className="font-semibold">Room:</span> {selectedItem.room}</div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <div className="text-center text-muted-foreground">
              {activeView === "new" ? "Fill out the form to create a new request" : "Select an item to view details"}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

-------------
import { fetchCourseListData, fetchTrainingRequest, fetchUserByAppRole, fetchUsersTeamlist } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import HODTrainingRequestSystem from "@/components/hod/hod-training-request";
import { TrainingRequestDashboard } from "@/components/training-request/training-request-dashboard";
import { Separator } from "@/components/ui/separator";
// import { cookies } from "next/headers";


export default async function HODTrainingRequestPage1() {
    const session = await auth();
    // const layout = cookies().get("react-resizable-panels:layout:mail");
    // const collapsed = cookies().get("react-resizable-panels:collapsed");

    // const defaultLayout = layout ? JSON.parse(layout.value) : undefined;
    // const defaultCollapsed = collapsed ? JSON.parse(collapsed.value) : undefined;

    const trainingRequestlist = await fetchTrainingRequest(session.accessToken);
    console.log("all requests that are been made:",trainingRequestlist);

    const application_name = process.env.APP_NAME;
    const role = "Trainers Admin";

    const courses = await fetchCourseListData(session.accessToken);
    console.log("course list data:", courses);
    const receivername = await fetchUserByAppRole(session.accessToken, application_name, role);
    console.log("receivers name details:", receivername);

    const teamslist = await fetchUsersTeamlist(session.accessToken);
    console.log("team list details:", teamslist);

    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <div className="fixed w-full shadow-2xl p-4 z-10 ">
                <DashboardBreadCrumb 
                    homelink="/dashboard/hod" 
                    hometitle="Home" 
                    mdipagelink="/dashboard/hod/training-request" 
                    mdipagetitle="Training Request" 
                    pagetitle="Training Requests"
                />
            </div>
            <Separator />
            <div className="mt-16">
                <HODTrainingRequestSystem  courseslist={courses} receiverData={receivername} teamsData={teamslist}/>
            </div>
            
            {/* <TrainingRequestDashboard
                defaultLayout={defaultLayout}
                defaultCollapsed={defaultCollapsed}
                courses={courses}
                recivers_name={receivername}
                teams={teamslist}
                mails={trainingRequestlist} // Assuming trainingRequestlist is the list you want to display
                trainingRequests={trainingRequestlist}
                
            /> */}
            
        </div>
    );
}
------------------------------
"use client";
import { cn } from "@/lib/utils";
import { Button } from "../ui/button";
import { useState } from "react";
import { CalendarIcon, Check, ChevronsUpDown, Clock, Inbox, PlusCircle, Send } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { Label } from "../ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "../ui/command";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Textarea } from "../ui/textarea";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { TrainingRequestSchema } from "@/schema";
import { createTrainingRequest } from "@/app/api/server/route";



export default function HODTrainingRequestSystem({ courseslist, receiverData, teamsData, }) {
    const [activeView, setActiveView] = useState("new");
    const [selectedItem, setSelectedItem] = useState(null);
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const [selectedReceiver, setSelectedReceiver] = useState("");


    const { data: session } = useSession();
    const router = useRouter();

    const form = useForm({
        resolver: zodResolver(TrainingRequestSchema),
        defaultValues: {
            course: "",
            requester: session?.user.user_id,
            receiver: "",
            mode: "",
            team_id: "",
            additional_notes: "",
            status: "pending",
        },
    });

    const handleOnSubmit = async (values) => {
        setLoading(true);
        try {
                await createTrainingRequest(session.accessToken, values);
                router.refresh();
            } catch (error) {
                console.error("Error submitting training request:", error.response ? error.response.data : error.message);
                toast.error(error.message || "An error occurred. Please try again.");
        } finally {
            setLoading(false);
        }
    };


    const NavItem = ({ icon: Icon, label, view }) => (
        <Button
          className={cn(
            "flex items-center gap-2 px-4 py-2 w-full text-left hover:bg-accent rounded-md",
            activeView === view && "bg-accent"
          )}
          onClick={() => {
            setActiveView(view);
            setSelectedItem(null);
          }}
        >
          <Icon className="h-5 w-5" />
          <span>{label}</span>
        </Button>
    );
  

    return(
        <div >
            <div className="w-64 border-r p-4 flex flex-col">
                <h1 className="text-2xl font-bold mb-6">Request Management</h1>
                <nav className="space-y-2">
                    <NavItem icon={PlusCircle} label="New Request" view="new" />
                    <NavItem icon={Send} label="Sent Requests" view="sent" />
                    <NavItem icon={Inbox} label="Replies" view="replies" />
                    <NavItem icon={Clock} label="Pending" view="pending" />
                    <NavItem icon={CalendarIcon} label="Scheduled" view="scheduled" />
                </nav>

            </div>
            <div className="flex-1 flex">
                <div className="w-1/3 border-r p-4 overflow-auto">
                    <h2 className="text-xl font-semibold mb-4">
                        {   activeView === "new" ? "New Training Request" : 
                            activeView === "sent" ? "Sent Requests" :
                            activeView === "replies" ? "Replies" :
                            activeView === "pending" ? "Pending Requests" : "Scheduled Trainings"
                        }
                    </h2>
                    {activeView !== "new" && <RequestList items={requests.filter(r => 
                        (activeView === "sent") ||
                        (activeView === "replies" && r.status !== "Pending") ||
                        (activeView === "pending" && r.status === "Pending") ||
                        (activeView === "scheduled" && r.status === "Scheduled")
                    )} />}
                </div>
                <div className="flex-1 p-4 overflow-auto">
                    {activeView ==="new" ? (
                        <Card>
                            <CardHeader>
                                <CardTitle> New Training Request</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <Form {...form}>
                                    <form className="grid gap-4" onSubmit={form.handleSubmit(handleOnSubmit)}>
                                        <div className="space-y-6">
                                            <Label>To:</Label>
                                            <Popover open={open} onOpenChange={setOpen}>
                                                <PopoverTrigger asChild>
                                                    <Button
                                                        variant="outline"
                                                        role="combobox"
                                                        aria-expanded={open}
                                                        className="w-[200px] justify-between"
                                                    >
                                                        {selectedReceiver || "Select receiver..."}
                                                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                                    </Button>
                                                </PopoverTrigger>
                                                <PopoverContent className="w-[200px] p-0">
                                                    <Command>
                                                        <CommandInput placeholder="Search receiver..." />
                                                        <CommandList>
                                                            <CommandEmpty>No receiver found.</CommandEmpty>
                                                            <CommandGroup>
                                                                {receiverData?.map((receiver) => (
                                                                    <CommandItem
                                                                        key={receiver.username}
                                                                        onSelect={() => {
                                                                            setSelectedReceiver(receiver.username);
                                                                            form.setValue('receiver_id', receiver.username); // Set receiver_id
                                                                            setOpen(false);
                                                                        }}
                                                                    >
                                                                        <Check
                                                                            className={`mr-2 h-4 w-4 ${selectedReceiver === receiver.username ? "opacity-100" : "opacity-0"}`}
                                                                        />
                                                                        {receiver.username}
                                                                    </CommandItem>
                                                                ))}
                                                            </CommandGroup>
                                                        </CommandList>
                                                    </Command>
                                                </PopoverContent>
                                            </Popover>
                                        </div>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="space-y-2">
                                                <FormField
                                                    control={form.control}
                                                    name="course"
                                                    render={({ field }) => (
                                                        <FormItem>
                                                            <FormLabel>Course Topic</FormLabel>
                                                            <Select
                                                                disabled={loading || !courseslist?.length}
                                                                onValueChange={field.onChange}
                                                                value={field.value}
                                                            >
                                                                <FormControl>
                                                                    <SelectTrigger>
                                                                        <SelectValue placeholder={courseslist?.length > 0 ? "Course Topic" : "No Courses available"} />
                                                                    </SelectTrigger>
                                                                </FormControl>
                                                                <SelectContent>
                                                                    {courseslist?.length > 0 ? (
                                                                        courseslist.map((course) => (
                                                                            <SelectItem key={course.id} value={course.title}>
                                                                                {course.title}
                                                                            </SelectItem>
                                                                        ))
                                                                    ) : (
                                                                        <SelectItem disabled>No Topic found</SelectItem>
                                                                    )}
                                                                </SelectContent>
                                                            </Select>
                                                            <FormMessage />
                                                        </FormItem>
                                                    )}
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <FormField
                                                    control={form.control}
                                                    name="mode"
                                                    render={({ field }) => (
                                                        <FormItem>
                                                            <FormLabel>Training Mode</FormLabel>
                                                            <Select
                                                                disabled={loading}
                                                                onValueChange={field.onChange}
                                                                value={field.value}
                                                            >
                                                                <FormControl>
                                                                    <SelectTrigger>
                                                                        <SelectValue placeholder="Training Mode" />
                                                                    </SelectTrigger>
                                                                </FormControl>
                                                                <SelectContent>
                                                                    <SelectItem value="online">Online</SelectItem>
                                                                    <SelectItem value="offline">Offline</SelectItem>
                                                                    <SelectItem value="self-learning">Self-learning</SelectItem>
                                                                </SelectContent>
                                                            </Select>
                                                            <FormMessage />
                                                        </FormItem>
                                                    )}
                                                />
                                            </div>
                                        </div>
                                        <FormField
                                            control={form.control}
                                            name="team_id"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Team</FormLabel>
                                                    <Select
                                                        disabled={loading || !teamsData?.length}
                                                        onValueChange={field.onChange}
                                                        value={field.value}
                                                    >
                                                        <FormControl>
                                                            <SelectTrigger>
                                                                <SelectValue placeholder={teamsData?.length > 0 ? "Team" : "No Team available"} />
                                                            </SelectTrigger>
                                                        </FormControl>
                                                        <SelectContent>
                                                            {teamsData?.length > 0 ? (
                                                                teamsData.map((team) => (
                                                                    <SelectItem key={team.id} value={team.id}>
                                                                        {team.name}
                                                                    </SelectItem>
                                                                ))
                                                            ) : (
                                                                <SelectItem disabled>No Teams found</SelectItem>
                                                            )}
                                                        </SelectContent>
                                                    </Select>
                                                </FormItem>
                                            )}
                                        />
                                        <FormField
                                            control={form.control}
                                            name="additional_notes"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Additional Notes</FormLabel>
                                                    <FormControl>
                                                        <Textarea
                                                            {...field}
                                                            placeholder="Additional Notes"
                                                            disabled={loading}
                                                        />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                        <div className="space-x-4">
                                            <Button disabled={loading} className="ml-auto" type="submit">
                                                {loading ? 'Submitting...' : 'Submit Request'}
                                            </Button>
                                            <Button
                                                disabled={loading}
                                                className="ml-auto"
                                                type="button"
                                                onClick={() => router.back()}
                                            >
                                                Cancel
                                            </Button>
                                        </div>
                                    </form>
                                </Form>
                            </CardContent>
                        </Card>
                    ): selectedItem ? (
                        <div>
                            <h2 className="text-2xl font-semibold mb-4">{selectedItem.subject}</h2>
                            <div className="mb-2">
                                <Badge variant={selectedItem.status === "Pending" ? "secondary" : "success"}>
                                {selectedItem.status}
                                </Badge>
                            </div>
                            <div className="mb-4">
                                <span className="font-semibold">Date Requested:</span> {selectedItem.date}
                            </div>
                            <div className="mb-4">{selectedItem.content}</div>
                            {selectedItem.status === "Scheduled" && (
                                <Card>
                                <CardHeader>
                                    <CardTitle>Training Details</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-2">
                                    <div><span className="font-semibold">Date:</span> {selectedItem.scheduledDate}</div>
                                    <div><span className="font-semibold">Time:</span> {selectedItem.scheduledTime}</div>
                                    <div><span className="font-semibold">Trainer:</span> {selectedItem.trainer}</div>
                                    <div><span className="font-semibold">Room:</span> {selectedItem.room}</div>
                                    </div>
                                </CardContent>
                                </Card>
                            )}
                        </div>
                    ) : (
                        <div className="text-center text-muted-foreground">
                            {activeView === "new" ? "Fill out the form to create a new request" : "Select an item to view details"}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}