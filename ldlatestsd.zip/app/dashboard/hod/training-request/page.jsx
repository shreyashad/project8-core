import { fetchCourseListData, fetchHODTrainingRequest, fetchSimilarDeptUsersList, fetchUserByAppRole } from "@/app/api/server/route";
import { auth } from "@/auth";
import { TrainingSystem } from "@/components/hod/training-request/hod-training-system";
import { cookies } from "next/headers";
import Image from "next/image";


export default async function HODTrainingRequestPage() {
  const layout = cookies().get("react-resizable-panels:layout:mail")
  const collapsed = cookies().get("react-resizable-panels:collapsed")
  const defaultLayout = layout ? JSON.parse(layout.value) : undefined
  const defaultCollapsed = collapsed ? JSON.parse(collapsed.value) : undefined
  const session = await auth();

  const application_name = process.env.APP_NAME;
  const role = "Trainers Admin";
  const trainerAdminData = await fetchUserByAppRole(session.accessToken, application_name, role);

  const teamEmployeeData = await fetchSimilarDeptUsersList(session.accessToken);
    

  const requestData = await fetchHODTrainingRequest(session.accessToken);
  const courseData = await fetchCourseListData(session.accessToken);
  return(
    <>
      <div className="md:hidden">
        <Image
          src="/examples/mail-dark.png"
          width={1280}
          height={727}
          alt="Mail"
          className="hidden dark:block"
        />
        <Image
          src="/examples/mail-light.png"
          width={1280}
          height={727}
          alt="Mail"
          className="block dark:hidden"
        />
      </div>
      <div className="hidden flex-col md:flex">
        <TrainingSystem 
          requestlist={requestData} 
          courselist={courseData}
          traineradminlist={trainerAdminData}
          employeelist={teamEmployeeData} 
          defaultLayout={defaultLayout}
          defaultCollapsed={defaultCollapsed} 
          navCollapsedSize={4}
          
        />
      </div>
    </>
  );
}