import { fetchTeamlistByRole } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import RoleFilterButton from "@/components/teams/rolefilter-button";
import { TeamsCard } from "@/components/teams/teams-card";
import TeamsCreateNewClient from "@/components/teams/teams-client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Pencil, Users } from "lucide-react";


export default async function HODTeamsPage({ searchParams }) {
    const { role = "Leader" } = searchParams;
    const session = await auth();
    const teamsData = await fetchTeamlistByRole(session.accessToken,role);
    console.log("teams Data:", teamsData);

    
    return(
        <div className="flex flex-col gap-4 p-4  md:gap-8 md:p-8">
            <div className="fixed w-full shadow-2xl p-4 z-10 ">
                <DashboardBreadCrumb 
                    homelink="/dashboard/hod/" 
                    hometitle="Home" 
                    mdipagelink="/dashboard/hod/team-management/" 
                    mdipagetitle="Team Management" 
                    pagetitle="Teams "
                />
            </div>
            <div className="mt-16" />
            <Card className="shadow-2xl">
                <CardHeader className="pb-3">
                    <CardTitle>Teams</CardTitle>
                    <CardDescription className="max-w-lg text-balance leading-relaxed">
                        Manage your courses category in one place.
                        <TeamsCreateNewClient />
                    </CardDescription>
                </CardHeader>
                <Separator />
                <CardContent>
                    <div className="mt-4 flex justify-between mb-4">
                        <RoleFilterButton />
                    </div>
                    
                    <div className="grid grid-cols-1 bp-4 md:grid-cols-2 lg:grid-cols-3 gap-4 ">
                        {teamsData?.map((team) => (
                        <TeamsCard teamData={team} key={team.id} />
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    )
};