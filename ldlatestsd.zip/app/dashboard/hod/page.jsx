import { fetchLatestTodaysWisdom } from "@/app/api/server/route";
import { auth } from "@/auth";
import CustomCalendar from "@/components/dashboard/custom-calendar";
import { StatsCard } from "@/components/dashboard/stats-card";
import UpcomingEventsCarousel from "@/components/dashboard/upcomming-events";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Star } from "lucide-react";
import Image from "next/image";
import { MdModelTraining ,MdPlayLesson} from "react-icons/md";
import { RiUserLocationLine, RiTeamFill } from "react-icons/ri";

const sampleEvents = [
    {
      id: 1,
      title: "Team Building Workshop",
      date: "2024-05-15",
      time: "10:00 AM - 4:00 PM",
      location: "Conference Room A"
    },
    {
      id: 2,
      title: "Quarterly Review Meeting",
      date: "2024-05-20",
      time: "2:00 PM - 5:00 PM",
      location: "Board Room"
    },
    {
      id: 3,
      title: "Product Launch Event",
      date: "2024-06-01",
      time: "7:00 PM - 10:00 PM",
      location: "Grand Ballroom, City Hotel"
    },
    {
      id: 4,
      title: "Annual Company Picnic",
      date: "2024-06-15",
      time: "11:00 AM - 6:00 PM",
      location: "Sunshine Park"
    },
    {
      id: 5,
      title: "Tech Talk: AI in Business",
      date: "2024-06-22",
      time: "3:00 PM - 5:00 PM",
      location: "Auditorium"
    }
  ]

  
const chartData = [
    { month: 'Jan', completed: 65 },
    { month: 'Feb', completed: 75 },
    { month: 'Mar', completed: 85 },
    { month: 'Apr', completed: 70 },
    { month: 'May', completed: 90 },
    { month: 'Jun', completed: 80 },
  ]  
export default async function HODDashboard() {
    const session = await auth();
    const todayswisdomResponse  = await fetchLatestTodaysWisdom(session.accessToken);
    const todayswisdom = todayswisdomResponse[0];

    return(
      <div className="flex-grow max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">  
      <div className="px-4 py-6 sm:px-0">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <StatsCard title="Total Teams Training Session" description="Total number of training session conducted for team members" value={50} icon={<MdPlayLesson  />}/>
            <StatsCard title="Active Team User" description="Total number of team members active online " value={2} icon={<RiUserLocationLine />}/>
            <StatsCard title="Total Team Members" description="Total number of team members" value={10} icon={<RiTeamFill />}/>
            <StatsCard title="Ongoin Training Session" description="Total number of on-going training sessions" value={1} icon={<MdModelTraining /> }/>
        </div>
        <div className="mt-8 grid grid-cols-5 grid-rows-6 gap-4">
            <div className="col-span-3 row-span-2 shadow-2xl">
                <Card className="w-full h-full">
                    <CardHeader className="relative flex ">
                        <Image 
                            src="/images/bulb-light.png"
                            height={80}
                            width={80}
                            className="rounded-full absolute -top-8 left-0" // Adjust position for overlap
                            alt="Light Bulb Icon" // Add alt text for accessibility
                        />
                        <CardTitle className="ml-10 font-bold">Today's Wisdom</CardTitle> {/* Add left margin for title spacing */}
                    </CardHeader>
                    <CardContent className="pb-10">
                    {todayswisdom?.topic ? (
                        <div
                        dangerouslySetInnerHTML={{ __html: todayswisdom.topic }}
                        />
                    ) : (
                        <p>No wisdom for today.</p>
                    )}
                    </CardContent>
                </Card>
            </div>
            <div className="col-span-3 row-span-4  col-start-1 row-start-3 shadow-2xl">
                <Tabs defaultValue="overview">
                    <TabsList className="w-full text-center">
                        <TabsTrigger value="overview">OverView</TabsTrigger>
                        <TabsTrigger value="feedback">Feedback</TabsTrigger>
                    </TabsList>
                    <TabsContent value="overview">
                        <div className="grid grid-cols-1  md:grid-cols-1 gap-6 row-span-6 ">
                            <Card>
                                <CardHeader>
                                <CardTitle>Training Completion Rates</CardTitle>
                                </CardHeader>
                                <CardContent>
                                <div className="h-[200px] w-full">
                                    {/* Simple bar chart implementation */}
                                    <div className="flex h-full items-end space-x-2">
                                    {chartData.map((data, index) => (
                                        <div key={index} className="flex-1 bg-blue-500" style={{ height: `${data.completed}%` }}>
                                        <div className="text-xs text-center">{data.month}</div>
                                        </div>
                                    ))}
                                    </div>
                                </div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader>
                                <CardTitle>Course Progress Tracker</CardTitle>
                                </CardHeader>
                                <CardContent>
                                <div className="space-y-4">
                                    <div>
                                    <div className="flex justify-between text-sm mb-1">
                                        <span>Advanced React Patterns</span>
                                        <span>75%</span>
                                    </div>
                                    <Progress value={75} />
                                    </div>
                                    <div>
                                    <div className="flex justify-between text-sm mb-1">
                                        <span>Data Science Fundamentals</span>
                                        <span>60%</span>
                                    </div>
                                    <Progress value={60} />
                                    </div>
                                    <div>
                                    <div className="flex justify-between text-sm mb-1">
                                        <span>UI/UX Design Principles</span>
                                        <span>90%</span>
                                    </div>
                                    <Progress value={90} />
                                    </div>
                                </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>
                    <TabsContent value="feedback">
                        <Card>
                        <CardHeader>
                            <CardTitle>Recent Feedback</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                            {[
                                { name: "John Doe", course: "Advanced React Patterns", rating: 4.8 },
                                { name: "Jane Smith", course: "Data Science Fundamentals", rating: 4.5 },
                                { name: "Alice Johnson", course: "UI/UX Design Principles", rating: 4.9 },
                            ].map((feedback, index) => (
                                <div key={index} className="flex items-center justify-between">
                                <div>
                                    <p className="font-medium">{feedback.name}</p>
                                    <p className="text-sm text-muted-foreground">{feedback.course}</p>
                                </div>
                                <div className="flex items-center">
                                    <Star className="h-4 w-4 text-yellow-400 mr-1" />
                                    <span>{feedback.rating}</span>
                                </div>
                                </div>
                            ))}
                            </div>
                        </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
            <div className="col-span-2 row-span-3 col-start-4 shadow-2xl">
                <CustomCalendar />
            </div>
            <div className="col-span-2 row-span-3 col-start-4 row-start-4 shadow-2xl">
                <UpcomingEventsCarousel events={sampleEvents}/>
            </div>
        </div>
        
      </div>
      </div>
        
      
    );
};