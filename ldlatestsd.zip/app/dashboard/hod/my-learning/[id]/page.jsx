import { fetchCourseDetails } from "@/app/api/server/route";
import { auth } from "@/auth";


export default async function HODCourseDetailsPage({ params }) {
    const { id } = params;
    const session = await auth();
    
    if (!session) {
        return new Response("Unauthorized", { status: 401});
    }
    let courseData = null;

    if (id==="new") {
        courseData = {};
    } else {
        const courseId = getAnnounceId(id);
        courseData = await fetchCourseDetails(session.accessToken, courseId);
    }
    return(
        <div className="flex flex-col">
            
        </div>
    );
}

