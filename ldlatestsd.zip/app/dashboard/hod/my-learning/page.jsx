import { fetchCourseEnrolledListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import CourseCard from "@/components/course/course-card";
import { Separator } from "@/components/ui/separator";

export default async function HodLearningPage() {
    const session = await auth();
    const courseData = await fetchCourseEnrolledListData(session.accessToken);
    console.log("course data:", courseData);
    console.log("sessiondata details:", session);
    const groupedCourses = courseData.reduce((acc, course) => {
        const categoryName = course.category.name; // Category name from the course data
        if (!acc[categoryName]) {
            acc[categoryName] = [];
        }
        acc[categoryName].push(course);
        return acc;
    }, {});

    return(
        <div className="flex flex-col h-screen">
            <header className="sticky top-0 bg-white shadow-md z-10 p-4">
            <div className="container mx-auto flex justify-between items-center">
                <h1 className="text-xl font-bold text-gray-800">Course</h1>
                <div className="w-1/3 relative">
                    {/* <input
                    type="text"
                    className="w-full p-2 border rounded-lg"
                    placeholder="Search for courses..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    /> */}
                    <span className="absolute right-3 top-2 text-gray-500">🔍</span>
                </div>
            </div>
            </header>
            <main className="flex-1 overflow-y-auto bg-gray-100 p-4">
                <div className="container mx-auto">
                    {Object.keys(groupedCourses).map((category) => (
                        <div key={category} className="mb-6">
                            <h2 className="text-2xl font-semibold text-gray-700">{category}</h2>
                            <Separator className="my-2" />
                            <div className="md:px-4 md:grid md:grid-cols-2 lg:grid-cols-3 gap-5 space-y-4 md:space-y-0">
                                {groupedCourses[category].map((course) => (
                                    <CourseCard key={course.id} course={course} linkRoute={`/dashboard/hod/my-learning/${course.id}`}/>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </main>
        </div>
    );
}