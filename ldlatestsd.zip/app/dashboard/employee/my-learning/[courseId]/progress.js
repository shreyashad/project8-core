// dashboard/employee/my-learning/[courseId]/progress.js
export const getProgress = async (courseId, userId) => {
    // Fetch user progress from the database or a service
    const res = await fetch(`/api/progress/${courseId}?userId=${userId}`);
    return res.json();
};

export const updateProgress = async (courseId, moduleId, videoId, userId) => {
    // Update user progress on video completion
    await fetch(`/api/progress/${courseId}/${moduleId}/${videoId}`, {
        method: 'POST',
        body: JSON.stringify({ userId, videoId }),
    });
};
