// dashboard/employee/my-learning/[courseId]/page.jsx
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

const CoursePage = () => {
    const router = useRouter();
    const { courseId } = router.query;
    const [courseData, setCourseData] = useState(null);

    useEffect(() => {
        if (courseId) {
            // Fetch course details and modules based on the courseId
            // You can use an API to fetch this data
            fetch(`/api/courses/${courseId}`)
                .then(res => res.json())
                .then(data => setCourseData(data));
        }
    }, [courseId]);

    if (!courseData) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h1>{courseData.title}</h1>
            <div>
                {courseData.modules.map((module) => (
                    <div key={module.id}>
                        <h3>{module.title}</h3>
                        <ul>
                            {module.videos.map((video) => (
                                <li key={video.id}>
                                    <a href={`/dashboard/employee/my-learning/${courseId}/${module.id}/${video.id}`}>
                                        {video.title}
                                    </a>
                                </li>
                            ))}
                        </ul>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default CoursePage;
