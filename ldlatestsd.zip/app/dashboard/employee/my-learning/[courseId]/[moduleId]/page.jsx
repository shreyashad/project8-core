// dashboard/employee/my-learning/[courseId]/[moduleId]/page.jsx
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

const ModulePage = () => {
    const router = useRouter();
    const { courseId, moduleId } = router.query;
    const [moduleData, setModuleData] = useState(null);

    useEffect(() => {
        if (courseId && moduleId) {
            // Fetch module data (including videos) for the specific course and module
            fetch(`/api/courses/${courseId}/modules/${moduleId}`)
                .then(res => res.json())
                .then(data => setModuleData(data));
        }
    }, [courseId, moduleId]);

    if (!moduleData) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h2>{moduleData.title}</h2>
            <ul>
                {moduleData.videos.map((video) => (
                    <li key={video.id}>
                        <a href={`/dashboard/employee/my-learning/${courseId}/${moduleId}/${video.id}`}>
                            {video.title}
                        </a>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default ModulePage;
