// dashboard/employee/my-learning/[courseId]/[moduleId]/[videoId]/page.jsx
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';

const VideoPage = () => {
    const router = useRouter();
    const { courseId, moduleId, videoId } = router.query;
    const [videoData, setVideoData] = useState(null);

    useEffect(() => {
        if (courseId && moduleId && videoId) {
            // Fetch video details from the API (e.g., video URL, title)
            fetch(`/api/courses/${courseId}/modules/${moduleId}/videos/${videoId}`)
                .then(res => res.json())
                .then(data => setVideoData(data));
        }
    }, [courseId, moduleId, videoId]);

    const handleVideoWatched = () => {
        // Update user's progress (e.g., mark this video as watched)
        fetch(`/api/progress/${courseId}/${moduleId}/${videoId}`, {
            method: 'POST',
            body: JSON.stringify({ watched: true }),
        });
    };

    if (!videoData) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h3>{videoData.title}</h3>
            <video width="100%" controls onEnded={handleVideoWatched}>
                <source src={videoData.videoUrl} type="video/mp4" />
                Your browser does not support the video tag.
            </video>
        </div>
    );
};

export default VideoPage;
