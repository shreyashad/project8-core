import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";

export default  async function TrainersPage() {
    const session = auth();
    return(
        <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboardBreadCrumb 
                homelink="/dashboard/trainers-admin/" 
                hometitle="Home" 
                mdipagelink="/dashboard/trainers-admin/trainers/" 
                mdipagetitle="Trainers Management" 
                pagetitle="Trainers "
            />
      </div>
    );
};