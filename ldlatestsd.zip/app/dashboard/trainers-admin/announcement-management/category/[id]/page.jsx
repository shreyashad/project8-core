import { fetchAnnouncementCategoryDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { AnnouncementCategoryForm } from "@/components/trainers-admin/announcement-category/announcement-category-form";


export default async function EditAnnouncementCategory({ params }) {
    const { id } = params;
    const session = await auth();

    if (!session){
        return new Response("Unauthorized", { status: 401 });
    }
    let catData = null;

    if (id === "new") {
        // Handle the case for creating a new organization
        catData = {}; // Pass an empty object for a new organization
    } else {
        // Handle the case for editing an existing organization
        const CateId = getCatId(id);
        catData = await fetchAnnouncementCategoryDetails(session.accessToken,CateId);
    }
    return (
        <div className="flex flex-col">
            <AnnouncementCategoryForm initialData={catData || {}}/>
        </div>
   );

}