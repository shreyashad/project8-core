import { fetchAnnouncementListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import AnnouncementClient from "@/components/trainers-admin/announcement/announcement-client";
import { AnnouncementColumns } from "@/components/trainers-admin/announcement/announcement-columns";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";


export default async function AnnouncementPage() {
    const session = await auth();
    const announcementData = await fetchAnnouncementListData(session.accessToken);

    return (
        <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboardBreadCrumb
                homelink="/dashboard/trainers-admin/" 
                hometitle="Home" 
                mdipagelink="/dashboard/trainers-admin/announcement-management/announcements" 
                mdipagetitle="Announcement Management" 
                pagetitle="Announcements"
            />
            <div className="mt-16" />
            <Card className="shadow-2xl">
                <CardHeader className="pb-3">
                    <CardTitle> Announcements </CardTitle>
                    <CardDescription className="max-w-lg text-balance leading-relaxed">
                        Manage your all announcements in one place.
                        
                    </CardDescription>
                    <AnnouncementClient />
                </CardHeader>
                <Separator />
                <CardContent>
                    <DataTable columns={AnnouncementColumns} data={announcementData} />
                </CardContent>
            </Card>
        </div>
    );
};