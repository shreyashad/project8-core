import { fetchAnnouncementCategoryListData, fetchAnnouncementDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { AnnouncementForm } from "@/components/trainers-admin/announcement/announcement-form";

function getAnnounceId(data) {
    try{
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode announcement Id')
        return data;
    }
};

export default async function EditAnnouncement({params}) {
    const { id } = params;
    const session = await auth();
    const categoryData = await fetchAnnouncementCategoryListData(session.accessToken);

    if (!session) {
        return new Response("Unauthorized", { status: 401});
    }
    let announcementData = null;

    if (id==="new") {
        announcementData = {};
    } else {
        const announceId = getAnnounceId(id);
        announcementData = await fetchAnnouncementDetails(session.accessToken, announceId);
    }
    return(
        <div className="flex flex-col">
            <AnnouncementForm initialData={announcementData || {}}  categories={categoryData}/>
        </div>
    );
}