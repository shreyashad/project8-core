import { fetchTrainingRequestDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import TrainingBookingForm from "@/components/trainers-admin/training-request/training-schedulingform";

function getRequestId(data) {
  try{
      return decodeURIComponent(data);
  } catch (error) {
      console.error('Failed to decode announcement Id')
      return data;
  }
};
export default async function TrainingRequestDetailsPage({ params }) {
    const { id } = params;
    const session = await auth();
    
    if (!session){
      return new Response("Unauthorized", { status: 401 });
    }

    

    const requestId = getRequestId(id);
    
    const trainingRequestData = await fetchTrainingRequestDetails(session.accessToken, requestId);

    
    return (
      <div className="container mx-auto py-10">
        <TrainingBookingForm initialData={trainingRequestData} />
      </div>
    )
  }
  