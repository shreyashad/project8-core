
import { auth } from "@/auth"
import { fetchTrainingRequest } from "@/app/api/server/route"
import TrainingRequestDashboardTA from "@/components/trainers-admin/training-request/training-request-dashboard";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { DataTable } from "@/components/ui/data-table/data-table";
import { TATrainingRequestColumns } from "@/components/trainers-admin/training-request/training-request-coloumn";
import { TrainingCalendar } from "@/components/trainers-admin/training-request/training-calendar";

export default async function TrainingRequestSystem() {
  const session = await auth();
  const requestdata = await fetchTrainingRequest(session.accessToken);
  console.log("request data:", requestdata);
  return (
    <Tabs defaultValue="inbox" className="space-y-4">
    <TabsList>
      <TabsTrigger value="inbox">Inbox</TabsTrigger>
      <TabsTrigger value="calendar">Calendar</TabsTrigger>
    </TabsList>
    
    <TabsContent value="inbox" className="space-y-4">
      <DataTable columns={TATrainingRequestColumns} data={requestdata} />
    </TabsContent>
    <TabsContent value="calendar">
      <TrainingCalendar />
    </TabsContent>
  </Tabs>
  );
}