import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import { StatsCard } from "@/components/dashboard/stats-card";
import { MdModelTraining } from "react-icons/md";
import { RiTeamFill, RiUserLocationLine } from "react-icons/ri";

export default async function TrainingManagementPage () {
    const session = await auth();
    
    return(
        <div className="grid grid-cols-12 grid-rows-5 gap-4">
            <div className="col-span-12 fixed w-full shadow-2xl p-4  z-10">
                <DashboardBreadCrumb 
                    homelink="/dashboard/trainers-admin/"
                    hometitle="Dashboard"
                    mdipagelink="/dashboard/trainers-admin/training-management"
                    mdipagetitle="Training Management"
                    pagetitle="Training"
                />
            </div>
            <div className="col-span-4 row-start-2">
                <StatsCard title="Total Completed Trainings" description="Total Completed Trainings" value={1} icon=""/>
            </div>
            <div className="col-span-4 col-start-5 row-start-2">
                <StatsCard title="Total Self-learining Training" description="Total Self-learining Training" value={2} icon={<RiTeamFill />}/>
            </div>
            <div className="col-span-4 col-start-9 row-start-2">
            <StatsCard title="Total Offline Training" description="Total Offline Training" value={1} icon={<MdModelTraining /> }/>
            </div>
            <div className="row-start-2">
               
            </div>
            <div className="col-span-8 row-span-3 row-start-3">5</div>
            <div className="col-span-4 row-span-3 col-start-9 row-start-3">6</div>
        </div>

        // <div className="flex flex-col grid grid-cols-5 grid-rows-5 gap-4"> 
        //     <div className=" col-span-5 fixed w-full shadow-2xl p-4  z-10 ">
                
        //     </div>
        //     <div className="row-start-2">
        //     <StatsCard title="Total Completed Trainings" description="Total Completed Trainings" value={1} icon=""/>
        //     </div>
        //     <div className="row-start-2"><StatsCard title="Total Self-learining Training" description="Total Self-learining Training" value={2} icon={<RiTeamFill />}/>
        //     </div>
        //     <div className="row-start-2"><StatsCard title="Total Offline Training" description="Total Offline Training" value={1} icon={<MdModelTraining /> }/>
        //     </div>
        //     <div className="row-start-2"><StatsCard title="Total Offline Training" description="Total Offline Training" value={1} icon={<MdModelTraining /> }/>
        //     </div>
        //     <div className="row-start-2"><StatsCard title="Total Offline Training" description="Total Offline Training" value={1} icon={<MdModelTraining /> }/>
        //     </div>
           
            
            
                

        // </div>
        
    );
}