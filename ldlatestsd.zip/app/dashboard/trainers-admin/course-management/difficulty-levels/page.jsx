import { fetchCategoryData, fetchDifficultyLevelListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import CourseDifficultyLevelClient from "@/components/course/course-difficulty-level-client";
import { CourseDifficultyLevelColumns } from "@/components/course/course-difficulty-level-column";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";

export default async function CourseDifficultyLevelPage() {
    const session = await auth();
    const difflevel = await fetchDifficultyLevelListData(session.accessToken);
    console.log("Difficulty level details:", difflevel);
    
    return (
        <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
            {/* Fixed breadcrumb */}
            <div className="fixed w-full shadow-2xl p-4 z-10 ">
                <DashboardBreadCrumb 
                    homelink="/dashboard/trainers-admin/" 
                    hometitle="Home" 
                    mdipagelink="/dashboard/trainers-admin/course-management/difficulty-levels" 
                    mdipagetitle="Course Management" 
                    pagetitle="Course Levels"
                />
            </div>

            {/* Spacer to prevent content from being hidden behind the fixed breadcrumb */}
            <div className="mt-16" /> {/* Adjust height as needed to match the breadcrumb's height */}
            
            <Card className="shadow-2xl">
                <CardHeader className="pb-3">
                    <CardTitle>Course Difficulty Levels</CardTitle>
                    <CardDescription className="max-w-lg text-balance leading-relaxed">
                        Manage your courses levels in one place.
                        <CourseDifficultyLevelClient />
                    </CardDescription>
                </CardHeader>
                <Separator />
                <CardContent>
                    <DataTable columns={CourseDifficultyLevelColumns} data={difflevel} />
                </CardContent>
            </Card>
        </div>
    );
}
