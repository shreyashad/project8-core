import {fetchDifficultyLevelDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { CourseDifficultyLevelForm } from "@/components/course/course-difficulty-level-form";

function getCatId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode org ID');
        return data;
    }
}

export default async function EditCourseDifficultyLevel({ params }) {
    const { id } = params;
    const session = await auth();

    if (!session){
        return new Response("Unauthorized", { status: 401 });
    }
    let catData = null;

    if (id === "new") {
        // Handle the case for creating a new organization
        catData = {}; // Pass an empty object for a new organization
    } else {
        // Handle the case for editing an existing organization
        const CateId = getCatId(id);
        catData = await fetchDifficultyLevelDetails(session.accessToken,CateId);
    }
    return (
        <div className="flex flex-col">
            <CourseDifficultyLevelForm initialData={catData || {}}/>
        </div>
   );
};