import { fetchCourseListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import ErrorMessage from "@/components/dashboard/error-message";

export default async function CoursePage() {
    const session = auth();

    try{
        const course = await fetchCourseListData(session.accessToken);
        console.log("course data:", course);
    } catch (error) {
      return <ErrorMessage message={error.message} />
    }

    return(
      <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
        <DashboardBreadCrumb 
           homelink="/dashboard/trainers-admin/" 
           hometitle="Home" 
           mdipagelink="/dashboard/trainers-admin/course-management/Course" 
           mdipagetitle="Course Management" 
           pagetitle="Course "
        />
      </div>
    );
}