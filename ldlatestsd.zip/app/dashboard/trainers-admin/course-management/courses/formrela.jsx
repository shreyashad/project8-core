import { fetchCategoryData, fetchCourseListData, fetchDifficultyLevelListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import { CourseForm } from "@/components/trainers-admin/course-management/course-form";
import CourseListCard from "@/components/course/course-list-card";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";


export default async function CoursePage() {
    const session = await auth();
    const courseData = await fetchCourseListData(session.accessToken);
    const categoryData = await fetchCategoryData(session.accessToken);
    const difflevelData = await fetchDifficultyLevelListData(session.accessToken);
    return (
        <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
            {/* Fixed breadcrumb */}
            <div className="fixed w-full shadow-2xl p-4 z-10 ">
                <DashboardBreadCrumb 
                    homelink="/dashboard/trainers-admin/" 
                    hometitle="Home" 
                    mdipagelink="/dashboard/trainers-admin/course-management/category" 
                    mdipagetitle="Course Management" 
                    pagetitle="Course "
                />
            </div>

            {/* Spacer to prevent content from being hidden behind the fixed breadcrumb */}
            <div className="mt-16" /> {/* Adjust height as needed to match the breadcrumb's height */}
            
            <Card className="shadow-2xl relative">
                <CardHeader className="pb-3">
                    <CardTitle>Course </CardTitle>
                    <CardDescription className="max-w-lg text-balance leading-relaxed">
                        Manage your courses module and videos all in one place.
                        
                    </CardDescription>
                </CardHeader>
                <Separator />
                <CardContent>
                    <div className="mt-8 p-4 shadow-md">
                        <CourseForm  categories={categoryData} difflevel={difflevelData}/>
                    </div>
                
                </CardContent>
            </Card>
        </div>
    );
}