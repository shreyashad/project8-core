import { fetchCategoryData, fetchCourseDetails, fetchDifficultyLevelListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import { CourseForm } from "@/components/trainers-admin/course-management/course-form";


function getCourseId(data) {
    try{
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode announcement Id')
        return data;
    }
};

export default async function EditCourses({ params }) {
    const { id } = params;
    const session = await auth();
    const courseCategoryList = await fetchCategoryData(session.accessToken);
    const difflevelList = await fetchDifficultyLevelListData(session.accessToken);
    const certificateList = await fetchDifficultyLevelListData(session.accessToken);
    
    if (!session){
        return new Response("Unauthorized", { status: 401 });
    }

    let courseData = null;

    if (id === "new") {
        courseData = {};
    } else {
        const CourseId = getCourseId(id);
        courseData = await fetchCourseDetails(session.accessToken, CourseId);
        
    }
    console.log("courseDetails:", courseData);
    return(
        <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
        {/* Fixed breadcrumb */}
            <div className="fixed w-full shadow-2xl p-4 z-10 ">
                <DashboardBreadCrumb 
                    homelink="/dashboard/trainers-admin/" 
                    hometitle="Home" 
                    mdipagelink="/dashboard/trainers-admin/course-management/Course" 
                    mdipagetitle="Course Management" 
                    pagetitle="Course "
                />
            </div>
    
            {/* Spacer to prevent content from being hidden behind the fixed breadcrumb */}
            <div className="mt-16" /> 

            <CourseForm initialData={courseData || {}} categoryList={courseCategoryList} difficultyList={difflevelList}  certificateList={certificateList} />
        </div>
    );

};