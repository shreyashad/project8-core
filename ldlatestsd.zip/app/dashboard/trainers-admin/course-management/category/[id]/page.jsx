import { fetchCourseCategoryDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { CourseCategoryForm } from "@/components/course/course-category-form";

function getCatId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode org ID');
        return data;
    }
}

export default async function EditCourseCategory({ params }) {
    const { id } = params;
    const session = await auth();

    if (!session){
        return new Response("Unauthorized", { status: 401 });
    }
    let catData = null;

    if (id === "new") {
        // Handle the case for creating a new organization
        catData = {}; // Pass an empty object for a new organization
    } else {
        // Handle the case for editing an existing organization
        const CateId = getCatId(id);
        catData = await fetchCourseCategoryDetails(session.accessToken,CateId);
    }
    return (
        <div className="flex flex-col">
            <CourseCategoryForm initialData={catData || {}}/>
        </div>
   );
};