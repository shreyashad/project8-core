"use client"

import { useState } from "react"
import { Trash2, Plus, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function CourseForm() {
  const [modules, setModules] = useState([{ title: "", description: "", videos: [{ title: "", url: "" }] }])

  const addModule = () => {
    setModules([...modules, { title: "", description: "", videos: [{ title: "", url: "" }] }])
  }

  const addVideo = (moduleIndex: number) => {
    const newModules = [...modules]
    newModules[moduleIndex].videos.push({ title: "", url: "" })
    setModules(newModules)
  }

  const removeModule = (index: number) => {
    setModules(modules.filter((_, i) => i !== index))
  }

  const removeVideo = (moduleIndex: number, videoIndex: number) => {
    const newModules = [...modules]
    newModules[moduleIndex].videos = newModules[moduleIndex].videos.filter((_, i) => i !== videoIndex)
    setModules(newModules)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission here
    console.log("Form submitted:", { modules })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8 max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle>Create New Course</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="courseTitle">Course Title</Label>
              <Input id="courseTitle" placeholder="Enter course title" required />
            </div>
            <div>
              <Label htmlFor="courseDescription">Course Description</Label>
              <Textarea id="courseDescription" placeholder="Enter course description" required />
            </div>
            <div>
              <Label htmlFor="courseThumbnail">Course Thumbnail</Label>
              <Input id="courseThumbnail" type="file" accept="image/*" required />
            </div>
            <div>
              <Label htmlFor="courseCategory">Course Category</Label>
              <Input id="courseCategory" placeholder="Enter course category" required />
            </div>
            <div>
              <Label htmlFor="courseDuration">Estimated Duration (in hours)</Label>
              <Input id="courseDuration" type="number" placeholder="Enter estimated duration" required />
            </div>
            <div>
              <Label htmlFor="coursePrice">Course Price ($)</Label>
              <Input id="coursePrice" type="number" step="0.01" placeholder="Enter course price" required />
            </div>
          </div>
        </CardContent>
      </Card>

      <Accordion type="single" collapsible className="w-full">
        {modules.map((module, moduleIndex) => (
          <AccordionItem value={`module-${moduleIndex}`} key={moduleIndex}>
            <AccordionTrigger>Module {moduleIndex + 1}</AccordionTrigger>
            <AccordionContent>
              <Card>
                <CardContent className="space-y-4 pt-4">
                  <div>
                    <Label htmlFor={`moduleTitle-${moduleIndex}`}>Module Title</Label>
                    <Input id={`moduleTitle-${moduleIndex}`} placeholder="Enter module title" required />
                  </div>
                  <div>
                    <Label htmlFor={`moduleDescription-${moduleIndex}`}>Module Description</Label>
                    <Textarea id={`moduleDescription-${moduleIndex}`} placeholder="Enter module description" required />
                  </div>
                  {module.videos.map((video, videoIndex) => (
                    <Card key={videoIndex}>
                      <CardContent className="space-y-4 pt-4">
                        <div>
                          <Label htmlFor={`videoTitle-${moduleIndex}-${videoIndex}`}>Video Title</Label>
                          <Input id={`videoTitle-${moduleIndex}-${videoIndex}`} placeholder="Enter video title" required />
                        </div>
                        <div>
                          <Label htmlFor={`videoUrl-${moduleIndex}-${videoIndex}`}>Video URL</Label>
                          <Input id={`videoUrl-${moduleIndex}-${videoIndex}`} placeholder="Enter video URL" required />
                        </div>
                        <Button
                          type="button"
                          variant="destructive"
                          size="sm"
                          onClick={() => removeVideo(moduleIndex, videoIndex)}
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Remove Video
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                  <Button type="button" variant="outline" size="sm" onClick={() => addVideo(moduleIndex)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Video
                  </Button>
                  <Button type="button" variant="destructive" size="sm" onClick={() => removeModule(moduleIndex)}>
                    <Trash2 className="mr-2 h-4 w-4" />
                    Remove Module
                  </Button>
                </CardContent>
              </Card>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>

      <Button type="button" onClick={addModule}>
        <Plus className="mr-2 h-4 w-4" />
        Add Module
      </Button>

      <Button type="submit" className="w-full">
        <Upload className="mr-2 h-4 w-4" />
        Create Course
      </Button>
    </form>
  )
}