import { fetchCourseListData, fetchExaminationDetails, fetchQuestionTypeListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import { TAExamForm } from "@/components/trainers-admin/examination/exam/exam-form";

function getExamId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode org ID');
        return data;
    }
}



export default async function EditExam({ params }) {
    const { id } = params;
    const session = await auth();
    const courseListData = await fetchCourseListData(session.accessToken);
    const queTypeListData = await fetchQuestionTypeListData(session.accessToken);
    
    if (!session){
        return new Response("Unauthorized", { status: 401 });
    }
    let examData = null;

    if (id === "new") {
        // Handle the case for creating a new organization
        examData = {}; // Pass an empty object for a new organization
    } else {
        // Handle the case for editing an existing organization
        const examId = getExamId(id);
        examData = await fetchExaminationDetails(session.accessToken,examId);
    }
    return (
        <div className="flex flex-col item-center">
            <TAExamForm initialData={examData || {}} courseList={courseListData} queTypeList={queTypeListData}/>
        </div>
   );
}