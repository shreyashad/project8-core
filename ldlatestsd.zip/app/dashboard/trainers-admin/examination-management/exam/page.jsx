import { fetchExaminationListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import TAExamClient from "@/components/trainers-admin/examination/exam/exam-client";
import { TAExamColumns } from "@/components/trainers-admin/examination/exam/exam-columns";
import { Card, CardHeader,CardTitle, CardContent,CardDescription } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";


export default async function ExamPage() {
    const session = await auth();
    const examData = await fetchExaminationListData(session.accessToken);
    return (
        <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
            {/* Fixed breadcrumb */}
            <div className="fixed w-full shadow-2xl p-4 z-10 ">
                <DashboardBreadCrumb 
                    homelink="/dashboard/trainers-admin/" 
                    hometitle="Home" 
                    mdipagelink="/dashboard/trainers-admin/examination-management/exam" 
                    mdipagetitle="Exam Management" 
                    pagetitle="Exam"
                />
            </div>

            {/* Spacer to prevent content from being hidden behind the fixed breadcrumb */}
            <div className="mt-16" /> {/* Adjust height as needed to match the breadcrumb's height */}
            
            <Card className="shadow-2xl">
                <CardHeader className="pb-3">
                    <CardTitle>Examination</CardTitle>
                    <CardDescription className="max-w-lg text-balance leading-relaxed">
                        Manage your Exam in one place.
                        <TAExamClient />
                    </CardDescription>
                </CardHeader>
                <Separator />
                <CardContent>
                    <DataTable columns={TAExamColumns} data={examData} />
                </CardContent>
            </Card>
        </div>
    );
}