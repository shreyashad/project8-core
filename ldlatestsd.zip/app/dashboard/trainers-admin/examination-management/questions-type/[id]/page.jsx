import { fetchQuestionTypeDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { QuestionTypeForm } from "@/components/trainers-admin/examination/category/que-cat-form";

function getQueTypeId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode Todays Wisdom ID');
        return data;
    }
};

export default async function EditQuestionType({ params }) {
    console.log(params);
    const { id } = params;
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    let queTypeData = null;

    if (id === "new") {
        queTypeData = {};
    } else {
        const queTypeId = getQueTypeId(id);
        queTypeData = await fetchQuestionTypeDetails(session.accessToken, queTypeId);
    }

    return (
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
                <QuestionTypeForm initialData={queTypeData || {}} />
            </div>
        </div>
    );
}