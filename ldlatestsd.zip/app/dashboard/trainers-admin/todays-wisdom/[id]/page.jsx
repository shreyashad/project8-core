import { fetchTodaysWisdomDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { TodaysWisdomForm } from "@/components/trainers-admin/todays-wisdom/wisdom-from";

function getTodaysWisdomId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode Todays Wisdom ID');
        return data;
    }
};

export default async function EditTodaysWisdom({ params }) {
    console.log(params);
    const { id } = params;
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    let todaysWisdomData = null;

    if (id === "new") {
        todaysWisdomData = {};
    } else {
        const todaysWisdomId = getTodaysWisdomId(id);
        todaysWisdomData = await fetchTodaysWisdomDetails(session.accessToken, todaysWisdomId);
    }

    return (
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
                <TodaysWisdomForm initialData={todaysWisdomData || {}} />
            </div>
        </div>
    );
}