import { fetchTodaysWisdomListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import TodaysWisdomClient from "@/components/trainers-admin/todays-wisdom/wisdom-client";
import { TodaysWisdomColumns } from "@/components/trainers-admin/todays-wisdom/wisdom-columns";
import { Card, CardHeader, CardDescription, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";


export default async function TodaysWisdomManagement() {
    const session = await auth();
    const todayswisdomData = await fetchTodaysWisdomListData(session.accessToken);
    return (
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboardBreadCrumb
                homelink="/dashboard/trainers-admin/"
                hometitle="Dashboard"
                mdipagelink="/dashboard/trainers-admin/todays-wisdom"
                mdipagetitle="Today's Wisdom Management"
                pagetitle="Today's Wisdom"
            />
            
            <Card className="sm:col-span-2" x-chunk="dashboard-05-chunk-0">
                <CardHeader className="pb-3">
                <CardTitle>Todays Wisdom Management</CardTitle>
                <CardDescription className="max-w-lg text-balance leading-relaxed">
                    Manage your all types of topics in one place.
                </CardDescription>
                </CardHeader>
                <CardFooter>
                    <TodaysWisdomClient />
                </CardFooter>
            </Card>
            <Separator />
            <Card >
                <CardHeader className="px-7">
                    <CardTitle>Todays Wisdom History</CardTitle>
                    <CardDescription>Manage your topics.</CardDescription>
                </CardHeader> 
                <CardContent>
                  <DataTable columns={TodaysWisdomColumns} data={todayswisdomData} />
                </CardContent>
            </Card>
            
        </div>
    );
}