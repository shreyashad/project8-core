"use client";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Trash, X } from "lucide-react";
import { useEffect, useState } from "react";
import { useFieldArray, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import toast from "react-hot-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { AlertModal } from "../dashboard/alert-modal";
import { createNewTeam, updateTeamDetails } from "@/app/api/server/route";
import { TeamsSchema } from "@/schema";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";



export const TeamForm = ({ initialData, usersList }) => {
    const router = useRouter();
    const { data: session } = useSession();

    const title = initialData && initialData.id ?  "Edit Team" : "Create New Team";
    const description = initialData && initialData.id ?  "Edit the Team details" : "Create a new Team";
    const action = initialData && initialData.id ?  "Save Changes" : "Create";
    
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    
    
    const form = useForm({
        resolver: zodResolver(TeamsSchema),
        defaultValues: initialData || {
            name: "",
            description: "",
            users: [],
        },
    });

    const { fields, append, remove } = useFieldArray({
        control: form.control,
        name: "users",
      });

    useEffect(() => {
        if (initialData) {
            form.reset(initialData);
        }
    }, [initialData, form]);

    const onSubmit = async (values) => {
        console.log("Form Values", values);
        
        const formattedData = {
            ...values,
            users: values.users.map(user => ({
                user: user.user.toString(), // user ID
                role: user.role,  // role: Leader or Member
            })),
        };

        try {
            setLoading(true);
            if (initialData && initialData.id) {
                await updateTeamDetails(session.accessToken, initialData.id, formattedData);
                router.push(`/dashboard/hod/team-management/teams/`);
            } else {
                await createNewTeam(session.accessToken, formattedData);
                router.push(`/dashboard/hod/team-management/teams/`);
            }
            router.refresh();
            toast.success(`${action} successfully!`)
        } catch (error) {
            console.error("Error on submit:", error);
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };

    

    const onDelete = async () => {
        try {
            setLoading(true);
            // await deleteCourseCategory(initialData.id, session.accessToken);
            toast.success("Team deleted successfully")
            router.push(`/dashboard/hod/team-management/teams/`);
        } catch (error) {
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };

    return(
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
                {initialData && initialData.id && (
                    <Button
                        disabled={loading}
                        variant="destructive"
                        size="icon"
                        onClick={() => setOpen(true)}
                    >
                        <Trash className="h-4 w-4" />
                    </Button>
                )}
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <FormField 
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel> Team Name </FormLabel>
                                    <FormControl>
                                        <Input 
                                            placeholder="Enter Team Name"
                                            {...field}
                                            disabled={loading}
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField 
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel> Description </FormLabel>
                                    <FormControl>
                                        <Textarea 
                                            placeholder="Enter Team Description"
                                            {...field}
                                            disabled={loading}
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <div>
                            <h3 className="text-lg font-medium mb-2">Team Members</h3>
                            {fields.map((field, index) => (
                                <div key={field.id} className="flex items-center space-x-2 mb-2">
                                    <FormField 
                                        control={form.control}
                                        name={`users.${index}.user`}
                                        render={({ field }) => (
                                            <FormItem className="flex-grow">
                                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select a user" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        {usersList.map((user) => (
                                                            <SelectItem key={user.id} value={user.id}>
                                                                {user.first_name} {user.last_name}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </FormItem>
                                        )}
                                    />
                                    <FormField 
                                        control={form.control}
                                        name={`users.${index}.role`}
                                        render={({ field }) => (
                                          <FormItem>
                                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                              <FormControl>
                                                <SelectTrigger>
                                                  <SelectValue placeholder="Role" />
                                                </SelectTrigger>
                                              </FormControl>
                                              <SelectContent>
                                                <SelectItem value="Leader">Leader</SelectItem>
                                                <SelectItem value="Member">Member</SelectItem>
                                              </SelectContent>
                                            </Select>
                                            <FormMessage />
                                          </FormItem>
                                        )}
                                    />
                                    <Button type="button" variant="ghost" size="icon" onClick={() => remove(index)}>
                                     <X className="h-4 w-4" />
                                    </Button>
                                </div>
                            ))}
                            <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                className="mt-2"
                                onClick={() => append({ user: '', role: 'Member' })}
                            >
                                Add Member
                            </Button>
                        </div>
                        <div className="mt-5 space-x-4">
                            <Button disabled={loading || !form.formState.isValid}  className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => router.back()}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
                {initialData && initialData.id && (
                    <AlertModal 
                        title="Are you Sure!"
                        description="This actions can not be undone."
                        name={initialData?.name}
                        isOpen={open}
                        onClose={() => setOpen(false)}
                        onConfirm={onDelete}
                        loading={loading}
                    />
                )}
            </CardContent>
        </Card>
    );

};