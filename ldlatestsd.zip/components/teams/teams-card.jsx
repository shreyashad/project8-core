"use client";
import { Pencil, Users } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { useRouter } from "next/navigation";




export function TeamsCard({ teamData }) {
    const router = useRouter();

    const handleEdit = () => {
        router.push(`/dashboard/hod/team-management/teams/${teamData.id}`);
       
    }
    return(
        <div  className="flex flex-col mt-4">
        <Card key={teamData.id}>
            <CardHeader className="bg-sky-400">
                <CardTitle className="flex justify-between items-center">
                    <span>{teamData.name}</span>
                    
                </CardTitle>
            </CardHeader>
            <CardContent className="flex-grow">
                <span className="text-sm font-normal text-muted-foreground flex items-center bp-4">
                    <Users className="w-10 h-10 mr-1 inline-block size-10 rounded-full ring-2 ring-white" />
                    <span className="text-bold text-2xl"> {teamData.member_count}</span>
                </span>
                <p className="mt-4 text-sm text-muted-foreground text-balance">
                    {teamData.description}
                </p>
            </CardContent>
            <CardFooter className="flex justify-end space-x-2">
            <Button variant="outline" size="sm" onClick={() => handleEdit()}>
                <Pencil className="w-4 h-4 mr-2" />
                Edit
            </Button>
            {/* <AlertDialog>
                <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the
                    teamData and remove all associated data.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => handleDelete(teamData.id)}>
                    Delete
                    </AlertDialogAction>
                </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog> */}
            </CardFooter>
        </Card>
        </div>
    );
}