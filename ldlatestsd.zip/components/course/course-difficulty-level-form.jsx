"use client";
import { createNewDifficultyLevel, deleteDifficultyLevelDetails, updateDifficultyLevelDetails } from "@/app/api/server/route";
import { CourseLevelSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Trash } from "lucide-react";
import { Separator } from "../ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { Input } from "../ui/input";
import { AlertModal } from "../dashboard/alert-modal";


export const CourseDifficultyLevelForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();

    const title = initialData && initialData.id ?  "Edit Course Level" : "Create Course Level";
    const description = initialData && initialData.id ?  "Edit the Course Level details" : "Create a new Course Level";
    const action = initialData && initialData.id ?  "Save Changes" : "Create";
    
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);

    const form = useForm({
        resolver: zodResolver(CourseLevelSchema),
        defaultValues: initialData || {
            name: "",
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async(values) => {
        try {
            setLoading(true);
            const formData = new FormData();
            formData.append("name", values.name);
            if (initialData && initialData.id) {
                await updateDifficultyLevelDetails(session.accessToken, initialData.id, formData);
                router.push(`/dashboard/trainers-admin/course-management/difficulty-levels/`);
            } else {
                await createNewDifficultyLevel(session.accessToken, formData);
                router.push(`/dashboard/trainers-admin/course-management/difficulty-levels/`);
            }
            router.refresh();
            toast.success(`${action} successfully!`)
        } catch (error) {
            toast.error(error.message);
        } finally {
            setLoading(false)
        }
    };
    
    const onDelete = async () => {
        try {
            setLoading(true);
            await deleteDifficultyLevelDetails(session.accessToken, initialData.id);
            toast.success("Course Level deleted successfully")
            router.push(`/dashboard/trainers-admin/course-management/difficulty-levels/`);
        } catch (error) {
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };
    

    return(
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
                {initialData && initialData.id && (
                    <Button
                        disabled={loading}
                        variant="destructive"
                        size="icon"
                        onClick={() => setOpen(true)}
                    >
                        <Trash className="h-4 w-4" />
                    </Button>
                )}
            </CardHeader>
            <Separator />
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid grid-cols-2 gap-8">
                            <FormField
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Course Level</FormLabel>
                                        <FormControl>
                                            <Input
                                                placeholder="Enter Course Level"
                                                {...field}
                                                disabled={loading}
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="mt-5 space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => {
                                    router.back();
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
                {initialData && initialData.id && (
                    <AlertModal 
                        title="Are you Sure!"
                        description="This actions can not be undone."
                        name={initialData?.name}
                        isOpen={open}
                        onClose={() => setOpen(false)}
                        onConfirm={onDelete}
                        loading={loading}
                    />
                )}
            </CardContent>
        </Card>
    );
}