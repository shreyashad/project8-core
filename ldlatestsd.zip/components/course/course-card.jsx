import Link from "next/link";
import { Progress } from "../ui/progress";

export default function CourseCard({ course, linkRoute  }) {
    
    return(
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
                <h2 className="text-xl font-semibold mb-2">{course.title}</h2>
                <p className="text-gray-600 mb-4">{course.description}</p>
                <div className="mb-4">
                <Progress value={course.progress} className="w-full" />
                <span className="text-sm text-gray-500">{course.progress}% Complete</span>
                </div>
                <Link
                    href={linkRoute}
                    className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors"
                >
                Continue
                </Link>
            </div>
        </div>
    );
}