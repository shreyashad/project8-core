"use client";
import Image from "next/image";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../ui/card";
import { Star } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../ui/dialog";
import { useEffect, useState } from "react";
import { Button } from "../ui/button";
import { ScrollArea } from "../ui/scroll-area";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";
import { checkEnrollmentStatus, courseEnrollment } from "@/app/api/server/route";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";


export default function CourseListCard({ course }) {
    const { data: session } = useSession();
    const [selectedCourse, setSelectedCourse] = useState(null);
    const [isEnrolled, setIsEnrolled] = useState(false);
    const [isLoading, setIsLoading] = useState(false); // For loading state
    const [error, setError] = useState(null); // For error state
    const [lastCompletedModule, setLastCompletedModule] = useState(null); // To track user's progress
    const router = useRouter();
    const userRole = session.user.roles
    console.log("roledetasilas:",userRole);
    // Fetch user's enrollment status and progress on initial load
    useEffect(() => {
      const fetchEnrollmentStatus = async () => {
          try {
              const response = await checkEnrollmentStatus(session.accessToken, course.id);
              console.log("enrolstat",response);
              setIsEnrolled(response.enrolled);
              setLastCompletedModule(response.last_completed_module); // Assuming backend sends last completed module
          } catch (err) {
              console.error("Error fetching enrollment status:", err);
          }
      };
      if (session?.accessToken) {
          fetchEnrollmentStatus();
      }
  }, [session, course.id]);

    // Handle the course enrollment action
    const handleEnroll = async () => {
        setIsLoading(true);
        setError(null); // Reset error state
        try {
            const response = await courseEnrollment(session.accessToken, course.id, userId);
            setIsEnrolled(true); // Set enrollment status to true
            setIsLoading(false);
        } catch (err) {
            setIsLoading(false);
            setError("Failed to enroll. Please try again later."); // Show error if enrollment fails
        }
    };

    // Handle the "Continue" action, navigating to the last completed module/video
    const handleContinue = () => {
      if (lastCompletedModule) {
          // Navigate to the last completed module/video
          const moduleId = lastCompletedModule.module_id; // Assuming you have the module ID
          const videoId = lastCompletedModule.video_id; // Assuming you have the video ID
          
          // Set dynamic base path based on user role
          let basePath = '';
          switch (userRole) {
            case "Trainers Admin":
              basePath = "/dashboard/trainers-admin";
              break;
            case "Trainer":
              basePath = "/dashboard/trainer";
              break;
            case "HOD's":
              basePath = "/dashboard/hod";
              break;
            case "Employee":
              basePath = "/dashboard/employee";
              break;
            default:
              console.error("Unknown user role:", userRole);
              return; // Don't proceed if the role is unknown
          }

          // Construct the route with dynamic user role and course information
          const route = videoId
            ? `${basePath}/my-learning/${course.slug}/${moduleId}/${videoId}`
            : `${basePath}/my-learning/${course.slug}/${moduleId}`;
          // Redirect to the appropriate URL for the module/video
          router.push(route);
      } else {
          // If no progress found, start from the first module
        let basePath = '';
        switch (userRole) {
          case "Trainers Admin":
            basePath = "/dashboard/trainers-admin";
            break;
          case "Trainer":
            basePath = "/dashboard/trainer";
            break;
          case "HOD's":
            basePath = "/dashboard/hod";
            break;
          case "Employee":
            basePath = "/dashboard/employee";
            break;
          default:
            console.error("Unknown user role:", userRole);
            return; // Don't proceed if the role is unknown
        }

      // Redirect to the first module for the course
      router.push(`${basePath}/my-learning/${course.slug}/${course.modules[0].id}`);
    }
    };
    return(
        <Card key={course.id} className="flex flex-col">
            <CardHeader>
              <img src={course.cover_image} alt={course.title} className="w-full h-48 object-cover rounded-t-lg" />
            </CardHeader>
            <CardContent className="flex-grow">
              <CardTitle className="mb-2">{course.title}</CardTitle>
              <p className="text-sm text-gray-600 mb-2">{course.description}</p>
              <div className="flex items-center mb-2">
                <Star className="w-4 h-4 text-yellow-400 mr-1" />
                <span className="text-sm font-medium">{course.course_reviews.rating}</span>
                <span className="text-sm text-gray-600 ml-2">({course.enrollment_count} enrolled)</span>
              </div>
              
            </CardContent>
            <CardFooter className="flex justify-between">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" onClick={() => setSelectedCourse(course)}>View Details</Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>{course.title}</DialogTitle>
                  </DialogHeader>
                  <ScrollArea className="max-h-[60vh]">
                    <div className="space-y-4">
                      <img src={course.cover_image} alt={course.title} className="w-full h-64 object-cover rounded-lg" />
                      <p>{course.description}</p>
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-400 mr-1" />
                        <span className="font-medium">{course.course_reviews.rating}</span>
                        <span className="text-gray-600 ml-2">({course.enrollment_count} enrolled)</span>
                      </div>
                      
                      <Accordion type="single" collapsible className="w-full">
                        {course.modules.map((module, index) => (
                           <AccordionItem value={`module-${index}`} key={module.id}>
                            <AccordionTrigger>{module.title}</AccordionTrigger>
                            <AccordionContent>
                            <p>{module.description}</p>
                            {module.cover_image && <img src={module.cover_image} alt={module.title} className="w-full h-auto" />}

                              <ul className="space-y-2 mt-4">
                                {/* Check if 'video_lessons' exists and has content */}
                                {module.video_lessons && module.video_lessons.length > 0 ? (
                                  module.video_lessons.map((video, vIndex) => (
                                    <li key={video.id} className="flex justify-between items-center">
                                      <div className="flex flex-col">
                                        <span>{video.title}</span>
                                        <span className="text-sm text-gray-600">{video.duration}</span>
                                      </div>
                                      {/* Optionally, you can add a link to the video */}
                                      <a href={video.video_url} className="text-blue-500 text-sm" target="_blank" rel="noopener noreferrer">
                                        Watch Video
                                      </a>
                                    </li>
                                  ))
                                ) : (
                                  <li>No video lessons available</li> // Display message if no video lessons are available
                                )}
                              </ul>
                            </AccordionContent>
                          </AccordionItem>
                        ))}
                      </Accordion>
                    </div>
                  </ScrollArea>
                </DialogContent>
              </Dialog>
              <div>
                    {/* Show "Continue" button if enrolled and have progress */}
                    {isEnrolled ? (
                        <Button onClick={handleContinue}>{lastCompletedModule ? "Continue" : "Start Course"}</Button>
                    ) : (
                        <Button onClick={handleEnroll} disabled={isEnrolled || isLoading}>
                            {isLoading ? "Enrolling..." : isEnrolled ? "Enrolled" : "Enroll Now"}
                        </Button>
                    )}
                </div>
            </CardFooter>
          </Card>
    );
}