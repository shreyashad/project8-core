"use client";
import Image from "next/image";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../ui/card";
import { Star } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../ui/dialog";
import { useState } from "react";
import { Button } from "../ui/button";
import { ScrollArea } from "../ui/scroll-area";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";
import axios from "axios"; // For making API requests

export default function CourseListCard({ course }) {
    const [selectedCourse, setSelectedCourse] = useState(null);
    const [isEnrolled, setIsEnrolled] = useState(false); // Track enrollment status

    // Function to handle course enrollment
    const handleEnroll = async () => {
        try {
            // Assuming you're using an API endpoint to handle course enrollment
            const response = await axios.post("/api/enroll", {
                course: course.id,
            });

            if (response.status === 201) {
                setIsEnrolled(true); // Mark as enrolled
            }
        } catch (error) {
            console.error("Error enrolling in course:", error);
            alert("Failed to enroll. Please try again later.");
        }
    };

    return (
        <Card key={course.id} className="flex flex-col">
            <CardHeader>
                <img src={course.cover_image} alt={course.title} className="w-full h-48 object-cover rounded-t-lg" />
            </CardHeader>
            <CardContent className="flex-grow">
                <CardTitle className="mb-2">{course.title}</CardTitle>
                <p className="text-sm text-gray-600 mb-2">{course.description}</p>
                <div className="flex items-center mb-2">
                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                    <span className="text-sm font-medium">{course.course_reviews.rating}</span>
                    <span className="text-sm text-gray-600 ml-2">({course.enrollment_count} enrolled)</span>
                </div>
            </CardContent>
            <CardFooter className="flex justify-between">
                <Dialog>
                    <DialogTrigger asChild>
                        <Button variant="outline" onClick={() => setSelectedCourse(course)}>View Details</Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-3xl">
                        <DialogHeader>
                            <DialogTitle>{course.title}</DialogTitle>
                        </DialogHeader>
                        <ScrollArea className="max-h-[60vh]">
                            <div className="space-y-4">
                                <img src={course.cover_image} alt={course.title} className="w-full h-64 object-cover rounded-lg" />
                                <p>{course.description}</p>
                                <div className="flex items-center">
                                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                                    <span className="font-medium">{course.course_reviews.rating}</span>
                                    <span className="text-gray-600 ml-2">({course.enrollment_count} enrolled)</span>
                                </div>

                                <Accordion type="single" collapsible className="w-full">
                                    {course.modules.map((module, index) => (
                                        <AccordionItem value={`module-${index}`} key={module.id}>
                                            <AccordionTrigger>{module.title}</AccordionTrigger>
                                            <AccordionContent>
                                                <p>{module.description}</p>
                                                {module.cover_image && <img src={module.cover_image} alt={module.title} className="w-full h-auto" />}

                                                <ul className="space-y-2 mt-4">
                                                    {module.video_lessons && module.video_lessons.length > 0 ? (
                                                        module.video_lessons.map((video, vIndex) => (
                                                            <li key={video.id} className="flex justify-between items-center">
                                                                <div className="flex flex-col">
                                                                    <span>{video.title}</span>
                                                                    <span className="text-sm text-gray-600">{video.duration}</span>
                                                                </div>
                                                                <a href={video.video_url} className="text-blue-500 text-sm" target="_blank" rel="noopener noreferrer">
                                                                    Watch Video
                                                                </a>
                                                            </li>
                                                        ))
                                                    ) : (
                                                        <li>No video lessons available</li>
                                                    )}
                                                </ul>
                                            </AccordionContent>
                                        </AccordionItem>
                                    ))}
                                </Accordion>
                            </div>
                        </ScrollArea>
                    </DialogContent>
                </Dialog>
                <Button onClick={handleEnroll} disabled={isEnrolled}>
                    {isEnrolled ? "Already Enrolled" : "Enroll Now"}
                </Button>
            </CardFooter>
        </Card>
    );
}
