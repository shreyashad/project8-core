"use client";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { CourseCategoryCellAction } from "./course-category-cell-action";



export const CourseCategoryColumns = [
    {
        id: "Select",
        header: ({ table }) => (
            <Checkbox
                checked={
                    table.getIsAllPageRowsSelected() ||
                    (table.getIsSomePageRowsSelected() && "indeterminate")
                }
                onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                aria-label="Select all"
                className="translate-y-[2px]"
            />
        ),

        cell: ({ row }) => (
            <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
            className="translate-y-[2px]"
          />
        ),
        enableSorting: false,
        enableHiding: false,
    },
    {
        accessorKey: "name",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Category Name"} />,

        cell: ({ row }) => {
          return <div className="flex items-center">{row.original.name }</div>;
      }
        
       
    
    },
    {
        accessorKey: "category_status",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Status"} />
    },
    {
        id: "actions",
        enableSorting: false,
        cell: ({ row }) => <CourseCategoryCellAction data={row.original} />,
    },
];