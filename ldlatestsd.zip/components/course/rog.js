"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CourseSchema } from "@/schema"; // Import the schema
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Button } from "../ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { useEffect } from "react";
import toast from "react-hot-toast";

export const CourseForm = ({ initialData }) => {
    const router = useRouter();
    const { data: session } = useSession();
    
    
    const form = useForm({
        resolver: zodResolver(CourseSchema),
        defaultValues: initialData || {
            title: "",
            description: "",
            coverImage: "",
            duration: "",
            difficulty_level: "",
            modules: [{ title: "", description: "", video_lessons: [{ title: "", video_url: "", duration: "" }] }],
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const { fields: moduleFields, append: appendModule, remove: removeModule } = useFieldArray({
        control: form.control,
        name: "modules",
    });

    const onSubmit = async (values) => {
        try {
            // API call to create or update the course
            if (initialData && initialData.id) {
                // Update logic
                await updateCourse(session.accessToken, initialData.id, values);
            } else {
                // Create logic
                await createCourse(session.accessToken, values);
            }
            toast.success("Course saved successfully");
            router.refresh();
        } catch (error) {
            toast.error(error.message);
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>{initialData && initialData.id ? "Edit Course" : "Create Course"}</CardTitle>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <FormField control={form.control} name="title">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Course Title</FormLabel>
                                    <FormControl>
                                        <Input {...field} placeholder="Enter course title" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="description">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Description</FormLabel>
                                    <FormControl>
                                        <Textarea {...field} placeholder="Course description" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="coverImage">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Cover Image URL</FormLabel>
                                    <FormControl>
                                        <Input {...field} placeholder="Enter image URL" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="duration">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Duration</FormLabel>
                                    <FormControl>
                                        <Input {...field} placeholder="Enter duration" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="difficulty_level">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Difficulty Level</FormLabel>
                                    <FormControl>
                                        <Input {...field} placeholder="Enter difficulty level" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <h3>Modules</h3>
                        {moduleFields.map((module, index) => (
                            <div key={module.id} className="border p-4 mb-4">
                                <FormField control={form.control} name={`modules.${index}.title`}>
                                    {({ field }) => (
                                        <FormItem>
                                            <FormLabel>Module Title</FormLabel>
                                            <FormControl>
                                                <Input {...field} placeholder="Enter module title" />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                </FormField>

                                <FormField control={form.control} name={`modules.${index}.description`}>
                                    {({ field }) => (
                                        <FormItem>
                                            <FormLabel>Module Description</FormLabel>
                                            <FormControl>
                                                <Textarea {...field} placeholder="Enter module description" />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                </FormField>

                                <h4>Video Lessons</h4>
                                {form.watch(`modules.${index}.video_lessons`).map((video, videoIndex) => (
                                    <div key={videoIndex} className="border p-2 mb-2">
                                        <FormField control={form.control} name={`modules.${index}.video_lessons.${videoIndex}.title`}>
                                            {({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Video Title</FormLabel>
                                                    <FormControl>
                                                        <Input {...field} placeholder="Enter video title" />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        </FormField>

                                        <FormField control={form.control} name={`modules.${index}.video_lessons.${videoIndex}.video_url`}>
                                            {({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Video URL</FormLabel>
                                                    <FormControl>
                                                        <Input {...field} placeholder="Enter video URL" />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        </FormField>

                                        <FormField control={form.control} name={`modules.${index}.video_lessons.${videoIndex}.duration`}>
                                            {({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Duration</FormLabel>
                                                    <FormControl>
                                                        <Input {...field} placeholder="Enter duration" />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        </FormField>

                                        <Button type="button" onClick={() => remove(videoIndex)}>
                                            Remove Video Lesson
                                        </Button>
                                    </div>
                                ))}
                                <Button type="button" onClick={() => appendVideo({ title: "", video_url: "", duration: "" })}>
                                    Add Video Lesson
                                </Button>
                                <Button type="button" onClick={() => removeModule(index)}>
                                    Remove Module
                                </Button>
                            </div>
                        ))}
                        <Button type="button" onClick={() => appendModule({ title: "", description: "", video_lessons: [] })}>
                            Add Module
                        </Button>

                        <Button type="submit">Save Course</Button>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};
---------------------
"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CourseSchema } from "@/schema"; // Import the course schema
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Button } from "../ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import toast from "react-hot-toast";

export const CourseForm = ({ initialData, categories }) => {
    const router = useRouter();
    const { data: session } = useSession();

    const form = useForm({
        resolver: zodResolver(CourseSchema),
        defaultValues: initialData || {
            title: "",
            description: "",
            category: "",
            cover_image: "",
            duration: "",
            difficulty_level: "",
            prerequisites: [],
            certification: "",
            learning_objectives: "",
            status: "active", // Default status
        },
    });

    const onSubmit = async (values) => {
        try {
            // API call to create or update the course
            if (initialData && initialData.id) {
                // Update logic
                await updateCourse(session.accessToken, initialData.id, values);
            } else {
                // Create logic
                await createCourse(session.accessToken, values);
            }
            toast.success("Course saved successfully");
            router.refresh();
        } catch (error) {
            toast.error(error.message);
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>{initialData && initialData.id ? "Edit Course" : "Create Course"}</CardTitle>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <FormField control={form.control} name="title">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Course Title</FormLabel>
                                    <FormControl>
                                        <Input {...field} placeholder="Enter course title" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="description">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Description</FormLabel>
                                    <FormControl>
                                        <Textarea {...field} placeholder="Course description" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="category">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Course Category</FormLabel>
                                    <FormControl>
                                        <Select {...field}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select category" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {categories.map((category) => (
                                                    <SelectItem key={category.id} value={category.id}>
                                                        {category.name}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="cover_image">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Cover Image URL</FormLabel>
                                    <FormControl>
                                        <Input {...field} placeholder="Enter image URL" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="duration">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Duration</FormLabel>
                                    <FormControl>
                                        <Input {...field} placeholder="Enter duration (e.g., 2h 30m)" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="difficulty_level">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Difficulty Level</FormLabel>
                                    <FormControl>
                                        <Input {...field} placeholder="Enter difficulty level" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="certification">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Certification</FormLabel>
                                    <FormControl>
                                        <Input {...field} placeholder="Enter certification details" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="learning_objectives">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Learning Objectives</FormLabel>
                                    <FormControl>
                                        <Textarea {...field} placeholder="List learning objectives" />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <FormField control={form.control} name="status">
                            {({ field }) => (
                                <FormItem>
                                    <FormLabel>Status</FormLabel>
                                    <FormControl>
                                        <Select {...field}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select status" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="active">Active</SelectItem>
                                                <SelectItem value="inactive">Inactive</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        </FormField>

                        <Button type="submit">
                            {initialData && initialData.id ? "Save Changes" : "Create Course"}
                        </Button>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};
