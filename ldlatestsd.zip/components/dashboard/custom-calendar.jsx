'use client'

import React, { useState } from 'react'
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react'
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, isToday } from 'date-fns'
import { Button } from "@/components/ui/button"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

export default function CustomCalendar({ events = [], onAddNote }) {
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState(null)
  const [noteText, setNoteText] = useState('')

  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1))
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1))

  const days = eachDayOfInterval({
    start: startOfMonth(currentMonth),
    end: endOfMonth(currentMonth)
  })

  const handleDateClick = (day) => {
    setSelectedDate(day)
    setNoteText('')
  }

  const handleAddNote = () => {
    if (selectedDate && noteText && onAddNote) {
      onAddNote(selectedDate, noteText)
      setNoteText('')
    }
  }

  return (
    <div className="w-full max-w-md mx-auto bg-background border rounded-lg shadow-lg">
      <div className="flex items-center justify-between p-4">
        <Button variant="outline" size="icon" onClick={prevMonth}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <h2 className="text-lg font-semibold">{format(currentMonth, 'MMMM yyyy')}</h2>
        <Button variant="outline" size="icon" onClick={nextMonth}>
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
      <div className="grid grid-cols-7 gap-1 p-4">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
          <div key={day} className="text-center font-medium text-muted-foreground">
            {day}
          </div>
        ))}
        {days.map((day) => {
          const dayEvents = events.filter(event => isSameDay(event.date, day))
          return (
            <Popover key={day.toString()}>
              <PopoverTrigger asChild>
                <Button
                  variant="ghost"
                  className={cn(
                    "h-10 w-10 p-0 font-normal",
                    !isSameMonth(day, currentMonth) && "text-muted-foreground opacity-50",
                    isSameDay(day, selectedDate) && "bg-primary text-primary-foreground",
                    isToday(day) && "border border-primary"
                  )}
                  onClick={() => handleDateClick(day)}
                >
                  <time dateTime={format(day, 'yyyy-MM-dd')}>{format(day, 'd')}</time>
                  {dayEvents.length > 0 && (
                    <span className="absolute bottom-1 right-1 h-1.5 w-1.5 rounded-full bg-primary"></span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80">
                <div className="space-y-2">
                  <h3 className="font-semibold">{format(day, 'MMMM d, yyyy')}</h3>
                  {dayEvents.map((event, index) => (
                    <div key={index} className="text-sm">
                      <CalendarIcon className="inline-block w-4 h-4 mr-1" />
                      {event.title}
                    </div>
                  ))}
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Add note"
                      value={noteText}
                      onChange={(e) => setNoteText(e.target.value)}
                    />
                    <Button onClick={handleAddNote}>Add</Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          )
        })}
      </div>
    </div>
  )
}
