import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";


export function StatsCard({ title, icon, value, description}) {
    return(
        <Card className="shadow-2xl rounded border">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                
                <CardTitle className="text-bold font-medium">
                    {title}
                </CardTitle>
                <div className="fs-4 1h-1 text-primary-dark">
                    {icon}
                </div>
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">
                    <h2 className="mb-0 me-2"></h2>{value}
                </div>
                <p className="text-xs text-muted-foreground">
                    {description}
                </p>
            </CardContent>
        </Card>
    );
};
{/* <div class="ms-2">
                    <div class="d-flex align-items-end">
                      <h2 class="mb-0 me-2">32</h2><span class="fs-7 fw-semibold text-body">Projects</span>
                    </div>
                    <p class="text-body-secondary fs-9 mb-0">Awating processing</p>
                  </div> */}