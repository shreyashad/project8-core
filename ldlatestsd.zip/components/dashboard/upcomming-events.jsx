'use client';

import React, { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CalendarIcon, MapPinIcon, ClockIcon } from 'lucide-react'

export default function UpcomingEventsCarousel({
  events,
  autoScrollInterval = 5000,
  cardWidth = 400
}) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const carouselRef = useRef(null)

  useEffect(() => {
    const interval = setInterval(() => {
      if (carouselRef.current) {
        const maxScroll = carouselRef.current.scrollWidth - carouselRef.current.clientWidth
        const newIndex = (currentIndex + 1) % events.length
        const newScrollPosition = newIndex * cardWidth

        if (newScrollPosition <= maxScroll) {
          carouselRef.current.scrollTo({
            left: newScrollPosition,
            behavior: 'smooth'
          })
          setCurrentIndex(newIndex)
        } else {
          carouselRef.current.scrollTo({
            left: 0,
            behavior: 'smooth'
          })
          setCurrentIndex(0)
        }
      }
    }, autoScrollInterval)

    return () => clearInterval(interval)
  }, [currentIndex, events.length, autoScrollInterval, cardWidth])

  return (
    <div className="w-full overflow-hidden bg-background p-4">
      <h2 className="text-2xl font-bold mb-4">Upcoming Events</h2>
      <div
        ref={carouselRef}
        className="flex space-x-4 h-64 overflow-x-hidden shadow-2xl "
        style={{ scrollSnapType: 'x mandatory' }}
      >
        {events.map((event) => (
          <Card
            key={event.id}
            className="flex-shrink-0 "
            style={{ width: `${cardWidth}px`, scrollSnapAlign: 'start' }}
          >
            <CardHeader className="bg-blue-500">
              <CardTitle className="text-white text-2xl font-bold">{event.title}</CardTitle>
            </CardHeader>
            <CardContent className="mt-8">
              <div className="flex items-center mb-2 ">
                <CalendarIcon className="mr-2 h-4 w-4" />
                <span>{event.date}</span>
              </div>
              <div className="flex items-center mb-2">
                <ClockIcon className="mr-2 h-4 w-4" />
                <span>{event.time}</span>
              </div>
              <div className="flex items-center">
                <MapPinIcon className="mr-2 h-4 w-4" />
                <span>{event.location}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
