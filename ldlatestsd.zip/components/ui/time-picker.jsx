import { Controller } from "react-hook-form";

const TimePicker = ({ name, control, label, required = false }) => {
  return (
    <div className="form-control">
      <label>{label}</label>
      <Controller
        name={name}
        control={control}
        render={({ field }) => (
          <input
            {...field}
            type="time"
            className="input"
            required={required}
            placeholder="HH:MM"
          />
        )}
      />
    </div>
  );
};

export default TimePicker;
