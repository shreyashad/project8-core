import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";

const { Button } = require("@/components/ui/button");
const { Card, CardHeader, CardContent, CardFooter } = require("@/components/ui/card");
const { FormItem, FormLabel, FormControl, FormMessage } = require("@/components/ui/form");
const { Input } = require("@/components/ui/input");
const { Controller } = require("react-hook-form");

const VideoForm = ({ index, moduleIndex, video, form, removeVideo, loading, initialData }) => {
    const [videoDuration, setVideoDuration] = useState(null);
    const [videoPreview, setVideoPreview] = useState(null);

    const handleVideoChange = (e, field) => {
        const file = e.target.files[0];
        if (file) {
            field.onChange(file);
            // Preview the video
            const videoUrl = URL.createObjectURL(file);
            setVideoPreview(videoUrl);

            // Calculate video duration using HTML5 Video
            const videoElement = document.createElement("video");
            videoElement.src = videoUrl;
            videoElement.onloadedmetadata = () => {
                const durationInSeconds = videoElement.duration;
                setVideoDuration(durationInSeconds);
                // Update form state with duration
                form.setValue(`modules[${moduleIndex}].videos[${index}].duration`, durationInSeconds);
            };
        }
    }
    
    return (
        <Card key={video.id} className="mb-4">
            <CardHeader>Video {index + 1}</CardHeader>
            <CardContent>
                <Controller 
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].title`}
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Video Title</FormLabel>
                            <FormControl>
                                <Input 
                                    {...field}
                                    placeholder="Video Title" 
                                    disabled={loading}
                                />
                            </FormControl>
                        </FormItem>
                    )}
                />
                <Controller 
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].video_url`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Video URL</FormLabel>
                            <FormControl>
                            <div className="flex items-center space-x-4">
                                    <Input 
                                        type="file"
                                        accept="video/*"
                                        disabled={loading}
                                        onChange={(e) => handleVideoChange(e, field)}
                                    />
                                    {videoPreview && (
                                    <div className="mt-2">
                                        <video controls width="250" height="auto">
                                            <source src={videoPreview} type="video/mp4" />
                                            Your browser does not support the video tag.
                                        </video>
                                    </div>
                                )}
                                    </div>
                            </FormControl>
                        </FormItem>
                    )}
                />
                <Controller 
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].cover_image`}
                    render={({field}) => (
                        <FormItem>
                                <FormLabel>Module Cover Image</FormLabel>
                                <FormControl>
                                    <div className="flex items-center space-x-4">
                                    <Input 
                                        type="file"
                                        accept="image/*"
                                        disabled={loading}
                                        onChange={(e) => field.onChange(e.target.files?.[0])}
                                    />
                                    {field.value ? (
                                        <img
                                        src={URL.createObjectURL(field.value)}
                                        alt="Video cover image"
                                        width={50}
                                        height={50}
                                        className="object-cover rounded"
                                        />
                                    ) : initialData?.cover_image ? (
                                        <Image
                                        src={initialData.cover_image}
                                        alt="Video cover image"
                                        width={50}
                                        height={50}
                                        className="object-cover rounded"
                                        />
                                    ) : null}
                                    </div>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                    )}
                />
                <Controller 
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].duration`}
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Video Duration</FormLabel>
                            <FormControl>
                                <Input 
                                    {...field}
                                    
                                    value={videoDuration ? `${Math.floor(videoDuration / 60)}:${Math.floor(videoDuration % 60)}` : ''}
                                    placeholder="Video Duration" 
                                    disabled={true}
                                />
                            </FormControl>
                        </FormItem>
                    )}
                />
                <Controller 
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].order`}
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Video Order</FormLabel>
                            <FormControl>
                                <Input 
                                    {...field}
                                    type="number"
                                    placeholder="Video Order" 
                                    disabled={loading}
                                />
                            </FormControl>
                        </FormItem>
                    )}
                />
                <Controller 
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].description`}
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Video Description</FormLabel>
                            <FormControl>
                                <Textarea 
                                    {...field} 
                                    placeholder="Video Description" 
                                    disabled={loading} 
                              />
                            </FormControl>
                        </FormItem>
                    )}
                />
                <Controller
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].status`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Status</FormLabel>
                            <FormControl>
                                <Select
                                    {...field}
                                    onValueChange={(value) => field.onChange(value)}
                                    
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a status" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Published">Published</SelectItem>
                                        <SelectItem value="Inactive">Inactive</SelectItem>
                                    </SelectContent>
                                </Select>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
            </CardContent>
            <CardFooter>
                <Button type="button" onClick={() => removeVideo(index)}>Remove Video</Button>
            </CardFooter>
                    
        </Card>
    );
};

export default VideoForm;