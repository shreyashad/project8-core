'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from 'next/link'
import ErrorMessage from '@/components/dashboard/error-message'


export default function CourseList({ initialCourses, initialCategories }) {
  const [courses, setCourses] = useState(initialCourses)
  const [categories] = useState(initialCategories)
  const [error, setError] = useState(null)

  const deleteCourse = async (courseId) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // Simulate a 10% chance of an error
      if (Math.random() < 0.1) {
        throw new Error('Failed to delete course')
      }

      setCourses(courses.filter(course => course.id !== courseId))
      setError(null)
    } catch (error) {
      setError(error.message)
    }
  }

  return (
    <>
      <Link href="/dashboard/trainers-admin/course-management/courses/new">
        <Button className="mb-6">Create New Course</Button>
      </Link>
      {error && <ErrorMessage message={error} />}
      {categories.map(category => (
        <div key={category} className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">{category}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses
              .filter(course => course.category === category)
              .map(course => (
                <Card key={course.id} className="flex flex-col">
                  <CardHeader>
                    <CardTitle>{course.title}</CardTitle>
                    <CardDescription>{course.difficulty_level} • {course.duration} minutes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p>Category: {course.category}</p>
                  </CardContent>
                  <CardFooter className="flex justify-between mt-auto">
                    <Link href={`/course/${course.id}`}>
                      <Button variant="outline">View</Button>
                    </Link>
                    <Link href={`/course/${course.id}/edit`}>
                      <Button variant="outline">Edit</Button>
                    </Link>
                    <Button variant="destructive" onClick={() => deleteCourse(course.id)}>Delete</Button>
                  </CardFooter>
                </Card>
              ))}
          </div>
        </div>
      ))}
    </>
  )
}

