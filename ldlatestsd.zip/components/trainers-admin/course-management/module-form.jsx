import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { FormControl, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import Image from "next/image";
import { Controller, useFieldArray } from "react-hook-form";
import VideoForm from "./video-form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";


const ModuleForm = ({ moduleIndex, module, form, removeModule, loading, initialData }) => {
    const { fields: videos, append: addVideo, remove: removeVideo } = useFieldArray({
        control: form.control,
        name: `modules[${moduleIndex}].videos`, // Dynamic name based on the module index
    });
    return(
        <Card key={module.id} className="mb-6">
            <CardHeader>
                <CardTitle>Module {moduleIndex + 1 } </CardTitle>
            </CardHeader>
            <CardContent>
                <Controller 
                     control={form.control} 
                     name={`modules[${moduleIndex}].title`}
                     render={({ field }) => (
                       <FormItem>
                         <FormLabel>Module Title</FormLabel>
                         <FormControl>
                           <Input 
                             {...field}
                             placeholder="Module Title"
                             disabled={loading}
                           />
                         </FormControl>
                       </FormItem>
                     )}
                />
                <div className="grid grid-cols-2 gap-8">
                    <Controller
                        control={form.control} 
                        name={`modules[${moduleIndex}].order`}
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>Module Order</FormLabel>
                            <FormControl>
                            <Input 
                                {...field}
                                type="number"
                                disabled={loading}
                            />
                            </FormControl>
                        </FormItem>
                        )}
                    />
                    <Controller
                        control={form.control} 
                        name={`modules[${moduleIndex}].status`}
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Module Status</FormLabel>
                            <FormControl>
                                <Select
                                    {...field}
                                    onValueChange={(value) => field.onChange(value)}
                                    
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a status" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Published">Published</SelectItem>
                                        <SelectItem value="Inactive">Inactive</SelectItem>
                                    </SelectContent>
                                </Select>
                            </FormControl>
                            </FormItem>
                        )}
                    />
                     
                </div>
                <Controller 
                        control={form.control}
                        name={`modules[${moduleIndex}].cover_image`}
                        render={({ field }) => (
                            
                            <FormItem>
                                <FormLabel>Module Cover Image</FormLabel>
                                <FormControl>
                                    <div className="flex items-center space-x-4">
                                    <Input 
                                        type="file"
                                        accept="image/*"
                                        disabled={loading}
                                        onChange={(e) => field.onChange(e.target.files?.[0])}
                                    />
                                    {field.value ? (
                                        <Image
                                        src={URL.createObjectURL(field.value)}
                                        alt="Module cover image"
                                        width={50}
                                        height={50}
                                        className="object-cover rounded"
                                        />
                                    ) : initialData?.image ? (
                                        <Image
                                        src={initialData.image}
                                        alt="Module cover image"
                                        width={50}
                                        height={50}
                                        className="object-cover rounded"
                                        />
                                    ) : null}
                                    </div>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                     />
                     <Controller 
                        control={form.control}
                        name={`modules[${moduleIndex}].description`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Module Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                {...field} 
                                placeholder="Module Description" 
                                disabled={loading} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                     />
                     <Separator />
                     <h4 className="text-lg mt-4">Videos</h4>
                    <div>
                        {videos.map((video, videoIndex) => (
                            <VideoForm
                                key={video.id}
                                index={videoIndex}
                                moduleIndex={moduleIndex}
                                video={video}
                                form={form}
                                removeVideo={removeVideo}
                                loading={loading}
                                initialData={initialData}
                            />
                        ))}
                        <Button type="button" onClick={() => addVideo({})}>Add Video</Button>
                    </div>
            </CardContent>
            <CardFooter>
            <Button type="button" onClick={() => removeModule(moduleIndex)} variant="destructive">Remove Module</Button>
            </CardFooter>
        </Card>
    );
};

export default ModuleForm;