"use client";
import { createNewCourse, updateCourseDetails } from "@/app/api/server/route";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { CourseSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSession } from "next-auth/react";
import Image from "next/image";
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react";
import { useFieldArray, useForm } from "react-hook-form";
import ModuleForm from "./module-form";


export const CourseForm = ({ initialData, categoryList, difficultyList, certificateList  }) => {
  const router = useRouter();
  const { data: session } = useSession();
  const [loading, setLoading] = useState(false);
  const form = useForm({
    resolver: zodResolver(CourseSchema),
    defaultValues: initialData || {
      title: "",
      description: "",
      category:"",
      cover_image: "",
      duration:"",
      difficulty_level:"",
      prerequisites:"",
      has_certificate: false, 
      certification: "",
      learning_objectives: "",
      status: "Inactive",
      modules:[],
    },
  });
  const { formState: { errors } } = form;
  console.log(errors);

  const { fields: modules, append: addModule, remove: removeModule } = useFieldArray({
    control: form.control,
    name: "modules",
  });

  
  const hasCertificate = form.watch("has_certificate");

  const calculateTotalDuration = () => {
    let totalDurationInSeconds = 0;
  
    // Iterate over all modules and their videos
    modules.forEach((module) => {
      if (Array.isArray(module.videos)) {
        module.videos.forEach((video) => {
          if (video.duration) {
            totalDurationInSeconds += video.duration; // Summing the durations in seconds
          }
        });
      }
    });
  
    return totalDurationInSeconds;
  };
  
  const formatDuration = (durationInSeconds) => {
    const totalMinutes = Math.floor(durationInSeconds / 60); // Convert to minutes
    const hours = Math.floor(totalMinutes / 60); // Calculate the number of hours
    const minutes = totalMinutes % 60; // Get the remaining minutes
  
    if (hours > 0) {
      return `${hours} hour${hours > 1 ? 's' : ''} ${minutes} minute${minutes !== 1 ? 's' : ''}`;
    } else {
      return `${minutes} minute${minutes !== 1 ? 's' : ''}`;
    }
  };
  
  const [totalDurationInSeconds, setTotalDurationInSeconds] = useState(0);
  
  useEffect(() => {
    const durationInSeconds = calculateTotalDuration(); // Calculate total duration in seconds
    setTotalDurationInSeconds(durationInSeconds);
  }, [modules]);
  
  useEffect(() => {
    const formattedDuration = formatDuration(totalDurationInSeconds); // Format the duration for display
    console.log("Formatted Duration:", formattedDuration);
  }, [totalDurationInSeconds]);
  


  useEffect(() => {
    form.reset(initialData);
  }, [initialData, form]);

  const handleSubmit = async (values) => {
    try {
        // API call to create or update the course
        if (initialData && initialData.id) {
            // Update logic
            await updateCourseDetails(session.accessToken, initialData.id, values);
        } else {
            // Create logic
            await createNewCourse(session.accessToken, values);

        }
        toast.success("Course saved successfully");
        router.refresh();
    } catch (error) {
        toast.error(error.message);
    }
  };


  return(
    <Form {...form} >
     <form onSubmit={form.handleSubmit(handleSubmit)}>
        <div className="flex flex-col-8 px-4">
        <Card >
          <CardHeader>
            <CardTitle>{initialData && initialData.id ? "Edit Course" : "Create Course"}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-8">
                <FormField 
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter Course title"
                          {...field}
                          disabled={loading}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Course Status</FormLabel>
                            <FormControl>
                                <Select
                                    {...field}
                                    onValueChange={(value) => field.onChange(value)}
                                    
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a status" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Published">Published</SelectItem>
                                        <SelectItem value="Inactive">Inactive</SelectItem>
                                    </SelectContent>
                                </Select>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="cover_image"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Cover Image</FormLabel>
                            <FormControl>
                                <div className="flex items-center space-x-4">
                                    <Input
                                        type="file"
                                        accept="image/*"
                                        disabled={loading}
                                        onChange={(e) => {
                                            field.onChange(e.target.files?.[0]);
                                        }}
                                    />
                                    {field.value ? (
                                        field.value instanceof File ? (
                                            <Image
                                                src={URL.createObjectURL(field.value)}
                                                alt="Course cover image preview"
                                                width={50}
                                                height={50}
                                                className="object-cover rounded"
                                            />
                                        ) : (
                                            <Image
                                                src={field.value} // assuming field.value is a URL string when editing
                                                alt="Course icon preview"
                                                width={50}
                                                height={50}
                                                className="object-cover rounded"
                                            />
                                        )
                                    ) : initialData?.image ? ( // check if there's an existing image URL in initialData
                                        <Image
                                            src={initialData.image} // use the existing image URL
                                            alt="Category icon preview"
                                            width={50}
                                            height={50}
                                            className="object-cover rounded"
                                        />
                                    ) : null}
                                </div>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <FormControl>
                        <Select
                          disabled={loading || !categoryList.length}
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <SelectTrigger>
                            <SelectValue
                              placeholder={
                                categoryList.length > 0
                                  ? "Course Category "
                                  : "No Category available"
                              }
                            />
                          </SelectTrigger>
                          <SelectContent>
                            { categoryList.length > 0 ? (
                              categoryList.map((cate) => (
                                <SelectItem key={cate.id} value={cate.id}>
                                  {cate.name}
                                </SelectItem>
                              ))
                            ) : (
                              <SelectItem disabled>
                                No Category found
                              </SelectItem>
                            )}
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="difficulty_level"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Difficulty Level</FormLabel>
                      <FormControl>
                        <Select
                          disabled={loading || !difficultyList.length}
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <SelectTrigger>
                            <SelectValue
                              placeholder={
                                difficultyList.length > 0
                                  ? "Course Level "
                                  : "No Category Level available"
                              }
                            />
                          </SelectTrigger>
                          <SelectContent>
                            { difficultyList.length > 0 ? (
                              difficultyList.map((cate) => (
                                <SelectItem key={cate.id} value={cate.id}>
                                  {cate.name}
                                </SelectItem>
                              ))
                            ) : (
                              <SelectItem disabled>
                                No Data found
                              </SelectItem>
                            )}
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField 
                  control={form.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                            <FormLabel>Total Duration</FormLabel>
                            <FormControl>
                            <Input
                                {...field}
                                value={formatDuration(totalDurationInSeconds)} // Display the formatted duration
                                disabled={true}
                              />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                  )}
                />
                <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                                <Textarea
                                    {...field}
                                    placeholder="Course Description"
                                />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="prerequisites"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Pre-Requisites</FormLabel>
                            <FormControl>
                                <Textarea
                                    {...field}
                                    placeholder="Course Pre-Requisites"
                                />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="learning_objectives"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Learning Objectives</FormLabel>
                            <FormControl>
                                <Textarea
                                    {...field}
                                    placeholder="Learning Objectives"
                                />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="has_certificate"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Certificate</FormLabel>
                            <FormControl>
                                <Switch
                                    {...field}
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                    
                                />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                {hasCertificate && (
                  <FormField 
                    control={form.control}
                    name="has_certificate"
                    render={({ field }) => (
                      <FormItem>
                         <FormLabel>Certificate</FormLabel>
                        <FormControl>
                        <Select
                          disabled={loading || !certificateList.length}
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <SelectTrigger>
                            <SelectValue
                              placeholder={
                                certificateList.length > 0
                                  ? "Certificate  "
                                  : "No Certificate available"
                              }
                            />
                          </SelectTrigger>
                          <SelectContent>
                            { certificateList.length > 0 ? (
                              certificateList.map((cate) => (
                                <SelectItem key={cate.id} value={cate.id}>
                                  {cate.name}
                                </SelectItem>
                              ))
                            ) : (
                              <SelectItem disabled>
                                No certificate found
                              </SelectItem>
                            )}
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </div>
              <div>
                <h3 className="text-xl font-bold">Modules</h3>
                {modules.map((module, moduleIndex) => (
                  <ModuleForm
                    key={module.id}
                    moduleIndex={moduleIndex}
                    module={module}
                    form={form}
                    removeModule={removeModule}
                    loading={false} // Add a loading state if needed
                    initialData={initialData}
                  />
                ))}
                <Button type="button" onClick={() => addModule({})}>Add Module</Button>
              </div>
             
          </CardContent>
        </Card>
        </div>
        <Button type="submit" disabled={loading}>Submit</Button>
          {Object.keys(errors).length > 0 && <div className="text-red-500">Please fix the errors above.</div>}
      </form>
    </Form>
  );
};

