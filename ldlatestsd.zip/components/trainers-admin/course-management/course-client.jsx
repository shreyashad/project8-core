"use client";
import { useRouter } from "next/navigation";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

const CourseClient = () => {
    const router = useRouter();
    return(
        <Button onClick={() => {
            router.push("/dashboard/trainers-admin/course-management/courses/new");
        }}>
            <Plus className="mr-2 h-4 w-4" /> Add New
        </Button>
    );
};

export default CourseClient;