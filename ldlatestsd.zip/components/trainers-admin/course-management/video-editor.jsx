"use client";
import { useRef, useState } from "react";
import VideoCanvas from "./video-canvas";
import { exportVideo, trimVideo } from "@/lib/FFmpeg";

const VideoEditor = () => {
  const [videoSrc, setVideoSrc] = useState(null);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(10);
  const [canvas, setCanvas] = useState(null);
  const videoInputRef = useRef(null);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const videoURL = URL.createObjectURL(file);
      setVideoSrc(videoURL);
    }
  };

  const handleTrim = async () => {
    if (videoSrc) {
      const trimmedVideo = await trimVideo(videoSrc, trimStart, trimEnd);
      setVideoSrc(trimmedVideo);
    }
  };

  const handleExport = async () => {
    if (videoSrc) {
      const exportedVideo = await exportVideo(videoSrc);
      const link = document.createElement('a');
      link.href = exportedVideo;
      link.download = 'edited-video.mp4';
      link.click();
    }
  };

  const handleAddText = () => {
    if (canvas) {
      const text = new fabric.Text('Sample Text', { left: 50, top: 50 });
      canvas.add(text);
      canvas.renderAll();
    }
  };

  return (
    <div>
      <h1>Video Editor</h1>

      <input type="file" ref={videoInputRef} onChange={handleFileChange} accept="video/*" />
      
      {videoSrc && <VideoPlayer videoSrc={videoSrc} />}
      
      <div>
        <button onClick={handleTrim}>Trim Video</button>
        <button onClick={handleExport}>Export Video</button>
        <button onClick={handleAddText}>Add Text Overlay</button>
      </div>

      <VideoCanvas videoSrc={videoSrc} onUpdateCanvas={setCanvas} />
      
      <div>
        <input
          type="number"
          value={trimStart}
          onChange={(e) => setTrimStart(Number(e.target.value))}
          placeholder="Start Time"
        />
        <input
          type="number"
          value={trimEnd}
          onChange={(e) => setTrimEnd(Number(e.target.value))}
          placeholder="End Time"
        />
      </div>
    </div>
  );
};

export default VideoEditor;
