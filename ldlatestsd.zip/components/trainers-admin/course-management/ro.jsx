import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { useState } from 'react';

const CourseForm = ({ initialData = {} }) => {
    const { control, handleSubmit, setValue, watch, register, formState: { errors } } = useForm({
        defaultValues: initialData
    });

    const { fields: modules, append: appendModule, remove: removeModule } = useFieldArray({
        control,
        name: 'modules', // Modules field in the form state
    });

    // Handle form submission
    const onSubmit = (data) => {
        console.log('Form data:', data);
    };

    // Watching for changes in the form (optional for debugging)
    const watchFields = watch(); 

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <h2>Course Form</h2>

            {/* Course Title */}
            <div>
                <label>Course Title</label>
                <Controller
                    control={control}
                    name="title"
                    rules={{ required: "Course title is required" }}
                    render={({ field }) => (
                        <input {...field} placeholder="Course Title" />
                    )}
                />
                {errors.title && <p>{errors.title.message}</p>}
            </div>

            {/* Course Description */}
            <div>
                <label>Course Description</label>
                <Controller
                    control={control}
                    name="description"
                    render={({ field }) => (
                        <textarea {...field} placeholder="Course Description" />
                    )}
                />
            </div>

            {/* Modules Section */}
            <div>
                <h3>Modules</h3>
                {modules.map((module, moduleIndex) => (
                    <div key={module.id}>
                        <h4>Module {moduleIndex + 1}</h4>
                        
                        {/* Module Title */}
                        <div>
                            <label>Module Title</label>
                            <Controller
                                control={control}
                                name={`modules.${moduleIndex}.title`}
                                rules={{ required: "Module title is required" }}
                                render={({ field }) => (
                                    <input {...field} placeholder="Module Title" />
                                )}
                            />
                            {errors.modules?.[moduleIndex]?.title && <p>{errors.modules[moduleIndex].title.message}</p>}
                        </div>

                        {/* Video Fields */}
                        {module.videos?.map((video, videoIndex) => (
                            <div key={video.id}>
                                <h5>Video {videoIndex + 1}</h5>

                                {/* Video Title */}
                                <div>
                                    <label>Video Title</label>
                                    <Controller
                                        control={control}
                                        name={`modules.${moduleIndex}.videos.${videoIndex}.title`}
                                        render={({ field }) => (
                                            <input {...field} placeholder="Video Title" />
                                        )}
                                    />
                                </div>

                                {/* Video Order */}
                                <div>
                                    <label>Video Order</label>
                                    <Controller
                                        control={control}
                                        name={`modules.${moduleIndex}.videos.${videoIndex}.order`}
                                        render={({ field }) => (
                                            <input {...field} type="number" placeholder="Video Order" />
                                        )}
                                    />
                                </div>

                                {/* Remove Video Button */}
                                <button
                                    type="button"
                                    onClick={() =>
                                        remove(moduleIndex, videoIndex) // Removes specific video from module
                                    }
                                >
                                    Remove Video
                                </button>
                            </div>
                        ))}

                        {/* Add Video Button */}
                        <button
                            type="button"
                            onClick={() =>
                                setValue(`modules.${moduleIndex}.videos`, [
                                    ...module.videos,
                                    { title: '', order: module.videos.length + 1 } // New video default values
                                ])
                            }
                        >
                            Add Video
                        </button>

                        {/* Remove Module Button */}
                        <button
                            type="button"
                            onClick={() => removeModule(moduleIndex)} // Removes entire module
                        >
                            Remove Module
                        </button>
                    </div>
                ))}

                {/* Add Module Button */}
                <button
                    type="button"
                    onClick={() =>
                        appendModule({
                            title: '',
                            videos: [{ title: '', order: 1 }]
                        })
                    }
                >
                    Add Module
                </button>
            </div>

            {/* Submit Button */}
            <div>
                <button type="submit">Submit</button>
            </div>
        </form>
    );
};

export default CourseForm;
