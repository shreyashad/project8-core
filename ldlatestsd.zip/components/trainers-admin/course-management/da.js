import React from 'react';
import { Controller } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, Input, FormMessage } from './FormComponents'; // Import your custom components
import { Button, Card, CardContent, CardFooter, CardHeader } from './CardComponents'; // Import your card components

const VideoForm = ({ index, moduleIndex, video, form, removeVideo, loading }) => {
  return (
    <Card key={video.id} className="mb-4">
      <CardHeader>Video {index + 1}</CardHeader>
      <CardContent>
        <Controller
          control={form.control}
          name={`modules[${moduleIndex}].videos[${index}].title`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Video Title</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Video Title" disabled={loading} />
              </FormControl>
            </FormItem>
          )}
        />
      </CardContent>
      <CardFooter>
        <Button type="button" onClick={() => removeVideo(index)}>Remove Video</Button>
      </CardFooter>
    </Card>
  );
};

export default VideoForm;
import React from 'react';
import { Controller } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, Input, Textarea, FormMessage } from './FormComponents'; // Import your custom components
import { Button, Card, CardContent, CardFooter, CardHeader, CardTitle } from './CardComponents'; // Import your card components

const ModuleForm = ({ index, module, form, removeModule, addVideo, removeVideo, loading, initialData }) => {
  return (
    <Card key={module.id} className="mb-6">
      <CardHeader>
        <CardTitle>Module {index + 1}</CardTitle>
      </CardHeader>
      <CardContent>
        {/* Module Title */}
        <Controller
          control={form.control}
          name={`modules[${index}].title`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Module Title</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Module Title" disabled={loading} />
              </FormControl>
            </FormItem>
          )}
        />

        {/* Module Order */}
        <div className="grid grid-cols-2 gap-8">
          <Controller
            control={form.control}
            name={`modules[${index}].order`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>Module Order</FormLabel>
                <FormControl>
                  <Input {...field} type="number" disabled={loading} />
                </FormControl>
              </FormItem>
            )}
          />

          {/* Module Status */}
          <Controller
            control={form.control}
            name={`modules[${index}].status`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>Module Status</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="Module Status" disabled={loading} />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        {/* Module Cover Image */}
        <Controller
          control={form.control}
          name={`modules[${index}].cover_image`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Module Cover Image</FormLabel>
              <FormControl>
                <div className="flex items-center space-x-4">
                  <Input
                    type="file"
                    accept="image/*"
                    disabled={loading}
                    onChange={(e) => field.onChange(e.target.files?.[0])}
                  />
                  {field.value ? (
                    <img
                      src={URL.createObjectURL(field.value)}
                      alt="Module cover image"
                      width={50}
                      height={50}
                      className="object-cover rounded"
                    />
                  ) : initialData?.image ? (
                    <img
                      src={initialData.image}
                      alt="Module cover image"
                      width={50}
                      height={50}
                      className="object-cover rounded"
                    />
                  ) : null}
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Module Description */}
        <Controller
          control={form.control}
          name={`modules[${index}].description`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Module Description</FormLabel>
              <FormControl>
                <Textarea {...field} placeholder="Module Description" disabled={loading} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Video Section */}
        <h4 className="text-lg mt-4">Videos</h4>
        <div>
          {module.videos && module.videos.map((video, videoIndex) => (
            <VideoForm
              key={video.id}
              index={videoIndex}
              moduleIndex={index}
              video={video}
              form={form}
              removeVideo={removeVideo}
              loading={loading}
            />
          ))}
          <Button type="button" onClick={() => addVideo({})}>Add Video</Button>
        </div>

        <Button type="button" onClick={() => removeModule(index)} variant="destructive">Remove Module</Button>
      </CardContent>
    </Card>
  );
};

export default ModuleForm;
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Controller } from "react-hook-form";
import Image from "next/image";
import { useState } from "react";

const VideoForm = ({ index, moduleIndex, video, form, removeVideo, loading, initialData }) => {
    // Local state to handle video preview and duration
    const [videoDuration, setVideoDuration] = useState(null);
    const [videoPreview, setVideoPreview] = useState(null);

    // Handle video file change for URL and duration calculation
    const handleVideoChange = (e, field) => {
        const file = e.target.files[0];
        if (file) {
            field.onChange(file);
            // Preview the video
            const videoUrl = URL.createObjectURL(file);
            setVideoPreview(videoUrl);

            // Calculate video duration using HTML5 Video
            const videoElement = document.createElement("video");
            videoElement.src = videoUrl;
            videoElement.onloadedmetadata = () => {
                const durationInSeconds = videoElement.duration;
                setVideoDuration(durationInSeconds);
                // Update form state with duration
                form.setValue(`modules[${moduleIndex}].videos[${index}].duration`, durationInSeconds);
            };
        }
    };

    return (
        <Card key={video.id} className="mb-4">
            <CardHeader>Video {index + 1}</CardHeader>
            <CardContent>
                <Controller
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].title`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Video Title</FormLabel>
                            <FormControl>
                                <Input {...field} placeholder="Video Title" disabled={loading} />
                            </FormControl>
                        </FormItem>
                    )}
                />

                <Controller
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].video_url`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Video File</FormLabel>
                            <FormControl>
                                <Input
                                    type="file"
                                    accept="video/*"
                                    disabled={loading}
                                    onChange={(e) => handleVideoChange(e, field)}
                                />
                                {videoPreview && (
                                    <div className="mt-2">
                                        <video controls width="250" height="auto">
                                            <source src={videoPreview} type="video/mp4" />
                                            Your browser does not support the video tag.
                                        </video>
                                    </div>
                                )}
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />

                <Controller
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].cover_image`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Video Cover Image</FormLabel>
                            <FormControl>
                                <div className="flex items-center space-x-4">
                                    <Input
                                        type="file"
                                        accept="image/*"
                                        disabled={loading}
                                        onChange={(e) => field.onChange(e.target.files?.[0])}
                                    />
                                    {field.value ? (
                                        <Image
                                            src={URL.createObjectURL(field.value)}
                                            alt="Video cover image"
                                            width={50}
                                            height={50}
                                            className="object-cover rounded"
                                        />
                                    ) : initialData?.cover_image ? (
                                        <Image
                                            src={initialData.cover_image}
                                            alt="Video cover image"
                                            width={50}
                                            height={50}
                                            className="object-cover rounded"
                                        />
                                    ) : null}
                                </div>
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />

                <Controller
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].duration`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Video Duration</FormLabel>
                            <FormControl>
                                <Input
                                    {...field}
                                    value={videoDuration ? `${Math.floor(videoDuration / 60)}:${Math.floor(videoDuration % 60)}` : ''}
                                    placeholder="Video Duration"
                                    disabled={true} // Duration is calculated automatically
                                />
                            </FormControl>
                        </FormItem>
                    )}
                />

                <Controller
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].order`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Video Order</FormLabel>
                            <FormControl>
                                <Input {...field} placeholder="Video Order" disabled={loading} />
                            </FormControl>
                        </FormItem>
                    )}
                />

                <Controller
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].description`}
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Video Description</FormLabel>
                            <FormControl>
                                <Textarea {...field} placeholder="Video Description" disabled={loading} />
                            </FormControl>
                        </FormItem>
                    )}
                />
            </CardContent>

            <CardFooter>
                <Button type="button" onClick={() => removeVideo(index)}>
                    Remove Video
                </Button>
            </CardFooter>
        </Card>
    );
};

export default VideoForm;
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Controller, useForm, useFieldArray } from "react-hook-form";
import ModuleForm from "./ModuleForm"; // Import the ModuleForm

const CourseForm = ({ initialData }) => {
  const { control, handleSubmit, setValue, getValues } = useForm({
    defaultValues: initialData,
  });

  // For modules
  const { fields: modules, append: addModule, remove: removeModule } = useFieldArray({
    control,
    name: "modules",
  });

  // Function to calculate the total duration of all videos
  const calculateTotalDuration = () => {
    let totalDuration = 0;
    // Iterate over modules and their videos to calculate total duration
    modules.forEach((module) => {
      module.videos.forEach((video) => {
        if (video.duration) {
          totalDuration += video.duration;
        }
      });
    });
    return totalDuration;
  };

  // State to hold the total duration of the course
  const [totalDuration, setTotalDuration] = useState(0);

  // Recalculate total duration whenever the form values change
  useEffect(() => {
    const duration = calculateTotalDuration();
    setTotalDuration(duration);
  }, [modules]);

  const onSubmit = (data) => {
    // Handle form submission
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Card>
        <CardHeader>
          <h2>Course Form</h2>
        </CardHeader>
        <CardContent>
          {/* Render the modules form */}
          {modules.map((module, moduleIndex) => (
            <ModuleForm
              key={module.id}
              moduleIndex={moduleIndex}
              module={module}
              form={{ control, setValue, getValues }}
              removeModule={removeModule}
              loading={false}
            />
          ))}
          <Button type="button" onClick={() => addModule({})}>Add Module</Button>
          
          <div className="mt-4">
            <h3>Total Course Duration: {totalDuration ? `${Math.floor(totalDuration / 60)}:${Math.floor(totalDuration % 60)}` : "0:00"}</h3>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit">Save Course</Button>
        </CardFooter>
      </Card>
    </form>
  );
};

export default CourseForm;
import { fetchCourseListData } from '@/app/api/server/route'
import { auth } from '@/auth'
import { DashboardBreadCrumb } from '@/components/dashboard/dashboard-breadcrumb'
import ErrorMessage from '@/components/dashboard/error-message'
import LoadingSpinner from '@/components/dashboard/loadining-spinner'
import CourseList from '@/components/trainers-admin/course-management/course-list'
import { Suspense } from 'react'


// // Mock function to fetch courses (replace with actual API call in a real app)
// async function fetchCourses() {
//   // Simulate API delay and potential error
//   await new Promise(resolve => setTimeout(resolve, 1000))
  
//   // Simulate a 10% chance of an error
//   if (Math.random() < 0.1) {
//     throw new Error('Failed to fetch courses')
//   }

//   return [
//     { id: 1, title: 'Introduction to React', category: 'Web Development', difficulty_level: 'Beginner', duration: 120 },
//     { id: 2, title: 'Advanced JavaScript', category: 'Web Development', difficulty_level: 'Advanced', duration: 180 },
//     { id: 3, title: 'Python for Data Science', category: 'Data Science', difficulty_level: 'Intermediate', duration: 150 },
//     { id: 4, title: 'Machine Learning Basics', category: 'Data Science', difficulty_level: 'Beginner', duration: 200 },
//     { id: 5, title: 'Mobile App Development with React Native', category: 'Mobile Development', difficulty_level: 'Intermediate', duration: 160 },
//   ]
// }

async function CourseListWrapper() {
  const session = auth();
  try {
    const courses = await fetchCourseListData(session.accessToken);
    console.log("course data:", courses);
    const categories = [...new Set(courses?.map(course => course.category))]
    return <CourseList initialCourses={courses} initialCategories={categories} />
  } catch (error) {
    return <ErrorMessage message={error.message} />
  }
}

export default async function CoursePage() {
  

  return (
    <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
    {/* Fixed breadcrumb */}
    <div className="fixed w-full shadow-2xl p-4 z-10 ">
        <DashboardBreadCrumb 
            homelink="/dashboard/trainers-admin/" 
            hometitle="Home" 
            mdipagelink="/dashboard/trainers-admin/course-management/Course" 
            mdipagetitle="Course Management" 
            pagetitle="Course "
        />
    </div>

    {/* Spacer to prevent content from being hidden behind the fixed breadcrumb */}
    <div className="mt-16" /> 

      <h1 className="text-3xl font-bold mb-8">Courses</h1>
      <Suspense fallback={<LoadingSpinner />}>
        <CourseListWrapper />
      </Suspense>
    </div>
  )
}

