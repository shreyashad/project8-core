"use client";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { TodaysWisdomCellAction } from "./wisdom-actions";



export const TodaysWisdomColumns = [
    {
        id: "Select",
        header: ({ table }) => (
            <Checkbox
                checked={
                    table.getIsAllPageRowsSelected() ||
                    (table.getIsSomePageRowsSelected() && "indeterminate")
                }
                onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                aria-label="Select all"
                className="translate-y-[2px]"
            />
        ),

        cell: ({ row }) => (
            <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
            className="translate-y-[2px]"
          />
        ),
        enableSorting: false,
        enableHiding: false,
    },
    {
        accessorKey: "topic",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Topic"} />,

        cell: ({ row }) => {
          return  <div
          className="flex items-center"
          dangerouslySetInnerHTML={{ __html: row.original.topic }}
      />;
          
      }
        
       
    
    },
    
    {
        id: "actions",
        enableSorting: false,
        cell: ({ row }) => <TodaysWisdomCellAction data={row.original} />,
    },
];