"use client";

import { createNewTodaysWisdom, deleteTodaysWisdomDetails, updateTodaysWisdomDetails } from "@/app/api/server/route";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Form, FormField, FormControl, FormItem, FormLabel } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { TodaysWisdomSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash2 } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import dynamic from "next/dynamic";
import "react-quill/dist/quill.snow.css"; // Import Quill's styles

// Dynamically load ReactQuill to support Next.js SSR
const ReactQuill = dynamic(() => import("react-quill"), { ssr: false });

export const TodaysWisdomForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);

    const title = initialData && initialData.id ? "Edit Today's Wisdom" : "Create Today's Wisdom";
    const description = initialData && initialData.id ? "Edit the Today's Wisdom" : "Create a new Today's Wisdom";
    const action = initialData && initialData.id ? "Save Changes" : "Create";
    const toastMessage = initialData && initialData.id ? "Today's Wisdom updated successfully" : "Today's Wisdom created successfully";

    const form = useForm({
        resolver: zodResolver(TodaysWisdomSchema),
        defaultValues: initialData || {
            topic: "",
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData && initialData.id) {
                await updateTodaysWisdomDetails(session.accessToken, initialData.id, values);
                router.refresh();
            } else {
                await createNewTodaysWisdom(session.accessToken, values);
                router.refresh();
            }
            toast.success(toastMessage);
            router.push("/dashboard/trainers-admin/todays-wisdom");
            router.refresh();
        } catch (error) {
            toast.error(error.message);
        }
        setLoading(false);
    };

    const onDelete = async () => {
        try {
            await deleteTodaysWisdomDetails(session.accessToken, initialData.id);
            router.refresh();
        } catch (error) {
            toast.error(error.message);
        }
    };

    return (
        <>
            <Card className="w-full max-w-2xl">
                <CardHeader>
                    <CardTitle> {title}</CardTitle>
                    <CardDescription>{description}</CardDescription>
                    <div className="flex items-center justify-between">
                        {initialData && initialData.id && (
                            <Button
                                variant="destructive"
                                onClick={onDelete}
                                disabled={loading}
                            >
                                <Trash2 className="h-4 w-4" /> Delete
                            </Button>
                        )}
                    </div>
                </CardHeader>
                <CardContent className="space-y-6">
                    <Separator />
                    <Form {...form}>
                        <form
                            onSubmit={form.handleSubmit(onSubmit)}
                            className="w-full space-y-8"
                        >
                            <FormField
                                control={form.control}
                                name="topic"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Topic</FormLabel>
                                        <FormControl>
                                            <ReactQuill
                                                {...field}
                                                value={field.value}
                                                onChange={field.onChange}
                                                placeholder="Enter today's wisdom..."
                                                modules={{
                                                    toolbar: [
                                                        ["bold", "italic", "underline", "strike"],
                                                        [{ list: "ordered" }, { list: "bullet" }],
                                                        ["link","image"],
                                                        [{ 'header': 1 }, { 'header': 2 }], 
                                                    ],
                                                }}
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <div className="space-x-4">
                                <Button disabled={loading} className="ml-auto" type="submit">
                                    {action}
                                </Button>
                                <Button
                                    disabled={loading}
                                    className="ml-auto"
                                    type="button"
                                    onClick={() => {
                                        router.back();
                                    }}
                                >
                                    Cancel
                                </Button>
                            </div>
                        </form>
                    </Form>
                </CardContent>
            </Card>
            {initialData && initialData.id && (
                <AlertModal
                    title="Are you Sure"
                    description="This action cannot be undone."
                    name={initialData?.name}
                    isOpen={open}
                    onClose={() => setOpen(false)}
                    onConfirm={onDelete}
                    loading={loading}
                />
            )}
        </>
    );
};
