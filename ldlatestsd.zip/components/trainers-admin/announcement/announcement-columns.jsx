"use client";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { AnnouncementCellAction } from "./announcement-cell-action";



export const AnnouncementColumns = [
    {
        id: "Select",
        header: ({ table }) => (
            <Checkbox
                checked={
                    table.getIsAllPageRowsSelected() ||
                    (table.getIsSomePageRowsSelected() && "indeterminate")
                }
                onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                aria-label="Select all"
                className="translate-y-[2px]"
            />
        ),

        cell: ({ row }) => (
            <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
            className="translate-y-[2px]"
          />
        ),
        enableSorting: false,
        enableHiding: false,
    },
    {
        accessorKey: "title",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Title"} />,

        cell: ({ row }) => {
          return <div className="flex items-center">{row.original.title }</div>;
      }
        
       
    
    },
    {
        accessorKey: "published_date",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Publish date"} />
    },
    {
        accessorKey: "expiration_date",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Expirey date"} />
    },
    
    {
        accessorKey: "is_active",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Active"} />
    },

    {
        id: "actions",
        enableSorting: false,
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Actions"} />,
        cell: ({ row }) => <AnnouncementCellAction data={row.original} />,
    },
];