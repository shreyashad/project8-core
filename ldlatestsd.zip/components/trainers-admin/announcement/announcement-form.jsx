"use client";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectItem, SelectTrigger, SelectContent, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import axios from "axios";
import { AnnouncementSchema} from "@/schema";
import { createNewAnnouncement, deleteAnnouncementDetails, updateAnnouncementDetails } from "@/app/api/server/route";
import { CalendarIcon, Trash2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";


export const AnnouncementForm = ({ initialData, categories }) => {
  const { data: session } = useSession();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const title = initialData && initialData.id ? "Edit Announcement" : "Create Announcement";
  const description = initialData && initialData.id ?"Edit the Announcement details" : "Create a new Announcement";
  const action = initialData && initialData.id ? "Save Changes" : "Create";
  const toastMessage = initialData && initialData.id ? "Announcement updated successfully" : "Announcement created successfully";
    
   

  const form = useForm({
    resolver: zodResolver(AnnouncementSchema),
    defaultValues: initialData || {
      title: "",
      content: "",
      category: "",
      expiration_date:"",
      is_active: false,      

    },
  });

  const onSubmit = async (values) => {
    try {
        setLoading(true);
        if (initialData && initialData.id) {
            await updateAnnouncementDetails(session.accessToken, initialData.id,  values);
            router.refresh();
        } else {
            await createNewAnnouncement(session.accessToken, values);
            router.refresh();
        }
        toast.success(`${action} successfully!`)
        router.push("/dashboard/trainers-admin/training-management/announcements");
       
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const onDelete = async () => {
    setLoading(true);
    try {
      await deleteAnnouncementDetails(session.accessToken,initialData.id,);
      toast.success("Category deleted successfully");
      router.push("/dashboard/trainers-admin/course-management/category");
    } catch (error) {
      toast.error(error.message);
    }
    setLoading(false);
  };

  return (
    <>
    <Card className="w-full max-w-2xl">
        <CardHeader>
            <CardTitle> {title}</CardTitle>
            <CardDescription>{description}</CardDescription>
            <div className="flex items-center justify-between">
              {initialData && initialData.id &&(
                <Button 
                  variant="destructive" 
                  onClick={onDelete} 
                  disabled={loading}
                >
                  <Trash2 className="h-4 w-4" /> Delete
                </Button>
              )}
            </div>
        </CardHeader>
        <CardContent className="space-y-6">
        <Separator />
        <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="w-full space-y-8">
          <div className="grid grid-cols-2 gap-8">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="Title"
                      disabled={loading}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <FormControl>
                    <Select
                      disabled={loading || !categories.length}
                      onValueChange={field.onChange}
                      value={field.value}
                    >
                      <SelectTrigger>
                        <SelectValue
                          placeholder={
                            categories.length > 0
                              ? "Course Category "
                              : "No Category available"
                          }
                        />
                      </SelectTrigger>
                      <SelectContent>
                        { categories.length > 0 ? (
                          categories.map((cate) => (
                            <SelectItem key={cate.id} value={cate.id}>
                              {cate.name}
                            </SelectItem>
                          ))
                        ) : (
                          <SelectItem disabled>
                            No Category found
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
          </div>
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea
                    {...field}
                    placeholder="Category Description"
                    disabled={loading}
                  />
                </FormControl>
              </FormItem>
            )}
          />
           <div className="grid grid-cols-2 gap-8">
          <FormField
            control={form.control}
            name="is_active"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                <FormLabel>
                 is Active 
                </FormLabel>
                
              </div>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="expiration_date"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Expiry Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-[240px] pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      // Disable dates less than or equal to today
                      disabled={(date) => {
                        const today = new Date();
                        today.setHours(0, 0, 0, 0); // Set time to 00:00:00 for comparison
                        return date <= today; // Disable dates before or equal to today
                      }}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>

                <FormMessage />
              </FormItem>
            )}
          />
          </div>
          <div className="mt-5 space-x-4">
              <Button disabled={loading} className="ml-auto" type="submit">
                  {action}
              </Button>
              <Button
                  disabled={loading}
                  className="ml-auto"
                  type="button"
                  onClick={() => {
                      router.back();
                  }}
              >
                  Cancel
              </Button>
          </div>
        </form>
      </Form>
        </CardContent>
    </Card>
      
      
      
    </>
  );
};

