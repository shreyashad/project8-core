"use client";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";


const AnnouncementClient = () => {
   const router = useRouter();
   return (
        <>
            
                <Button
                    onClick={() => {
                        router.push("/dashboard/trainers-admin/announcement-management/announcements/new")
                    }}
                >Create New Announcement</Button>
             
        </>

    );
};

export default AnnouncementClient;