"use client";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { zodResolver } from "@hookform/resolvers/zod";

import {  QueTypeSchema} from "@/schema";
import { createNewQuestionType, deleteQuestionTypeDetails, updateQuestionTypeDetails } from "@/app/api/server/route";
import { CalendarIcon, Trash2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";


export const QuestionTypeForm = ({ initialData }) => {
  const { data: session } = useSession();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const title = initialData && initialData.id ? "Edit Question Type" : "Create Question Type";
  const description = initialData && initialData.id ?"Edit the Question Type details" : "Create a new Question Type";
  const action = initialData && initialData.id ? "Save Changes" : "Create";
  const toastMessage = initialData && initialData.id ? "Question Type updated successfully" : "Question Type created successfully";
    
   

  const form = useForm({
    resolver: zodResolver(QueTypeSchema),
    defaultValues: initialData || {
      name: "",
      description: ""

    },
  });

  const onSubmit = async (values) => {
    try {
        setLoading(true);
        if (initialData && initialData.id) {
            await updateQuestionTypeDetails(session.accessToken, initialData.id,  values);
            router.refresh();
        } else {
            await createNewQuestionType(session.accessToken, values);
            router.refresh();
        }
        toast.success(`${action} successfully!`)
        router.push("/dashboard/trainers-admin/examination-management/questions-type");
       
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const onDelete = async () => {
    setLoading(true);
    try {
      await deleteQuestionTypeDetails(session.accessToken,initialData.id,);
      toast.success("Category deleted successfully");
      router.push("/dashboard/trainers-admin/examination-management/questions-type");
    } catch (error) {
      toast.error(error.message);
    }
    setLoading(false);
  };

  return (
    <>
    <Card className="w-full max-w-2xl">
        <CardHeader>
            <CardTitle> {title}</CardTitle>
            <CardDescription>{description}</CardDescription>
            <div className="flex items-center justify-between">
              {initialData && initialData.id &&(
                <Button 
                  variant="destructive" 
                  onClick={onDelete} 
                  disabled={loading}
                >
                  <Trash2 className="h-4 w-4" /> Delete
                </Button>
              )}
            </div>
        </CardHeader>
        <CardContent className="space-y-6">
        <Separator />
        <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="w-full space-y-8">
          <div className="grid grid-cols-2 gap-8">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="Question Type"
                      disabled={loading}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
                        
          </div>
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Textarea
                    {...field}
                    placeholder="Question Type Description"
                    disabled={loading}
                  />
                </FormControl>
              </FormItem>
            )}
          />
           
          <div className="mt-5 space-x-4">
              <Button disabled={loading} className="ml-auto" type="submit">
                  {action}
              </Button>
              <Button
                  disabled={loading}
                  className="ml-auto"
                  type="button"
                  onClick={() => {
                      router.back();
                  }}
              >
                  Cancel
              </Button>
          </div>
        </form>
      </Form>
        </CardContent>
    </Card>
      
      
      
    </>
  );
};

