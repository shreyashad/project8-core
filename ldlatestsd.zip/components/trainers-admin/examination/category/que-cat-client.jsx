"use client";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";


const QuestionTypeClient = () => {
   const router = useRouter();
   return (
        <>
            
                <Button
                    onClick={() => {
                        router.push("/dashboard/trainers-admin/examination-management/questions-type/new")
                    }}
                   
                >Create New Question Type</Button>
             
        </>

    );
};

export default QuestionTypeClient;