import { useForm, Controller, useFieldArray } from "react-hook-form";
import { useEffect, useState } from "react";
import { Button, Input, Textarea, Select, SelectItem, SelectTrigger, SelectValue, SelectContent, Form, FormField, FormLabel, FormControl, FormItem, FormMessage } from "@/components/ui"; 

export const TAExamForm = ({ initialData, courseList, queTypeList }) => {
    const { data: session } = useSession();
    const [loading, setLoading] = useState(false);
    
    const title = initialData && initialData.id ? "Edit Examination" : "Create New Examination";
    const description = initialData && initialData.id ? "Edit the Examination details" : "Create a new Examination";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(ExaminationSchema),
        defaultValues: initialData || {
            title: "",
            course: "",
            total_marks: 0,
            pass_marks: "",
            duration: "",
            description: "",
            questions: [],
        }
    });

    const { fields, append, remove } = useFieldArray({
        control: form.control,
        name: "questions",
    });

    const updateTotalMarks = () => {
        const questions = form.getValues("questions");
        const totalMarks = questions.reduce((sum, question) => sum + Number(question.marks || 0), 0);
        form.setValue("total_marks", totalMarks);
    };

    useEffect(() => {
        form.watch((value, { name, type }) => {
            if (name.includes("questions")) {
                updateTotalMarks();
            }
        });
    }, [form]);

    const addQuestion = () => {
        append({ question_type: "", question: "", marks: 0, options: [] });
    };

    const removeQuestion = (index) => {
        const updatedQuestions = form.getValues("questions").filter((_, i) => i !== index);
        form.setValue("questions", updatedQuestions);
    };

    return (
        <div className="container mx-auto p-4">
            <h1 className="text-2xl font-bold mb-4">{title}</h1>
            <p>{description}</p>

            <Card>
                <CardHeader>
                    <CardTitle>Exam Details</CardTitle>
                </CardHeader>
                <CardContent>
                    <Form {...form}>
                        <form>
                            <div className="grid grid-cols-2 gap-8">
                                <FormField
                                    control={form.control}
                                    name="title"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Quiz Title</FormLabel>
                                            <FormControl>
                                                <Input {...field} placeholder="Enter Quiz Title" disabled={loading} />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="course"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Course</FormLabel>
                                            <FormControl>
                                                <Select
                                                    disabled={loading || !courseList.length}
                                                    onValueChange={field.onChange}
                                                    value={field.value}
                                                >
                                                    <SelectTrigger>
                                                        <SelectValue
                                                            placeholder={courseList.length > 0 ? "Course" : "No Course available"}
                                                        />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {courseList.length > 0
                                                            ? courseList.map((course) => (
                                                                  <SelectItem key={course.id} value={course.id}>
                                                                      {course.title}
                                                                  </SelectItem>
                                                              ))
                                                            : (
                                                                <SelectItem disabled>No Course found</SelectItem>
                                                            )}
                                                    </SelectContent>
                                                </Select>
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="total_marks"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Total Marks</FormLabel>
                                            <FormControl>
                                                <Input {...field} type="number" disabled />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="pass_marks"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Passing Marks</FormLabel>
                                            <FormControl>
                                                <Input {...field} type="number" disabled={loading} />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="duration"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Duration</FormLabel>
                                            <FormControl>
                                                <Input {...field} type="time" disabled={loading} />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                            </div>
                            <FormField
                                control={form.control}
                                name="description"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Description</FormLabel>
                                        <FormControl>
                                            <Textarea {...field} placeholder="Enter Quiz description" disabled={loading} />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />

                            <div className="mt-6">
                                <Card className="mb-4">
                                    <CardHeader>
                                        <CardTitle>Add Questions</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-2 mb-4">
                                            {fields.map((item, index) => (
                                                <div key={item.id} className="border p-4 mb-4 rounded-md">
                                                    <FormField
                                                        control={form.control}
                                                        name={`questions[${index}].question`}
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Question Text</FormLabel>
                                                                <FormControl>
                                                                    <Textarea {...field} placeholder="Enter your Question" disabled={loading} />
                                                                </FormControl>
                                                            </FormItem>
                                                        )}
                                                    />
                                                    <FormField
                                                        control={form.control}
                                                        name={`questions[${index}].marks`}
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Marks</FormLabel>
                                                                <FormControl>
                                                                    <Input
                                                                        {...field}
                                                                        type="number"
                                                                        placeholder="Enter Marks"
                                                                        onChange={(e) => {
                                                                            field.onChange(e);
                                                                            updateTotalMarks();  // Recalculate total marks when marks change
                                                                        }}
                                                                        disabled={loading}
                                                                    />
                                                                </FormControl>
                                                            </FormItem>
                                                        )}
                                                    />
                                                    {/* Add dynamic question type handling */}
                                                    <Button
                                                        type="button"
                                                        onClick={() => remove(index)}
                                                        disabled={loading}
                                                        className="mt-2 px-4 py-2 bg-red-500 text-white rounded"
                                                    >
                                                        Remove Question
                                                    </Button>
                                                </div>
                                            ))}
                                            <Button
                                                type="button"
                                                onClick={addQuestion}
                                                disabled={loading}
                                                className="px-4 py-2 bg-blue-500 text-white rounded"
                                            >
                                                Add Question
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </div>

                            <div className="mt-4 flex justify-end">
                                <Button
                                    type="submit"
                                    disabled={loading}
                                    className="px-6 py-2 text-white bg-blue-600 rounded-md disabled:bg-gray-400"
                                >
                                    {action}
                                </Button>
                            </div>
                        </form>
                    </Form>
                </CardContent>
            </Card>
        </div>
    );
};
