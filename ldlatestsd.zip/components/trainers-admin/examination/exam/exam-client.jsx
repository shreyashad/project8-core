
"use client";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";


const TAExamClient = () => {
   const router = useRouter();
   return (
        <>
            
                <Button
                    onClick={() => {
                        router.push("/dashboard/trainers-admin/examination-management/exam/new")
                    }}
                >Create New Exam</Button>
             
        </>

    );
};

export default TAExamClient;