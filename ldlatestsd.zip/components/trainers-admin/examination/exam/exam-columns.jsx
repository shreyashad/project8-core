"use client";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { TAExamCellAction } from "./exam-actions";


export const TAExamColumns = [
    {
        id: "Select",
        header: ({ table }) => (
            <Checkbox
                checked={
                    table.getIsAllPageRowsSelected() ||
                    (table.getIsSomePageRowsSelected() && "indeterminate")
                }
                onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                aria-label="Select all"
                className="translate-y-[2px]"
            />
        ),

        cell: ({ row }) => (
            <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
            className="translate-y-[2px]"
          />
        ),
        enableSorting: false,
        enableHiding: false,
    },
    {
        accessorKey: "title",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Title"} />,

        cell: ({ row }) => {
          return <div className="flex items-center">{row.original.title }</div>;
      }
        
       
    
    },
    {
        accessorKey: "course",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Course"} />,

        cell: ({ row }) => {
          return <div className="flex items-center">{row.original.course }</div>;
      }
        
       
    
    },
    {
        accessorKey: "start_time",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Start time"} />
    },
    {
        accessorKey: "end_time",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" End time"} />
    },
    
    {
        accessorKey: "total_marks",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Total Marks"} />
    },

    {
        id: "actions",
        enableSorting: false,
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Actions"} />,
        cell: ({ row }) => <TAExamCellAction data={row.original} />,
    },
]