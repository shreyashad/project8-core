"use client";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";


const AnnouncementCategoryClient = () => {
   const router = useRouter();
   return (
        <>
            
                <Button
                    onClick={() => {
                        router.push("/dashboard/trainers-admin/announcement-management/category/new")
                    }}
                >Create New Announcement Category</Button>
             
        </>

    );
};

export default AnnouncementCategoryClient;