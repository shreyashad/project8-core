"use client";
import { useState, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import toast from "react-hot-toast";
import { fetchRoomAvailabilityData, fetchTrainerAvailabilityData } from "@/app/api/server/route";
import { TrainingScheduleSchema } from "@/schema";  // Zod validation schema
import { Select } from "@/components/ui/select";
import { DatePicker } from "@/components/ui/date-picker";
import { Button } from "@/components/ui/button";
import TimePicker from "@/components/ui/time-picker";

export const TrainingBookingForm = ({ initialData, accessToken }) => {
  const { control, handleSubmit, watch, setValue, formState: { errors } } = useForm({
    resolver: zodResolver(TrainingScheduleSchema),
    defaultValues: {
      trainingRequest: initialData?.id || null,
      course: initialData?.course_info?.title || "",
      preferredMode: initialData?.preferred_mode || "offline",
      employeeIds: initialData?.employee_info?.map(emp => emp.id) || [],
      roomId: "",
      trainers: [],
      scheduledDate: "",
      startTime: "",
      endTime: "",
      durationHours: "",
      additionalNotes: "",
    },
  });

  const [step, setStep] = useState(1); // Tracks the current step of the form
  const [loadingRooms, setLoadingRooms] = useState(false);
  const [loadingTrainers, setLoadingTrainers] = useState(false);
  const [roomAvailability, setRoomAvailability] = useState([]);
  const [trainerAvailability, setTrainerAvailability] = useState([]);

  const preferredMode = watch("preferredMode");
  const scheduledDate = watch("scheduledDate");

  // Fetch Room and Trainer Availability based on selected date
  useEffect(() => {
    if (scheduledDate) {
      fetchRoomAvailability(scheduledDate);
      fetchTrainerAvailability(scheduledDate);
    }
  }, [scheduledDate]);

  const fetchRoomAvailability = async (date) => {
    setLoadingRooms(true);
    try {
      const rooms = await fetchRoomAvailabilityData(accessToken, null, date);
      setRoomAvailability(rooms);
    } catch (error) {
      console.error("Error fetching room availability:", error);
    }
    setLoadingRooms(false);
  };

  const fetchTrainerAvailability = async (date) => {
    setLoadingTrainers(true);
    try {
      const trainers = await fetchTrainerAvailabilityData(accessToken, date);
      setTrainerAvailability(trainers);
    } catch (error) {
      console.error("Error fetching trainer availability:", error);
    }
    setLoadingTrainers(false);
  };

  const onSubmit = async (data) => {
    // Handle form submission
    try {
      // Assume we have a function `createTrainingSchedule` that handles the backend request
      await createTrainingSchedule(data, accessToken);
      toast.success("Training session booked successfully!");
    } catch (error) {
      toast.error("Error booking training session.");
    }
  };

  const nextStep = () => {
    setStep((prev) => prev + 1);
  };

  const prevStep = () => {
    setStep((prev) => prev - 1);
  };

  const stepContent = () => {
    switch (step) {
      case 1:
        return (
          <div>
            <h3>Training Request Details</h3>
            <p><strong>Course:</strong> {initialData?.course_info?.title}</p>
            <p><strong>Requester:</strong> {initialData?.requester_info?.username}</p>
            <p><strong>Preferred Mode:</strong> {initialData?.preferred_mode}</p>
            <p><strong>Employees:</strong> 
              <ul>
                {initialData?.employee_info?.map((emp, idx) => <li key={idx}>{emp.username}</li>)}
              </ul>
            </p>
          </div>
        );

      case 2:
        return (
          <div>
            <h3>Room and Trainer Selection</h3>
            {preferredMode === "offline" && (
              <div>
                <label>Room:</label>
                <Controller
                  control={control}
                  name="roomId"
                  render={({ field }) => (
                    <Select {...field} disabled={loadingRooms}>
                      {loadingRooms ? (
                        <option>Loading...</option>
                      ) : (
                        roomAvailability.map((room) => (
                          <option key={room.id} value={room.id}>{room.name}</option>
                        ))
                      )}
                    </Select>
                  )}
                />
              </div>
            )}

            <div>
              <label>Trainers:</label>
              <Controller
                control={control}
                name="trainers"
                render={({ field }) => (
                  <Select {...field} multiple disabled={loadingTrainers}>
                    {loadingTrainers ? (
                      <option>Loading...</option>
                    ) : (
                      trainerAvailability.map((trainer) => (
                        <option key={trainer.id} value={trainer.id}>{trainer.name}</option>
                      ))
                    )}
                  </Select>
                )}
              />
            </div>
          </div>
        );

      case 3:
        return (
          <div>
            <h3>Scheduled Date, Time, and Duration</h3>
            <div>
              <label>Scheduled Date:</label>
              <Controller
                control={control}
                name="scheduledDate"
                render={({ field }) => <DatePicker {...field} />}
              />
            </div>

            <div>
              <label>Start Time:</label>
              <Controller
                control={control}
                name="startTime"
                render={({ field }) => <TimePicker {...field} />}
              />
            </div>

            <div>
              <label>End Time:</label>
              <Controller
                control={control}
                name="endTime"
                render={({ field }) => <TimePicker {...field} />}
              />
            </div>

            <div>
              <label>Duration (hours):</label>
              <Controller
                control={control}
                name="durationHours"
                render={({ field }) => <Input type="number" {...field} />}
              />
            </div>
          </div>
        );

      case 4:
        return (
          <div>
            <h3>Additional Notes</h3>
            <div>
              <label>Additional Notes:</label>
              <Controller
                control={control}
                name="additionalNotes"
                render={({ field }) => <Textarea {...field} />}
              />
            </div>
          </div>
        );

      case 5:
        return (
          <div>
            <h3>Confirm Your Details</h3>
            <p><strong>Course:</strong> {watch("course")}</p>
            <p><strong>Room:</strong> {watch("roomId")}</p>
            <p><strong>Trainers:</strong> {watch("trainers")?.join(", ")}</p>
            <p><strong>Date:</strong> {watch("scheduledDate")}</p>
            <p><strong>Start Time:</strong> {watch("startTime")}</p>
            <p><strong>End Time:</strong> {watch("endTime")}</p>
            <p><strong>Duration:</strong> {watch("durationHours")} hours</p>
            <p><strong>Notes:</strong> {watch("additionalNotes")}</p>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {stepContent()}

      <div className="flex justify-between mt-6">
        {step > 1 && (
          <Button type="button" onClick={prevStep}>Back</Button>
        )}
        {step < 5 ? (
          <Button type="button" onClick={nextStep}>Next</Button>
        ) : (
          <Button type="submit">Submit</Button>
        )}
      </div>
    </form>
  );
};

export default TrainingBookingForm;
