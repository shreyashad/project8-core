"use client";
import { Checkbox } from "@/components/ui/checkbox";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { TrainingRequestCellAction } from "./trainingrequest-cell-action";


export const TATrainingRequestColumns = [
    {
        id: "Select",
        header: ({ table }) => (
            <Checkbox 
                checked={
                    table.getIsAllPageRowsSelected() ||
                    (table.getIsSomePageRowsSelected() && "indeterminate")
                }
                onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                aria-label="Select all"
                className="translate-y-[2px]"
            />
        ),
        cell : ({ row }) => (
            <Checkbox 
                checked={row.getIsSelected()}
                onCheckedChange={(value) => row.toggleSelected(!!value)}
                aria-label="Select row"
                className="translate-y-[2px]"
            />
        ),
    },
    {
        accessorKey: "course",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Course"} /> ,
        
        cell: ({ row }) => {
            return <div className="flex items-center">{row.original.course_info.title }</div>;
        }
    },
    {
        accessorKey: "requester",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Requested By"} />,
        
        cell: ({ row }) => {
            return <div className="flex items-center">{row.original.requester_info.username }</div>;
        }
    },
    {
        accessorKey: "status",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Status"} />
    },
    {
        accessorKey: "created_at",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Requested date"} />,
        
        cell: ({ row }) => {
            return <div className="flex items-center">{new Date(row.original.created_at).toLocaleDateString()}</div>;
        }
        
        
    },

    {
        id: "actions",
        enableSorting: false,
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Actions"} />,
        cell: ({ row }) => <TrainingRequestCellAction data={row.original} />,
    },
]