"use client";

import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { CalendarIcon, Clock, Inbox, PlusCircle } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { TrainingCalendar } from "./training-calendar";
import { SearchAndFilter } from "./search-filter";
import { DataTable } from "@/components/ui/data-table/data-table";
import { TATrainingRequestColumns } from "./training-request-coloumn";

export default function TrainingRequestDashboardTA({ initialRequests }) {
  const [activeTab, setActiveTab] = useState();
  const [searchTerm, setSearchTerm] = useState("")
  const [filters, setFilters] = useState({
    status: "all",
    priority: "all",
    dateRange: { from: null, to: null },
  })

  return(
    <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
      <TabsList>
        <TabsTrigger value="inbox">Inbox</TabsTrigger>
        <TabsTrigger value="calendar">Calendar</TabsTrigger>
      </TabsList>
      <SearchAndFilter
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        filters={filters}
        setFilters={setFilters}
      />
      <TabsContent value="inbox" className="space-y-4">
        <DataTable columns={TATrainingRequestColumns} data={initialRequests} />
      </TabsContent>
      <TabsContent value="calendar">
        <TrainingCalendar />
      </TabsContent>
    </Tabs>
  );

}
 