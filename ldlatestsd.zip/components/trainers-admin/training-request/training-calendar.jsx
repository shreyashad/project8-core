"use client"

import React from 'react'
import { Calendar, momentLocalizer } from 'react-big-calendar'
import moment from 'moment'
import 'react-big-calendar/lib/css/react-big-calendar.css'

// Setup the localizer for react-big-calendar
const localizer = momentLocalizer(moment)


export default function TrainingCalendar({ scheduledTrainings }) {
  return (
    <div className="h-[600px]">
      <Calendar
        localizer={localizer}
        events={scheduledTrainings}
        startAccessor="start"
        endAccessor="end"
        titleAccessor="title"
        tooltipAccessor={(event) => `${event.title}\nRoom: ${event.room}\nTrainer: ${event.trainer}`}
        views={['month', 'week', 'day']}
        defaultView='month'
      />
    </div>
  )
}

