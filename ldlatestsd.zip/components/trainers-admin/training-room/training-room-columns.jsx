"use client";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { Checkbox } from "@/components/ui/checkbox";
import { TrainingRoomCellAction } from "./training-room-cell-actions";

export const TrainingRoomColumns = [
    {
        id: "Select",
        header: ({ table }) => (
            <Checkbox
                checked={
                    table.getIsAllPageRowsSelected() ||
                    (table.getIsSomePageRowsSelected() && "indeterminate")
                }
                onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                aria-label="Select all"
                className="translate-y-[2px]"
            />
        ),

        cell: ({ row }) => (
            <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
            className="translate-y-[2px]"
          />
        ),
        enableSorting: false,
        enableHiding: false,
    },
    {
        accessorKey: "name",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Room Name"} />,

        cell: ({ row }) => {
          return <div className="flex items-center">{row.original.name }</div>;
      }
        
       
    
    },
    {
        accessorKey: "capacity",
        header: ({ column }) => <DataTableColumnHeader column={column} title={" Capacity"} />
    },
    
    {
        id: "actions",
        enableSorting: false,
        cell: ({ row }) => <TrainingRoomCellAction data={row.original} />,
    },
];