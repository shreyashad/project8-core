import { Bookmark, LayoutGrid, Settings, SquarePen, Tag, Users } from "lucide-react";
import { GrCatalog } from "react-icons/gr";
import { MdOnDeviceTraining, MdOutgoingMail, MdPermMedia  } from "react-icons/md";
import { GiNotebook, GiWisdom  } from "react-icons/gi";
import { GrAchievement, GrAnnounce} from "react-icons/gr";
import { SiSololearn } from "react-icons/si";

export const dashboardData = {
    TrainersAdmin : [
        {
            groupLabel: "",
            menus: [
              {
                href: "/dashboard/trainers-admin",
                label: "Dashboard",
                icon: LayoutGrid,
               
              }
            ]
        },
        {
            groupLabel: "Contents",
            menus:[
                  {
                    href: "/dashboard/trainers-admin/announcement-management/",
                    label: "Announcement Management",
                    icon: GrAnnounce,
                    submenus:[
                      {
                        href: "/dashboard/trainers-admin/announcement-management/category",
                        label: "Announcement Category"
                      },
                      {
                        href: "/dashboard/trainers-admin/announcement-management/announcements",
                        label: "Announcements"
                      }
                    ]
                  },
                  {
                    href: "/dashboard/trainers-admin/assignment-management",
                    label: "Assignment Management",
                    icon: SquarePen ,
                    submenus: []
                  },
                  {
                    href: "/dashboard/trainers-admin/course-management",
                    label: "Course Management",
                    icon: MdPermMedia ,
                    submenus: [
                      {
                        href: "/dashboard/trainers-admin/course-management/difficulty-levels",
                        label: "Course Difficulty Level"
                      },
                      {
                        href: "/dashboard/trainers-admin/course-management/category",
                        label: "Course Category"
                      },
                      {
                        href: "/dashboard/trainers-admin/course-management/courses",
                        label: "Courses"
                      },
                      {
                        href: "/dashboard/trainers-admin/course-management/modules",
                        label: "Module"
                      },
                      {
                        href: "/dashboard/trainers-admin/course-management/videos",
                        label: "Video"
                      },
                      
                    ]
                },
                {
                    href: "/dashboard/trainers-admin/examination-management",
                    label: "Examination Management",
                    icon: GiNotebook,
                    submenus:[
                      {
                        href: "/dashboard/trainers-admin/examination-management/exam",
                        label: "Exam"
                      },
                      {
                        href: "/dashboard/trainers-admin/examination-management/questions-type/",
                        label: "Questions Types"
                      },
                      {
                        href: "/dashboard/trainers-admin/examination-management/questions",
                        label: "Questions"
                      },
                      {
                        href: "/dashboard/trainers-admin/examination-management/results",
                        label: "Results"
                      },
                      
                    ]
                },
                {
                  href: "/dashboard/trainers-admin/training-requests",
                  label: "Traning Request",
                  icon: MdOutgoingMail,
                },
                {
                  href: "/dashboard/trainers-admin/training-management",
                  label: "Training Management",
                  icon: SquarePen,
                  submenus:[
                    {
                      href: "/dashboard/trainers-admin/training-management/training-rooms",
                      label: "Training Rooms"
                    },
                    {
                      href: "/dashboard/trainers-admin/training-management/training-modes",
                      label: "Training Modes"
                    },
                    {
                      href: "/dashboard/trainers-admin/training-management/training-sessions",
                      label: "Training Sessions"
                    },

                  ]
                },
                {
                  href: "/dashboard/trainers-admin/todays-wisdom",
                  label: "Today Wisdom",
                  icon: GiWisdom ,
                },
                {
                  href: "/dashboard/trainers-admin/trainers",
                  label: "Trainers",
                  icon: SquarePen,
                },
                {
                  href: "/dashboard/trainers-admin/trainers",
                  label: "Learners",
                  icon: SquarePen,
                },
                {
                  href: "/dashboard/trainers-admin/trainers",
                  label: "Reports & Analytics",
                  icon: SquarePen,
                },
                {
                  href: "/dashboard/trainers-admin/trainers",
                  label: "Certificates",
                  icon: SquarePen,
                },
            ]
        },
        {
          groupLabel: "Settings",
          menus: [
            {
              href: "/dashboard/trainers-admin/profile",
              label: "Users",
              icon: Users
            },
            {
              href: "/account",
              label: "Account",
              icon: Settings
            }
          ]
      }
    ],
    HOD: [
        {
            groupLabel: "",
            menus: [
              {
                href: "/dashboard/hod",
                label: "Dashboard",
                icon: LayoutGrid,
               
              }
            ]
        },
        {
            groupLabel: "Contents",
            menus: [
              {
                href:"/dashboard/hod/courses",
                label: "Courses",
                icon: SiSololearn,
              },
              {
                href:"/dashboard/hod/my-learning",
                label: "My Courses",
                icon: GrCatalog,
              },
              {
                href:"/dashboard/hod/training-request",
                label: "Trainings Request",
                icon: MdOutgoingMail, 
              },
              {
                href:"/dashboard/hod/trainings",
                label: "Trainings",
                icon: MdOnDeviceTraining, 
              },
              {
                href:"/dashboard/hod/exams",
                label: "Exams",
                icon: GiNotebook, 
              },
              {
                href:"/dashboard/hod/my-progress",
                label: "My Progress",
                icon: GrAchievement , 
              },
              {
                href: "/dashboard/hod/team-management",
                label: "Team Management",
                icon: SquarePen,
                submenus: [
                  {
                    href: "/dashboard/hod/team-management/teams",
                    label: "Teams"
                  },
                  {
                    href: "/dashboard/hod/team-management/team-members",
                    label: "Team Member"
                  },
                  {
                    href: "/dashboard/hod/team-management/team-performance",
                    label: "Team Performance"
                  }
                  
                  
                  
                ]
              },
              
              
            ]
        },
        {
            groupLabel: "Settings",
            menus: [
              {
                href: "/dashboard/hod/profile",
                label: "Users",
                icon: Users
              },
              {
                href: "/account",
                label: "Account",
                icon: Settings
              }
            ]
        }
    ],
    Trainer: [],
    Employee:[],
}