import { Bell, Menu, Search, User } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import Notification from "./notification"
import UserNav from "./user-nav"
import { ThemeToggle } from "./theme-toggle"
import { SidebarTrigger } from "../ui/sidebar"

export default function Header({ onMenuClick }) {
  return (
    <header className="sticky top-0 z-50 flex h-16 w-full shrink-0 items-center gap-4 border-b bg-background px-4 shadow-sm">
      {/* bg-background border-b fixed top-0 left-0 right-0 z-30 md:relative
      sticky top-0 z-50 flex h-16 w-full shrink-0 items-center gap-4 border-b bg-background px-4 shadow-sm*/}
      <div className="flex items-center justify-between px-4 py-4 md:px-6"> 
        <div className="flex items-center gap-2 md:gap-4">
          <SidebarTrigger />
          <div className="flex flex-col">
            <div className="hidden lg:block">
              <span className="font-bold text-indigo">MDIndia Health Insurance TPA Pvt. Ltd.</span>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <Notification />
          <ThemeToggle />
          <UserNav />
        </div>
      </div>
    </header>
  )
}