"use client";
import { LogOut, User } from "lucide-react";
import { Button } from "../ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "../ui/dropdown-menu";
import {  signOut, useSession } from "next-auth/react";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";


const API_CAS_URL = process.env.AUTH_SERVER_API_BASE_URL || "";


async function handleSignOut(service_ticket) {
    if (service_ticket) {
        try {
       
            await axios.post(`${API_CAS_URL}api/user-logout/`, {
                service_ticket: service_ticket
            });
        } catch (error) {
            console.error("Error logging out from backend:", error);
        }
    }
    // Call NextAuth signOut after backend logout
    await signOut({ redirect: false }); // Set redirect to false to control redirection manually if needed
}

export default function UserNav() {
   const { data: session, status } = useSession();

   if (status === 'loading ') {
    return <Loading />;
   }

   if (!session || !session.user) {
    return <div>No user data available</div>;
  }


    return(
        <DropdownMenu>
            <DropdownMenuTrigger>
                <Button variant="outline" size="icon" className="relative bg-blue border rounded-full">
                  <Avatar >
                        <AvatarImage src={session.user.profile_picture} alt={session.user.first_name} /> 
                        <AvatarFallback className="bg-blue">{session.user.first_name.split(' ').map(n => n[0].toUpperCase()).join('')}{session.user.last_name.split(' ').map(n => n[0].toUpperCase()).join('')}</AvatarFallback>
                    </Avatar>
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <div className="flex items-center justify-start gap-4 p-2">
                <div className="flex flex-col space-y-1 leading-none">
                        {session.user && <p className="font-medium">{session.user.first_name}</p>}
                        {session.user.username && (
                            <p className="w-[200px] truncate text-sm text-zinc-700">
                                {session.user.username}
                            </p>
                        )}
                    </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                    <Button
                        variant="outline"
                        className="w-full"
                        onClick={async () =>{
                            await handleSignOut(session.user.service_ticket);
                        }}
                    >
                        <LogOut className="mr-2 h-4 w-4" aria-hidden="true" />
                        Log Out
                    </Button>
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}