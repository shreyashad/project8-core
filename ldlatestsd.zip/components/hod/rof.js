"use client";
import { cn } from "@/lib/utils";
import { Button } from "../ui/button";
import { useState } from "react";
import { CalendarIcon, Check, ChevronsUpDown, Clock, Inbox, PlusCircle, Send } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { Label } from "../ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "../ui/command";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Textarea } from "../ui/textarea";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { TrainingRequestSchema } from "@/schema";
import { createTrainingRequest } from "@/app/api/server/route";

export default function HODTrainingRequestSystem({ courseslist, receiverData, teamsData }) {
    const [activeView, setActiveView] = useState("new");
    const [selectedItem, setSelectedItem] = useState(null);
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const [selectedReceiver, setSelectedReceiver] = useState("");

    const { data: session } = useSession();
    const router = useRouter();

    const form = useForm({
        resolver: zodResolver(TrainingRequestSchema),
        defaultValues: {
            course: "",
            requester: session?.user.username,
            receiver: "",
            mode: "",
            team_id: "",
            additional_notes: "",
            status: "pending",
        },
    });

    const handleOnSubmit = async (values) => {
        setLoading(true);
        try {
            await createTrainingRequest(session.accessToken, values);
            router.refresh();
        } catch (error) {
            console.error("Error submitting training request:", error.response ? error.response.data : error.message);
            toast.error(error.message || "An error occurred. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    const NavItem = ({ icon: Icon, label, view }) => (
        <Button
            className={cn(
                "flex items-center gap-2 px-4 py-2 w-full text-left hover:bg-accent rounded-md",
                activeView === view && "bg-accent"
            )}
            onClick={() => {
                setActiveView(view);
                setSelectedItem(null);
            }}
        >
            <Icon className="h-5 w-5" />
            <span>{label}</span>
        </Button>
    );

    return (
        <div className="flex flex-col md:flex-row h-full">
            <div className="w-full md:w-64 border-r p-4 flex flex-col md:shrink-0">
                <h1 className="text-2xl font-bold mb-6">Request Management</h1>
                <nav className="space-y-2">
                    <NavItem icon={PlusCircle} label="New Request" view="new" />
                    <NavItem icon={Send} label="Sent Requests" view="sent" />
                    <NavItem icon={Inbox} label="Replies" view="replies" />
                    <NavItem icon={Clock} label="Pending" view="pending" />
                    <NavItem icon={CalendarIcon} label="Scheduled" view="scheduled" />
                </nav>
            </div>
            <div className="flex-1 flex flex-col overflow-hidden">
                <div className="flex-1 p-4 overflow-auto">
                    <h2 className="text-xl font-semibold mb-4">
                        {activeView === "new" ? "New Training Request" : 
                         activeView === "sent" ? "Sent Requests" :
                         activeView === "replies" ? "Replies" :
                         activeView === "pending" ? "Pending Requests" : "Scheduled Trainings"}
                    </h2>
                    {activeView === "new" ? (
                        <Card>
                        <CardHeader>
                            <CardTitle> New Training Request</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Form {...form}>
                                <form className="grid gap-4" onSubmit={form.handleSubmit(handleOnSubmit)}>
                                    <div className="space-y-6">
                                        <Label>To:</Label>
                                        <Popover open={open} onOpenChange={setOpen}>
                                            <PopoverTrigger asChild>
                                                <Button
                                                    variant="outline"
                                                    role="combobox"
                                                    aria-expanded={open}
                                                    className="w-[200px] justify-between"
                                                >
                                                    {selectedReceiver || "Select receiver..."}
                                                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                                </Button>
                                            </PopoverTrigger>
                                            <PopoverContent className="w-[200px] p-0">
                                                <Command>
                                                    <CommandInput placeholder="Search receiver..." />
                                                    <CommandList>
                                                        <CommandEmpty>No receiver found.</CommandEmpty>
                                                        <CommandGroup>
                                                            {receiverData?.map((receiver) => (
                                                                <CommandItem
                                                                    key={receiver.username}
                                                                    onSelect={() => {
                                                                        setSelectedReceiver(receiver.username);
                                                                        form.setValue('receiver_id', receiver.username); // Set receiver_id
                                                                        setOpen(false);
                                                                    }}
                                                                >
                                                                    <Check
                                                                        className={`mr-2 h-4 w-4 ${selectedReceiver === receiver.username ? "opacity-100" : "opacity-0"}`}
                                                                    />
                                                                    {receiver.username}
                                                                </CommandItem>
                                                            ))}
                                                        </CommandGroup>
                                                    </CommandList>
                                                </Command>
                                            </PopoverContent>
                                        </Popover>
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <FormField
                                                control={form.control}
                                                name="course"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Course Topic</FormLabel>
                                                        <Select
                                                            disabled={loading || !courseslist?.length}
                                                            onValueChange={field.onChange}
                                                            value={field.value}
                                                        >
                                                            <FormControl>
                                                                <SelectTrigger>
                                                                    <SelectValue placeholder={courseslist?.length > 0 ? "Course Topic" : "No Courses available"} />
                                                                </SelectTrigger>
                                                            </FormControl>
                                                            <SelectContent>
                                                                {courseslist?.length > 0 ? (
                                                                    courseslist.map((course) => (
                                                                        <SelectItem key={course.id} value={course.title}>
                                                                            {course.title}
                                                                        </SelectItem>
                                                                    ))
                                                                ) : (
                                                                    <SelectItem disabled>No Topic found</SelectItem>
                                                                )}
                                                            </SelectContent>
                                                        </Select>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                        </div>
                                        <div className="space-y-2">
                                            <FormField
                                                control={form.control}
                                                name="mode"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Training Mode</FormLabel>
                                                        <Select
                                                            disabled={loading}
                                                            onValueChange={field.onChange}
                                                            value={field.value}
                                                        >
                                                            <FormControl>
                                                                <SelectTrigger>
                                                                    <SelectValue placeholder="Training Mode" />
                                                                </SelectTrigger>
                                                            </FormControl>
                                                            <SelectContent>
                                                                <SelectItem value="online">Online</SelectItem>
                                                                <SelectItem value="offline">Offline</SelectItem>
                                                                <SelectItem value="self-learning">Self-learning</SelectItem>
                                                            </SelectContent>
                                                        </Select>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                        </div>
                                    </div>
                                    <FormField
                                        control={form.control}
                                        name="team_id"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Team</FormLabel>
                                                <Select
                                                    disabled={loading || !teamsData?.length}
                                                    onValueChange={field.onChange}
                                                    value={field.value}
                                                >
                                                    <FormControl>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder={teamsData?.length > 0 ? "Team" : "No Team available"} />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        {teamsData?.length > 0 ? (
                                                            teamsData.map((team) => (
                                                                <SelectItem key={team.id} value={team.id}>
                                                                    {team.name}
                                                                </SelectItem>
                                                            ))
                                                        ) : (
                                                            <SelectItem disabled>No Teams found</SelectItem>
                                                        )}
                                                    </SelectContent>
                                                </Select>
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="additional_notes"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Additional Notes</FormLabel>
                                                <FormControl>
                                                    <Textarea
                                                        {...field}
                                                        placeholder="Additional Notes"
                                                        disabled={loading}
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <div className="space-x-4">
                                        <Button disabled={loading} className="ml-auto" type="submit">
                                            {loading ? 'Submitting...' : 'Submit Request'}
                                        </Button>
                                        <Button
                                            disabled={loading}
                                            className="ml-auto"
                                            type="button"
                                            onClick={() => router.back()}
                                        >
                                            Cancel
                                        </Button>
                                    </div>
                                </form>
                            </Form>
                        </CardContent>
                    </Card>
                    ) : (
                        <div className="text-center text-muted-foreground">
                            {activeView === "new" ? "Fill out the form to create a new request" : "Select an item to view details"}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

<>
            <div className="w-64 border-r p-4 flex flex-col justify-between">
                <div>
                    <h1 className="text-2xl font-bold mb-6">Training Request Management</h1>
                    <nav className="space-y-2">
                        <NavItem icon={Inbox} label={"Inbox"} view={"inbox"} />
                        <NavItem icon={Send} label={"Sent Requests"} view={"sent"} />
                        <NavItem icon={Clock} label={"Pending"} view={"pending"} />
                        <NavItem icon={CalendarIcon} label={"Scheduled"} view={"scheduled"} />
                    </nav>
                </div>
                <Button className="mt-auto" onClick={() => setActiveView("new")}>
                    <PlusCircle className="mr-2 h-4 w-4" /> New Request
                </Button>
            </div>
            <div className="flex-1 flex">
                <div className="w-1/3 border-r p-4 overflow-auto">
                    <h2 className="text-xl font-semibold mb-4">
                        {
                            activeView === "inbox" ? "All Requests" :
                            activeView === "sent" ? "Sent Requests" :
                            activeView === "scheduled" ? "Scheduled Trainings" :
                            activeView === "pending" ? "Pending Trainings": ""
                        }
                    </h2>
                    
                </div>
                <div className="flex-1 p-4 overflow-auto">
                    {
                        activeView === "new" ? (
                            <Card>
                                <CardHeader>
                                    <CardTitle>New Training Request</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <Form {...form}>
                                        <form onSubmit={form.handleSubmit(handleRequestSubmit)}>
                                            <div className="space-y-6">
                                                <FormField 
                                                    control={form.control}
                                                    name="receiver"
                                                    render={({ field }) => (
                                                        <FormItem>
                                                            <FormLabel>To</FormLabel>
                                                            <FormControl>
                                                                <Popover open={open} onOpenChange={setOpen}>
                                                                    <PopoverTrigger asChild>
                                                                        <Button>
                                                                            {selectedReceiver || "Select Trainer's Admin "}
                                                                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                                                        </Button>
                                                                    </PopoverTrigger>
                                                                    <PopoverContent className="w-[200px] p-0">
                                                                        <Command>
                                                                            <CommandInput placeholder="Search receiver..." />
                                                                            <CommandList>
                                                                                <CommandEmpty> No receiver found. </CommandEmpty>
                                                                                <CommandGroup>
                                                                                    {receiverListData?.map((receiver) => (
                                                                                        <CommandItem
                                                                                            key={receiver.id}
                                                                                            onSelect={() => {
                                                                                                setSelectedReceiver(receiver.username);
                                                                                                form.setValue('receiver', receiver.id);
                                                                                                setOpen(false);
                                                                                            }}
                                                                                        >
                                                                                            <Check
                                                                                                className={`mr-2 h-4 w-4 ${selectedReceiver === receiver.id ? "opacity-100" : "opacity-0"}`}
                                                                                            />
                                                                                            {receiver.username}
                                                                                        </CommandItem>
                                                                                    ))}
                                                                                </CommandGroup>
                                                                            </CommandList>
                                                                        </Command>
                                                                    </PopoverContent>
                                                                </Popover>
                                                            </FormControl>
                                                        </FormItem>
                                                    )}
                                                />
                                            </div>
                                            <div className="grid grid-cols-2 gap-4">
                                                <div className="space-y-2">
                                                    <FormField
                                                        control={form.control}
                                                        name="course"
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Course Topic</FormLabel>
                                                                <Select
                                                                    disabled={loading || !courseListData?.length}
                                                                    onValueChange={field.onChange}
                                                                    value={field.value}
                                                                >
                                                                    <FormControl>
                                                                        <SelectTrigger>
                                                                            <SelectValue placeholder={courseListData?.length > 0 ? "Course Topic" : "No Courses available"} />
                                                                        </SelectTrigger>
                                                                    </FormControl>
                                                                    <SelectContent>
                                                                        {courseListData?.length > 0 ? (
                                                                            courseListData.map((course) => (
                                                                                <SelectItem key={course.id} value={course.id}>
                                                                                    {course.title}
                                                                                </SelectItem>
                                                                            ))
                                                                        ) : (
                                                                            <SelectItem disabled>No Topic found</SelectItem>
                                                                        )}
                                                                    </SelectContent>
                                                                </Select>
                                                                <FormMessage />
                                                            </FormItem>
                                                        )}
                                                    />
                                                </div>
                                                <div className="space-y-2">
                                                    <FormField
                                                        control={form.control}
                                                        name="preferred_mode"
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Training Mode</FormLabel>
                                                                <Select
                                                                    disabled={loading}
                                                                    onValueChange={field.onChange}
                                                                    value={field.value}
                                                                >
                                                                    <FormControl>
                                                                        <SelectTrigger>
                                                                            <SelectValue placeholder="Training Mode" />
                                                                        </SelectTrigger>
                                                                    </FormControl>
                                                                    <SelectContent>
                                                                        <SelectItem value="online">Online</SelectItem>
                                                                        <SelectItem value="offline">Offline</SelectItem>
                                                                        <SelectItem value="self-learning">Self-learning</SelectItem>
                                                                    </SelectContent>
                                                                </Select>
                                                                <FormMessage />
                                                            </FormItem>
                                                        )}
                                                    />
                                                </div>
                                            </div>
                                            <FormField
                                                control={form.control}
                                                name="employee"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Employees</FormLabel>
                                                        <FormControl>
                                                            <MultiSelect
                                                                options={employeeOptions}
                                                                onValueChange={field.onChange}
                                                                defaultValue={field.value}
                                                                placeholder="Select employees"
                                                                variant="inverted"
                                                                animation={2}
                                                            
                                                            />
                                                        </FormControl>
                                                        <FormDescription>
                                                            Choose the Employees you are want training for.
                                                        </FormDescription>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                            <FormField 
                                                control={form.control}
                                                name="additional_notes"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Additional Notes</FormLabel>
                                                        <FormControl>
                                                            <Textarea
                                                                {...field}
                                                                placeholder="Additional Notes"
                                                                disabled={loading}
                                                            />
                                                        </FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                            <div className="mt-4 space-x-4">
                                                <Button disabled={loading} className="ml-auto" type="submit">
                                                    {loading ? 'Submitting...' : 'Submit Request'}
                                                </Button>
                                                <Button
                                                    disabled={loading}
                                                    className="ml-auto"
                                                    type="button"
                                                    onClick={() => router.back()}
                                                >
                                                    Cancel
                                                </Button>
                                            </div>
                                        </form>

                                    </Form>
                                </CardContent>
                            </Card>
                        ) : selectedItem ? (
                            <div>
                                <h2 className="text-2xl font-semibold mb-4">{selectedItem.subject}</h2>
                                <div className="mb-2">
                                    <Badge variant={selectedItem.status === "Pending" ? "secondary" : "success"}>
                                        {selectedItem.status}
                                    </Badge>
                                </div>
                                <div className="mb-4">
                                    <span className="font-semibold">Date Requested:</span> {selectedItem.date}
                                </div>
                                <div className="mb-4">{selectedItem.content}</div>

                                {selectedItem.status === "Scheduled" && (
                                    <Card>
                                        <CardHeader>
                                            <CardTitle>Training Details</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="space-y-2">
                                                <div><span className="font-semibold">Date:</span> {selectedItem.scheduledDate}</div>
                                                <div><span className="font-semibold">Time:</span> {selectedItem.scheduledTime}</div>
                                                <div><span className="font-semibold">Trainer:</span> {selectedItem.trainer}</div>
                                                <div><span className="font-semibold">Room:</span> {selectedItem.room}</div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                )}
                            </div>
                        ) : (
                            <div className="text-center text-muted-foreground">
                                {activeView === "new" ? "Fill out the form to create a new request" : "Select an item to view details"}
                            </div>
                        )
                    }
                </div>
            </div>
        </>

226,86,18,840