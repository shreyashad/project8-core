"use client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { Separator } from "@/components/ui/separator";
import { TooltipProvider } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { useState } from "react";
import HODTrainingRequestForm from "./hod-training-request-form";
import { CalendarIcon, Clock, Inbox, Plus, Send } from "lucide-react";

export function TrainingSystem({ 
    requestlist, 
    courselist, 
    employeelist, 
    traineradminlist, 
    defaultLayout = [20, 32, 48],
    defaultCollapsed = false,
    navCollapsedSize,
    }) {
        const [isCollapsed, setIsCollapsed] = useState(defaultCollapsed);
        const [activeView, setActiveView] = useState("inbox");
        const [selectedRequest, setSelectedRequest] = useState(null);

        const NavItem = ({ icon: Icon, label, view }) => (
            <Button
                className={cn(
                    "flex item-center gap-2 px-4 py-2 w-full text-left hover:bg-primary rounded-md",
                    activeView === view && "bg-primary"
                )}
                onClick={() => setActiveView(view)}
            >   
                <Icon className="h-5 w-5" />
                {!isCollapsed && <span>{label}</span>}
            </Button>
        );

        const RequestList = ({ items }) => {
            if (items.length === 0) {
                return <div>No training request available</div>;
            }
            return(
                <div className="space-y-2">
                    {items.map((item) => (
                        <Card key={item.id} className="cursor-pointer" onClick={() => setSelectedRequest(item)}>
                            <CardHeader>
                                <CardTitle>{item.course}</CardTitle>
                                <CardDescription>
                                    <Badge variant={item.status === "Pending" ? "secondary" : "success"}>
                                        {item.status}
                                    </Badge>
                                </CardDescription>
                            </CardHeader>
                            <CardFooter>{item.created_at}</CardFooter>
                        </Card>
                    ))}
                </div>
            );
        };

        const filteredRequests = requestlist.filter((r) => {
            switch (activeView) {
                case "inbox":
                    return true;
                case "sent":
                    return r.status === "Sent";
                case "pending":
                    return r.status === "Pending";
                case "scheduled":
                    return r.status === "Scheduled";
                default:
                    return false;
            }
        });

        return(
            <TooltipProvider delayDuration={0}>
                <ResizablePanelGroup
                    direction="horizontal"
                    onLayout={(sizes) => {
                        document.cookie = `react-resizable-panels:layout:mail=${JSON.stringify(
                            sizes
                        )}`;
                    }}
                    className="h-full max-h-[800px] items-stretch"
                >
                    <ResizablePanel
                        defaultSize={defaultLayout[0]}
                        collapsedSize={navCollapsedSize}
                        collapsible={true}
                        minSize={15}
                        maxSize={20}
                        onCollapse={() => {
                            setIsCollapsed(true);
                            document.cookie = `react-resizable-panels:collapsed=${JSON.stringify(
                            true
                            )}`;
                        }}
                        onResize={() => {
                            setIsCollapsed(false);
                            document.cookie = `react-resizable-panels:collapsed=${JSON.stringify(
                            false
                            )}`;
                        }}
                        className={cn(
                            isCollapsed && "min-w-[50px] transition-all duration-300 ease-in-out"
                        )}
                    >
                        <Separator/>
                        <div className="flex flex-col space-y-2 p-4">
                        <h1
                            className={cn(
                                "text-2xl font-bold mb-4",
                                isCollapsed && "hidden"
                            )}
                            >
                            Training Requests
                        </h1>
                            <NavItem icon={Inbox} label="Inbox" view="inbox" />
                            <NavItem icon={Send} label="Sent Requests" view="sent" />
                            <NavItem icon={Clock} label="Pending" view="pending" />
                            <NavItem icon={CalendarIcon} label="Scheduled" view="scheduled" />
                            {!isCollapsed && (
                                <Button className="mt-4" onClick={() => setActiveView("new")}>
                                    + New Request
                                </Button>
                            )}
                        </div>
                        {/* <div className="flex flex-col space-y-2 p-4">
                            <button
                                className={cn(
                                    "py-2 px-4 rounded",
                                    activeView === "new" ? "bg-blue-500 text-white" : "bg-gray-200"
                                )}
                                onClick={() => setActiveView("new")}
                            >
                                New Request
                            </button>
                            {requestlist.map((request) => (
                                <button
                                    key={request.id}
                                    className={cn(
                                        "py-2 px-4 rounded",
                                        selectedRequest?.id === request.id ? "bg-blue-500 text-white" : "bg-gray-200"
                                    )}
                                    onClick={() => {
                                        setActiveView("details");
                                        setSelectedRequest(request);
                                    }}
                                >
                                    {request.title}
                                </button>
                            ))}
                        </div> */}
                    </ResizablePanel>
                    {/* Middle Panel */}
                    <ResizableHandle withHandle />
                    <ResizablePanel defaultSize={defaultLayout[1]} minSize={30}>
                        <div className="p-4">
                            <h2 className="text-xl font-semibold mb-4">
                                {activeView === "new"
                                    ? "Requests"
                                    : activeView.charAt(0).toUpperCase() + activeView.slice(1) + " Requests"}
                            </h2>
                            {activeView === "new" ? (
                                <div className="text-gray-500">Select a request or create a new one.</div>
                            ) : (
                                <RequestList items={filteredRequests} />
                            )}
                        </div>  
                    </ResizablePanel>
                    {/* Details Panel */}
                    <ResizableHandle withHandle />
                    <ResizablePanel  defaultSize={defaultLayout[2]} minSize={30}>
                        <div className="p-4">
                            {activeView === "new" ? (
                                <HODTrainingRequestForm courseList={courselist} receiverList={traineradminlist} employeeList={employeelist}/>
                            ): selectedRequest ? (
                                <div>
                                    <h2 className="text-xl font-semibold">{selectedRequest.title}</h2>
                                    <p>{selectedRequest.additional_notes}</p>
                                    {/* Additional details */}
                                </div>
                            ) : (
                                <div className="text-gray-500">No request selected</div>
                            )}
                        </div>   
                    </ResizablePanel>
                </ResizablePanelGroup>
            </TooltipProvider>
        );
};