"use client";
import { createTrainingRequest } from "@/app/api/server/route";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import MultiSelect from "@/components/ui/multi-select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { TrainingRequestSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { Check, ChevronsUpDown } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";

const HODTrainingRequestForm = ({ courseList, receiverList, employeeList, onAddNewRequest }) => {
    const {data: session} = useSession();
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const [selectedReceiver, setSelectedReceiver] = useState("");

    const form = useForm({
        resolver: zodResolver(TrainingRequestSchema),
        defaultValues: {
            course:"",
            receiver:"",
            preferred_mode:"",
            employees: [],
            additional_notes:"",
            status:"pending",
        },
    });

    const employeeOptions = employeeList.map((employee) => ({
        label: employee.username,  // Displayed option in MultiSelect
        value: employee.id,        // Value that gets stored when selected
    }));


    const handleRequestSubmit = async (values) => {
        console.log("Form Submit triggered!");
        console.log("Form Values:", values);
        const formattedValues = {
            course: values.course,
            employees: values.employees,
            receiver: values.receiver,
            preferred_mode: values.preferred_mode,
            additional_notes: values.additional_notes,
            status: "Pending", 
        };


        setLoading(true);
        try {
            const response = await createTrainingRequest(session.accessToken, formattedValues);
            console.log("API Response:", response);
            
            if (response && !response.error) {
                toast.success("Training request created successfully!");
                setRequests((prevRequests) => [...prevRequests, formattedValues]);  // Add to requests
            } else {
                toast.error(response?.error || "Failed to create training request. Please try again.");
            }
        } catch (error) {
            console.error("Error submitting training request:", error);
            toast.error(error.message || "An error occurred. Please try again.");
        } finally {
            setLoading(false);
        }
    };


   

    return(
        <Card>
            <CardHeader>
                <CardTitle>New Training Request</CardTitle>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={(e) => {
                        e.preventDefault();
                        console.log("Form Submit Triggred!");
                        handleRequestSubmit(form.getValues());
                    }}
                    >
                        <div className="space-y-6">
                            <FormField 
                                control={form.control}
                                name="receiver"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>To  </FormLabel>
                                        <FormControl>
                                            <Popover open={open} onOpenChange={setOpen}>
                                                <PopoverTrigger asChild>
                                                    <Button>
                                                        {selectedReceiver || "Select Trainer's Admin "}
                                                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                                    </Button>
                                                </PopoverTrigger>
                                                <PopoverContent className="w-[200px] p-0">
                                                    <Command>
                                                        <CommandInput placeholder="Search receiver..." />
                                                        <CommandList>
                                                            <CommandEmpty> No receiver found. </CommandEmpty>
                                                            <CommandGroup>
                                                                {receiverList?.map((receiver) => (
                                                                    <CommandItem
                                                                        key={receiver.id}
                                                                        onSelect={() => {
                                                                            setSelectedReceiver(receiver.username);
                                                                            form.setValue('receiver', receiver.id);
                                                                            setOpen(false);
                                                                        }}
                                                                    >
                                                                        <Check
                                                                            className={`mr-2 h-4 w-4 ${selectedReceiver === receiver.id ? "opacity-100" : "opacity-0"}`}
                                                                        />
                                                                        {receiver.username}
                                                                    </CommandItem>
                                                                ))}
                                                            </CommandGroup>
                                                        </CommandList>
                                                    </Command>
                                                </PopoverContent>
                                            </Popover>
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <FormField 
                                    control={form.control}
                                    name="course"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Course Topic </FormLabel>
                                            <Select 
                                                disabled={loading || !courseList?.length}
                                                onValueChange={(value) => {
                                                    const selectedCourse = courseList.find(course => course.id === value);
                                                    if (selectedCourse) {
                                                        form.setValue('course', selectedCourse.id);
                                                    }
                                                }}
                                                value={field.value || ''}
                                            >
                                                <FormControl>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder={courseList?.length > 0 ? "Course Topic": "No Courses available"} />
                                                    </SelectTrigger>
                                                </FormControl>
                                                <SelectContent>
                                                    {courseList?.length > 0 ? (
                                                        courseList.map((course) => (
                                                            <SelectItem key={course.id} value={course.id}>
                                                                {course.title}
                                                            </SelectItem>
                                                        ))
                                                    ) : (
                                                        <SelectItem disabled>No Course found</SelectItem>
                                                    )}
                                                </SelectContent>
                                            </Select>
                                        </FormItem>
                                    )}
                                />
                                
                            </div>
                            <div className="space-y-2">
                                <FormField
                                    control={form.control}
                                    name="preferred_mode"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Training Mode</FormLabel>
                                            <Select
                                                disabled={loading}
                                                onValueChange={field.onChange}
                                                value={field.value}
                                            >
                                                <FormControl>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Training Mode" />
                                                    </SelectTrigger>
                                                </FormControl>
                                                <SelectContent>
                                                    <SelectItem value="online">Online</SelectItem>
                                                    <SelectItem value="offline">Offline</SelectItem>
                                                    <SelectItem value="self-learning">Self-learning</SelectItem>
                                                </SelectContent>
                                            </Select>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>
                        </div>
                        <FormField
                            control={form.control}
                            name="employee"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Employees</FormLabel>
                                    <FormControl>
                                        <MultiSelect
                                            options={employeeOptions}
                                            onValueChange={(value) => form.setValue('employees', value)}
                                            defaultValue={field.value}
                                            placeholder="Select employees"
                                            variant="inverted"
                                            animation={2}
                                           
                                        />
                                    </FormControl>
                                    <FormDescription>
                                        Choose the Employees you are want training for.
                                    </FormDescription>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField 
                            control={form.control}
                            name="additional_notes"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Additional Notes</FormLabel>
                                    <FormControl>
                                        <Textarea
                                            {...field}
                                            placeholder="Additional Notes"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <div className="mt-4 space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {loading ? 'Submitting...' : 'Submit Request'}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => router.back()}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>

                </Form>
            </CardContent>
        </Card>
    );
};

export default HODTrainingRequestForm;