// /components/hod/training-request/hod-sidebar.js
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Inbox, Send, Clock, CalendarIcon, PlusCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function HODSidebar({ setActiveView }) {
  const [activeView, setActive] = useState('inbox');

  const handleNavClick = (view) => {
    setActive(view);
    setActiveView(view); // Update parent component with the selected view
  };

  return (
    <div className="w-64 border-r p-4 flex flex-col">
      <h1 className="text-2xl font-bold mb-6">Training Request Management</h1>
      <nav className="space-y-2 mb-16">
        <NavItem
          icon={Inbox}
          label="Inbox"
          view="inbox"
          isActive={activeView === 'inbox'}
          onClick={handleNavClick}
        />
        <NavItem
          icon={Send}
          label="Sent Requests"
          view="sent"
          isActive={activeView === 'sent'}
          onClick={handleNavClick}
        />
        <NavItem
          icon={Clock}
          label="Pending"
          view="pending"
          isActive={activeView === 'pending'}
          onClick={handleNavClick}
        />
        <NavItem
          icon={CalendarIcon}
          label="Scheduled"
          view="scheduled"
          isActive={activeView === 'scheduled'}
          onClick={handleNavClick}
        />
      </nav>
      <Button
        className="mt-auto"
        onClick={() => setActiveView('new')}
      >
        <PlusCircle className="mr-2 h-4 w-4" /> New Request
      </Button>
    </div>
  );
}

function NavItem({ icon: Icon, label, view, isActive, onClick }) {
  return (
    <Button
      className={cn(
        'flex items-center gap-2 px-4 py-2 w-full text-left hover:bg-primary rounded-md',
        isActive && 'bg-primary'
      )}
      onClick={() => onClick(view)}
    >
      <Icon className="h-5 w-5" />
      <span>{label}</span>
    </Button>
  );
}
