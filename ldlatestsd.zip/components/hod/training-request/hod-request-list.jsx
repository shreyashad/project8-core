// /components/hod/training-request/hod-request-list.js
'use client';

export default function HODRequestList({ requests, activeView }) {
  // Filter the requests based on activeView
  const filteredRequests = requests.filter(request => {
    switch (activeView) {
      case 'inbox':
        return request.status !== 'Sent';
      case 'sent':
        return request.status === 'Sent';
      case 'pending':
        return request.status === 'Pending';
      case 'scheduled':
        return request.status === 'Scheduled';
      default:
        return true;
    }
  });

  return (
    <div className="space-y-2">
      {filteredRequests.length === 0 ? (
        <p>No requests available for this view.</p>
      ) : (
        filteredRequests.map(request => (
          <div key={request.id} className="cursor-pointer">
            <div className="font-semibold">{request.course_info.title}</div>
            <div className="text-sm text-muted-foreground">{request.created_at}</div>
            <div>{request.status}</div>
          </div>
        ))
      )}
    </div>
  );
}
