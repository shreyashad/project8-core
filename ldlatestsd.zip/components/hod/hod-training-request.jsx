"use client";
import { cn } from "@/lib/utils";
import { Button } from "../ui/button";
import { useState } from "react";
import { CalendarIcon, Check, ChevronsUpDown, Clock, Inbox, PlusCircle, Send } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { Label } from "../ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "../ui/command";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Textarea } from "../ui/textarea";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { TrainingRequestSchema } from "@/schema";
import { createTrainingRequest } from "@/app/api/server/route";
import HODTraininRequestNavBar from "./training-request/hod-sidebar";
import { HODTrainingRequestForm } from "./training-request/hod-training-request-form";
import { TrainingRequestList } from "../trainers-admin/training-request/training-request-list";

export default function HODTrainingRequestSystem({ courseslist, receiverData, employeeslist, initialRequests }) {
    const [activeView, setActiveView] = useState("inbox")
    const [selectedRequest, setSelectedRequest] = useState(null);
    const [requests, setRequests] = useState(initialRequests)
    return(
        <div className="flex h-screen bg-background">
        <HODTraininRequestNavBar activeView={activeView} setActiveView={setActiveView} /> {/* Pass setActiveView */}
        <div className="flex-1 flex">
            <div className="w-1/3 border-r p-4 overflow-auto">
                <h2>
                    { 
                        activeView === "new" ? "New Training Request" : 
                        activeView === "inbox" ? "Incoming Requests (Replies)" :
                        activeView === "sent" ? "Sent Requests" :
                        activeView === "scheduled" ? "Scheduled Trainings" :
                        activeView === "pending" ? "Pending Requests" : "Scheduled Trainings"
                    }
                </h2>

                {/* Conditionally render content based on activeView */}
                {activeView === "new" && <HODTrainingRequestForm />}
                {activeView === "inbox" && <TrainingRequestList requests={requests}  setSelectedRequest={setSelectedRequest} selectedRequest={selectedRequest}/>}
                {activeView === "sent" && <TrainingRequestList requests={requests}  setSelectedRequest={setSelectedRequest} selectedRequest={selectedRequest} />}
                {activeView === "scheduled" && <TrainingRequestList requests={requests}  setSelectedRequest={setSelectedRequest} selectedRequest={selectedRequest} />}
                {activeView === "pending" && <TrainingRequestList  requests={requests}  setSelectedRequest={setSelectedRequest} selectedRequest={selectedRequest} />}
            </div>
        </div>
    </div>
    );
}
  
