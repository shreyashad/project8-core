"use client";


import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { signIn, useSession } from "next-auth/react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";




export default function LoginPage() {
    const [formData, setFormData] = useState({
        username: "",
        password: "",
    });
    const [errorMessage, setErrorMessage] = useState(null);
    const [successMessage, setSuccessMessage] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const router = useRouter();
    const { data: session, status } = useSession();


    useEffect(() => {
        if (status === "loading") return;

        if (session?.user) {
            const userRole = session.user.roles;
            console.log("user role details:", userRole);
            if (!userRole) {
                setErrorMessage("User role not found. Please contact support.");
                return;
            }

            switch (userRole) {
                case "Administrator":
                    router.push("/dashboard/administrator");
                    break;
                case "Authenticator":
                    router.push("/dashboard/authenticator");
                    break;
                case "Site Admin":
                    router.push("/dashboard/site-admin");
                    break;
                default:
                    router.push("/");
            }
        }
    }, [session, status, router]);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setIsLoading(true);
        setErrorMessage("");
        setSuccessMessage("");

        const { username, password } = formData
        try {
           
            const response = await signIn("credentials", {
                username,
                password,
                redirect: false,
            });

            if (response?.error) {
                setErrorMessage(response.error);
            } else {
                setSuccessMessage("Login successful. Redirecting...");
                
            }
        } catch (error) {
            console.error('Login error:', error.response ? error.response.data : error.message);
            setErrorMessage(error.message || 'An unexpected error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleChange = (event) => {
        setFormData({ ...formData, [event.target.name]: event.target.value });
    };

    return (
        <div>
            <Card className="mx-auto max-w-sm shadow-2xl">
                <CardHeader>
                    <CardTitle className="text-2xl text-center font-semibold tracking-tight py-5">🔐 Login</CardTitle>
                    <CardDescription>Please enter your credentials to login your account</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid gap-4">
                        {(errorMessage || successMessage) && (
                            <Alert variant={errorMessage ? "destructive" : "success"}>
                                <AlertTitle>{errorMessage ? "Error:" : "Success:"}</AlertTitle>
                                <AlertDescription>{errorMessage || successMessage}</AlertDescription>
                            </Alert>
                        )}
                        <form onSubmit={handleSubmit}>
                            <div className="grid gap-2">
                                <Label>Username</Label>
                                <Input 
                                    type="text"
                                    id="username"
                                    name="username"
                                    value={formData.username}
                                    onChange={handleChange}
                                    disabled={isLoading}
                                    required
                                />
                                
                            </div>
                            <div className="grid gap-2">
                                <div className="flex items-center">
                                    <Label>Password</Label>
                                    <Link href="/auth/forget-password" className="ml-auto inline-block text-sm underline">
                                            Forgot password?
                                    </Link>
                                </div>
                                <Input 
                                    type="password"
                                    id="password"
                                    name="password"
                                    value={formData.password}
                                    onChange={handleChange}
                                    disabled={isLoading}
                                    required
                                />
                               
                            </div>
                           
                            <div className="mt-4">
                                <Button 
                                    type="submit" 
                                    disabled={isLoading} 
                                    className="w-full bg-blue-500 text-white py-2 rounded"
                                >
                                    {isLoading ? "Logging in..." : "Login"}
                                </Button>
                            </div>
                        </form>
                    </div>
                    <div className="mt-4 text-center text-sm">
                            Don&apos;t have an account?{" "}
                            <Link href="/register" className="underline">Sign Up</Link>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
