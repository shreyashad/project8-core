import { auth } from "@/auth";
import { RolesColumns } from "@/components/administrator/roles-permission/roles-management/roles-columns";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";
import { fetchRolesListData } from "@/lib/administrator/rolesPermission_api";



export default async function RolesManagementPage() {
    const session = await auth();

    const rolesData = await fetchRolesListData(session.accessToken);

    const facetedFilters = [
        {
          id: "application",
          title: "Application",
          options:[]
        },
       
    ];
   
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/roles-permission/roles"
                mdipagetitle="Roles & Permission Management"
                pagetitle="Roles"
            />
                
                <Separator />
                <DataTable 
                  data={rolesData}
                  columns={RolesColumns}
                  globalFilterColumnId="name"
                  facetedFilters={facetedFilters}
        
                />
        </div>

    );
};