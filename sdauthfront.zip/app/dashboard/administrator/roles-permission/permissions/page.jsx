import { auth } from "@/auth";
import { PermissionClient } from "@/components/administrator/roles-permission/permission-management/permission-client";
import { PermissionColumns } from "@/components/administrator/roles-permission/permission-management/permission-columns";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";
import { fetchPermissionListData } from "@/lib/administrator/rolesPermission_api";



export default async function PermissionManagementPage() {
    const session = await auth();

    const permissionData = await fetchPermissionListData(session.accessToken);

    const facetedFilters = [
        {
          id: "application",
          title: "Application",
          options:[]
        },
       
    ];

    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/roles-permission/permission"
                mdipagetitle="Roles & Permission Management"
                pagetitle="Permission"
            />
                <PermissionClient />
                <Separator />
                <DataTable 
                    data={permissionData}
                    columns={PermissionColumns}
                    globalFilterColumnId="name"
                    facetedFilters={facetedFilters}
        
                />
        </div>
    
    );
}