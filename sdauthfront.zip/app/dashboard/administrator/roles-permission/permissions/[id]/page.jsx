import { auth } from "@/auth";
import { PermissionForm } from "@/components/administrator/roles-permission/permission-management/permission-form";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { fetchApplicationListData } from "@/lib/administrator/applications_api";
import { fetchPermissionDetails } from "@/lib/administrator/rolesPermission_api";


function getPermissionId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode org ID');
        return data;
    }
}



export default async function EditPermission({ params }) {
    const { id } = await params;
    const session = await auth();

    if (!session){
        redirect("/login");
    }

    
    let initialData = null;
    if (id) {
            // Fetch existing application for edit
            try {
                initialData = await fetchPermissionDetails(id, session.accessToken);
            } catch (error) {
                console.error("Error fetching application:", error);
            }
    }

    const appData = await fetchApplicationListData(session.accessToken);

    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="/dashboard/administrator"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/roles-permission/permissions"
                mdipagetitle="Roles & Permission Management"
                pagetitle="Permission"
            />
            <PermissionForm initialData={initialData} appData={appData}/>
        </div>
        
    );




};