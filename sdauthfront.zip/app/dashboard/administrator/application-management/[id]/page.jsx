import { auth } from "@/auth";
import { AppForm } from "@/components/administrator/applications/app-form";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { fetchApplicationDetails } from "@/lib/administrator/applications_api";

function getAppId(data) {
    try {
        return decodeURIComponent(data);
    } catch(error) {
        console.error('Failed to decode app Id')
        return data;
    }
};

export default async function EditApp({ params }) {
    const { id } = params;
    const session = await auth();
    
    if (!session){
        redirect("/login");
    }

    

    let initialData = null;
    if (id) {
        // Fetch existing application for edit
        try {
            initialData = await fetchApplicationDetails(id, session.accessToken);
        } catch (error) {
            console.error("Error fetching application:", error);
        }
    }

    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="/dashboard/administrator"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/application-management/"
                mdipagetitle="Application Management"
                pagetitle="Applicaion"
            />
            <AppForm initialData={initialData} />
        </div>
        
    );
};