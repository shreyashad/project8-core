import { auth } from "@/auth";
import { AppCellAction } from "@/components/administrator/applications/app-cell-actions";
import { AppClient } from "@/components/administrator/applications/app-client";
import { ApplicationColumns } from "@/components/administrator/applications/app-columns";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";

import {  fetchApplicationListData } from "@/lib/administrator/applications_api";


export default async function ApplicationManagementPage() {
    const session = await auth();

    const appData = await fetchApplicationListData(session.accessToken);
    
    const facetedFilters = [
      {
        id: "active",
        title: "Status",
       
      },
     
    ];
     
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
              homelink="administrator/dashboard"
              hometitle="Dashboard"
              mdipagelink="/dashboard/administrator/application-management/"
              mdipagetitle="Application Management"
              pagetitle="Applicaion"
            />
        <AppClient />
        <Separator />
        <DataTable 
          data={appData}
          columns={ApplicationColumns}
          globalFilterColumnId="name"
          facetedFilters={facetedFilters}

        />
        </div>
        
    );
};