"use client";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { StatsCard } from "@/components/common/stats-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip } from "@/components/ui/tooltip";
import { LogInIcon } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, XAxis, YAxis } from "recharts";


export default function ReportManagementPage() {
    
const loginData = [
    { day: 'Mon', logins: 1000 },
    { day: 'Tue', logins: 1200 },
    { day: 'Wed', logins: 1500 },
    { day: 'Thu', logins: 1300 },
    { day: 'Fri', logins: 1400 },
    { day: 'Sat', logins: 800 },
    { day: 'Sun', logins: 700 },
  ]
  
  const userTypeData = [
    { name: 'Regular Users', value: 70 },
    { name: 'Premium Users', value: 20 },
    { name: 'Admin Users', value: 10 },
  ]
  
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28']
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="dashboard/administrator/"
                hometitle="Dashboard"
                mdipagelink="dashboard/administrator/logs-report/reports"
                mdipagetitle="Log & Reports Management"
                pagetitle="Report Management"
            />
            <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h1 className="text-3xl font-bold">Reports & Analytics</h1>
                <div className="flex gap-2">
                <Select defaultValue="7days">
                    <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select time range" />
                    </SelectTrigger>
                    <SelectContent>
                    <SelectItem value="7days">Last 7 days</SelectItem>
                    <SelectItem value="30days">Last 30 days</SelectItem>
                    <SelectItem value="3months">Last 3 months</SelectItem>
                    </SelectContent>
                </Select>
                <Button>Export Report</Button>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <StatsCard 
                    title="Total login"
                    icon= {<LogInIcon className="h-5 w-5"/>}
                
                />
                <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Logins</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">24,567</div>
                    <p className="text-xs text-muted-foreground">+5.2% from last period</p>
                </CardContent>
                </Card>
                <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Average Session Duration</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">18m 32s</div>
                    <p className="text-xs text-muted-foreground">-2.1% from last period</p>
                </CardContent>
                </Card>
                <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">New User Registrations</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">1,274</div>
                    <p className="text-xs text-muted-foreground">+12.5% from last period</p>
                </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                <CardTitle>Login Activity</CardTitle>
                </CardHeader>
                <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={loginData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="logins" fill="#8884d8" />
                    </BarChart>
                </ResponsiveContainer>
                </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-2">
                <Card>
                <CardHeader>
                    <CardTitle>User Types Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                        <Pie
                        data={userTypeData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                        {userTypeData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                        </Pie>
                        <Tooltip />
                    </PieChart>
                    </ResponsiveContainer>
                </CardContent>
                </Card>
                <Card>
                <CardHeader>
                    <CardTitle>Top 5 Applications by Usage</CardTitle>
                </CardHeader>
                <CardContent>
                    <ul className="space-y-2">
                    <li className="flex justify-between items-center">
                        <span>App 1</span>
                        <span>45%</span>
                    </li>
                    <li className="flex justify-between items-center">
                        <span>App 2</span>
                        <span>30%</span>
                    </li>
                    <li className="flex justify-between items-center">
                        <span>App 3</span>
                        <span>15%</span>
                    </li>
                    <li className="flex justify-between items-center">
                        <span>App 4</span>
                        <span>7%</span>
                    </li>
                    <li className="flex justify-between items-center">
                        <span>App 5</span>
                        <span>3%</span>
                    </li>
                    </ul>
                </CardContent>
                </Card>
            </div>
            </div>
        </div>


    );
}