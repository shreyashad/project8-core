import { auth } from "@/auth";
import { OrganizationClient } from "@/components/administrator/organization-management/organization/organization-client";
import { OrganizationColumns } from "@/components/administrator/organization-management/organization/organization-columns";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";
import { fetchOrganizationListData } from "@/lib/administrator/org_api";



export default async function OrganizationManagementPage() {
    const session = await auth();

    const orgData = await fetchOrganizationListData(session.accessToken);

    const facetedFilters = [
        {
          id: "org_type",
          title: "Organization Type",
          options: [
            { label: "MDIndia", value: "MDIndia" },
            { label: "Insurance Company", value: "Insurance Company" },
            { label: "Broker", value: "Broker"},
            { label: "Corporate", value: "Corporate"}
          ],
        },
       
    ];
    
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="administrator/org-management/organization"
                mdipagetitle="Organization Management"
                pagetitle="Organization"
            />
            <OrganizationClient />
            <Separator />
            <DataTable 
                data={orgData}
                columns={OrganizationColumns}
                globalFilterColumnId="name"
                facetedFilters={facetedFilters}
    
            />
        </div>
    );
};