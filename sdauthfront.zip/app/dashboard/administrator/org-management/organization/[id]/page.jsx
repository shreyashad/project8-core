import { auth } from "@/auth";
import { OrganizationForm } from "@/components/administrator/organization-management/organization/organization-form";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { fetchOrganizationDetails, fetchOrgTypeListData } from "@/lib/administrator/org_api";



export default async function EditOrganization({ params }) {
    const  { id } = params;
    const session = await auth();

    const orgTypeData = await fetchOrgTypeListData(session.accessToken);

    if (!session) {
        redirect("/login");
    }


    let initialData = null;
    if (id) {
        try {
            initialData = await fetchOrganizationDetails(id, session.accessToken);
        } catch (error) {

        }
    }

    return(
            <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
                <DashboradBreadCrumb 
                    homelink="administrator/dashboard"
                    hometitle="Dashboard"
                    mdipagelink="administrator/org-management/organization"
                    mdipagetitle="Organization  Management"
                    pagetitle="Organization"
                />
                <OrganizationForm initialData={initialData} orgTypedata={orgTypeData}/>
            </div>
            
    );
};