import { auth } from "@/auth";
import { OrgTypeForm } from "@/components/administrator/organization-management/orgtype/orgtype-form";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { fetchOrgTypeDeatils } from "@/lib/administrator/org_api";

function getAppId(data) {
    try {
        return decodeURIComponent(data);
    } catch(error) {
        console.error('Failed to decode app Id')
        return data;
    }
};

export default async function EditOrgType({ params }) {
    const { id } = params;
    const session = await auth();
    
    if (!session){
        redirect("/login");
    }

    

    let initialData = null;
    if (id) {
        // Fetch existing application for edit
        try {
            initialData = await fetchOrgTypeDeatils(id, session.accessToken);
        } catch (error) {
            console.error("Error fetching application:", error);
        }
    }

    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="administrator/application-management/"
                mdipagetitle="Application Management"
                pagetitle="Applicaion"
            />
            <OrgTypeForm initialData={initialData} />
        </div>
        
    );
};