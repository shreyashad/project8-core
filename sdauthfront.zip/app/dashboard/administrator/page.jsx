import { auth } from "@/auth";
import { PieChartCard } from "@/components/common/charts/pie-chart-card";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { StatsCard } from "@/components/common/stats-card";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";



export default async function AdministratorPage() {
    const session = await auth();
    console.log("admin session details:", session);
   
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="dashboard/administrator/"
                hometitle="Dashboard"
                mdipagelink="dashboard/administrator/"
                mdipagetitle="Log & Reports Management"
                pagetitle="Report Management"
            />
            <div className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                    <StatsCard />
                    <StatsCard />
                    <StatsCard />
                    <StatsCard />
                </div>
                <div className="grid gap-6 md:grid-cols-2">
                    <div className="col-8">
                        <div className="grid gap-6 md:grid-cols-2">
                            {/* <PieChartCard 
                                title="Users By Application"
                                description="On-line users by applications"
                                
                            /> */}
                        </div>
                    </div>
                    
                    
                    <Calendar />
                </div>
                <Card>
                    <CardHeader>
                        <CardTitle></CardTitle>
                    </CardHeader>
                </Card>
            </div>
        </div>
    );
}