"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { createNewOrganization, updateOrganizationDetails } from "@/lib/administrator/org_api";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash } from "lucide-react";
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";



export const OrganizationForm = ({ initialData, orgTypedata }) => {
    const {data: session} = useSession();
    const router = useRouter();

    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Application" : "Create Application";
    const description = initialData && initialData.id ? "Edit an Application" : "Create a new Application";
    const toastMessage = initialData && initialData.id ? "Application updated successfully" : "Application created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";


    const form = useForm({
        resolver: zodResolver(),
        defaultValues: initialData || {
            name: "",
            org_type: "",
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try{
            if (initialData && initialData.id) {
                const updateForm = await updateOrganizationDetails(session.accessToken, initialData.id, values);
                console.log("Update Response:", updateForm);
            } else {
                const newOrganization = createNewOrganization(session.accessToken, values);
                console.log("Create Response:", newOrganization);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/application-management`);
        } catch(error) {
            console.error("Submission Error:", error.response || error.message);
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };

    return(
        <Card className="border-2 shadow-2xl">
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <div className="flex items-center justify-between">
                    <CardDescription>{description}</CardDescription>
                    {initialData && initialData.id && (
                        <Button
                            disabled={loading}
                            variant="destructive"
                            size="icon"
                            onClick={() => setOpen(true)}
                        >
                            <Trash className="h-4 w-4" />
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid-cols-2 gap-8 md:grid pb-5">
                            <FormField 
                                control={form.control}
                                name="org_type"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Organization Type</FormLabel>
                                        <Select
                                            disabled={loading || !orgTypedata.length}
                                            onValueChange={field.onChange}
                                            value={field.value}
                                        >
                                            <FormControl>
                                                <SelectTrigger>
                                                    <SelectValue 
                                                        placeholder={
                                                            orgTypedata.length > 0
                                                                ? "Organization Type"
                                                                : "No ORG Type available"
                                                        }
                                                    />
                                                </SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                                {orgTypedata.length > 0 ? (
                                                    orgTypedata.map((orgtype) => (
                                                        <SelectItem key={orgtype.id} value={orgtype.org_type}>
                                                            {orgtype.org_type}
                                                        </SelectItem>
                                                    ))
                                                ): (
                                                    <SelectItem disabled>
                                                        No Org Type found
                                                    </SelectItem>
                                                )}
                                            </SelectContent>
                                        </Select>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField 
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Organization Name</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                placeholder="Name"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => {
                                    router.back();
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>

    );
};