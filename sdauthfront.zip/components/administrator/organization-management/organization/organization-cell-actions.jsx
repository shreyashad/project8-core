"use client";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { deleteApplicationDetails } from "@/lib/administrator/applications_api";
import { Pencil, Trash2 } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";


export function OrganizationCellAction({ data }) {
    const { data: session } = useSession();
    const router = useRouter();
    const [alertModalOpen, setAlertModalOpen] = useState(false);

    const handleEdit = () => {
        router.push(`/dashboard/administrator/org-management/organization/${data.id}`);
    };

    const deleteOrgType = async () => {
        try {
            await deleteApplicationDetails(data.id, session.accessToken);
            toast.success("Organization deleted successfully");
            setAlertModalOpen(false);
            router.refresh();
        } catch (error) {
            toast.error("Error deleting  Organization");
        }
    };
    return(
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={handleEdit}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update Organization</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={() => setAlertModalOpen(true)}
                        >
                            <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete Organization</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
        </div>
    );
};