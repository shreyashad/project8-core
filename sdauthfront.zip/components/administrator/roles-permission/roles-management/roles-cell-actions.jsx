"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";

export function RolesCellAction ({ data }) {
    const { data: session } = useSession();
    const router = useRouter();
    const [alertModalOpen, setAlertModalOpen] = useState(false);

    const handleEdit = () => {
        router.push(`/dashboard/administrator/roles-permission/roles/${data.id}`);
    };
};