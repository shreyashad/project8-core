"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";


export const RolesForm = ({ initialData }) => {
    const  {data: session } = useSession();
    const router = useRouter();

    const [open, setOpen] = useState();
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Application" : "Create Application";
    const description = initialData && initialData.id ? "Edit an Application" : "Create a new Application";
    const toastMessage = initialData && initialData.id ? "Application updated successfully" : "Application created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";


    const form = useForm({
        resolver: zodResolver(),
        defaultValues: initialData || {
            name: "",
            description: "",
            application: "",
            Permissions: "",
            default_for_application: false,
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try{
            if (initialData && initialData.id) {
               const updateform = await updateApplicationDetails(session.accessToken, initialData.id, values);
               console.log("Update Response:", updateform);
            } else {
                const newRole = await createNewApplication(session.accessToken, values);
                console.log("Create Response:", newRole);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/application-management`);
        } catch (error) {
            console.error("Submission Error:", error.response || error.message);
            toast.error(error.message);
        }
        finally {
            setLoading(false);
        }
    };
    return();
};