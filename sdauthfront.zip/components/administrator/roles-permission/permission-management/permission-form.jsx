"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { createNewPermission, updatePermissionDetails } from "@/lib/administrator/rolesPermission_api";
import { PermissionFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";

export const PermissionForm = ({ initialData, appData }) => {
    const { data: session } = useSession();
    const router = useRouter();

    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Application" : "Create Application";
    const description = initialData && initialData.id ? "Edit an Application" : "Create a new Application";
    const toastMessage = initialData && initialData.id ? "Application updated successfully" : "Application created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";
   
    
    const form = useForm({
        resolver: zodResolver(PermissionFormSchema),
        defaultValues: initialData || {
            name: "",
            description: "",
            application:"",
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try{
            if (initialData && initialData.id) {
                const updateForm = await updatePermissionDetails(session.accessToken, initialData.id, values);
                console.log("Update Response:", updateForm);
            } else {
                const newPermission = await createNewPermission(session.accessToken, values);
                console.log("Create Response:", newPermission);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/roles-permission/permissions`);
        } catch  (error) {
            console.error("Submission Error:", error.response || error.message);
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };

    return(
        <Card className="border-2 shadow-2xl">
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <div className="flex items-center justify-between">
                    <CardDescription>{description}</CardDescription>
                    {initialData && initialData.id && (
                        <Button
                            disabled={loading}
                            variant="destructive"
                            size="icon"
                            onClick={() => setOpen(true)}
                        >
                            <Trash className="h-4 w-4" />
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid-cols-2 gap-8 md:grid pb-5">
                            <FormField 
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Name</FormLabel>
                                        <FormControl>
                                            <Input 
                                                {...field}
                                                placeholder="Name"

                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <FormField 
                                control={form.control}
                                name="application"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Application</FormLabel>
                                        <Select
                                            disabled={loading || !appData.length}
                                            onValueChange={field.onChange}
                                            value={field.value}
                                        >
                                            <FormControl>
                                                <SelectTrigger>
                                                    <SelectValue 
                                                        placeholder={
                                                            appData.length > 0
                                                                ? "Application "
                                                                : "No Application available"
                                                        }
                                                    />
                                                </SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                                {appData.length > 0 ? (
                                                    appData.map((apps) => (
                                                        <SelectItem key={apps.id} value={apps.id}>
                                                            {apps.name}
                                                        </SelectItem>
                                                    ))
                                                ): (
                                                    <SelectItem disabled>
                                                        No Application found
                                                    </SelectItem>
                                                )}
                                            </SelectContent>
                                        </Select>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField 
                                control={form.control}
                                name="description"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Description</FormLabel>
                                        <FormControl>
                                            <Textarea
                                                {...field}
                                                placeholder="Description"
                                                rows={4}

                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => {
                                    router.back();
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};