"use client";

import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useRouter } from "next/navigation"

export const PermissionClient = () => {
    const router = useRouter();
    return(
        <div className="flex items-center justify-between">
            <h2 className="text-3xl font-bold tracking-tight">Permission Management</h2>
            <Button
                onClick={() => {
                    router.push("/dashboard/administrator/roles-permission/permissions/new");
                }}
            >
                <Plus className="mr-2 h-4 w-4" /> Add New
            </Button>
        </div>
    );
};