"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";

export const PieChartCard = ({ title, description, data, colors= [] }) => {
    return(
        <Card className="border-2 shadow-lg">
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                        <Pie
                            data={data}
                            dataKey="value"
                            nameKey="name"
                            outerRadius="80%"
                            label
                        >
                            {data.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={colors[index] || defaultColors[index % defaultColors.length]} />
                            ))}
                        </Pie>
                    </PieChart>
                    <Tooltip />
                </ResponsiveContainer>
            </CardContent>
        </Card>
    );
};