// components/PieChartCard.tsx
import React from 'react';
import { PieChart, Pie, Tooltip, Cell, ResponsiveContainer } from 'recharts';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";  // Assuming you have these UI components already defined in your project.

interface PieChartCardProps {
  title: string;
  description: string;
  data: { name: string; value: number }[]; // Data structure for Pie Chart
  colors?: string[]; // Optional: Custom colors for each segment of the pie chart
}

const PieChartCard: React.FC<PieChartCardProps> = ({ title, description, data, colors = [] }) => {
  
  // Default colors for the chart if no custom colors are provided
  const defaultColors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#FF6347', '#4682B4'];

  return (
    <Card className="border-2 shadow-lg">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="p-4">
        <ResponsiveContainer width="100%" height={250}>
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              outerRadius="80%" // You can adjust this to your preference
              label
            >
              {/* Render segments with custom colors */}
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colors[index] || defaultColors[index % defaultColors.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

export default PieChartCard;
<!-- src/components/PieChartCard.js -->
import React from 'react';
import { PieChart, Pie, Tooltip, Cell, ResponsiveContainer, Legend, AnimationDuration } from 'recharts';

// Default colors in case custom colors are not provided
const defaultColors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#FF6347', '#4682B4'];

const PieChartCard = ({ title, description, data, colors = [], onSliceClick }) => {
  
  // Default slice colors
  const chartColors = colors.length ? colors : defaultColors;

  return (
    <div className="pie-chart-card border-2 shadow-lg rounded-md p-4">
      <div className="card-header">
        <h3 className="text-xl font-bold">{title}</h3>
        <p className="text-sm text-gray-600">{description}</p>
      </div>
      
      <div className="card-content mt-4">
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              outerRadius="80%"
              label
              onClick={onSliceClick} // Handler for slice click
              animationDuration={1000} // Animation duration (1 second)
            >
              {/* Rendering slices with custom colors */}
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={chartColors[index % chartColors.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend verticalAlign="bottom" height={36} />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default PieChartCard;
