import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";

export const StatsCard = ({ title, value, desc, icon}) => {
    return(

        <Card className="border-2 drop-shadow-2xl">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-md font-medium">{title}</CardTitle>
                <CardDescription className="text-center justify-center">{icon}</CardDescription>
            </CardHeader>
            <CardContent>
            <div className="text-2xl font-bold">{value}</div>
            <p className="text-xs text-muted-foreground">{desc}</p>
            </CardContent>
        </Card>
    );
}