"use client";

import { X } from "lucide-react";
import { Button } from "@/registry/new-york/ui/button";
import { Input } from "@/registry/new-york/ui/input";
import { DataTableViewOptions } from "@/app/(app)/examples/tasks/components/data-table-view-options";
import { DataTableFacetedFilter } from "./data-table-faceted-filter";

export function DataTableToolbar({ table, globalFilterColumnId, facetedFilters = [] }) {
  const isFiltered = table.getState().columnFilters.length > 0;

  return (
    <div className="flex items-center justify-between">
      <div className="flex flex-1 items-center space-x-2">
        {globalFilterColumnId && (
          <Input
            placeholder={`Filter ${globalFilterColumnId}...`}
            value={(table.getColumn(globalFilterColumnId)?.getFilterValue() || "")}
            onChange={(event) =>
              table.getColumn(globalFilterColumnId)?.setFilterValue(event.target.value)
            }
            className="h-8 w-[150px] lg:w-[250px]"
          />
        )}
        {facetedFilters.map((filter) => (
          <DataTableFacetedFilter
            key={filter.id}
            column={table.getColumn(filter.id)}
            title={filter.title}
            options={filter.options}
          />
        ))}
        {isFiltered && (
          <Button
            variant="ghost"
            onClick={() => table.resetColumnFilters()}
            className="h-8 px-2 lg:px-3"
          >
            Reset
            <X />
          </Button>
        )}
      </div>
      <DataTableViewOptions table={table} />
    </div>
  );
}
-----------------
import React, { useState } from "react";
import { Check, PlusCircle } from "lucide-react";

import { cn } from "@/lib/utils";
import { Badge } from "@/registry/new-york/ui/badge";
import { Button } from "@/registry/new-york/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/registry/new-york/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/registry/new-york/ui/popover";
import { Separator } from "@/registry/new-york/ui/separator";

export function DataTableFacetedFilter({ column, title, options }) {
  const facets = column?.getFacetedUniqueValues();
  const selectedValues = new Set(column?.getFilterValue() || []);

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="h-8 border-dashed">
          <PlusCircle />
          {title}
          {selectedValues.size > 0 && (
            <>
              <Separator orientation="vertical" className="mx-2 h-4" />
              <Badge
                variant="secondary"
                className="rounded-sm px-1 font-normal lg:hidden"
              >
                {selectedValues.size}
              </Badge>
              <div className="hidden space-x-1 lg:flex">
                {selectedValues.size > 2 ? (
                  <Badge
                    variant="secondary"
                    className="rounded-sm px-1 font-normal"
                  >
                    {selectedValues.size} selected
                  </Badge>
                ) : (
                  options
                    .filter((option) => selectedValues.has(option.value))
                    .map((option) => (
                      <Badge
                        variant="secondary"
                        key={option.value}
                        className="rounded-sm px-1 font-normal"
                      >
                        {option.label}
                      </Badge>
                    ))
                )}
              </div>
            </>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[200px] p-0" align="start">
        <Command>
          <CommandInput placeholder={title} />
          <CommandList>
            <CommandEmpty>No results found.</CommandEmpty>
            <CommandGroup>
              {options.map((option) => {
                const isSelected = selectedValues.has(option.value);
                return (
                  <CommandItem
                    key={option.value}
                    onSelect={() => {
                      if (isSelected) {
                        selectedValues.delete(option.value);
                      } else {
                        selectedValues.add(option.value);
                      }
                      const filterValues = Array.from(selectedValues);
                      column?.setFilterValue(
                        filterValues.length ? filterValues : undefined
                      );
                    }}
                  >
                    <div
                      className={cn(
                        "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                        isSelected
                          ? "bg-primary text-primary-foreground"
                          : "opacity-50 [&_svg]:invisible"
                      )}
                    >
                      <Check />
                    </div>
                    {option.icon && (
                      <option.icon className="mr-2 h-4 w-4 text-muted-foreground" />
                    )}
                    <span>{option.label}</span>
                    {facets?.get(option.value) && (
                      <span className="ml-auto flex h-4 w-4 items-center justify-center font-mono text-xs">
                        {facets.get(option.value)}
                      </span>
                    )}
                  </CommandItem>
                );
              })}
            </CommandGroup>
            {selectedValues.size > 0 && (
              <>
                <CommandSeparator />
                <CommandGroup>
                  <CommandItem
                    onSelect={() => column?.setFilterValue(undefined)}
                    className="justify-center text-center"
                  >
                    Clear filters
                  </CommandItem>
                </CommandGroup>
              </>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
-------
"use client";
import { X } from "lucide-react";
import { Button } from "../button";
import { Input } from "../input";
import { DataTableViewOptions } from "./data-table-view-options";
import { DataTableFacetedFilter } from "./data-table-faceted-filter";

export function DataTableToolbar({ table, globalFilterColumnId, facetedFilters = [] }) {
    const isFiltered = table.getState().columnFilters.length > 0;

    // Function to generate dynamic filter options based on column data
    const getColumnOptions = (columnId) => {
        const column = table.getColumn(columnId);
        if (!column) return [];

        // Get the column data and extract unique values for filtering
        const columnData = table.getRowModel().rows.map(row => row.getValue(columnId));
        const uniqueOptions = Array.from(new Set(columnData)); // Get unique values
        return uniqueOptions;
    };

    return (
        <div className="flex item-center justify-between">
            <div className="flex flex-1 item-center space-x-2">
                {globalFilterColumnId && (
                    <Input
                        placeholder={`Filter ${globalFilterColumnId}...`}
                        value={(table.getColumn(globalFilterColumnId)?.getFilterValue() || "")}
                        onChange={(event) =>
                            table.getColumn(globalFilterColumnId)?.setFilterValue(event.target.value)
                        }
                        className="h-8 w-[150px] lg:w-[250px]"
                    />
                )}
                
                {facetedFilters.map((filter) => {
                    // Generate options dynamically for each filter
                    const options = getColumnOptions(filter.id);

                    return (
                        <DataTableFacetedFilter
                            key={filter.id}
                            column={table.getColumn(filter.id)}
                            title={filter.title}
                            options={options} // Dynamically generated options
                        />
                    );
                })}

                {isFiltered && (
                    <Button
                        variant="ghost"
                        onClick={() => table.resetColumnFilters()}
                        className="h-8 px-2 lg:px-3"
                    >
                        Reset
                        <X />
                    </Button>
                )}
            </div>
            <DataTableViewOptions table={table} />
        </div>
    );
}
------------
"use client";
import { X } from "lucide-react";
import { Button } from "../button";
import { Input } from "../input";
import { DataTableViewOptions } from "./data-table-view-options";
import { DataTableFacetedFilter } from "./data-table-faceted-filter";

// Updated to handle nested object filtering
export function DataTableToolbar({ table, globalFilterColumnId, facetedFilters = [] }) {
    const isFiltered = table.getState().columnFilters.length > 0;

    // Function to generate dynamic filter options based on column data
    const getColumnOptions = (columnId) => {
        const column = table.getColumn(columnId);
        if (!column) return [];

        // Get the column data and extract unique values for filtering
        const columnData = table.getRowModel().rows.map(row => {
            const value = row.getValue(columnId);
            if (value && typeof value === "object" && value.name) {
                return value.name; // Access nested property `name` for `application`
            }
            return value; // For non-nested data
        });

        const uniqueOptions = Array.from(new Set(columnData)); // Get unique values
        return uniqueOptions;
    };

    return (
        <div className="flex item-center justify-between">
            <div className="flex flex-1 item-center space-x-2">
                {globalFilterColumnId && (
                    <Input
                        placeholder={`Filter ${globalFilterColumnId}...`}
                        value={(table.getColumn(globalFilterColumnId)?.getFilterValue() || "")}
                        onChange={(event) =>
                            table.getColumn(globalFilterColumnId)?.setFilterValue(event.target.value)
                        }
                        className="h-8 w-[150px] lg:w-[250px]"
                    />
                )}
                
                {facetedFilters.map((filter) => {
                    const options = getColumnOptions(filter.id); // Generate dynamic options

                    return (
                        <DataTableFacetedFilter
                            key={filter.id}
                            column={table.getColumn(filter.id)}
                            title={filter.title}
                            options={options} // Dynamically generated options
                        />
                    );
                })}

                {isFiltered && (
                    <Button
                        variant="ghost"
                        onClick={() => table.resetColumnFilters()}
                        className="h-8 px-2 lg:px-3"
                    >
                        Reset
                        <X />
                    </Button>
                )}
            </div>
            <DataTableViewOptions table={table} />
        </div>
    );
}
--------------------

"use client";
import { X } from "lucide-react";
import { Button } from "../button";
import { Input } from "../input";
import { DataTableViewOptions } from "./data-table-view-options";
import { DataTableFacetedFilter } from "./data-table-faceted-filter";

// Helper function to dynamically get the filter value from the column data
const getColumnOptions = (columnId, table, getFilterValue) => {
  const column = table.getColumn(columnId);
  if (!column) return [];

  // Extract values from all rows using the provided `getFilterValue` function
  const columnData = table.getRowModel().rows.map((row) => {
    const value = row.getValue(columnId);
    
    // If getFilterValue is provided, use it to extract the value for the filter options
    if (getFilterValue) {
      return getFilterValue(value, row);
    }

    // Default: return value itself (if no getFilterValue function is provided)
    return value;
  });

  // Remove duplicates and return unique options
  return Array.from(new Set(columnData));
};

export function DataTableToolbar({
  table,
  globalFilterColumnId,
  facetedFilters = [],
}) {
  const isFiltered = table.getState().columnFilters.length > 0;

  return (
    <div className="flex items-center justify-between">
      <div className="flex flex-1 items-center space-x-2">
        {/* Global Filter Input */}
        {globalFilterColumnId && (
          <Input
            placeholder={`Filter ${globalFilterColumnId}...`}
            value={table.getColumn(globalFilterColumnId)?.getFilterValue() || ""}
            onChange={(event) =>
              table.getColumn(globalFilterColumnId)?.setFilterValue(event.target.value)
            }
            className="h-8 w-[150px] lg:w-[250px]"
          />
        )}

        {/* Dynamic Faceted Filters */}
        {facetedFilters.map((filter) => (
          <DataTableFacetedFilter
            key={filter.id}
            column={table.getColumn(filter.id)}
            title={filter.title}
            options={getColumnOptions(
              filter.id,
              table,
              filter.getFilterValue // Dynamically pass the function to extract the value for filtering
            )}
          />
        ))}

        {/* Reset Filters Button */}
        {isFiltered && (
          <Button
            variant="ghost"
            onClick={() => table.resetColumnFilters()}
            className="h-8 px-2 lg:px-3"
          >
            Reset
            <X />
          </Button>
        )}
      </div>
      <DataTableViewOptions table={table} />
    </div>
  );
}
const facetedFilters = [
  {
    id: "application", // Column ID
    title: "Application", // Filter title
    getFilterValue: (value) => value?.name || value, // Custom logic to extract the filter value (e.g., handle `value.name` or just `value`)
  },
  {
    id: "category", // Another filter column
    title: "Category",
    getFilterValue: (value) => value?.category || value, // Custom logic for category
  },
  // More filters...
];

<DataTableToolbar 
  table={table} 
  globalFilterColumnId="name" 
  facetedFilters={facetedFilters}
/>
-------------
// Utility function to safely access a nested property (e.g., value.application.name)
const getNestedValue = (obj, path) => {
  return path.split('.').reduce((acc, part) => (acc ? acc[part] : undefined), obj);
};

const getColumnOptions = (columnId, table, getFilterValue) => {
  const column = table.getColumn(columnId);
  if (!column) return [];

  // Extract values using the `getFilterValue` function or default to column value
  const columnData = table.getRowModel().rows.map((row) => {
    const value = row.getValue(columnId);
    
    // Use getFilterValue or default to value
    if (getFilterValue) {
      return getFilterValue(value, row);
    }
    
    return value; // default handling if no custom extraction logic provided
  });

  return Array.from(new Set(columnData));
};

// Example of using getNestedValue to access deeply nested properties
const facetedFilters = [
  {
    id: "application", 
    title: "Application", 
    getFilterValue: (value) => getNestedValue(value, "application.name"), // Accessing nested value
  },
];

<DataTableToolbar 
  table={table} 
  globalFilterColumnId="name" 
  facetedFilters={facetedFilters}
/>
-------
"use client";
import { Check, PlusCircle } from "lucide-react";
import { Badge } from "../badge";
import { Button } from "../button";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator } from "../command";
import { Popover, PopoverContent, PopoverTrigger } from "../popover";
import { Separator } from "../separator";
import { cn } from "@/lib/utils";

// Utility function to get a value from a nested object using a path (array of keys)
function getNestedValue(obj, path) {
    return path.split('.').reduce((acc, key) => acc?.[key], obj);
}

export function DataTableFacetedFilter({ column, title, options }) {
    // Get unique values from the column, and handle nested data if path is provided
    const facets = column?.getFacetedUniqueValues();
    const selectedValues = new Set(column?.getFilterValue() || []);

    return (
        <Popover>
            <PopoverTrigger asChild>
                <Button variant="outline">
                    <PlusCircle />
                    {title}
                    {selectedValues.size > 0 && (
                        <>
                            <Separator orientation="vertical" className="mx-2 h-4" />
                            <Badge variant="secondary" className="rounded-sm px-1 font-normal lg:hidden">
                                {selectedValues.size}
                            </Badge>
                            <div className="hidden space-x-1 lg:flex">
                                {selectedValues.size > 2 ? (
                                    <Badge variant="secondary" className="rounded-sm px-1 font-normal">
                                        {selectedValues.size} selected
                                    </Badge>
                                ) : (
                                    options
                                        .filter((option) => selectedValues.has(option.value))
                                        .map((option) => (
                                            <Badge variant="secondary" key={option.value} className="rounded-sm px-1 font-normal">
                                                {option.label}
                                            </Badge>
                                        ))
                                )}
                            </div>
                        </>
                    )}
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[200px] p-0" align="start">
                <Command>
                    <CommandInput placeholder={title} />
                    <CommandList>
                        <CommandEmpty>No Result found</CommandEmpty>
                        <CommandGroup>
                            {options.map((option) => {
                                const isSelected = selectedValues.has(option.value);
                                return (
                                    <CommandItem
                                        key={option.value}
                                        onSelect={() => {
                                            if (isSelected) {
                                                selectedValues.delete(option.value);
                                            } else {
                                                selectedValues.add(option.value);
                                            }
                                            const filterValues = Array.from(selectedValues);
                                            column?.setFilterValue(
                                                filterValues.length ? filterValues : undefined
                                            );
                                        }}
                                    >
                                        <div className={cn(
                                            "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                                            isSelected ? "bg-primary text-primary-foreground" : "opacity-50 [&_svg]:invisible"
                                        )}>
                                            <Check />
                                        </div>
                                        {option.icon && (
                                            <option.icon className="mr-2 h-4 w-4 text-muted-foreground" />
                                        )}
                                        <span>{option.label}</span>
                                        {facets?.get(option.value) && (
                                            <span className="ml-auto flex h-4 w-4 items-center justify-center font-mono text-xs">
                                                {facets.get(option.value)}
                                            </span>
                                        )}
                                    </CommandItem>
                                );
                            })}
                        </CommandGroup>
                        {selectedValues.size > 0 && (
                            <>
                                <CommandSeparator />
                                <CommandGroup>
                                    <CommandItem onSelect={() => column?.setFilterValue(undefined)} className="justify-center text-center">
                                        Clear filters
                                    </CommandItem>
                                </CommandGroup>
                            </>
                        )}
                    </CommandList>
                </Command>
            </PopoverContent>
        </Popover>
    );
}
--------
"use client";
import { Check, PlusCircle } from "lucide-react";
import { Badge } from "../badge";
import { Button } from "../button";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator } from "../command";
import { Popover, PopoverContent, PopoverTrigger } from "../popover";
import { Separator } from "../separator";
import { cn } from "@/lib/utils";

// Utility function to get a value from a nested object using a path (array of keys)
function getNestedValue(obj, path) {
    return path.split('.').reduce((acc, key) => acc?.[key], obj);
}

export function DataTableFacetedFilter({ column, facetedFilters }) {
    // Store the selected filter values
    const selectedValues = new Set(column?.getFilterValue() || []);
    const facets = column?.getFacetedUniqueValues(); // Get unique values from the column for filtering

    // Dynamically create filter options based on facetedFilters
    const generateFilterOptions = (columnId) => {
        const options = [];
        const values = facets?.get(columnId);

        if (values) {
            values.forEach((value) => {
                options.push({
                    label: value,
                    value: value
                });
            });
        }

        return options;
    };

    return (
        <Popover>
            <PopoverTrigger asChild>
                <Button variant="outline">
                    <PlusCircle />
                    {facetedFilters.title}
                    {selectedValues.size > 0 && (
                        <>
                            <Separator orientation="vertical" className="mx-2 h-4" />
                            <Badge variant="secondary" className="rounded-sm px-1 font-normal lg:hidden">
                                {selectedValues.size}
                            </Badge>
                            <div className="hidden space-x-1 lg:flex">
                                {selectedValues.size > 2 ? (
                                    <Badge variant="secondary" className="rounded-sm px-1 font-normal">
                                        {selectedValues.size} selected
                                    </Badge>
                                ) : (
                                    generateFilterOptions(facetedFilters.id).map((option) => (
                                        <Badge variant="secondary" key={option.value} className="rounded-sm px-1 font-normal">
                                            {option.label}
                                        </Badge>
                                    ))
                                )}
                            </div>
                        </>
                    )}
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[200px] p-0" align="start">
                <Command>
                    <CommandInput placeholder={facetedFilters.title} />
                    <CommandList>
                        <CommandEmpty>No Result found</CommandEmpty>
                        <CommandGroup>
                            {generateFilterOptions(facetedFilters.id).map((option) => {
                                const isSelected = selectedValues.has(option.value);
                                return (
                                    <CommandItem
                                        key={option.value}
                                        onSelect={() => {
                                            if (isSelected) {
                                                selectedValues.delete(option.value);
                                            } else {
                                                selectedValues.add(option.value);
                                            }
                                            const filterValues = Array.from(selectedValues);
                                            column?.setFilterValue(
                                                filterValues.length ? filterValues : undefined
                                            );
                                        }}
                                    >
                                        <div className={cn(
                                            "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                                            isSelected ? "bg-primary text-primary-foreground" : "opacity-50 [&_svg]:invisible"
                                        )}>
                                            <Check />
                                        </div>
                                        <span>{option.label}</span>
                                        {facets?.get(option.value) && (
                                            <span className="ml-auto flex h-4 w-4 items-center justify-center font-mono text-xs">
                                                {facets.get(option.value)}
                                            </span>
                                        )}
                                    </CommandItem>
                                );
                            })}
                        </CommandGroup>
                        {selectedValues.size > 0 && (
                            <>
                                <CommandSeparator />
                                <CommandGroup>
                                    <CommandItem onSelect={() => column?.setFilterValue(undefined)} className="justify-center text-center">
                                        Clear filters
                                    </CommandItem>
                                </CommandGroup>
                            </>
                        )}
                    </CommandList>
                </Command>
            </PopoverContent>
        </Popover>
    );
}
--------------

"use client";
import { Check, PlusCircle } from "lucide-react";
import { Badge } from "../badge";
import { Button } from "../button";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator } from "../command";
import { Popover, PopoverContent, PopoverTrigger } from "../popover";
import { Separator } from "../separator";
import { cn } from "@/lib/utils";

// Utility function to get a value from a nested object using a path (array of keys)
function getNestedValue(obj, path) {
    return path.split('.').reduce((acc, key) => acc?.[key], obj);
}

export function DataTableFacetedFilter({ column, title }) {
    // Get the unique values (facets) for this column
    const facets = column?.getFacetedUniqueValues();
    const selectedValues = new Set(column?.getFilterValue() || []);

    // Dynamically generate options based on the column's unique values
    const generateFilterOptions = () => {
        const options = [];
        const values = facets?.get(column.id);

        if (values) {
            values.forEach((value) => {
                // For nested data, use getNestedValue to fetch the value
                let displayValue = value;
                if (typeof value === 'string' && value.includes('.')) {
                    displayValue = getNestedValue(value, value);
                }
                options.push({
                    label: displayValue,
                    value: value
                });
            });
        }

        return options;
    };

    return (
        <Popover>
            <PopoverTrigger asChild>
                <Button variant="outline">
                    <PlusCircle />
                    {title}
                    {selectedValues.size > 0 && (
                        <>
                            <Separator orientation="vertical" className="mx-2 h-4" />
                            <Badge variant="secondary" className="rounded-sm px-1 font-normal lg:hidden">
                                {selectedValues.size}
                            </Badge>
                            <div className="hidden space-x-1 lg:flex">
                                {selectedValues.size > 2 ? (
                                    <Badge variant="secondary" className="rounded-sm px-1 font-normal">
                                        {selectedValues.size} selected
                                    </Badge>
                                ) : (
                                    generateFilterOptions().map((option) => (
                                        <Badge variant="secondary" key={option.value} className="rounded-sm px-1 font-normal">
                                            {option.label}
                                        </Badge>
                                    ))
                                )}
                            </div>
                        </>
                    )}
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[200px] p-0" align="start">
                <Command>
                    <CommandInput placeholder={title} />
                    <CommandList>
                        <CommandEmpty>No Result found</CommandEmpty>
                        <CommandGroup>
                            {generateFilterOptions().map((option) => {
                                const isSelected = selectedValues.has(option.value);
                                return (
                                    <CommandItem
                                        key={option.value}
                                        onSelect={() => {
                                            if (isSelected) {
                                                selectedValues.delete(option.value);
                                            } else {
                                                selectedValues.add(option.value);
                                            }
                                            const filterValues = Array.from(selectedValues);
                                            column?.setFilterValue(
                                                filterValues.length ? filterValues : undefined
                                            );
                                        }}
                                    >
                                        <div className={cn(
                                            "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                                            isSelected ? "bg-primary text-primary-foreground" : "opacity-50 [&_svg]:invisible"
                                        )}>
                                            <Check />
                                        </div>
                                        <span>{option.label}</span>
                                    </CommandItem>
                                );
                            })}
                        </CommandGroup>
                        {selectedValues.size > 0 && (
                            <>
                                <CommandSeparator />
                                <CommandGroup>
                                    <CommandItem onSelect={() => column?.setFilterValue(undefined)} className="justify-center text-center">
                                        Clear filters
                                    </CommandItem>
                                </CommandGroup>
                            </>
                        )}
                    </CommandList>
                </Command>
            </PopoverContent>
        </Popover>
    );
}
----
"use client";
import { flexRender, getCoreRowModel, getFacetedRowModel, getFacetedUniqueValues, getFilteredRowModel, getPaginationRowModel, getSortedRowModel, useReactTable } from "@tanstack/react-table";
import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../table";
import { DataTableToolbar } from "./data-table-toolbar";
import { DataTablePagination } from "./data-table-pagination";

export function DataTable({ columns, data, globalFilterColumnId, facetedFilters }) {
    const [rowSelection, setRowSelection] = useState({});
    const [columnVisibility, setColumnVisibility] = useState({});
    const [columnFilters, setColumnFilters] = useState([]);
    const [sorting, setSorting] = useState([]);

    const table = useReactTable({
        data,
        columns,
        state: {
            sorting,
            columnVisibility,
            rowSelection,
            columnFilters,
        },
        enableRowSelection: true,
        onRowSelectionChange: setRowSelection,
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        onColumnVisibilityChange: setColumnVisibility,
        getCoreRowModel: getCoreRowModel(),
        getFilteredRowModel: getFilteredRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getFacetedRowModel: getFacetedRowModel(),
        getFacetedUniqueValues: getFacetedUniqueValues(),
    });

    return (
        <div className="space-y-4 shadow-2xl border-2">
            <DataTableToolbar table={table} globalFilterColumnId={globalFilterColumnId} facetedFilters={facetedFilters} />
            <div className="rounded-md border">
                <Table>
                    <TableHeader>
                        {table.getHeaderGroups().map((headerGroup) => (
                            <TableRow key={headerGroup.id}>
                                {headerGroup.headers.map((header) => (
                                    <TableHead key={header.id} colSpan={header.colSpan}>
                                        {header.isPlaceholder
                                            ? null
                                            : flexRender(header.column.columnDef.header, header.getContext())
                                        }
                                    </TableHead>
                                ))}
                            </TableRow>
                        ))}
                    </TableHeader>
                    <TableBody>
                        {table.getRowModel().rows?.length ? (
                            table.getRowModel().rows.map((row) => (
                                <TableRow key={row.id} data-state={row.getIsSelected() && "selected"}>
                                    {row.getVisibleCells().map((cell) => (
                                        <TableCell key={cell.id}>
                                            {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                <TableCell colSpan={columns.length} className="h-24 text-center">
                                    No Result
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>
            <DataTablePagination table={table} />
        </div>
    );
}
