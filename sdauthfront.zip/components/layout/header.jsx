import { SidebarTrigger } from "../ui/sidebar";
import NotificationComponent from "./notification";
import { ThemeToggle } from "./theme-toggle";
import UserNav from "./user-nav";


export default function HeaderComponent({ onMenuClick }) {
    return(
        <header className="sticky top-0 z-50 flex h-16 w-full shrink-0 items-center gap-4 border-b bg-background px-4 shadow-sm">
            <div className="flex items-center justify-between px-4 py-4 md:px-6"> 
                <div className="flex items-center gap-2 md:gap-4">
                    <SidebarTrigger />
                    <div className="flex flex-col">
                        <div className="hidden lg:block">
                            <span className="font-bold text-indigo">MDIndia Health Insurance TPA Pvt. Ltd.</span>
                        </div>
                    </div>
                </div>
                <div className="flex items-center space-x-4">
                    <NotificationComponent />
                    <ThemeToggle />
                    <UserNav />
                </div>
            </div>
        </header>
    );
}