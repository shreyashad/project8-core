"use client";

import { useEffect, useState } from "react";
import { Button } from "../ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Bell } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { useSession } from "next-auth/react";
import { fetchNotification } from "@/lib/common/user_api";

export default function NotificationComponent() {
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const { data: session } = useSession();

  useEffect(() => {
    if (!session) return;

    const getNotifications = async () => {
      setError(null);
      setIsLoading(true);
      try {
        const appName = process.env.APP_NAME; // Safely access the environment variable
        const notifyData = await fetchNotification(session.accessToken, appName);
        const today = new Date();
        const filteredNotifications = notifyData.filter((notification) => {
          const notificationDate = new Date(notification.date);
          return (
            notificationDate.getDate() === today.getDate() &&
            notificationDate.getMonth() === today.getMonth() &&
            notificationDate.getFullYear() === today.getFullYear()
          );
        });
        setNotifications(filteredNotifications);
      } catch (err) {
        console.error("Error fetching notifications:", err);
        setError("Failed to load notifications. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    getNotifications();
  }, [session]);

  if (!session) {
    return <div>Loading...</div>;
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="icon" className="relative bg-blue border rounded-full">
          <Bell className="h-[1.2rem] w-[1.2rem]" />
          {notifications.length > 0 && (
            <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500" />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80">
        <Card>
          <CardHeader>
            <CardTitle>Notifications</CardTitle>
            <CardDescription>You have {notifications.length} unread messages</CardDescription>
          </CardHeader>
          <CardContent className="max-h-[300px] overflow-auto">
            {isLoading ? (
              <p>Loading notifications...</p>
            ) : error ? (
              <p className="text-red-500">{error}</p>
            ) : notifications.length > 0 ? (
              notifications.map((notification) => (
                <div
                  key={notification.id}
                  className="mb-4 grid grid-cols-[25px_1fr] items-start pb-4 last:mb-0 last:pb-0"
                >
                  <span className="flex h-2 w-2 translate-y-1.5 rounded-full bg-sky-500" />
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">{notification.title}</p>
                    <p className="text-sm text-muted-foreground">{notification.description}</p>
                    <p className="text-xs text-muted-foreground">{notification.time}</p>
                  </div>
                </div>
              ))
            ) : (
              <p>No notifications for today.</p>
            )}
          </CardContent>
        </Card>
      </PopoverContent>
    </Popover>
  );
}

export async function fetchNotification(accessToken) {
    try {
        // Ensure the APP_NAME is accessible and valid
        const appName = process.env.NEXT_PUBLIC_APP_NAME; // Use the correct prefix for environment variables in Next.js
        if (!appName) {
            throw new Error("APP_NAME environment variable is not defined.");
        }

        // Make the API call with the application name and access token
        const response = await axios.get(
            `${API_BASE_URL}api/notifications/?application_name=${appName}`,
            {
                headers: {
                    Authorization: `Bearer ${accessToken}`, // Include the JWT access token
                },
            }
        );

        // Return the response data (list of notifications)
        return response.data;
    } catch (error) {
        console.error("Error while fetching notifications:", error.message || error);
        throw new Error("Failed to fetch notifications. Please try again.");
    }
}

useEffect(() => {
    const getNotifications = async () => {
        setErrors(null);
        setIsLoading(true);

        try {
            // Fetch notifications using the access token
            const notifyData = await fetchNotification(session.accessToken);

            // Filter notifications based on the current date
            const today = new Date();
            const filteredNotifications = notifyData.filter((notification) => {
                const notificationDate = new Date(notification.date);
                return (
                    notificationDate.getDate() === today.getDate() &&
                    notificationDate.getMonth() === today.getMonth() &&
                    notificationDate.getFullYear() === today.getFullYear()
                );
            });

            // Update the state with filtered notifications
            setNotifications(filteredNotifications);
        } catch (error) {
            console.error("Error fetching notifications:", error);
            setErrors(error.message);
        } finally {
            setIsLoading(false);
        }
    };

    if (session) {
        getNotifications();
    }
}, [session]);
