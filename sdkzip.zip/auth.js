import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

import axios from "axios";
import { fetchAuthApplicationDetails, validateTicket } from "./lib/auth/auth_api";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";


export const { handlers, signIn, signOut, auth } = NextAuth({
    providers: [
        CredentialsProvider({
            name: "Credentials",
            credentials: {
                username: { label: "Username", type: "text"},
                password: { label: "Password", type: "password"},
            },
            authorize: async (credentials) => {
                try {
                    const application = await fetchAuthApplicationDetails();
                    const appId = application.app.id;
                    console.log("app details:", appId);

                    const response = await axios.post(`${API_BASE_URL}api/login/`, {
                        username: credentials.username,
                        password: credentials.password,
                        application_id : appId, 
                    });
                    console.log("authorize response:", response.data);
                    if (response.status !== 200) {
                        throw new Error("Invalid credentials");
                    }

                    const user = response.data;

                    const userDetails = await validateTicket(user.service_ticket, appId);

                    if (userDetails) {
                        return {
                            id: userDetails.id || user.id,
                            roles: userDetails.roles,
                            permissions: userDetails.permissions,
                            profile_picture: userDetails.profile_picture,
                            first_name: userDetails.first_name,
                            last_name: userDetails.last_name,
                            org_type: userDetails.org_type,
                            org_name: userDetails.org_name,
                            org_sub_type: userDetails.org_sub_type,
                            location_type: userDetails.location_type,
                            location_name: userDetails.location_name,
                            location_code: userDetails.location_code,
                            emp_code: userDetails.emp_code,
                            department: userDetails.department,
                            designation: userDetails.designation,
                            accessToken: user.access, // Include the access token
                            refreshToken: user.refresh,
                            sessionKey: user.session_key,
                            service_ticket: user.service_ticket,
                            sessionExp: new Date(user.session_expires_at).getTime(),
                        };
                    } else {
                        throw new Error ("Invalid service ticket");
                    }
                } catch (error) {
                    let errorMessage = error.response?.data?.error || error.message;
                    console.error("Authentication failed:", errorMessage);
                    throw new Error(getCustomErrorMessage(errorMessage));
                }
            },

        }),

    ],

    pages: {
        signIn: "/login",
        
    },
    callbacks: {
        async jwt( { token, user }) {
            if (user) {
                token.accessToken = user.accessToken;
                token.refreshToken = user.refreshToken;
                token.sessionKey = user.sessionKey;
                token.sessionExp = user.sessionExp;
                token.user = user;
            }

            if (Date.now() >  token.sessionExp) {
                try {
                    const response = await axios.post(`${API_BASE_URL}api/token/refresh/`, {
                        refresh: token.refreshToken,
                    });
                    if (response.status === 200) {
                        token.accessToken = response.data.access;
                        token.refreshToken = response.data.refresh;
                        token.sessionExp = Date.now() + 60 * 60 * 1000; // Update expiration
                    } else {
                        throw new Error("Token refresh failed");
                    }
                } catch (error) {
                    console.error("Error refreshing token:", error.response?.data || error.message);
                    // token.accessToken = null;
                    // token.refreshToken = null;
                    // token.sessionExp = 0;
                    token.error = "SessionExpired";
                    throw new Error("Session expired. Please log in again.");
                }
            }

            return token;
        },

        async session({ session, token }) {
            if (!token || !token.accessToken) {
                session.error = "Session expired, please log in again.";
                return session;
            }

            session.accessToken = token.accessToken;
            session.refreshToken = token.refreshToken;
            session.sessionKey = token.sessionKey;
            session.sessionExp = token.sessionExp;
            session.user = token.user
            
            console.log("user session details:", session);
            
            if (token.error === "SessionExpired") {
                session.error = "Session expired. Please log in again.";
            }
            
            return session;
        }
    },
    session: {
        strategy: "jwt"
    },
    server: {
        trustedHosts: ['localhost:3000']
    },
    secret: process.env.AUTH_SECRET,
    

});

function getCustomErrorMessage(errorMessage) {
    switch (errorMessage) {
      case "Invalid username or password":
        return "The username or password you entered is incorrect.";
      case "Invalid service ticket":
        return "Your session has expired. Please log in again.";
      case "Token refresh failed":
        return "Failed to refresh your session. Please log in again.";
      case "Network Error":
        return "Please check your internet connection.";
      case "Application not authorized":
        return "This application is not authorized for the current user.";
      default:
        return "An unexpected error occurred. Please try again.";
    }
  }
  
