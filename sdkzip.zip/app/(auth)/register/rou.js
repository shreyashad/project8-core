"use client";
import { useEffect, useState } from "react";
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { fecthDepartments,  fetchDesignations, fetchLocationCode, fetchLocationName, fetchLocationTypes, fetchOrgNames, fetchOrgSubTypes, fetchOrgTypes, register } from "@/app/api/server/route";
import Link from "next/link";
import { PhoneInput } from "@/components/ui/phone-input";

export default function RegisterPage() {
    const [formData, setFormData] = useState({
        first_name: "",
        last_name: "",
        emp_code: "",
        designation: "",
        org_type: "",
        org_name: "",
        org_sub_type: "",
        location_type: "",
        location_name: "",
        location_code: "",
        assigned_details: "",
        department:"",
        username: "",
        password: "",
        confirm_password: "",
        mobile: "",
        application_name: "Auth Server",
    });

    const [desigData, setDesigData] = useState([]);
    const [deptData, setDeptData] = useState([]);
    const [orgTypeData, setOrgTypeData] = useState([]);
    const [orgNamesData, setOrgNamesData] = useState([]);
    const [orgSubTypeData, setOrgSubTypeData] = useState([]);
    const [locationTypeData, setLocationTypeData] = useState([]);
    const [locationNamesData, setLocationNamesData] = useState([]);
    const [locationCodeData, setLocationCodeData] = useState([]);
    const [currentStep, setCurrentStep] = useState(0);
    const [showAssignedDetails, setShowAssignedDetails] = useState(false);
    
    
    const handleNext = () => {
        setCurrentStep(currentStep + 1)
    }

    const handlePrevious = () => {
        setCurrentStep(currentStep - 1)
    }

    useEffect (() => {
        const fetchData = async () => {
          try {
            const desig = await fetchDesignations();
            setDesigData(desig);
            const orgtype = await fetchOrgTypes();
            setOrgTypeData(orgtype);
            const dept = await fecthDepartments();
            setDeptData(dept);
           
          } catch (error) {
            console.error("Error fetching data:", error);
          }
        };
        fetchData();
      }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSelectChange = async (name, value) => {
        setFormData({ ...formData, [name]: value});

        if (name === "org_type") {
            console.log("Selected org_type:", value); 
            try{
                const subtypeRes =  await fetchOrgSubTypes(value);
                const orgNamesRes = await fetchOrgNames(value);
                
                console.log ("org-name- res:", orgNamesRes);
                setOrgNamesData(orgNamesRes);
                
                console.log ("subtypeRes res:", subtypeRes);
                setOrgSubTypeData(subtypeRes);

                setLocationTypeData([]);
                setLocationNamesData([]);
                setLocationCodeData([]);
                setShowAssignedDetails(false);
            } catch (error){
                console.error("Error fetching organization data:", error);
            }
            
        } else if (name === "org_name") {
            try{
                const locationTypeRes = await fetchLocationTypes(value);
                setLocationTypeData(locationTypeRes);
            } catch (error) {
                console.error("Error fetching location types:", error);
            }
            
        } else if (name === "org_sub_type") {
            const selectedSubtype = orgSubTypeData.find(subtype => subtype.subtype === value);
            setShowAssignedDetails(selectedSubtype && !['MDI- Management', 'MDI-Retail'].includes(selectedSubtype.subtype));
        } else if (name === "location_type") {
            try {
                const locationNameRes = await fetchLocationName(formData.org_name, value);
                console.log("locationnameRes:",locationNameRes);
                setLocationNamesData(locationNameRes);
            } catch (error) {
                console.error("Error fetching location Name:", error);
            }
        }  else if (name === "location_name") {
            try {
                const locationCodeRes = await fetchLocationCode(formData.org_name, formData.location_type, value);
                setLocationCodeData(locationCodeRes);
            } catch (error) {
                console.error("Error fetching location code:", error);
            }
        }
    };



    const handleSubmit = async (e) => {
        e.preventDefault();

        if (formData.password !== formData.confirm_password) {
            alert("Password do not match!");
            return;

        }

        try{
            const response = await register(formData);
            console.log("Response status---->",response);
            if (response.status === 400) {
                alert("Registration failed. Please try again.");
                //alert("Registration successful!");
                // Redirect to login page or another page
                //window.location.href = "/login";
            } else {
                alert("Registration successful!");
                window.location.href = "/login";
            }
        } catch (error) {
            console.error("Error submitting form:", error);
            alert("An error occurred. Please try again.");
        }
    };

    return(
        <>
            <h1 className="text-center space-x-4 mt-20 text-2xl text-bold">User Registeration</h1>
            <div className="mt-4 text-center text-sm">
                Already have an account?{" "}
                <Link href="/login" className="underline">Sign In</Link>
            </div>
            <div className="container  mx-auto max-w-6xl py-12 md:py-16 lg:py-20 flex gap-8">
                <div className="w-1/3 bg-muted rounded-lg p-6 shadow-md">
                    <div>
                        <div>
                            <div>
                                <div className="space-y-4">
                                    <div className="flex items-center space-x-4">
                                        <div
                                            className={`rounded-full w-8 h-8 flex items-center justify-center font-semibold ${
                                            currentStep === 0 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                                            }`}
                                        >
                                            1
                                        </div>
                                        <h3 className={`text-lg font-semibold ${currentStep === 0 ? "text-primary" : ""}`}>Personal Info</h3>
                                    </div>
                                    <p className={`text-muted-foreground ${currentStep === 0 ? "text-primary" : ""}`}>
                                    Enter your name, email, and phone number.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div>
                                <div className="space-y-4">
                                    <div className="flex items-center space-x-4">
                                        <div
                                            className={`rounded-full w-8 h-8 flex items-center justify-center font-semibold ${
                                            currentStep === 1 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                                            }`}
                                        >
                                            2
                                        </div>
                                        <h3 className={`text-lg font-semibold ${currentStep === 1 ? "text-primary" : ""}`}>Company Info</h3>
                                    </div>
                                    <p className={`text-muted-foreground ${currentStep === 1 ? "text-primary" : ""}`}>
                                    Enter your company name, industry, and size.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div>
                                <div className="space-y-4">
                                    <div className="flex items-center space-x-4">
                                    <div
                                        className={`rounded-full w-8 h-8 flex items-center justify-center font-semibold ${
                                        currentStep === 2 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                                        }`}
                                    >
                                        3
                                    </div>
                                    <h3 className={`text-lg font-semibold ${currentStep === 2 ? "text-primary" : ""}`}>Account Info</h3>
                                    </div>
                                    <p className={`text-muted-foreground ${currentStep === 2 ? "text-primary" : ""}`}>
                                    Create a username and password for your account.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="w-2/3 bg-background border rounded-lg p-6 shadow-lg">
                    <form onSubmit={handleSubmit}>
                        {currentStep === 0 && (
                            <div className="space-y-6">
                                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                    <div className="space-y-2">
                                        <Label>First Name</Label>
                                        <Input 
                                            type="text"
                                            name="first_name"
                                            value={formData.first_name}
                                            onChange={handleChange}
                                            required 
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Last Name</Label>
                                        <Input 
                                            type="text"
                                            name="last_name"
                                            value={formData.last_name}
                                            onChange={handleChange}
                                            required 
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Employee Code</Label>
                                        <Input
                                            type="text"
                                            name="emp_code"
                                            value={formData.emp_code}
                                            onChange={handleChange}
                                            required
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Designation</Label>
                                        <Select onValueChange={(value) => handleSelectChange("designation", value)}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select Designation" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {desigData.map((desg) => (
                                                    <SelectItem key={desg.id} value={desg.name}>
                                                        {desg.name}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                            </div>
                        )}
                        {currentStep === 1 && (
                            <div className="space-y-6">
                                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                    <div className="space-y-2">
                                        <Label>Organization Type</Label>
                                        <Select onValueChange={(value) => handleSelectChange("org_type", value)}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select Org Type" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {orgTypeData.map((orgtype) => (
                                                    <SelectItem key={orgtype} value={orgtype}>
                                                        {orgtype}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Organization Name</Label>
                                        <Select onValueChange={(value) => handleSelectChange("org_name", value)}>
                                            
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select Org Name" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {orgNamesData.map((orgName) => (
                                                    <SelectItem key={orgName.id} value={orgName.name}>
                                                        {orgName.name}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Organization Subtype</Label>
                                        <Select onValueChange={(value) => handleSelectChange("org_sub_type", value)}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select Org subType" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {orgSubTypeData.map((orgSubtype) => (
                                                    <SelectItem key={orgSubtype.id} value={orgSubtype.subtype}>
                                                        {orgSubtype.subtype}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    {showAssignedDetails && (
                                    <div className="space-y-2">
                                        <Label>Assigned Details</Label>
                                        <Input 
                                            type="text"
                                            name="assigned_details"
                                            value={formData.assigned_details}
                                            onChange={handleChange}
                                            required 
                                        />
                                        
                                    </div>
                                    )}
                                    {formData.org_type === "MDIndia" && (
                                    <div className="space-y-2">
                                        <Label>Department </Label>
                                        <Select onValueChange={(value) => handleSelectChange("department", value)}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select Department" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {deptData.map((dept) => (
                                                    <SelectItem key={dept.id} value={dept.name}>
                                                        {dept.name}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    )}
                                    <div className="space-y-2">
                                        <Label>Location Type</Label>
                                        <Select onValueChange={(value) => handleSelectChange("location_type", value)}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select Location Type" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {locationTypeData.map((locationtype, index) => (
                                                    <SelectItem key={index} value={locationtype}>
                                                        {locationtype}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Location Name</Label>
                                        <Select onValueChange={(value) => handleSelectChange("location_name", value)}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select Location Name" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {locationNamesData.map((locationName) => (
                                                    <SelectItem key={locationName.id} value={locationName.location_name}>
                                                        {locationName.location_name}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <Label>Location Code</Label>
                                        <Select onValueChange={(value) => handleSelectChange("location_code", value)}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select Location Type" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {locationCodeData.map((locationCode, index) => (
                                                    <SelectItem key={index} value={locationCode}>
                                                        {locationCode}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                            </div>
                        )}
                        {currentStep === 2 && (
                            <div className="space-y-6">
                                <div className="space-y-2">
                                    <Label htmlFor="username">Username</Label>
                                    <Input 
                                        id="username" 
                                        placeholder="Enter your username" 
                                        name="username"
                                        value={formData.username}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                    <div className="space-y-2">
                                        <Label htmlFor="password">Password</Label>
                                        <Input 
                                            id="password" 
                                            type="password" 
                                            name="password"
                                            value={formData.password}
                                            onChange={handleChange}
                                            required    
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="confirm-password">Confirm Password</Label>
                                        <Input 
                                            id="confirm-password" 
                                            type="password" 
                                            name="confirm_password"
                                            value={formData.confirm_password}
                                            onChange={handleChange}
                                            required      
                                        />
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <Label>Mobile Number</Label>
                                        <PhoneInput 
                                            name="mobile"
                                            value={formData.mobile}
                                            onChange={(value) => setFormData(prev => ({ ...prev, mobile: value }))}
                                            required
                                        />
                                        
                                        
                                </div>
                            </div>
                        )}
                        <div className="flex justify-between mt-6">
                            {currentStep > 0 && (
                                <Button type="button" onClick={handlePrevious}>
                                    Previous
                                </Button>
                            )}
                            {currentStep < 2 ? (
                                <Button type="button" onClick={handleNext}>
                                    Next
                                </Button>
                            ) : (
                                <Button type="submit">
                                    Create Account
                                </Button>
                            )}
                        </div>
                    </form>            
                </div>
            </div>
        </>
    );
}