import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import Image from "next/image";
import Link from "next/link";

const AuthLayout = ({ children }) => {
    return(
        <>
             <div className="md:hidden">
                <Image
                    src="/examples/authentication-light.png"
                    width={1280}
                    height={843}
                    alt="Authentication"
                    className="block dark:hidden"
                />
                <Image
                    src="/examples/authentication-dark.png"
                    width={1280}
                    height={843}
                    alt="Authentication"
                    className="hidden dark:block"
                />
            </div>
            <div className="container relative hidden h-[800px] flex-col items-center justify-center md:grid lg:max-w-none lg:grid-cols-2 lg:px-0">
                <Link
                href="/examples/authentication"
                className={cn(
                    buttonVariants ({ variant: "ghost" }),
                    "absolute right-4 top-4 md:right-8 md:top-8"
                )}
                >
                Login
                </Link>
            <div className="relative hidden h-full flex-col bg-muted p-10 text-white dark:border-r lg:flex">
                <div className="absolute inset-0 bg-zinc-900" />
                <div className="relative z-20 flex items-center text-lg font-medium">
                    <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mr-2 h-6 w-6"
                    >
                    <path d="M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3" />
                    </svg>
                    Acme Inc
                </div>
                <div className="relative z-20 mt-auto">
                    <blockquote className="space-y-2">
                    <p className="text-lg">
                        &ldquo;This library has saved me countless hours of work and
                        helped me deliver stunning designs to my clients faster than
                        ever before.&rdquo;
                    </p>
                    <footer className="text-sm">Sofia Davis</footer>
                    </blockquote>
                </div>
            </div>
            <div className="lg:p-8">
            <div className="mx-auto flex w-full flex-col justify-center space-y-6 sm:w-[350px]">
                <div className="flex flex-col space-y-2 text-center">
                <h1 className="text-2xl font-semibold tracking-tight">
                    Create an account
                </h1>
                <p className="text-sm text-muted-foreground">
                    Enter your email below to create your account
                </p>
                </div>
                
                <p className="px-8 text-center text-sm text-muted-foreground">
                By clicking continue, you agree to our{" "}
                <Link
                    href="/terms"
                    className="underline underline-offset-4 hover:text-primary"
                >
                    Terms of Service
                </Link>{" "}
                and{" "}
                <Link
                    href="/privacy"
                    className="underline underline-offset-4 hover:text-primary"
                >
                    Privacy Policy
                </Link>
                .
                </p>
            </div>
            </div>
      </div>
    
        </>
    );
};
export default AuthLayout;
// app/auth/layout.tsx
import { useState, useEffect } from "react";
import { Geist, Geist_Mono } from "next/font/google";
import "./auth.css"; // Custom styles for authentication layout

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: "Authentication",
  description: "Login, Register, Forgot Password",
};

export default function AuthLayout({ children }) {
  const [theme, setTheme] = useState("light");

  useEffect(() => {
    // Detect the user's theme preference (light or dark)
    const savedTheme = window.localStorage.getItem("theme");
    setTheme(savedTheme || (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? "dark" : "light"));
  }, []);

  // Dynamically set the image path based on the theme
  const imagePath = theme === "dark" ? "/images/auth-dark.png" : "/images/auth-light.png";

  return (
    <html lang="en" className={theme}>
      <head />
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
        <div className="auth-layout flex items-center justify-center min-h-screen p-4 lg:flex-row flex-col">
          {/* Image for large/medium screens */}
          <div className="auth-image hidden lg:block lg:w-1/2 xl:w-1/3">
            <img src={imagePath} alt="Auth Image" className="w-full h-full object-cover" />
          </div>

          {/* Authentication forms */}
          <div className="auth-content lg:w-1/2 xl:w-1/3 w-full flex justify-center items-center py-6">
            {children}
          </div>
        </div>

        {/* Footer */}
        <footer className="auth-footer w-full text-center py-4 bg-gray-100 mt-6">
          <p>
            <a href="/privacy-policy" className="text-blue-600 hover:underline">
              Privacy Policy
            </a>
          </p>
        </footer>
      </body>
    </html>
  );
}
---------
<div className="w-full lg:grid lg:grid-cols-2">
            <div className="hidden bg-muted lg:block">
                <Image 
                    src="/auth-images/auth-img1.png"
                    width={1280}
                    height={843}
                    alt="Authentication"
                />
            </div>
            <div className="flex items-center justify-center py-10">
                <div className="container relative hidden flex-col items-center justify-center md:grid lg:max-w-none lg:grid-cols-2 lg:px-0">
                    <Link
                        href="/examples/authentication"
                        className={cn(
                            buttonVariants ({ variant: "ghost" }),
                            "absolute right-4 top-4 md:right-8 md:top-8"
                        )}
                    >
                    Login
                    </Link>
                    <div className="relative hidden h-full flex-col bg-muted p-10 text-white dark:border-r lg:flex">
                        <div className="absolute inset-0 bg-zinc-900" />
                        <div className="relative z-20 flex items-center text-lg font-medium">
                            
                            MDIndia
                        </div>
                        <div className="relative z-20 mt-auto">
                            <blockquote className="space-y-2">
                            <p className="text-lg">
                                &ldquo;This library has saved me countless hours of work and
                                helped me deliver stunning designs to my clients faster than
                                ever before.&rdquo;
                            </p>
                            <footer className="text-sm">Sofia Davis</footer>
                            </blockquote>
                        </div>
                    </div>
                    <div className="lg:p-8">
                        <div className="mx-auto flex w-full flex-col justify-center space-y-6 sm:w-[350px]">
                            <div className="flex flex-col space-y-2 text-center">
                        <h1 className="text-2xl font-semibold tracking-tight">
                            Create an account
                        </h1>
                        <p className="text-sm text-muted-foreground">
                            Enter your email below to create your account
                        </p>
                        </div>
                        
                        <p className="px-8 text-center text-sm text-muted-foreground">
                        By clicking continue, you agree to our{" "}
                        <Link
                            href="/terms"
                            className="underline underline-offset-4 hover:text-primary"
                        >
                            Terms of Service
                        </Link>{" "}
                        and{" "}
                        <Link
                            href="/privacy"
                            className="underline underline-offset-4 hover:text-primary"
                        >
                            Privacy Policy
                        </Link>
                        .
                        </p>
                    </div>
                            {children}
                    </div>
                </div>
            </div>
        </div>