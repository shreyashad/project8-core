import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import Image from "next/image";
import Link from "next/link";



export default function AuthLayout({ children }) {
    return(
       <div className="w-full lg:grid lg:grid-cols-2">
            <div className="hidden bg-muted lg:block">
                <Image 
                    src="/auth-images/auth-img1.png"
                    width={1280}
                    height={843}
                    alt="Authentication"
                />
            </div>
            <div className="flex items-center justify-center py-10 ">
                <div className="container relative  flex-col items-center justify-center">
                    <div className="relative  flex items-center justify-center">
                        <Image 
                            src="/logo/mdi_logo1.png"
                            width={100}
                            height={100}
                            alt="MdIndia Log"
                        />
                    </div>
                    <div className="mt-10 p-5 ">
                        {children}
                    </div>
                    
                    <div className="lg:p-8">
                        <div className="mx-auto flex w-full flex-col justify-center space-y-6 sm:w-[350px]">
                            
                        
                            <p className="px-8 text-center text-sm text-muted-foreground">
                                 By clicking continue, you agree to our{" "}
                                <Link
                                    href="/terms"
                                    className="underline underline-offset-4 hover:text-primary"
                                >
                                    Terms of Service
                                </Link>{" "}
                                     and{" "}
                                <Link
                                    href="/privacy"
                                    className="underline underline-offset-4 hover:text-primary"
                                >
                                    Privacy Policy
                                </Link>
                                .
                            </p>
                        </div>
                    </div>
                </div>
            </div>
       </div>
    );
}