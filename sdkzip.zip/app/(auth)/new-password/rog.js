"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { signIn, useSession } from "next-auth/react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

// Map error codes/messages to user-friendly messages
const getErrorMessage = (error) => {
    switch (error) {
        case "Invalid credentials":
            return "The username or password you entered is incorrect.";
        case "Invalid service ticket":
            return "Your session has expired. Please log in again.";
        case "Token refresh failed":
            return "Failed to refresh your session. Please log in again.";
        case "Network Error":
            return "Unable to connect. Please check your internet connection.";
        default:
            return "An unexpected error occurred. Please try again.";
    }
};

export default function LoginPage() {
    const [formData, setFormData] = useState({
        username: '',
        password: '',
    });

    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [roleMessage, setRoleMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { data: session, status } = useSession();
    const router = useRouter();

    useEffect(() => {
        if (status === "loading") return; // Wait for session to load

        if (session?.user) {
            // Check user role and redirect accordingly
            const userRole = session.user.roles;

            if (!userRole) {
                setRoleMessage("User role not found. Please contact support.");
                return;
            }

            switch (userRole) {
                case "Administrator":
                    router.push("/dashboard/administrator");
                    break;
                case "Authenticator":
                    router.push("/dashboard/authenticator");
                    break;
                case "Site Admin":
                    router.push("/dashboard/site-admin");
                    break;
                default:
                    router.push("/");
            }
        }
    }, [session, status, router]);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setIsLoading(true);
        setErrorMessage('');
        setSuccessMessage('');
        setRoleMessage('');

        const { username, password } = formData;

        try {
            const result = await signIn("credentials", {
                username,
                password,
                redirect: false,
            });

            if (result?.error) {
                // Map error messages
                setErrorMessage(getErrorMessage(result.error));
                console.error("Login error:", result.error);
            } else {
                setSuccessMessage("Login successful. Redirecting...");
                router.reload(); // Trigger session reload after successful sign-in
            }
        } catch (error) {
            console.error("Unexpected error:", error);
            setErrorMessage(
                error.response?.data?.message || getErrorMessage(error.message)
            );
        } finally {
            setIsLoading(false);
        }
    };

    const handleChange = (event) => {
        setFormData({ ...formData, [event.target.name]: event.target.value });
    };

    return (
        <div className="w-full lg:grid lg:min-h-[500px] lg:grid-cols-2 xl:min-h-[600px]">
            <div className="flex items-center justify-center py-10">
                <Card className="mx-auto max-w-sm shadow-2xl">
                    <CardHeader>
                        <CardTitle className="text-2xl text-center">Login</CardTitle>
                        <CardDescription>
                            Enter your credentials below to login to your account
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid gap-4">
                            {(errorMessage || successMessage || roleMessage) && (
                                <div
                                    className={`${
                                        errorMessage || roleMessage
                                            ? "bg-red-100 border border-red-400 text-red-700"
                                            : "bg-green-100 border border-green-400 text-green-700"
                                    } px-4 py-3 rounded relative`}
                                    role="alert"
                                >
                                    <strong className="font-bold">
                                        {errorMessage ? "Error:" : "Success:"}{" "}
                                    </strong>
                                    <span className="block sm:inline">
                                        {errorMessage || successMessage || roleMessage}
                                    </span>
                                </div>
                            )}
                            <form onSubmit={handleSubmit}>
                                <div className="grid gap-2">
                                    <Label>Username</Label>
                                    <Input
                                        type="text"
                                        id="username"
                                        name="username"
                                        value={formData.username}
                                        onChange={handleChange}
                                        required
                                        disabled={isLoading}
                                    />
                                </div>
                                <div className="grid gap-2">
                                    <div className="flex items-center">
                                        <Label>Password</Label>
                                        <Link
                                            href="/forgot-password"
                                            className="ml-auto inline-block text-sm underline"
                                        >
                                            Forgot password?
                                        </Link>
                                    </div>
                                    <Input
                                        type="password"
                                        id="password"
                                        name="password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        required
                                        disabled={isLoading}
                                    />
                                </div>
                                <Button
                                    type="submit"
                                    className="w-full mt-4"
                                    disabled={isLoading}
                                >
                                    {isLoading ? "Logging in..." : "Login"}
                                </Button>
                            </form>
                        </div>
                        <div className="mt-4 text-center text-sm">
                            Don&apos;t have an account?{" "}
                            <Link href="/register" className="underline">
                                Sign Up
                            </Link>
                        </div>
                    </CardContent>
                </Card>
            </div>
            <div className="hidden bg-muted lg:block">
                <Image
                    src="/boy-with-rocket-light.png"
                    alt="Image"
                    width="1920"
                    height="1080"
                    className="h-full w-full object-cover dark:brightness-[0.2] dark:grayscale"
                />
            </div>
        </div>
    );
}
-------
"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { signIn, useSession } from "next-auth/react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

const getErrorMessage = (error) => {
    switch (error) {
        case "Invalid username or password":
            return "The username or password you entered is incorrect.";
        case "Invalid service ticket":
            return "Your session has expired. Please log in again.";
        case "Token refresh failed":
            return "Failed to refresh your session. Please log in again.";
        case "Network Error":
            return "Unable to connect. Please check your internet connection.";
        default:
            return "An unexpected error occurred. Please try again.";
    }
};



export default function LoginPage() {
    const [formData, setFormData] = useState({
        username: '',
        password: '',
    });

    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [roleMessage, setRoleMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { data: session, status } = useSession();
    const router = useRouter();

    useEffect(() => {
        if (status === 'loading') return; // Wait for session to load

        if (session?.user) {
            // Check user role and redirect accordingly
            const userRole = session.user.roles; // Adjust according to how roles are provided
            
            if (!userRole) {
                setRoleMessage("User role not found. Please contact support.");
                return;
            }

            switch (userRole) {
                case "Administrator":
                    router.push("/dashboard/administrator");
                    break;
                case "Authenticator":
                    router.push("/dashboard/authenticator");
                    break;
                case "Site Admin":
                    router.push("/dashboard/site-admin");
                    break;
                default:
                    router.push("/");
            }
        }
    }, [session, status, router]);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setIsLoading(true);
        setErrorMessage('');
        setSuccessMessage('');
        setRoleMessage('');
        
        const { username, password } = formData;
        // const data = { username, password };
        
        try {
            const response = await signIn('credentials', {
                username,
                password,
                redirect: false,
            });

            if (result?.error) {
                setErrorMessage(getErrorMessage(response.error));
                console.error("Login error:",response.error);
            } else {
                setSuccessMessage("Login successful. Redirecting...");
                router.reload(); // Trigger session reload after successful sign-in
                
            }
        } catch (error) {
            console.error('Login error:', error.response ? error.response.data : error.message);
            setErrorMessage(
                error.response?.data?.message || getErrorMessage(error.message)
            );
        } finally {
            setIsLoading(false);
        }
    };

    const handleChange = (event) => {
        setFormData({ ...formData, [event.target.name]: event.target.value });
    };

    return (
        <div className="w-full lg:grid lg:min-h-[500px] lg:grid-cols-2 xl:min-h-[600px]">
            <div className="flex items-center justify-center py-10">
                <Card className="mx-auto max-w-sm shadow-2xl">
                    <CardHeader>
                        <CardTitle className="text-2xl text-center">Login</CardTitle>
                        <CardDescription>
                            Enter your credentials below to login to your account
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid gap-4">
                            {(errorMessage || successMessage || roleMessage) && (
                                <div
                                    className={`${
                                        errorMessage || roleMessage 
                                            ? "bg-red-100 border border-red-400 text-red-700" 
                                            : "bg-green-100 border border-green-400 text-green-700"
                                    } px-4 py-3 rounded relative`}
                                    role="alert"
                                >
                                    <strong className="font-bold">
                                        {errorMessage ? "Error:" : "Success:"}{" "} 
                                    </strong>
                                    <span className="block sm:inline">
                                        {errorMessage || successMessage || roleMessage}
                                    </span>
                                </div>
                            )}
                            <form onSubmit={handleSubmit}>
                                <div className="grid gap-2">
                                    <Label>Username</Label>
                                    <Input 
                                        type="text"
                                        id="username"
                                        name="username"
                                        value={formData.username}
                                        onChange={handleChange}
                                        required
                                        disabled={isLoading}
                                    />
                                </div>
                                <div className="grid gap-2">
                                    <div className="flex items-center">
                                        <Label>Password</Label>
                                        <Link href="/forgot-password" className="ml-auto inline-block text-sm underline">
                                            Forgot password?
                                        </Link>
                                    </div>
                                    <Input
                                        type="password"
                                        id="password"
                                        name="password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        required
                                        disabled={isLoading}
                                    />
                                </div>
                                <Button type="submit" className="w-full mt-4">Login</Button>
                            </form>
                        </div>
                        <div className="mt-4 text-center text-sm">
                            Don&apos;t have an account?{" "}
                            <Link href="/register" className="underline">Sign Up</Link>
                        </div>
                    </CardContent>
                </Card>
            </div>
            <div className="hidden bg-muted lg:block">
                <Image
                    src="/boy-with-rocket-light.png"
                    alt="Image"
                    width="1920"
                    height="1080"
                    className="h-full w-full object-cover dark:brightness-[0.2] dark:grayscale"
                />
            </div>
        </div>
    );
}
-------
"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

const loginSchema = z.object({
  username: z.string().nonempty("Username is required"),
  password: z.string().nonempty("Password is required"),
});

const LoginPage = () => {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data) => {
    setError(null);
    setLoading(true);

    try {
      const response = await signIn("credentials", {
        redirect: false,
        username: data.username,
        password: data.password,
      });

      if (response.error) {
        setError(response.error);
        setLoading(false);
        return;
      }

      // Fetch user session to determine role-based redirection
      const res = await fetch("/api/auth/session");
      const session = await res.json();

      const roles = session.user.roles || [];
      if (roles.includes("Administrator")) {
        router.push("/dashboard/administrator");
      } else if (roles.includes("Authenticator")) {
        router.push("/dashboard/authenticator");
      } else if (roles.includes("Site-Admin")) {
        router.push("/dashboard/site-admin");
      } else {
        router.push("/dashboard"); // Fallback dashboard
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.");
      console.error("Login error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="w-full max-w-md p-8 space-y-6 bg-white shadow-md rounded-lg">
        <h1 className="text-xl font-bold text-center">Login</h1>
        {error && <div className="p-4 text-red-500 bg-red-100 rounded">{error}</div>}
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-gray-700">
              Username
            </label>
            <input
              id="username"
              type="text"
              {...register("username")}
              className={`w-full px-3 py-2 border rounded ${
                errors.username ? "border-red-500" : "border-gray-300"
              }`}
            />
            {errors.username && (
              <span className="text-sm text-red-500">{errors.username.message}</span>
            )}
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">
              Password
            </label>
            <input
              id="password"
              type="password"
              {...register("password")}
              className={`w-full px-3 py-2 border rounded ${
                errors.password ? "border-red-500" : "border-gray-300"
              }`}
            />
            {errors.password && (
              <span className="text-sm text-red-500">{errors.password.message}</span>
            )}
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2 text-white bg-blue-600 rounded hover:bg-blue-700"
          >
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;
