"use client";
import HeaderComponent from "@/components/layout/header";
import SidebarComponent from "@/components/layout/sidebar";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import { fetchUserDetails } from "@/lib/common/user_api";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function AdministratorLayout({ children }) {
        
    return(
        <SidebarProvider>
            <SidebarComponent dashboardType="Administrator" />
            <SidebarInset>
                <HeaderComponent />
                <main>
                    {children}
                </main>
            </SidebarInset>
        </SidebarProvider>
    );
};




// import { auth } from "@/auth";
// import SidebarComponent from "@/components/layout/sidebar";
// import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar";


// const AdministratorLayout = ({ children }) => {


//     return (
//         <SidebarProvider>
//             <SidebarComponent dashboardType="Administrator" />
//             <SidebarInset>
//                 <main>
//                     { children }
//                 </main>
//             </SidebarInset>
//         </SidebarProvider>
//     );
// };

// export default AdministratorLayout;