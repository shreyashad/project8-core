import { auth } from "@/auth";
import { AdminUserClient } from "@/components/administrator/users-management/user-client";
import { AdminUserColumns } from "@/components/administrator/users-management/users-columns";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";
import { fetchUsersListData } from "@/lib/common/user_api";


export default async function AdminUserManagementPage() {
    const session = await auth();

    const userData = await fetchUsersListData(session.accessToken);
        
    const facetedFilters = [
        {
        id: "is_verified",
        title: "is Verified",
        options: [
            { label: "Verified", value: true },
            { label: "Not Verified", value: false },
        ],
        },
        {
            id: "is_online",
            title: "Status",
            options: [
                { label: "Online", value: true },
                { label: "Off-line", value: false },
            ],
        },
        {
            id: "location_type",
            title: "Location Type",
            options: [
                { label: "Branch", value: "Branch" },
                { label: "Head Office", value: "HO" },
            ],
        },
    ];

    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="administrator/user-management/"
                mdipagetitle="User Management"
                pagetitle="Users"
            />
            
                <AdminUserClient />
                <Separator />
                <DataTable 
                  data={userData}
                  columns={AdminUserColumns}
                  globalFilterColumnId="username"
                  facetedFilters={facetedFilters}
        
                />
        </div>
    );
};