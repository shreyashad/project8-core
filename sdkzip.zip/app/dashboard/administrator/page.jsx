import { auth } from "@/auth";



export default async function AdministratorPage() {
    const session = await auth();
    console.log("admin session details:", session);
    return(
        <>
            <h1>Welcome, Admninistrtator  </h1>
        </>
    );
}