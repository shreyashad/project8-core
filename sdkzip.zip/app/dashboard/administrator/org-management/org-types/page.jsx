import { auth } from "@/auth";
import { OrgTypeClient } from "@/components/administrator/organization-management/orgtype/orgtype-client";
import { OrgTypeColumns } from "@/components/administrator/organization-management/orgtype/orgtype-columns";
import { DashboradBreadCrumb } from "@/components/common/dashboard-breadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";
import { fetchOrgTypeListData } from "@/lib/administrator/org_api";



export default async function OrgTypeManagementPage() {
    const session = await auth();

    const orgTypeData = await fetchOrgTypeListData(session.accessToken);
    console.log("orgType:", orgTypeData);
    
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboradBreadCrumb 
                homelink="administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="administrator/org-management/org-types"
                mdipagetitle="Organization Management"
                pagetitle="Organization Type"
            />
            <OrgTypeClient />
            <Separator />
            <DataTable 
                data={orgTypeData}
                columns={OrgTypeColumns}
                globalFilterColumnId="org_type"
                

            />
        </div>
        
    );
};