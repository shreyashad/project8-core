"use client";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useRouter } from "next/navigation"


export const AdminUserClient = () => {
    const router = useRouter();
    return(
        <div className="flex items-center justify-between">
            <h2 className="text-3xl font-bold tracking-tight">User Management</h2>
            <Button
                onClick={() => {
                    router.push("/dashboard/administrator/user-management/new");
                }}
            >
                <Plus className="mr-2 h-4 w-4" /> Add New
            </Button>
        </div>
    );
};