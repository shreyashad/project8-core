"use client";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Pencil, Trash2 } from "lucide-react";
import { useSession } from "next-auth/react";

import { useRouter } from "next/navigation";
import { useState } from "react";


export function AdminUserCellAction({ data }) {
    const { data: session } = useSession();
    const router = useRouter();
    const [alertModalOpen, setAlertModalOpen] = useState(false);
    
    const handleEdit = () => {
        router.push(`/dashboard/administrator/user-management/${data.id}`);
    };

    const deleteUser = async () => {

    };

    return(
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={handleEdit}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update User</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={() => setAlertModalOpen(true)}
                        >
                            <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete User</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
        </div>
    );
};

