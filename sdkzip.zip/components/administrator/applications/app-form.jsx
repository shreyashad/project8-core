"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { createNewApplication, updateApplicationDetails } from "@/lib/administrator/applications_api";
import { ApplicationFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";


export const AppForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();

    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Application" : "Create Application";
    const description = initialData && initialData.id ? "Edit an Application" : "Create a new Application";
    const toastMessage = initialData && initialData.id ? "Application updated successfully" : "Application created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";



    const form = useForm({
        resolver: zodResolver(ApplicationFormSchema),
        defaultValues: initialData || {
            name: "",
            description: "",
            base_url: "",
            active: false,
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try{
            if (initialData && initialData.id) {
               const updateform = await updateApplicationDetails(session.accessToken, initialData.id, values);
               console.log("Update Response:", updateform);
            } else {
                const newApp = await createNewApplication(session.accessToken, values);
                console.log("Create Response:", newApp);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/application-management`);
        } catch (error) {
            console.error("Submission Error:", error.response || error.message);
            toast.error(error.message);
        }
        finally {
            setLoading(false);
        }
    };

    return(
        <Card className="border-2 shadow-2xl">
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <div className="flex items-center justify-between">
                    <CardDescription>{description}</CardDescription>
                    {initialData && initialData.id && (
                        <Button
                            disabled={loading}
                            variant="destructive"
                            size="icon"
                            onClick={() => setOpen(true)}
                        >
                            <Trash className="h-4 w-4" />
                        </Button>
                    )}
                </div>
                
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid-cols-2 gap-8 md:grid">
                            <FormField 
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Name</FormLabel>
                                        <FormControl>
                                            <Input 
                                                {...field}
                                                placeholder="Name"

                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <FormField 
                                control={form.control}
                                name="base_url"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>URL</FormLabel>
                                        <FormControl>
                                            <Input 
                                                {...field}
                                                placeholder="Name"

                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <FormField 
                                control={form.control}
                                name="description"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Description</FormLabel>
                                        <FormControl>
                                            <Textarea
                                                {...field}
                                                placeholder="Description"
                                                rows={4}

                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <FormField 
                                control={form.control}
                                name="active"
                                render={({ field }) => (
                                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 shadow">
                                        <FormControl>
                                            <Checkbox 
                                                checked={field.value}
                                                onCheckedChange={field.onChange}
                                            />
                                        </FormControl>
                                        <div className="space-y-1 leading-none">
                                            <FormLabel>Is Active</FormLabel>
                                        </div>
                                    </FormItem>
                                )}
                            />
                        </div>
                        <div className="space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => {
                                    router.back();
                                }}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};