import { Building2, FileClock, LayoutGrid, Server, ShieldPlus, SquarePen, UserRoundCog, UsersRound } from "lucide-react";


export const dashboardData = {
    Administrator : [
        {
            groupLabel: "Dashboard",
            menus: [
              {
                href: "/dashboard/adminidtrator",
                label: "Dashboard",
                icon: LayoutGrid,
                submenus:[
                    {
                        href: "/dashboard/administrator/announcement-management/category",
                        label: "Announcement Category"
                    },
                    {
                        href: "/dashboard/administrator/announcement-management/announcements",
                        label: "Announcements"
                    }
                ]
               
              },
            ]
        },
        {
            groupLabel: "Contents",
            menus: [
                {
                    href: "/dashboard/administrator/application-management",
                    label: "Application Management",
                    icon: Server ,
                    
                },
                {
                    href: "/dashboard/administrator/user-management",
                    label: "User Management",
                    icon: UserRoundCog ,
                    
                },
                {
                    href: "/dashboard/administrator/roles-permission",
                    label: "Roles & Permission Management",
                    icon: ShieldPlus ,
                    submenus: []
                },
                {
                    href: "/dashboard/administrator/org-management",
                    label: "Organization Management",
                    icon: Building2 ,
                    submenus: [
                        {
                            href: "/dashboard/administrator/org-management/org-types",
                            label: "Organization Type"
                        },
                        {
                            href: "/dashboard/administrator/org-management/org-subtypes",
                            label: "Organization Sub-Type"
                        },
                        {
                            href: "/dashboard/administrator/org-management/organization",
                            label: "Organizations"
                        },
                        {
                            href: "/dashboard/administrator/org-management/locations",
                            label: "Locations"
                        },
                        {
                            href: "/dashboard/administrator/org-management/department",
                            label: "Departments"
                        },
                        {
                            href: "/dashboard/administrator/org-management/designations",
                            label: "Designations"
                        }
                    ]
                },
                {
                    href: "/dashboard/administrator/teams-management",
                    label: "Team Management",
                    icon: UsersRound ,
                    submenus: []
                },
                {
                    href: "/dashboard/administrator/logs-management",
                    label: "Logs & Reports",
                    icon: FileClock ,
                    submenus: []
                },
            ]
        }
    ],
    Authenticator : [],
    SiteAdmin :[],
};