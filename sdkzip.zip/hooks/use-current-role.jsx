"use client";

import { useSession } from "next-auth/react";

export const useCurrentRole = () => {
  const { data: session } = useSession();

  // Assuming role is part of the session object
  return session?.user?.role || null;
};
