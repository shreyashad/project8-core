"use client";
import { SonnToaster } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "next-themes";
import { useEffect, useState } from "react";


const Providers = ({ childern }) => {
    const [mounted, setMounted] = useState(false);
    
    
    useEffect(() => {
        setMounted(true); // Ensures no mismatch during hydration
      }, []);
    
    // if (!mounted) {
    //     return <div style={{ visibility: "hidden" }}>{ children }</div>; // Avoid mismatch by hiding until mounted
    // };

    return(
        <ThemeProvider attribute="class" enableSystem={false} defaultTheme="light">
            <div>
                <Toaster />
                {childern}
            </div>
            <SonnToaster />
        </ThemeProvider>
    );
};

export default Providers;