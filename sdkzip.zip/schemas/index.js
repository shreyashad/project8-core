// schema for authentication related forms

import { z } from "zod";

// schema for applications management realted form

export const ApplicationFormSchema = z.object({
    name: z.string().min(4, {
        message: " Application name is required"
    }),
    description: z.string().optional(),
    base_url: z.string().min(4, {
        message: "application Url Is required"
    }).url(),
    active: z.boolean({

    }).default(false)
});


// schema for Organization Management

// for Org Type Form

export const OrgTypeFormSchema = z.object({
    org_type: z.string().min(4,{
        message: "Org type is required"
    })
});