from django.urls import path, include

urlpatterns = [
    path('', include('common.hod.urls')),
    path('', include('common.custom_admin.urls')),
    path('', include('common.trainer.urls')),
    path('', include('common.trainers_admin.urls')),
    path('', include('common.employee.urls')),


]