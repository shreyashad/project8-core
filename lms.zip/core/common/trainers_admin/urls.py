from django.urls import path
from . import views
urlpatterns = [
    path('trainers-admin-dashboard', views.dashboard, name='trainers_admin_dashboard'),
    path('todays-wisdom', views.todays_wisdom, name='todays_wisdom'),
    path('trainers-admin-training-request', views.trainers_admin_training_request, name='trainers_admin_training_request'),
    path('trainers-admin-inbox', views.trainers_admin_training_inbox, name='trainers_admin_inbox'),
    path('trainers-admin-sent-items', views.trainers_admin_sent_request, name='trainers_admin_sent'),
]