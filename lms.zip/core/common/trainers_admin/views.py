from accounts.models import *
from common.models import *
from accounts.decorators import login_required_as_role
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from datetime import datetime


@login_required_as_role('trainers_admin')
def dashboard(request):
    today_wisdom = DailyWise.objects.latest('created_date')
    available_trainer = CustomUser.objects.filter(roles='trainer').count()
    online_user = CustomUser.objects.filter(is_online=True).count()

    my_context = {
        'today_wisdom': today_wisdom,
        'available_trainer': available_trainer,
        'online_user': online_user,
    }
    return render(request, 'trainers_admin/dashboard.html', context=my_context)

@login_required_as_role('trainers_admin')
def todays_wisdom(request):
    if request.method == 'POST':
        topic = request.POST.get('today_wisdom')
        if topic:
            daily_wisdom = DailyWise.objects.create(topic=topic,created_by=request.user)
            daily_wisdom.save()
    return redirect('trainers_admin_dashboard')


@login_required_as_role('trainers_admin')
def my_profile(request):
    user = request.user
    profile = get_object_or_404(UserProfile, user=user)
    return render(request, 'trainers_admin/my_profile.html', {'user_profile': profile})


@login_required_as_role('trainers_admin')
def trainers_admin_training_request(request):
    employees = CustomUser.objects.filter(roles='employee')
    admin_trainers = CustomUser.objects.filter(roles='trainers_admin')
    training_name = Course.objects.all()
    my_context = {
        'employees': employees,
        'admin_trainers': admin_trainers,
        'training_name': training_name,

    }
    return render(request, 'trainers_admin/trainers_admin_training_request.html',context=my_context)



@login_required_as_role('trainers_admin')
def trainers_admin_training_inbox(request):
    user = request.user.username
    receiver = CustomUser.objects.get(username=user)
    inbox_data = TrainingRequest.objects.filter(receiver=receiver).order_by('-request_date').select_related('sender')
    return render(request, 'trainers_admin/trainers_admin_inbox.html', {'training_data': inbox_data})



def trainers_admin_sent_request(request):
    user = request.user.username
    sender = CustomUser.objects.get(username=user)
    sent_request = TrainingRequest.objects.filter(sender=sender).order_by('-request_date')
    return render(request,'trainers_admin/trainers_admin_sent.html',{'sent_request': sent_request})




#
# from django.db import transaction
# from django.shortcuts import render, redirect
# from .models import Course, Module, VideoLesson

# @login_required_as_role('trainers_admin')
# def create_course(request):
#     if request.method == 'POST':
#         title = request.POST.get('title')
#         descriptions = request.POST.get('descriptions')
#         category = request.POST.get('category')
#         difficulty_level = request.POST.get('difficulty_level')
#         is_published = request.POST.get('is_published')
#         image = request.FILES.get('cover_image')
#
#         try:
#             with transaction.atomic():
#                 course = Course.objects.create(
#                     title=title,
#                     description=descriptions,
#                     category=category,
#                     difficulty_level=difficulty_level,
#                     is_published=is_published,
#                     image=image,
#                     created_by=request.user,
#                     updated_by=request.user,
#                 )
#
#                 modules_data = request.POST.getlist('modules')
#                 videos_data = request.POST.getlist('videos')
#                 module_images = request.FILES.getlist('module_images')
#                 video_files = request.FILES.getlist('video_files')
#                 video_covers = request.FILES.getlist('video_covers')
#
#                 for index, module_data in enumerate(modules_data):
#                     module_title, module_description, order = module_data.split(',')
#                     module_image = module_images[index] if index < len(module_images) else None
#                     module = Module.objects.create(
#                         course=course,
#                         title=module_title,
#                         description=module_description,
#                         image=module_image,
#                         created_by=request.user,
#                         updated_by=request.user,
#                     )
#                     total_course_duration = 0.0
#
#                     for index, video_data in enumerate(videos_data):
#                         video_title, video_duration, video_order = video_data.split(',')
#                         video_file = video_files[index] if index < len(video_files) else None
#                         video_cover = video_covers[index] if index < len(video_covers) else None
#
#                         VideoLesson.objects.create(
#                             title=video_title,
#                             module=module,
#                             video_file=video_file,
#                             cover_image=video_cover,
#                             duration=video_duration,
#                             order=video_order,
#                             created_by=request.user,
#                             updated_by=request.user
#                         )
#
#             total_course_duration = course.calculate_total_duration()
#             course.duration = total_course_duration
#             course.save()
#             return redirect('course_details')
#
#         except Exception as e:
#             # Handle exceptions, such as database errors or form data validation errors
#             # You can log the error, display an error message, or perform other actions
#             return render(request, 'error_page.html', {'error_message': str(e)})
#
#     categorys = Category.objects.all()
#     return render(request, 'trainers_admin/create_course.html', {'categories': categorys})
