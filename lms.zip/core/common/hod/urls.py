from django.urls import path
from . import views
urlpatterns = [
    path('hod_dashboard', views.dashboard, name='hod_dashboard'),
    path('training-request', views.training_request, name='training_request_inbox_hod'),
    path('training-inbox', views.training_inbox, name='training_inbox'),
    path('sent-request', views.sent_training_request, name='sent_training_request'),
    path('new-training-request', views.create_training_request, name='create_training_request'),
    path('change-password', views.change_password, name='change_password_hod'),
    path('my-profile', views.my_profile, name='my_profile_hod'),
    path('update-profile', views.update_profile, name='update_profile_hod'),
    path('teams', views.hods_team, name='team_details'),

]
