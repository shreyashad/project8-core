from django.urls import path
from . import views
urlpatterns = [
    path('trainers-dashboard', views.dashboard, name='trainers_dashboard'),
]
