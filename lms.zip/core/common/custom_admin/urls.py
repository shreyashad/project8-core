from django.urls import path
from . import views
urlpatterns = [
    path('admin-dashboard', views.dashboard, name='admin_dashboard'),
    path('admin-change-password', views.change_password, name='admin_change_password'),
    path('admin-update-profile', views.update_profile, name='admin_update_profile'),
    path('branches', views.branches, name='add_branches'),
    path('departments', views.departments, name='add_departments'),
    path('designation', views.designations, name='add_designations'),
    path('verify-users', views.verify_user, name='verify_user_admin'),
    path('add-user-role', views.user_roles, name='add_user_role'),
]