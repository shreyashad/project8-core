from accounts.models import *
from common.models import *
from accounts.decorators import login_required_as_role
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from datetime import datetime


def dashboard(request):
    return render(request, 'custom_admin/dashboard.html')


def user_roles(request):
    roles_list = Role.objects.all()

    if request.method == 'POST':
        name = request.POST.get('name')

        if Role.objects.filter(name=name).exists():
            messages.info(request, 'Roles is already registered.')
        else:
            roles = Role.objects.create(name=name)
            roles.save()
            messages.success(request, 'Your branch is successfully created.')
            return redirect('add_user_role')

    return render(request, 'custom_admin/branches.html', {'branches_list': branches_list})


def branches(request):
    branches_list = Branches.objects.all()

    if request.method == 'POST':
        name = request.POST.get('name')

        if Branches.objects.filter(name=name).exists():
            messages.info(request, 'Branch is already registered.')
        else:
            branch = Branches.objects.create(name=name)
            branch.save()
            messages.success(request, 'Your branch is successfully created.')
            return redirect('add_branches')

    return render(request, 'custom_admin/branches.html', {'branches_list': branches_list})




def departments(request):
    departments_list = Departments.objects.all()

    if request.method == 'POST':
        name = request.POST.get('name')

        if Departments.objects.filter(name=name).exists():
            messages.info(request, 'Departments is already registered.')
        else:
            departments = Departments.objects.create(name=name)
            departments.save()
            messages.success(request, 'Your department is successfully created.')
            return redirect('add_departments')

    return render(request, 'custom_admin/departments.html', {'departments_list': departments_list})



def designations(request):
    designation_list = Designation.objects.all()

    if request.method == 'POST':
        name = request.POST.get('name')

        if Designation.objects.filter(name=name).exists():
            messages.info(request, 'designation is already registered.')
        else:
            designation = Designation.objects.create(name=name)
            messages.success(request, 'Your Designation is successfully created.')
            return redirect('add_designations')

    return render(request, 'custom_admin/designations.html', {'designation_list': designation_list})



def change_password(request):
    if request.method == 'POST':
        old_password = request.POST.get('old_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')
        if not request.user.check_password(old_password):
            messages.error(request,'Old password is incorrect')
            return redirect('admin_change_password')
        if new_password != confirm_password:
            messages.error(request, 'New password and confirmation do not match.')
            return redirect('admin_change_password')

        request.user.set_password(new_password)
        request.user.save()

        update_session_auth_hash(request, request.user)
        messages.success(request, 'Password changed successfully')
        return redirect('admin_change_password')
    return render(request, 'custom_admin/change_password.html')

def update_profile(request):
    user = request.user
    profile = get_object_or_404(UserProfile, user=user)
    if request.method == 'POST':
        date_of_birth = request.POST.get('date_of_birth')
        gender = request.POST.get('gender')
        email = request.POST.get('email')
        bio = request.POST.get('bio')
        address = request.POST.get('address')
        photo = request.FILES.get('photo')
        skills = request.POST.getlist('skills')

        if date_of_birth and not date_of_birth_valid(date_of_birth):
            messages.error(request,'Invalid date of birth format.')
            return redirect('update_profile_hod')

        if gender and gender not in ['male', 'female', 'other']:
            messages.error(request, 'Invalid gender value.')
            return redirect('update_profile')

        if email and not email_valid(email):
            messages.error(request, 'Invalid email address.')
            return redirect('update_profile')


        if date_of_birth != profile.date_of_birth:
            profile.date_of_birth = date_of_birth

        if gender != profile.gender:
            profile.gender = gender

        if email != profile.email:
            profile.email = email

        if bio != profile.bio:
            profile.bio = bio

        if address != profile.address:
            profile.address = address

        if photo:
            profile.photo = photo

        if skills != [str(skill.id) for skill in profile.skills.all()]:
            profile.skills.set(skills)

        profile.save()
        messages.success(request, 'Profile updated Successfully')
        return redirect('hod_profile')
    skills = Skill.objects.all()

    return render(request,'update_profile.html',{'user_profile': profile, 'skills': skills})




def date_of_birth_valid(date_str):
    try:
        datetime.datetime.strptime(date_str, '%Y-%m-%d')
        return True
    except ValueError:
        return False

def email_valid(email):
    try:
        validators.validate_email(email)
        return True
    except ValidationError:
        return False

def executive_list(request):
    # to display online users
    hod_branch = request.user.branch
    hod_department = request.user.department
    all_users = CustomUser.objects.filter(branch=hod_branch, department=hod_department, is_verified=True).values()
    new_users = CustomUser.objects.filter(branch=hod_branch, department=hod_department, is_verified=False).values()

    mycontext = {
        'new_users':new_users,
        'all_users': all_users,

        'active_page': 'dashboard',
    }
    return render(request, 'hod/executive_list.html', context=mycontext)


def verify_user(request,user_id):
    try:
        emp = CustomUser.objects.get(id=user_id)
    except CustomUser.DoesNotExist:
        # Handle the case when the video lesson does not exist
        messages.error(request, 'User does not exist')
        return redirect('executive_list')  # Redirect to a course list view or another appropriate page
    if request.method =='POST':
        role = request.POST.get('role')
        is_verified = request.POST.get('is_verified')
        emp.role = role
        emp.is_verified = is_verified
        emp.save()
        messages.success(request, 'user has been approved')
        return redirect('executive_list')
    return render(request, 'custom_admin/approve_user.html', {'emp': emp})
