from django.db import models

# Create your models here.
import subprocess
from django.urls import reverse
from django.db import models
from autoslug import AutoSlugField
from accounts.models import *
from django.db.models import Sum






    # def calculate_total_duration(self):
    #     total_duration = 0
    #     for module in self.module_set.all():
    #         for lesson in module.lesson_set.all():
    #             video_lesson = lesson.videolesson
    #             if video_lesson:
    #                 total_duration += video_lesson.duration
    #     return total_duration


#
# class Badge(models.Model):
#     title = models.CharField(max_length=255)
#     slug = AutoSlugField(populate_from='title', unique=True)
#     description = models.TextField()
#     image = models.ImageField(upload_to='badge_images/')
#     users = models.ManyToManyField(
#         CustomUser,
#         through='Award',
#         verbose_name='user',
#         help_text=('Users that earned this badge'))
#
#     users_count = models.IntegerField(
#         default=0,
#         verbose_name=('users count'),
#         editable=False)
#
#     class Meta:
#         verbose_name = 'badge'
#         verbose_name_plural = 'badges'
#
#     def __str__(self):
#         return self.title
#
#     def get_absolute_url(self):
#         return reverse('badge_detail', kwargs={'slug': self.slug})
#
# class Award(models.Model):
#     """
#     An Award.
#     """
#     user = models.ForeignKey(
#         CustomUser,
#         verbose_name=('user'),
#         on_delete=models.CASCADE,
#         related_name='badges')
#
#     badge = models.ForeignKey(
#         Badge,
#         verbose_name=('badge'),
#         on_delete=models.CASCADE,
#         related_name='awards')
#
#     awarded_at = models.DateTimeField(
#         verbose_name=('awarded at'),
#         auto_now_add=True)
#
#     class Meta:
#         abstract = True
#         app_label = 'badgify'
#         verbose_name = ('award')
#         verbose_name_plural = ('awards')
#         unique_together = (('user', 'badge'),)
#
#     def __str__(self):
#         return '%s earned %s' % (self.user, self.badge.title)
# class UserBadge(models.Model):
#     user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
#     badge = models.ForeignKey(Badge, on_delete=models.CASCADE)
#     awarded_at = models.DateTimeField(auto_now_add=True)



# class UserProgress(models.Model):
#     user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
#     content = models.ForeignKey(ContentType, on_delete=models.CASCADE)
#     object_id = models.PositiveIntegerField()
#     content_object = GenericForeignKey('content', 'object_id')
#     completed = models.BooleanField(default=False)

# ------------------------------------------------- models
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Course, Module, VideoLesson, Category
import subprocess

def create_course(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        category_id = request.POST.get('category')
        difficulty_level = request.POST.get('difficulty_level')
        duration = request.POST.get('duration')
        image = request.FILES.get('course_image')
        is_published = request.POST.get('is_published', False)

        course = Course.objects.create(
            title=title,
            description=description,
            category_id=category_id,
            difficulty_level=difficulty_level,
            duration=duration,
            image=image,
            is_published=is_published,
            created_by=request.user,
            update_by=request.user
        )

        modules_data = request.POST.getlist('modules')
        videos_data = request.POST.getlist('videos')
        module_images = request.FILES.getlist('module_images')
        video_files = request.FILES.getlist('video_files')

        for index, module_data in enumerate(modules_data):
            module_title, module_description = module_data.split(',')
            module_image = module_images[index] if index < len(module_images) else None
            module = Module.objects.create(
                course=course,
                title=module_title,
                description=module_description,
                image=module_image,
                created_by=request.user,
                update_by=request.user
            )

        total_course_duration = 0.0

        for index, video_data in enumerate(videos_data):
            video_title, video_duration = video_data.split(',')
            video_file = video_files[index] if index < len(video_files) else None
            video = VideoLesson.objects.create(
                title=video_title,
                duration=video_duration,
                module=module,
                video_file=video_file,
                created_by=request.user,
                update_by=request.user
            )
            total_course_duration += video_duration

        course.duration = total_course_duration
        course.save()

        return redirect('course_details', slug=course.slug)

    categories = Category.objects.all()
    return render(request, 'create_course.html', {'categories': categories})


from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Course, Module, VideoLesson, Category
import subprocess

def create_course(request):
    if request.method == 'POST':
        # Extract course details from the POST request
        title = request.POST.get('title')
        description = request.POST.get('description')
        category_id = request.POST.get('category')
        difficulty_level = request.POST.get('difficulty_level')
        duration = request.POST.get('duration')
        image = request.FILES.get('course_image')
        is_published = request.POST.get('is_published', False)

        # Create the course
        course = Course.objects.create(
            title=title,
            description=description,
            category_id=category_id,
            difficulty_level=difficulty_level,
            duration=duration,
            image=image,
            is_published=is_published,
            created_by=request.user,
            update_by=request.user
        )

        # Extract modules and videos from the POST request
        modules_data = request.POST.getlist('modules')
        videos_data = request.FILES.getlist('video_files')
        video_titles = request.POST.getlist('video_titles')
        video_covers = request.FILES.getlist('video_covers')

        # Create modules for the course
        for index, module_data in enumerate(modules_data):
            module_title, module_description = module_data.split(',')
            module = Module.objects.create(
                course=course,
                title=module_title,
                description=module_description,
                created_by=request.user,
                update_by=request.user
            )

            # Create videos for the module
            for index, video_file in enumerate(videos_data):
                video_title = video_titles[index]
                video_cover = video_covers[index] if index < len(video_covers) else None
                video = VideoLesson.objects.create(
                    title=video_title,
                    module=module,
                    video_file=video_file,
                    cover_image=video_cover,
                    created_by=request.user,
                    update_by=request.user
                )

        # Calculate the total course duration based on video durations
        total_course_duration = course.calculate_total_duration()
        course.duration = total_course_duration
        course.save()

        return redirect('course_details', slug=course.slug)

    # Fetch categories for dropdown
    categories = Category.objects.all()
    return render(request, 'create_course.html', {'categories': categories})
