from django.shortcuts import render, redirect
from .models import *
from accounts.decorators import login_required_as_role
from django.contrib import messages
from .forms import CourseForm, ModuleForm, VideoLessonForm
from django.forms import inlineformset_factory
from django.db import transaction

# Create your views here.

@login_required_as_role('trainers_admin')
def course_category(request):
    course_category_list = Category.objects.all()

    if request.method == 'POST':
        name = request.POST.get('category_title')
        image = request.FILES.get('category_image')
        description = request.POST.get('category_description')
        category_status = request.POST.get('category_status')

        if Category.objects.filter(name=name).exists():
            messages.info(request, 'Course Category is already registered.')
        else:
            category = Category.objects.create(
                name=name, image=image, description=description,category_status=category_status
            )

            category.save()
            messages.success(request, 'Your Course Category is successfully created.')
            return redirect('add_course_category')

    return render(request, 'trainers_admin/course_category.html', {'course_category_list': course_category_list})

@login_required_as_role('trainers_admin')
def course_list(request):
    courses = Course.objects.all()
    return render(request,'trainers_admin/course_list.html',{'couse_list': courses})

#
# class CourseListJsonView(DatatableView):
#     model = Course
#     template_name = 'course_list.html'  # This should be a template with your DataTable HTML
#
#     # Specify the columns to be displayed in the DataTable
#     columns = ['name', 'instructor', 'start_date', 'end_date']
#
#     # Additional configuration options for DataTables
#     order_columns = ['name', 'instructor', 'start_date', 'end_date']
#
#     def get_initial_queryset(self):
#         # Customize the queryset if needed
#         return Course.objects.all()

@login_required_as_role('trainers_admin')
def create_course(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        descriptions = request.POST.get('description')
        category = request.POST.get('category')
        difficulty_level = request.POST.get('difficulty_level')
        is_published = request.POST.get('is_published')
        image = request.FILES.get('cover_image')

        try:
            with transaction.atomic():
                course = Course.objects.create(
                    title=title,
                    description=descriptions,
                    category=category,
                    difficulty_level=difficulty_level,
                    is_published=is_published,
                    image=image,
                    created_by=request.user,
                    update_by=request.user,
                )

                # Extract modules and videos from the POST request
                modules_data = request.POST.getlist('modules')
                videos_data = request.POST.getlist('videos')
                module_images = request.FILES.getlist('module_images')
                video_files = request.FILES.getlist('video_files')
                video_covers = request.FILES.getlist('video_covers')

                # Create modules for the course
                for index, module_data in enumerate(modules_data):
                    module_title, module_description, module_order = module_data.split(',')
                    module_image = module_images[index] if index < len(module_images) else None
                    module = Module.objects.create(
                        course=course,
                        title=module_title,
                        description=module_description,
                        image=module_image,
                        order=module_order,
                        create_by=request.user,
                        update_by=request.user,
                    )
                    module.save()
                    total_course_duration = 0.0
                    # Create videos for the module
                    for index, video_data in enumerate(videos_data):
                        video_title, video_duration, video_order = video_data.split(',')
                        video_file = video_files[index] if index < len(video_files) else None
                        video_cover = video_covers[index] if index < len(video_covers) else None

                        video = VideoLesson.objects.create(
                            title=video_title,
                            module=module,
                            video_file=video_file,
                            cover_image=video_cover,
                            duration=video_duration,
                            order=video_order,
                            created_by=request.user,
                            update_by=request.user
                        )
                        video.save()


            total_course_duration = course.calculate_total_duration()
            course.duration = total_course_duration
            course.save()
            messages.success('Course Added Successfully !')
            return redirect('course_list')
        except Exception as e:
            return render(request,'trainers_admin/create_course.html', {'error_message': str(e)})
    categorys = Category.objects.all()
    return render(request,'trainers_admin/create_course.html',{'categories': categorys})










#
# def create_course(request):
#     if request.method == 'POST':
#         course_form = CourseForm(request.POST, request.FILES)
#         module_formset = inlineformset_factory(Course, Module, form=ModuleForm, extra=1)
#         video_formset = inlineformset_factory(Module, VideoLesson, form=VideoLessonForm, extra=1)
#
#
#         if course_form.is_valid():
#             course = course_form.save(commit=False)
#             course.created_by = request.user
#             course.update_by = request.user
#             course.save()
#
#             if module_formset.is_valid():
#                 modules = module_formset.save(commit=False)
#                 for module in modules:
#                     module.course = course
#                     module.save()
#             if video_formset.is_valid():
#                 videos = video_formset.save(commit=False)
#                 for video in videos:
#                     video.module = modules[0]
#                     video.save()
#                 return redirect('course_list')
#     else:
#         course_form = CourseForm()
#         module_formset = inlineformset_factory(Course, Module, form=ModuleForm, extra=1)
#         video_formset = inlineformset_factory(Module, VideoLesson, form=VideoLessonForm, extra=1)
#
#     return render(
#         request,
#         'trainers_admin/create_course.html',
#         {'course_form': course_form, 'module_formset': module_formset, 'video_formset': video_formset}
#     )

from django.contrib.auth import get_user_model

@login_required_as_role('hod')
def create_training_request(request):
    if request.method == 'POST':
        training_type = request.POST.get('training_type')
        receiver_username = request.POST.get('receiver')  # Assuming receiver is a username
        receiver_type = 'trainers_admin'
        request_program = request.POST.get('requested_program')
        message = request.POST.get('message')
        employees_ids = request.POST.getlist('employees')
        hod_username = request.user.username

        try:
            sender = CustomUser.objects.get(username=hod_username)
        except CustomUser.DoesNotExist:
            messages.error(request, 'Invalid sender')
            return render(request, 'hod/new_training_request.html')

        try:
            requested_program = Course.objects.get(pk=request_program)
        except Course.DoesNotExist:
            messages.error(request, 'Invalid requested program')
            return render(request, 'hod/new_training_request.html')

        try:
            receiver = get_user_model().objects.get(username=receiver_username)
        except get_user_model().DoesNotExist:
            messages.error(request, 'Invalid receiver')
            return render(request, 'hod/new_training_request.html')

        training_request = TrainingRequest.objects.create(
            sender=sender,
            receiver_type=receiver_type,
            training_type=training_type,
            receiver=receiver,  # Assign the CustomUser instance to receiver field
            requested_program=requested_program,
            message=message
        )
        training_request.employees.set(employees_ids)
        messages.success(request, 'Training request sent successfully!')
        return redirect('hod_dashboard')

    return render(request, 'hod/all_training_request.html')
