from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect

def login_required_as_role(required_role):
    def decorator(view_func):
        @login_required
        def wrapper(request, *args, **kwargs):
            user_roles = request.user.roles
            if request.user.is_verified and required_role in user_roles:
                return view_func(request, *args, **kwargs)
            else:
                return redirect('custom_login')
        return wrapper
    return decorator