from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from django.test import Client
# Create your tests here.


class CustomLoginTestCase(TestCase):
    def setUp(self):
        # Create a test user
        self.user = get_user_model().objects.create_user(
            username='testuser',
            password='testpassword',
            is_verified=True,
            roles='trainers_admin'
        )

    def test_successful_login(self):
        client = Client()

        # Simulate a POST request with valid credentials
        response = client.post(reverse('custom_login'), {'username': 'testuser', 'password': 'testpassword'})

        # Check if the user is redirected to the correct dashboard
        self.assertRedirects(response, reverse('employee_dashboard'))

        # Check if the user is marked as online
        self.user.refresh_from_db()
        self.assertTrue(self.user.is_online)

    def test_unsuccessful_login(self):
        client = Client()

        # Simulate a POST request with invalid credentials
        response = client.post(reverse('custom_login'), {'username': 'invaliduser', 'password': 'invalidpassword'})

        # Check if the user stays on the login page
        self.assertTemplateUsed(response, 'accounts/login.html')

        # Check if the error message is displayed
        self.assertContains(response, 'Invalid username or password. Please try again.')

        # Check if the user is not marked as online
        self.user.refresh_from_db()
        self.assertFalse(self.user.is_online)
