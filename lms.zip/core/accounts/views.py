from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import SetPasswordForm

# Create your views here.


def register(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        branch_id = request.POST.get('branch')
        department_id = request.POST.get('department')
        designation_id = request.POST.get('designation')
        emp_id = request.POST.get('emp_id')
        mobile = request.POST.get('mobile')
        username = request.POST.get('username')
        password = request.POST.get('password')
        password1 = request.POST.get('password1')
        if password1 == password:
            if CustomUser.objects.filter(username=username).exists():
                messages.info(request, 'Username already taken..')
                return render(request,'accounts/register.html')
            if CustomUser.objects.filter(emp_id=emp_id).exists():
                messages.info(request,'Employee already registered. Please login to your account!')
                return render(request,'accounts/register.html')

            try:
                branch = Branches.objects.get(pk=branch_id)
                department = Departments.objects.get(pk=department_id)
                designation = Designation.objects.get(pk=designation_id)
            except Branches.DoesNotExist:
                messages.error(request, 'Selected branch dose not exist.')
                return render(request, 'accounts/register.html')
            except Departments.DoesNotExist:
                messages.error(request, 'Selected department dose not exist.')
                return render(request, 'accounts/register.html')
            except Designation.DoesNotExist:
                messages.error(request, 'Selected designation dose not exist.')
                return render(request, 'accounts/register.html')

            user = CustomUser.objects.create_user(
                first_name=first_name,last_name=last_name,branch=branch,
                department=department,designation=designation,emp_id=emp_id,
                mobile=mobile,username=username, password=password
            )
            user.save()
            profile_obj = UserProfile.objects.create(user=user)
            profile_obj.save()
            messages.info(request,'Your account is successfully created, ')
            return render(request,'accounts/login.html')
        else:
            messages.info(request,'password not matching...')
            return render('accounts/register.html')
    else:
        branches = Branches.objects.all()
        designations = Designation.objects.all()
        departments = Departments.objects.all()
        my_context = {
            'branches': branches,
            'departments': departments,
            'designations': designations,
        }
        return render(request,'accounts/register.html', context=my_context)


#
# def custom_login(request):
#     if request.method == 'POST':
#         username = request.POST.get('username')
#         password = request.POST.get('password')
#
#         user = authenticate(username=username,password=password)
#         if user is not None:
#             if not user.is_verified:
#                 messages.info(request,'Profile is not verified please contact your hod')
#                 return render(request,'accounts/login.html')
#
#             user.is_online = True
#             user.save()
#
#             role = user.roles
#             if role == 'custom_admin':
#                 login(request, user)
#                 return redirect('admin_dashboard')
#             elif role == 'hod':
#                 login(request, user)
#                 return redirect('hod_dashboard')
#             elif role == 'trainers_admin':
#                 login(request, user)
#                 return redirect('trainers_admin_dashboard')
#             elif role == 'trainer':
#                 login(request, user)
#                 return redirect('trainers_dashboard')
#             else:
#                 login(request, user)
#                 return redirect('employee_dashboard')
#         else:
#             messages.error(request,'Invalid username or password. Please try again')
#             return render(request, 'accounts/login.html')
#     else:
#         return render(request, 'accounts/login.html')




def custom_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        if user is not None:
            if not user.is_verified:
                messages.info(request, 'Profile is not verified. Please contact your HOD.')
                return render(request, 'accounts/login.html')

            user.is_online = True
            user.save()

            role_dashboard_mapping = {
                'custom_admin': 'admin_dashboard',
                'hod': 'hod_dashboard',
                'trainers_admin': 'trainers_admin_dashboard',
                'trainer': 'trainers_dashboard',
            }
            default_dashboard = 'employee_dashboard'
            role = user.roles
            dashboard_url = role_dashboard_mapping.get(role, default_dashboard)
            login(request, user)
            return redirect(dashboard_url)
        else:
            messages.error(request, 'Invalid username or password. Please try again.')
            return render(request, 'accounts/login.html')
    else:
        return render(request, 'accounts/login.html')



def cust_logout(request):
    user = request.user
    user.is_online = False
    user.save()
    logout(request)
    return redirect('custom_login')


def forgot_password(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        emp_id = request.POST.get('emp_id')
        mobile = request.POST.get('mobile')

        try:
            user = CustomUser.objects.get(username=username,emp_id=emp_id,mobile=mobile)
        except CustomUser.DoesNotExist:
            messages.error(request, 'Invalid credentials. Please try again')
            return render(request, 'accounts/forget_password.html')

        request.session['reset_user_id'] = user.id
        return redirect('reset_password')
    return render(request,'accounts/forget_password.html')

def rest_password(request):
    user_id = request.session.get('reset_user_id')
    if not user_id:
        return redirect('forget_password')
    user = CustomUser.objects.get(pk=user_id)
    if request.method == 'POST':
        form = SetPasswordForm(user, request.POST)
        if form.is_valid():
            form.save()
            del request.session['reset_user_id']
            messages.success(request,'Your password has been reset successfully ')
            return redirect('custom_login')
        else:
            form = SetPasswordForm(user)
        return render(request, 'accounts/reset_password.html', {'form': form})