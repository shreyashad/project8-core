from django.db import models
from django.core import validators
from django.contrib.auth.models import AbstractBaseUser,PermissionsMixin,Group
from .user_manager import CustomUserManager
from django.templatetags.static import static
# Create your models here.

class Branches(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class Departments(models.Model):
    name = models.CharField(max_length=150)

    def __str__(self):
        return self.name

class Designation(models.Model):
    name = models.CharField(max_length=150)

    def __str__(self):
        return self.name

class Permission(models.Model):
    # Define custom permissions if needed
    name = models.CharField(max_length=150)

    def __str__(self):
        return self.name
    # Define other fields as required for the permissions


class Team(models.Model):
    name = models.CharField(max_length=150)
    employee = models.ManyToManyField('CustomUser', related_name='emp_teams')
    hod = models.ForeignKey('CustomUser', on_delete=models.SET_NULL, related_name='hod_teams', null=True, blank=True)

    def __str__(self):
        return self.name




Roles = [
    ('employee', 'employee'),
    ('hod', 'hod'),
    ('trainer', 'trainer'),
    ('trainers_admin', 'trainers_admin'),
    ('custom_admin', 'custom_admin'),

]


class CustomUser(AbstractBaseUser,PermissionsMixin):
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    username = models.CharField(max_length=150, unique=True)
    branch = models.ForeignKey(Branches, on_delete=models.CASCADE, null=True)
    department = models.ForeignKey(Departments, on_delete=models.CASCADE, null=True)
    designation = models.ForeignKey(Designation, on_delete=models.CASCADE, null=True)
    emp_id = models.CharField(max_length=15,unique=True)
    mobile = models.IntegerField(null=True)
    is_superuser = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_verified = models.BooleanField(default=False)
    is_online = models.BooleanField(default=False)
    created_date = models.DateTimeField(auto_now_add=True)
    update_date = models.DateTimeField(auto_now=True)
    roles = models.CharField(max_length=20, choices=Roles, default='employee')
    teams = models.ManyToManyField(Team)
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='customuser_groups',  # Change 'customuser_groups' to your preferred name
        blank=True,
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='customuser_user_permissions',  # Change 'customuser_user_permissions' to your preferred name
        blank=True,
    )
    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    def __str__(self):
      return self.username

    def get_full_name(self):
        return f"{self.first_name}{self.last_name}"


def user_directory_path(instance,filename):
    this = UserProfile.objects.filter(user=instance.user)
    if len(this) == 0:
        return 'user_{0}/{1}'.format(instance.user,filename)
    this = UserProfile.objects.get(user=instance.user)
    if this.photo !=filename:
        this.photo.delete(save=False)
        return 'user_{0}/{1}'.format(instance.user, filename)
    else:
        return 'user_{0}/{1}'.format(instance.user, filename)



class Skill(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name


class UserProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=10, choices=[('male', 'Male'), ('female', 'Female'), ('other', 'Other')],
                              blank=True)
    join_date = models.DateTimeField(null=True, blank=True)
    email = models.EmailField(max_length=254, unique=True, null=True)
    bio = models.TextField(blank=True)
    address = models.TextField(blank=True)
    photo = models.ImageField(upload_to='user_directory_path/', blank=True)
    skills = models.ManyToManyField('Skill', related_name='users', blank=True)

    def __str__(self):
        return f"Profile of {self.user.username}"

    def get_user_skills(self):
        return self.skills.all()

    def get_photo_url(self):
        # Check if the user has uploaded a photo
        if self.photo:
            # Return the URL for the user's photo
            return self.photo.url
        else:
            # If no photo is uploaded, return a default photo URL or None
            return static('vendors/images/person.svg')  # Replace 'default_photo_url_name' with the actual URL name

