from django.shortcuts import render
from .models import *
# Create your views here.

def notification_list(request):
    # Retrieve notifications for the current user
    notifications = Notification.objects.filter(user=request.user).order_by('-timestamp')

    # Mark notifications as read when viewed
    for notification in notifications:
        if not notification.is_read:
            notification.is_read = True
            notification.save()

    return render(request, 'notifications/notification_list.html', {'notifications': notifications})