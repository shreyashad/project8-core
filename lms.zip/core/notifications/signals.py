from django.db.models.signals import post_save
from django.dispatch import receiver
from coursemanagement.models import Course
from common.models import TrainingRequest
from notifications.models import Notification
from accounts.models import CustomUser




@receiver(post_save, sender=TrainingRequest)
def create_training_request_notification(sender, instance, created, **kwargs):
    if created:
        message = f"New training request submitted: {instance.message}"
        Notification.objects.create(user=instance.receiver, message=message)


@receiver(post_save, sender=CustomUser)
def send_user_verification_notification(sender, instance, created, **kwargs):
    if created:
        # Assuming custom admin user is already defined
        custom_admin = CustomUser.objects.get(role='custom_admin')

        message = f"New user '{instance.username}' has registered. Please verify the user."
        Notification.objects.create(user=custom_admin, message=message)




@receiver(post_save, sender=CustomUser)
def notify_hod_of_new_user(sender, instance, created, **kwargs):
    """
    Notifies the Head of Department (HOD) when a new user is registered within their department.
    """
    if created:
        # Find the HOD associated with the department of the new user
        hod = instance.department.hod  # Assuming each department has a 'hod' field referencing the HOD

        # If HOD is found, create a notification
        if hod:
            message = f"A new user '{instance.username}' has registered in your department. Please add them to your team."
            Notification.objects.create(user=hod, message=message)