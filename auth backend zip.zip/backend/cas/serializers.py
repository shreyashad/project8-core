from rest_framework import serializers
from .models import *
from roles.models import UserRole
from roles.serializers import RoleSerializer


from rest_framework import serializers
from django.contrib.auth import authenticate
from django.contrib.auth.models import User

from rest_framework import serializers

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=255, required=True)
    password = serializers.CharField(max_length=128, write_only=True, required=True)
    application_id = serializers.CharField(max_length=255, required=True)





class ServiceTicketValidationSerializer(serializers.Serializer):
    service_ticket = serializers.CharField(max_length=255, required=True)
    application_id = serializers.CharField(max_length=255, required=True)






# class LoginSerializer(serializers.Serializer):
#     username = serializers.CharField(required=True)
#     password = serializers.CharField(write_only=True, required=True)
#     application_id = serializers.UUIDField(required=True)  # Add application_id to filter roles
#
#     def validate(self, data):
#         username = data.get('username')
#         password = data.get('password')
#         application_id = data.get('application_id')
#
#         # Use Django's authenticate method to check the credentials
#         user = authenticate(username=username, password=password)
#         if user is None:
#             raise serializers.ValidationError('Invalid credentials.')
#
#         # Fetch user roles for the given application
#         roles = UserRole.objects.filter(user=user, application_id=application_id)
#         if not roles.exists():
#             raise serializers.ValidationError('User has no roles for the specified application.')
#
#         # Serialize roles
#         role_serializer = RoleSerializer(roles, many=True)
#
#         # Add roles to validated data
#         data['user'] = user
#         data['roles'] = role_serializer.data
#         return data

# class ChangePasswordSerializer(serializers.Serializer):
#     old_password = serializers.CharField(style={'input_type': 'password'}, trim_whitespace=False)
#     new_password = serializers.CharField(style={'input_type': 'password'}, trim_whitespace=False)
#
#     def validate(self, data):
#         user = self.context['request'].user
#         old_password = data.get('old_password')
#         new_password = data.get('new_password')
#
#         if not user.check_password(old_password):
#             raise serializers.ValidationError("Old password is incorrect.")
#         if old_password == new_password:
#             raise serializers.ValidationError("New password must be different from old password.")
#
#         return data
#
#
# class TicketSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Ticket
#         fields = ['ticket', 'user', 'service', 'expires', 'consumed']
#
#
# class ServiceSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Service
#         fields = ['id', 'name', 'base_url', 'active']
#
#
# class UserProfileSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = UserProfile
#         fields = ['address', 'city', 'state', 'country', 'postal_code', 'phone_number', 'date_of_birth', 'profile_picture', 'bio']
