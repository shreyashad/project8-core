# audit/models.py
from django.db import models
from accounts.models import CustomUser
from roles.models import Application
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey

# Create your models here.


class ActionType(models.TextChoices):
    ASSIGN_ROLE = 'Assign Role', 'Assign Role'
    REVOKE_ROLE = 'Revoke Role', 'Revoke Role'
    CREATE = 'Create', 'Create'
    UPDATE = 'Update', 'Update'
    DELETE = 'Delete', 'Delete'
    READ = 'Read', 'Read'
    LOGIN = 'Login', 'Login'
    LOGOUT = 'Logout', 'Logout'
    ERROR = 'Error', 'Error'
    CHANGED_PASSWORD = 'Changed password', 'Changed password'
    PROFILE_UPDATE = 'Update Profile', 'Update Profile'
    GENRATE_REPORT = 'Generate Report','Generate Report'
    DOWNLOAD_REPORT = 'Download Report', 'Download Report'

class AuditLogEntry(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True)
    application = models.ForeignKey(Application,  on_delete=models.SET_NULL, null=True, related_name='audit_logs')
    action_type =models.CharField(max_length=20, choices=ActionType)
    timestamp = models.DateTimeField(auto_now_add=True)
    object_id = models.CharField(max_length=255)
    object_type = models.ForeignKey(ContentType, on_delete=models.SET_NULL, null=True, blank=True)
    content_object = GenericForeignKey('object_type', 'object_id')
    details = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.action_type} on {self.object_type} - {self.timestamp}"

    class Meta:
        indexes = [
            models.Index(fields=['user']),
            models.Index(fields=['application']),
            models.Index(fields=['action_type']),
            models.Index(fields=['timestamp']),
        ]


class UserApplicationStatus(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    application = models.ForeignKey(Application, on_delete=models.CASCADE)
    is_online = models.BooleanField(default=False)
    last_active = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'application')

    def __str__(self):
        return f"{self.user.username} - {self.application.name} - {'Online' if self.is_online else 'Offline'}"
