from django.db.models import Count
from django.shortcuts import render
from rest_framework.response import Response

from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework import status, generics
from rest_framework.permissions import IsAuthenticated

# Create your views here.


class AuditLogListView(generics.ListAPIView):
    serializer_class = AuditLogSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        """
               Optionally filter logs based on request parameters (e.g., by user, application, or action type).
               """
        queryset = AuditLogEntry.objects.all()

        # Filtering by user
        user = self.request.query_params.get('user')
        if user:
            queryset = queryset.filter(user__username=user)

        # Filtering by application
        application = self.request.query_params.get('application')
        if application:
            queryset = queryset.filter(application__name=application)

        # Filtering by action type
        action_type = self.request.query_params.get('action_type')
        if action_type:
            queryset = queryset.filter(action_type=action_type)

        return queryset


class AuditLogDetailView(generics.RetrieveAPIView):
    queryset = AuditLogEntry.objects.all()
    serializer_class = AuditLogSerializer
    permission_classes = [IsAuthenticated]


class UserApplicationStatusChartView(APIView):
    def get(self, request, *args, **kwargs):
        online_status = UserApplicationStatus.objects.filter(is_online=True) \
            .values('application__name') \
            .annotate(online_count=Count('id'))
        return Response(online_status, status=status.HTTP_200_OK)



class OnlineUsersByApplicationView(APIView):
    def get(self, request, *args, **kwargs):
        application_name = request.query_params.get('application_name')

        if not application_name:
            return Response({"error": "Application name is required."}, status=status.HTTP_400_BAD_REQUEST)

        online_users = UserApplicationStatus.objects.filter(
            is_online=True,
            application__name=application_name
        ).values('user__username')  # Adjust this field based on how you want to represent users

        online_user_count = online_users.count()
        online_user_list = list(online_users)  # Convert to list if you want to return user details

        return Response({
            "application_name": application_name,
            "online_count": online_user_count,
            "online_users": online_user_list  # You can return usernames or other user details here
        }, status=status.HTTP_200_OK)
