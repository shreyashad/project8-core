from datetime import timedelta

from django.contrib.auth.tokens import default_token_generator

from roles.models import UserRole
from .models import *
from .notification import create_admin_notification
from .serializers import *
from rest_framework.response import Response
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from django.contrib.auth.forms import SetPasswordForm
from rest_framework.views import APIView
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.contrib.auth import get_user_model
from audit.models import *




# for user registration
class UserRegistrationView(generics.CreateAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserRegistrationSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            application_name = serializer.validated_data.get('application_name')
            application = Application.objects.filter(name=application_name).first()
            if not application:
                return Response({'error': 'Application not found.'}, status=status.HTTP_400_BAD_REQUEST)

            create_admin_notification(new_user=user,  application=application)
            AuditLogEntry.objects.create(
                user=user,  # user who registered
                application=application,  # Replace with appropriate application instance
                action_type=ActionType.CREATE,
                object_id=str(user.id),
                object_type=ContentType.objects.get_for_model(CustomUser),
                details=f"Registered user - ID: {user.id}"
            )
            return Response({'message': 'User registered successfully.'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



# for user profile details
class UserProfileDetailView(generics.RetrieveUpdateAPIView):
    queryset = UserProfile.objects.all()
    serializer_class = UserProfileSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        user = self.request.user
        return UserProfile.objects.get(user=user)



# for user Accounts Details
class UserAccountDetailsView(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        try:
            users = request.user
            serializer = CustomUserSerializer(users)  # Serialize the user object
            return Response(serializer.data, status=status.HTTP_200_OK)  # Return serialized data
        except CustomUser.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)




# forgot password related view  part 1:-  for password reset request
class PasswordResetRequestView(APIView):

    def post(self, request):
        serializer = PasswordResetRequestSerializer(data=request.data)
        if serializer.is_valid():
            username = serializer.validated_data['username']
            emp_code = serializer.validated_data['emp_code']
            mobile = serializer.validated_data['mobile']

            try:
                user = CustomUser.objects.get(username=username, emp_code=emp_code, mobile=mobile)
                token = default_token_generator.make_token(user)
                user.password_reset_token = token
                user.token_expiration = timezone.now() + timedelta(hours=1)
                user.save()

                return Response({"token": token}, status=status.HTTP_200_OK)
            except CustomUser.DoesNotExist:
                return Response({"error": "Invalid credentials"}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# forgot password related view  part 2:-  for password reset
class PasswordResetView(APIView):
    def post(self, request):
        serializer = PasswordResetSerializer(data=request.data)
        if serializer.is_valid():
            token = serializer.validated_data['token']
            new_password = serializer.validated_data['new_password']

            try:
                user = CustomUser.objects.get(password_reset_token=token)

                if user.token_expiration < timezone.now():
                    return  Response({"error": "Token has expired"}, status=status.HTTP_400_BAD_REQUEST)

                if default_token_generator.check_token(user, token):
                    user.set_password(new_password)
                    user.password_reset_token = ""
                    user.token_expiration = None
                    user.save()
                    return Response({"status": "Password reset successful"}, status=status.HTTP_200_OK)
                else:
                    return Response({"error": "Invalid token "}, status=status.HTTP_400_BAD_REQUEST)
            except CustomUser.DoesNotExist:
                return Response({"error": "Invalid token"}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



# for changing users password
class ChangePasswordView(generics.UpdateAPIView):
    serializer_class = ChangePasswordSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user

    def update(self, request, *args, **kwargs):
        self.object = self.get_object()
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        # Set the new password
        self.object.set_password(serializer.validated_data['new_password'])
        self.object.save()

        return Response({"detail": "Password has been changed successfully."}, status=status.HTTP_200_OK)




# views for administrator

class UserListView(generics.ListCreateAPIView):
    queryset = CustomUser.objects.all().exclude(username='admin')
    serializer_class = CustomUserSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]




class UserDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = CustomUserSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]



class ChangePasswordUserView(generics.UpdateAPIView):
    queryset = CustomUser.objects.all()
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def put(self, request, *args, **kwargs):
        user = self.get_object()
        if not request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")

        form = SetPasswordForm(user, data=request.data)
        if form.is_valid():
            form.save()
            return Response({'status': 'password set'}, status=status.HTTP_200_OK)
        return Response(form.errors, status=status.HTTP_400_BAD_REQUEST)



class ListAdministratorsView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return CustomUser.objects.filter(is_administrator=True)


class ListAuthenticatorsView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return CustomUser.objects.filter(is_authenticator=True)



class ListSiteAdminsView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if not self.request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")
        return CustomUser.objects.filter(is_site_admin=True)


class RevokeRolesView(generics.UpdateAPIView):
    queryset = CustomUser.objects.all()
    permission_classes = [IsAuthenticated]

    def put(self, request, *args, **kwargs):
        user = self.get_object()
        if not request.user.is_administrator:
            raise PermissionDenied("You do not have permission to access this resource.")

        user.is_administrator = False
        user.is_authenticator = False
        user.is_site_admin = False
        user.save()
        return Response({'status': 'roles revoked'})



class FilterSettingsDetailView(generics.RetrieveUpdateAPIView):
    serializer_class = AuthenticatorFilterSettingsSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        try:
            return AuthenticatorFilterSettings.objects.get(user=self.request.user)
        except AuthenticatorFilterSettings.DoesNotExist:
            # Create a new filter settings instance if it doesn't exist
            return AuthenticatorFilterSettings.objects.create(user=self.request.user)

    def perform_update(self, serializer):
        instance = self.get_object()
        serializer.save(user=instance.user)




class AuthenticatorFilteredUserListView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if not user:
            raise PermissionDenied("You do not have permission to access this resource.")

        # Get filter settings for the user
        filter_settings = AuthenticatorFilterSettings.objects.get(user=user)

        # Apply filters based on the filter settings
        queryset = CustomUser.objects.filter(is_authenticator=True)

        if filter_settings.filter_org_type:
            queryset = queryset.filter(org_type=user.org_type)
        if filter_settings.filter_org_name:
            queryset = queryset.filter(org_name=user.org_name)
        if filter_settings.filter_org_sub_type:
            queryset = queryset.filter(org_sub_type=user.org_sub_type)
        if filter_settings.filter_location_type:
            queryset = queryset.filter(location_type=user.location_type)
        if filter_settings.filter_location_name:
            queryset = queryset.filter(location_name=user.location_name)
        if filter_settings.filter_department:
            queryset = queryset.filter(department=user.department)

        return queryset

# -------------------------------for Administrators dashboard related view--------------------

class OnlineUserCountView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            online_user = CustomUser.objects.filter(is_online=True).count()
            return Response({'active_user': online_user})
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class VerificationPendingCountView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            unverified_users = CustomUser.objects.filter(is_verified=False).count()
            return Response({'unverified_users': unverified_users})
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class TotalUserCountView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            total_user = CustomUser.objects.count()
            return Response({'total_user': total_user})
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AdministratorUserCountView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            administrator_user_count = UserRole.objects.filter(role__name='Administrator').count()
            return Response({'admin_user': administrator_user_count})
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AuthenticatorUserCountView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            authenticator_user_count = UserRole.objects.filter(role__name='Authenticator').count()
            return Response({'authenticator_user': authenticator_user_count})
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class SiteAdminUserCountView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            siteadmin_user_count = UserRole.objects.filter(role__name='Site Admin').count()
            return Response({'siteadmin_user': siteadmin_user_count})
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class UserCountViewByRoleApp(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            role_name = request.query_params.get('role_name', None)
            app_name = request.query_params.get('app_name', None)

            # Validate if both parameters are provided
            if not role_name or not app_name:
                return Response({
                    'error': 'Both role_name and app_name must be provided.'
                }, status=status.HTTP_400_BAD_REQUEST)

            # Querying the user count based on role and application name
            user_count_by_role = UserRole.objects.filter(
                role__name=role_name,
                application__name=app_name  # Assuming you have an application field
            ).count()

            # Returning the user count
            return Response({'user_count': user_count_by_role})

        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class SimilarDepartmentUsersView(generics.ListAPIView):
    serializer_class = CustomUserSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]


    def get_queryset(self):
        """
        This method returns a list of users who belong to the same department as the requesting user,
        excluding the requesting user themselves.
        """
        # Get the department of the logged-in user
        user_department = self.request.user.department

        # Filter users by department, excluding the requesting user
        queryset = CustomUser.objects.filter(department=user_department).exclude(id=self.request.user.id)

        return queryset