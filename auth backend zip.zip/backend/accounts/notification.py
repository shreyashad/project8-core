# cas/notifications.py (Example module within CAS app)
from django.utils import timezone
from notifications.models import Notification  # Assuming Notification model is defined in cas.models
from roles.models import *
from .models import CustomUser
def create_admin_notification(new_user, application):
    admin_role = Role.objects.get(name='Administrator')
    admin_users = UserRole.objects.filter(role=admin_role).select_related('user')
    for user_role in admin_users:
        admin_user = user_role.user
        Notification.objects.create(
            user=admin_user,
            application=application,
            title=f'New User Registration: {new_user.username}',
            message=f'A new user with username {new_user.username} has registered.',
            notification_type='info',  # Adjust notification type as needed
            created_at=timezone.now(),
            read=False
        )
