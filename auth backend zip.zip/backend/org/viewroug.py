from rest_framework import generics
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import OrgType, AuditLogEntry, ActionType
from .serializers import OrgTypeSerializer
from django.contrib.contenttypes.models import ContentType
from django.utils.timezone import now


class OrgTypeListView(generics.ListCreateAPIView):
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        # Perform the normal creation
        org_type = serializer.save()

        # Log the create action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(org_type.id),
            object_type=content_type,
            content_object=org_type,
            details=f"Created OrgType: {org_type.org_type}"
        )

    def list(self, request, *args, **kwargs):
        # List OrgTypes and log this action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of OrgTypes"
        )
        return super().list(request, *args, **kwargs)


class OrgTypeRetrieveView(generics.RetrieveAPIView):
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated]

    def retrieve(self, request, *args, **kwargs):
        # Log the 'READ' action for this specific OrgType retrieval
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched OrgType: {instance.org_type}"
        )
        return super().retrieve(request, *args, **kwargs)


class OrgTypeUpdateView(generics.RetrieveUpdateAPIView):
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        # Get the existing object before update
        instance = self.get_object()
        old_data = instance.org_type  # Store old data before update

        # Perform the update
        updated_org_type = serializer.save()

        # Log the 'UPDATE' action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(updated_org_type.id),
            object_type=content_type,
            content_object=updated_org_type,
            details=f"Updated OrgType: {old_data} to {updated_org_type.org_type}"
        )

    def update(self, request, *args, **kwargs):
        # Optionally, log when an update is requested
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Requested update for OrgType: {instance.org_type}"
        )
        return super().update(request, *args, **kwargs)



class OrgTypeDeleteView(generics.DestroyAPIView):
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated]

    def perform_destroy(self, instance):
        # Log the 'DELETE' action before the instance is deleted
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted OrgType: {instance.org_type}"
        )
        super().perform_destroy(instance)

    def destroy(self, request, *args, **kwargs):
        # Optionally log when a delete request is made
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Requested delete for OrgType: {instance.org_type}"
        )
        return super().destroy(request, *args, **kwargs)



from django.urls import path
from .views import OrgTypeListView, OrgTypeRetrieveView, OrgTypeUpdateView, OrgTypeDeleteView

urlpatterns = [
    path('orgtypes/', OrgTypeListView.as_view(), name='orgtype-list'),
    path('orgtypes/<int:pk>/', OrgTypeRetrieveView.as_view(), name='orgtype-retrieve'),
    path('orgtypes/<int:pk>/update/', OrgTypeUpdateView.as_view(), name='orgtype-update'),
    path('orgtypes/<int:pk>/delete/', OrgTypeDeleteView.as_view(), name='orgtype-delete'),
]
# def retrieve(self, request, *args, **kwargs):
#     # Log the 'READ' action for this specific OrgType retrieval
#     instance = self.get_object()
#     content_type = ContentType.objects.get_for_model(OrgType)
#     AuditLogEntry.objects.create(
#         user=self.request.user,
#         application=self.request.user.application,
#         action_type=ActionType.READ,
#         timestamp=now(),
#         object_id=str(instance.id),
#         object_type=content_type,
#         content_object=instance,
#         details=f"Fetched OrgType: {instance.org_type}"
#     )
#     return super().retrieve(request, *args, **kwargs)
#
# def update(self, request, *args, **kwargs):
#     # Optionally, log when an update is requested
#     instance = self.get_object()
#     content_type = ContentType.objects.get_for_model(OrgType)
#     AuditLogEntry.objects.create(
#         user=self.request.user,
#         application=self.request.user.application,
#         action_type=ActionType.READ,
#         timestamp=now(),
#         object_id=str(instance.id),
#         object_type=content_type,
#         content_object=instance,
#         details=f"Requested update for OrgType: {instance.org_type}"
#     )
#     return super().update(request, *args, **kwargs)
#
# def destroy(self, request, *args, **kwargs):
#     # Optionally log when a delete request is made
#     instance = self.get_object()
#     content_type = ContentType.objects.get_for_model(OrgType)
#     AuditLogEntry.objects.create(
#         user=self.request.user,
#         application=self.request.user.application,
#         action_type=ActionType.READ,
#         timestamp=now(),
#         object_id=str(instance.id),
#         object_type=content_type,
#         content_object=instance,
#         details=f"Requested delete for OrgType: {instance.org_type}"
#     )
#     return super().destroy(request, *args, **kwargs)
#
