from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from org.serializers import *
from org.models import *
from django.shortcuts import get_object_or_404
from rest_framework import status, generics, permissions
from django.db import IntegrityError



# Create your views here.

class OrganizationListView(APIView):
    def get(self, request):
        org = Organization.objects.all()
        serializer = OrganizationSerializer(org, many=True)
        return Response(serializer.data)


class OrganizationCreateView(generics.CreateAPIView):
    serializer_class = OrganizationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_application(self):
        return Application.objects.first()

    def perform_create(self, serializer):
        application = self.get_application()
        serializer.save(
            created_by=self.request.user,
            updated_by=self.request.user
        )
        log_action(self.request.user, application, 'create', 'Organization', serializer.instance.id)

    def post(self, request, *args, **kwargs):
        try:
            return super().post(request, *args, **kwargs)
        except IntegrityError as e:
            application = self.get_application()
            log_error(request.user, application, str(e), e.__traceback__)
            return Response(
                {
                    "error": True,
                    "message": "An organization with this name already exists.",
                },
                status=status.HTTP_400_BAD_REQUEST
            )

class OrganizationDetailView(APIView):
    serializer_class = OrganizationSerializer

    def get(self, request, pk):
        org = get_object_or_404(Organization, id=pk)
        serializer = self.serializer_class(org)
        return Response(serializer.data)

    def put(self, request, pk):
        org = get_object_or_404(Organization, id=pk)
        serializer = self.serializer_class(org, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        org = get_object_or_404(Organization, id=pk)
        org.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class OrgSubtypeListView(APIView):
    def get(self, request):
        org_subtype = OrganizationSubType.objects.all()
        serializer = OrgSubTypeSerializer(org_subtype, many=True)
        return Response(serializer.data)

class OrgSubtpeCreateView(APIView):
    serializer_class = OrgSubTypeSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                org_subtype_obj = serializer.save()
                return Response(
                    {
                        "error": False,
                        "message": "New Org-subtype is created",
                        "org_subtype": self.serializer_class(org_subtype_obj).data,
                    },
                    status=status.HTTP_201_CREATED
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An organization subtype with this name already exists.",
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                },
                status=status.HTTP_400_BAD_REQUEST
            )

class OrgSubtypeDetailView(APIView):
    serializer_class = OrgSubTypeSerializer

    def get(self, request, pk):
        subtype = get_object_or_404(OrganizationSubType, id=pk)
        serializer = self.serializer_class(subtype)
        return Response(serializer.data)

    def put(self, request, pk):
        subtype =  get_object_or_404(OrganizationSubType, id=pk)
        serializer = self.serializer_class(subtype, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save(updated_by=request.user.username)
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        subtype =  get_object_or_404(OrganizationSubType, id=pk)
        subtype.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)



class LocationsListView(APIView):
    def get(self, request):
        loc = Locations.objects.all()
        serializer = LocationsSerializer(loc, many=True)
        return Response(serializer.data)


class LocationsCreateView(APIView):
    serializer_class = LocationsSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                loc_obj = serializer.save(created_by=request.user, update_by=request.user)
                return Response(
                    {
                        "error": False,
                        "message": "New Locations is created",
                        "loc": self.serializer_class(loc_obj).data,
                    },
                    status=status.HTTP_201_CREATED
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An location with this name already exists.",
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                },
                status=status.HTTP_400_BAD_REQUEST
            )


class LocationsDetailView(APIView):
    serializer_class = LocationsSerializer

    def get(self, request, pk):
        loc = get_object_or_404(Locations, id=pk)
        serializer = self.serializer_class(loc)
        return Response(serializer.data)

    def put(self, request, pk):
        loc = get_object_or_404(Locations, id=pk)
        serializer = self.serializer_class(loc, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        loc = get_object_or_404(Locations, id=pk)
        loc.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class DesignationListView(APIView):
    def get(self, request):
        designation = Designation.objects.all()
        serializer = DesignationSerializer(designation, many=True)
        return Response(serializer.data)


class DesignationCreateView(APIView):
    serializer_class = DesignationSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                designation_obj = serializer.save(created_by=request.user)
                return Response(
                    {
                        "error": False,
                        "message": "New Designation is created",
                        "designation": self.serializer_class(designation_obj).data,
                    },
                    status=status.HTTP_201_CREATED
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An designation with this name already exists.",
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class DesignationDetailView(APIView):
    serializer_class = DesignationSerializer

    def get(self, request, pk):
        desg = get_object_or_404(Designation, id=pk)
        serializer = self.serializer_class(desg)
        return Response(serializer.data)

    def put(self, request, pk):
        desg = get_object_or_404(Designation, id=pk)
        serializer = self.serializer_class(desg, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        desg = get_object_or_404(Designation, id=pk)
        desg.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class DepartmentListView(APIView):
    def get(self, request):
        department = Department.objects.all()
        serializer = DepartmentSerializer(department, many=True)
        return Response(serializer.data)


class DepartmentCreateView(APIView):
    serializer_class = DepartmentSerializer

    def post(self, request, format=None):
        data = request.data
        serializer = self.serializer_class(data=data)
        if serializer.is_valid():
            try:
                dept_obj = serializer.save(created_by=request.user)
                return Response(
                    {
                        "error": False,
                        "message": "New Department is created",
                        "designation": self.serializer_class(dept_obj).data,
                    },
                    status=status.HTTP_201_CREATED
                )
            except IntegrityError:
                return Response(
                    {
                        "error": True,
                        "message": "An Department with this name already exists.",
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )
        else:
            return Response(
                {
                    "error": True,
                    "errors": serializer.errors,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class DepartmentDetailView(APIView):
    serializer_class = DepartmentSerializer

    def get(self, request, pk):
        dept = get_object_or_404(Department, id=pk)
        serializer = self.serializer_class(dept)
        return Response(serializer.data)

    def put(self, request, pk):
        dept = get_object_or_404(Department, id=pk)
        serializer = self.serializer_class(dept, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        dept = get_object_or_404(Department, id=pk)
        dept.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
--------
# views.py
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from .models import Organization, OrganizationSubType, Locations, Department, Designation
from .serializers import OrganizationSerializer, OrganizationSubTypeSerializer, LocationsSerializer, DepartmentSerializer, DesignationSerializer

class OrganizationListCreateAPIView(generics.ListCreateAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class OrganizationRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)

# Repeat for other models...

class OrganizationSubTypeListCreateAPIView(generics.ListCreateAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrganizationSubTypeSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user, updated_by=self.request.user)

class OrganizationSubTypeRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrganizationSubTypeSerializer
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        serializer.save(updated_by=self.request.user)

# Similar implementations for Locations, Department, and Designation
