from django.urls import path
from .views import *

urlpatterns = [
    # for organization type related
    path('orgtype-list/', OrgTypeListView.as_view(), name='orgtype'),
    path('create-orgtype/', OrgTypeCreateView.as_view(), name='create-orgtype'),
    path('orgtype/<uuid:pk>/details/', OrgTypeRetrieveView.as_view(), name='orgtype-details'),
    # for organization related
    path('organization-list/', OrganizationListView.as_view(), name='organization'),
    path('create-organization/', OrganizationCreateView.as_view(), name='organization-create'),
    path('organization/<uuid:pk>/details/', OrganizationRetrieveUpdateDestroyAPIView.as_view(), name='organization-details'),
    # for org-subtype related
    path('org-subtype-list/', OrganizationSubTypeListView.as_view(),
         name='org-subtype-list'),
    path('create-org-subtype/', OrganizationSubTypeCreateView.as_view(), name='org-subtype-create'),
    path('org-subtype/<uuid:pk>/details/', OrganizationSubTypeRetrieveUpdateDestroyAPIView.as_view(),
         name='org-subtype-details'),

    # # for location related
    # path('locations-list/', LocationsListCreateAPIView.as_view(), name='locations'),
    # path('locations/<uuid:pk>/details/', LocationsRetrieveUpdateDestroyAPIView.as_view(), name='locations-details'),
    # path('import-locations/', ExcelImportViewLocation.as_view(), name='import-location-data'),




#
#     # for designation related
#     path('designation-list/', DesignationListCreateAPIView.as_view(), name='designation'),
#     path('designation/<uuid:pk>/details/', DesignationRetrieveUpdateDestroyAPIView.as_view(), name='designation-details'),
# # for department related
#     path('department-list/', DepartmentListCreateAPIView.as_view(), name='department'),
#     path('department/<uuid:pk>/details/', DepartmentRetrieveUpdateDestroyAPIView.as_view(),
#          name='department-details'),
#
#     # for registration form related
#     path('departments/', DepartmentListAPIView.as_view(), name='departments'),
#     path('designations/', DesignationListAPIView.as_view(), name='designations'),
#     path('org-type-list/', OrgTypeListView.as_view(), name='org-type'),
#     path('org-name-list/', OrgNameList.as_view(), name='org-name-list'),
#     path('org-subtypes/', OrgSubTypeList.as_view(), name='org-subtype-list'),
#     path('location-type-list/', LocationTypeList.as_view(), name='location-type-list'),
#     path('location-name-list/', LocationNameList.as_view(), name='location-name-list'),
#     path('location-code-list/', LocationCodeList.as_view(), name='location-code-list'),

]