from .serializers import *
from rest_framework import generics,status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.contrib.contenttypes.models import ContentType
from audit.models import *
from django.utils.timezone import now

class OrgTypeListView(generics.ListAPIView):
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        application = Application.objects.get(name="Auth Server")
        # List OrgTypes and log this action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of OrgTypes"
        )
        return super().list(request, *args, **kwargs)


class OrgTypeCreateView(generics.CreateAPIView):
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        # Perform the normal creation
        org_type = serializer.save()
        application = Application.objects.get(name="Auth Server")
        # Log the create action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(org_type.id),
            object_type=content_type,
            content_object=org_type,
            details=f"Created OrgType: {org_type.org_type}"
        )

class OrgTypeRetrieveView(generics.RetrieveUpdateDestroyAPIView):
    queryset = OrgType.objects.all()
    serializer_class = OrgTypeSerializer
    permission_classes = [IsAuthenticated]

    def perform_retrieve(self, request, *args, **kwargs):
        application = Application.objects.get(name="Auth Server")
        # Log the 'READ' action for this specific OrgType retrieval
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched OrgType: {instance.org_type}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        # Perform the normal update
        org_type = serializer.save()

        application = Application.objects.get(name="Auth Server")
        # Log the update action
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(org_type.id),
            object_type=content_type,
            content_object=org_type,
            details=f"Updated OrgType: {org_type.org_type}"
        )

    def perform_destroy(self, instance):
        # Log the delete action
        application = Application.objects.get(name="Auth Server")
        content_type = ContentType.objects.get_for_model(OrgType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted OrgType: {instance.org_type}"
        )
        super().perform_destroy(instance)




class OrganizationListView(generics.ListAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        application = Application.objects.get(name="Auth Server")
        # List Organizations and log this action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of Organizations"
        )
        return super().list(request, *args, **kwargs)


class OrganizationCreateView(generics.CreateAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        # Perform the normal creation
        organization = serializer.save()

        application = Application.objects.get(name="Auth Server")
        # Log the create action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(organization.id),
            object_type=content_type,
            content_object=organization,
            details=f"Created Organization: {organization.org_name}"
        )


class OrganizationRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [IsAuthenticated]

    def perform_retrieve(self, request, *args, **kwargs):
        # Log the 'READ' action for this specific Organization retrieval
        instance = self.get_object()
        application = Application.objects.get(name="Auth Server")
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched Organization: {instance.org_name}"
        )
        return super().retrieve(request, *args, **kwargs)

    def perform_update(self, serializer):
        # Perform the normal update
        organization = serializer.save()
        application = Application.objects.get(name="Auth Server")
        # Log the update action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(organization.id),
            object_type=content_type,
            content_object=organization,
            details=f"Updated Organization: {organization.org_name}"
        )

    def perform_destroy(self, instance):
        application = Application.objects.get(name="Auth Server")
        # Log the delete action
        content_type = ContentType.objects.get_for_model(Organization)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=application,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted Organization: {instance.org_name}"
        )
        super().perform_destroy(instance)


class OrganizationSubTypeListView(generics.ListAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        # List OrganizationSubTypes and log this action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_type=content_type,
            details="Fetched list of OrganizationSubTypes"
        )
        return super().list(request, *args, **kwargs)


class OrganizationSubTypeCreateView(generics.CreateAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        # Perform the normal creation
        organization_subtype = serializer.save()

        # Log the create action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,  # Assuming the user has an application field
            action_type=ActionType.CREATE,
            timestamp=now(),
            object_id=str(organization_subtype.id),
            object_type=content_type,
            content_object=organization_subtype,
            details=f"Created OrganizationSubType: {organization_subtype.org_sub_type}"
        )


class OrganizationSubTypeRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = OrganizationSubType.objects.all()
    serializer_class = OrgSubTypeSerializer
    permission_classes = [IsAuthenticated]

    def perform_retrieve(self, request, *args, **kwargs):
        # Log the 'READ' action for this specific OrganizationSubType retrieval
        instance = self.get_object()
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,
            action_type=ActionType.READ,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Fetched OrganizationSubType: {instance.org_sub_type}"
        )
        return super().retrieve(request, *args, **kwargs)


    def perform_update(self, serializer):
        # Perform the normal update
        organization_subtype = serializer.save()

        # Log the update action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,  # Assuming the user has an application field
            action_type=ActionType.UPDATE,
            timestamp=now(),
            object_id=str(organization_subtype.id),
            object_type=content_type,
            content_object=organization_subtype,
            details=f"Updated OrganizationSubType: {organization_subtype.org_sub_type}"
        )

    def perform_destroy(self, instance):
        # Log the delete action
        content_type = ContentType.objects.get_for_model(OrganizationSubType)
        AuditLogEntry.objects.create(
            user=self.request.user,
            application=self.request.user.application,  # Assuming the user has an application field
            action_type=ActionType.DELETE,
            timestamp=now(),
            object_id=str(instance.id),
            object_type=content_type,
            content_object=instance,
            details=f"Deleted OrganizationSubType: {instance.org_sub_type}"
        )
        super().perform_destroy(instance)

