from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from .models import *
from .serializers import *
from rest_framework.response import Response
from rest_framework import status
from rest_framework.exceptions import ValidationError
# Create your views here.

# View for listing all teams
class AllTeamListView(generics.ListAPIView):
    """
    to get all the teams that are been created
    """
    queryset = Team.objects.all()
    serializer_class = TeamSerializerList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]




class TeamListByUserView(generics.ListAPIView):
    """
    to get all teams that are related to requested user
    """
    serializer_class = TeamSerializerList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]


    def get_queryset(self):
        # Get the current authenticated user
        user = self.request.user

        # Filter teams that the user is a member of via TeamMembership
        return Team.objects.filter(users=user)




class TeamListByRoleView(generics.ListAPIView):
    """
    List Teams filtered by the role of the logged-in user in the team.
    """

    serializer_class = TeamSerializerList
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user  # Get the logged-in user
        role = self.request.query_params.get('role', None)  # Get the role from query params

        # Check if the role is provided in the request, if not, default to showing all teams the user is part of
        if role not in ['Leader', 'Member']:
            return Team.objects.none()  # If the role is invalid or not provided, return an empty queryset

        # Filter teams based on the user’s role in that team
        return Team.objects.filter(
            teammembership__user=user,
            teammembership__role=role
        ).distinct()

    def list(self, request, *args, **kwargs):
        """
        Overriding the list method to return a filtered list of teams
        based on the user's role.
        """
        return super().list(request, *args, **kwargs)


class TeamCreateView(generics.CreateAPIView):
    """
     API view to create a new team. The view ensures that:
    1. The team is created with the authenticated user as the 'created_by' field.
    2. The authenticated user is automatically added as a 'Leader' to the team in the TeamMembership model.
    3. The 'created_by' and 'updated_by' fields are populated with the authenticated user, linking the team to the user who created and last updated it.

    On successful creation, the view:
    - Creates a new Team instance.
    - Adds the authenticated user as the first member of the team with the role 'Leader'.
    - Handles errors gracefully by raising a ValidationError if there is an issue during the membership creation.

    The `CreateAPIView` class handles the creation of a Team object using the `TeamSerializer`.
    """
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        """
        Override the default perform_create method to:
        1. Save the team instance with the 'created_by' field set to the authenticated user.
        2. Automatically add the authenticated user as a 'Leader' to the team in the TeamMembership model.
        """
        # Save the team instance, associating the creator with the `created_by` field
        team = serializer.save(created_by=self.request.user)

        # After creating the team, automatically add the creator as a member with the role of 'Leader'
        try:
            # Create the TeamMembership for the user
            TeamMembership.objects.create(
                team=team,
                user=self.request.user,
                role='Leader',  # Role is automatically assigned as 'Leader' for the creator
            )
        except Exception as e:
            # Handle any errors that might occur during membership creation
            raise ValidationError(f"Error creating team membership: {str(e)}")




# View for retrieving a single team
class TeamDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Team.objects.all()
    serializer_class = TeamSerializer
    permission_classes = [IsAuthenticated]

# View for creating a new team

# # View for updating an existing team
# class TeamUpdateView(generics.UpdateAPIView):
#     queryset = Team.objects.all()
#     serializer_class = TeamSerializer
#     permission_classes = [IsAuthenticated]
#
#     def perform_update(self, serializer):
#         # Optionally, track who updated the team
#         serializer.save(updated_by=self.request.user)
#
# # View for deleting a team
# class TeamDeleteView(generics.DestroyAPIView):
#     queryset = Team.objects.all()
#     serializer_class = TeamSerializer
#     permission_classes = [IsAuthenticated]
#
#     def perform_destroy(self, instance):
#         # Optionally, you could log who deleted the team or handle related logic
#         instance.delete()
